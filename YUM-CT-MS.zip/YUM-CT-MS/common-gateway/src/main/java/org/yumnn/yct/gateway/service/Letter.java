package org.yumnn.yct.gateway.service;


/**
 *
 * @author Christian Alvarez
 * @department PMU - MIS
 * @owner UNICEF
 * @class_name Letter.java
 * @class_description
 * @create_date Apr 24, 2019
 * @last_Update Apr 24, 2019
 */
public class Letter {

    /*
     * instance variables
     */

    private int number;
    private char character;

    /*
     * instance methods
     */

    /**
     * Constructor
     *
     * @param character
     */
    public Letter(char character) {
        super();
        this.character = character;
    }

    /**
     * Constructor
     *
     * @param number
     * @param character
     */
    public Letter(int number, char character) {
        super();
        this.number = number;
        this.character = character;
    }

    /**
     * @return the number
     */
    public int getNumber() {
        return number;
    }

    /**
     * @param number the number to set
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * @return the character
     */
    public char getCharacter() {
        return character;
    }

    /**
     * @param character the character to set
     */
    public void setCharacter(char character) {
        this.character = character;
    }

    /**
     * @return String
     */
    @Override
    public String toString() {
        return "Letter [number=" + number + ", character=" + character + "]";
    }

    /**
     * @return hashcode
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + character;
        return result;
    }

    /**
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Letter other = (Letter) obj;
        if (character != other.character)
            return false;
        return true;
    }

}
