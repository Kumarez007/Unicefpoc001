package org.yumnn.yct.gateway.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.administration.User;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Repository
@Transactional
public interface UserRepository extends JpaRepository<User, Long> {

  User findByUsername(String username);

  User findByUsernameAndPassword(String username, String password);

  Optional<User> findById(Long id);

  User findByIdAndUniqueUserSignature(Long id, String uniqueUserSignature);

  User findByUniqueUserSignature(String uniqueUserSignature);
  
  User findBySessionToken(String sessionToken);
}
