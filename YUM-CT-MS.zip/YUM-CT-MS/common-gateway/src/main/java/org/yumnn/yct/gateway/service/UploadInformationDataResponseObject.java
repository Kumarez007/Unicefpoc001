package org.yumnn.yct.gateway.service;

import org.yumnn.yct.common.enumeration.uploadInfo.UploadInformationCodesEnum;
import org.yumnn.yct.common.json.ParentResponseObject;

import java.io.Serializable;

public class UploadInformationDataResponseObject extends ParentResponseObject implements Serializable {
    private static final long serialVersionUID = 1L;

    public UploadInformationDataResponseObject(Boolean success, UploadInformationCodesEnum uploadInformationCodesEnum) {
        super(success, uploadInformationCodesEnum.getValue());
    }

    public UploadInformationDataResponseObject() {
    }

}
