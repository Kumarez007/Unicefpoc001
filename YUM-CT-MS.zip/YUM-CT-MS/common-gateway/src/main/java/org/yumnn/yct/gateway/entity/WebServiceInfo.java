/*
 * Copyright 2018 UNICEF PMU.
 *
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 *
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.gateway.entity;


import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name WebServiceModule.java
 * @class_description
 * @create_date Aug 13, 2019
 * @last_Update Aug 13, 2019
 */
@Entity
@Table(name = "user_access.adm_web_service_info")
public class WebServiceInfo extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "name")
    private String name;

    @ManyToOne
    @JoinColumn(name = "updated_by", referencedColumnName = "ID")
    private User updatedBy;

    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    @ManyToOne
    @JoinColumn(name = "id_ws_module_fk", referencedColumnName = "ID")
    private WebServiceModule webServiceModule;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the updatedBy
     */
    public User getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(User updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the updated_date
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updated_date
     *            the updated_date to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the webServiceModule
     */
    public WebServiceModule getWebServiceModule() {
        return webServiceModule;
    }

    /**
     * @param webServiceModule
     *            the webServiceModule to set
     */
    public void setWebServiceModule(WebServiceModule webServiceModule) {
        this.webServiceModule = webServiceModule;
    }
}
