package org.yumnn.yct.gateway;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import javax.security.sasl.AuthenticationException;
import javax.xml.ws.WebServiceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.RequestPath;
import org.springframework.stereotype.Component;
import org.yumnn.yct.common.entity.catalog.Quarter;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.uploadInfo.UploadInformationCodesEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.Constants;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.gateway.entity.WebServiceTokenByQuarter;
import org.yumnn.yct.gateway.repository.QuarterRepository;
import org.yumnn.yct.gateway.repository.WebServiceTokenByQuarterRepository;
import org.yumnn.yct.gateway.service.BlockEncrypterDecrypter;


@Component
public class AuthenticationValidator {

    @Autowired
    private QuarterRepository quarterRepository;

    @Autowired
    private WebServiceTokenByQuarterRepository webServiceTokenByQuarterRepository;


    @Autowired
    private  BlockEncrypterDecrypter blockEncrypterDecrypter;

    public void validate(List<String> authorizationHeader, RequestPath requestPath) throws IOException {

        if (authorizationHeader == null || !authorizationHeader.get(0).startsWith(Constants.BEARER_AUTHENTICATION_PREFIX)) {

            throw new AuthenticationException(UploadInformationCodesEnum.INVALID_TOKEN.toString());
        }

        String sentToken = authorizationHeader.get(0).substring(Constants.BEARER_AUTHENTICATION_PREFIX.length()).trim();
        String serviceName = getWebServiceName(requestPath);

        
        try {
            if (!validateToken(sentToken, serviceName)) {
                throw new AuthenticationException(UploadInformationCodesEnum.INVALID_TOKEN.toString());

            }
        } catch ( FailProcessException e) {
            throw new WebServiceException(HttpStatus.INTERNAL_SERVER_ERROR.toString());
        }

    }

    private String getWebServiceName( RequestPath requestPath) {
        return Paths.get(requestPath.toString()).getFileName().toString();
    }

    /**
     *
     * @author Reem Issa
     * @date Aug 12, 2019
     * @description_method
     * @param token
     * @throws NamingException
     * @throws FailProcessException
     */
    public Boolean validateToken(String token, String serviceName) throws  FailProcessException {
        String systemToken = null;
        WebServiceTokenByQuarter webServiceTokenByQuarter = null;
        Quarter activeQuarter = quarterRepository.findByIsActive(YesNoEnum.YES);
        webServiceTokenByQuarter = webServiceTokenByQuarterRepository.getByWebServiceAndQuarter(activeQuarter,
        		serviceName);
        if(webServiceTokenByQuarter == null) {
        	return Boolean.FALSE;
        }

        systemToken = webServiceTokenByQuarter.getGeneratedToken();
        String decryptedSystemToken = blockEncrypterDecrypter.decrypt(systemToken);

        if (Utilities.isNULLOrEmpty(systemToken)) {
            return Boolean.FALSE;
        }

        if (!token.equals(decryptedSystemToken)) {
            return Boolean.FALSE;
        }

        return Boolean.TRUE;

    }
}