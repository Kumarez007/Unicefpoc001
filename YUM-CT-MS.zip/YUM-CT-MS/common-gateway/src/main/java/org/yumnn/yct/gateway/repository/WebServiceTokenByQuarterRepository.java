package org.yumnn.yct.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.yumnn.yct.common.entity.catalog.Quarter;
import org.yumnn.yct.gateway.entity.WebServiceTokenByQuarter;

public interface WebServiceTokenByQuarterRepository extends JpaRepository<WebServiceTokenByQuarter, Long> {

@Query("SELECT t FROM WebServiceTokenByQuarter t WHERE t.currentQuarter = :currentQuarter and t.webServiceInfo.name = :serviceName ")
    public WebServiceTokenByQuarter getByWebServiceAndQuarter(Quarter currentQuarter, String serviceName);
}
