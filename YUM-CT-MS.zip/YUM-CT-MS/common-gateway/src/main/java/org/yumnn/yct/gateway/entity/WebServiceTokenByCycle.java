package org.yumnn.yct.gateway.entity;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.cycle.Cycle;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "user_access.adm_ws_token_by_cycle")
public class WebServiceTokenByCycle extends BaseEntity implements Serializable {


    private static final long serialVersionUID = 1L;

    @ManyToOne
    @JoinColumn(name = "id_ws_info_fk", referencedColumnName = "ID")
    private WebServiceInfo webServiceInfo;

    @ManyToOne
    @JoinColumn(name = "id_cycle_fk", referencedColumnName = "ID")
    private Cycle cycle;

    @Column(name = "generated_token")
    private String generatedToken;

    @ManyToOne
    @JoinColumn(name = "updated_by", referencedColumnName = "ID")
    private User updatedBy;

    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    /**
     * @return the webServiceInfo
     */
    public WebServiceInfo getWebServiceInfo() {
        return webServiceInfo;
    }

    /**
     * @param webServiceInfo the webServiceInfo to set
     */
    public void setWebServiceInfo(WebServiceInfo webServiceInfo) {
        this.webServiceInfo = webServiceInfo;
    }

    /**
     * @return the cycle
     */
    public Cycle getCycle() {
        return cycle;
    }

    /**
     * @param cycle the cycle to set
     */
    public void setCycle(Cycle cycle) {
        this.cycle = cycle;
    }

    /**
     * @return the generatedToken
     */
    public String getGeneratedToken() {
        return generatedToken;
    }

    /**
     * @param generatedToken the generatedToken to set
     */
    public void setGeneratedToken(String generatedToken) {
        this.generatedToken = generatedToken;
    }

    /**
     * @return the updatedBy
     */
    public User getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(User updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }


}
