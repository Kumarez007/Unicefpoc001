package org.yumnn.yct.gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfiguration {
	
	@Autowired
	private GatewayRoutesConfiguration gatewayRoutesConfiguration;

	@Bean
	RouteLocator gatewayRouter(RouteLocatorBuilder builder) {

		return gatewayRoutesConfiguration.generateRoutesByProject(builder);
	}
}
