package org.yumnn.yct.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.yumnn.yct.common.entity.administration.ProjectParameter;


public interface ProjectParameterRepository extends JpaRepository<ProjectParameter, Long> {

    @Query("select p from ProjectParameter p where p.name = :name")
    public ProjectParameter findProjectParameterByParemeterName(String name);
}

