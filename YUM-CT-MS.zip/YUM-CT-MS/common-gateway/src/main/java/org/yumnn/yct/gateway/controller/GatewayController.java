/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Apr 27, 2021 6:36:13 PM
 */
package org.yumnn.yct.gateway.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Apr 27, 2021 6:36:13 PM
 */
@RestController
public class GatewayController {
	@RequestMapping("/")
	public String checkGatewayLiveness() throws Exception {

		return "<div style='position: fixed;color:#009999;width:800px; margin:0 auto;'>"
				+ "<h1>"
				+ "API gateway is running... &#128512; <br> <br>"
				+ "Try Some Backend Services Endpoints To Route."
				+ "</h1>"
				+ "</div>";
	}
}
