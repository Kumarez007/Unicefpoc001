package org.yumnn.yct.gateway.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.gateway.enumeration.EncryptionKeysEnum;

/**
 *
 * @author Christian Alvarez
 * @department PMU - MIS
 * @owner UNICEF
 * @class_name BlockEncrypterDecrypter.java
 * @class_description
 * @create_date Apr 24, 2019
 * @last_Update Apr 24, 2019
 */

@Component
public class BlockEncrypterDecrypter {

    public static Logger LOG = LoggerFactory.getLogger(BlockEncrypterDecrypter.class);


    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method this method encrypts a string and returns the encrypted
     *                     result
     * @param message
     * @return encrypted message
     */
    public String encrypt(String message) throws FailProcessException {

        String encryptedMessage = null;

        try {

            String key = EncryptionKeysEnum.MIN_2018.getValue();
            AlgorithmData algorithmData = new AlgorithmData(key);
            encryptedMessage = algorithmData.encrypt(message);

        } catch (Exception e) {
            LOG.error("... BlockEncrypterDecrypter : encrypt issue " + Utilities.convertStacktraceErrorToString(e));
            throw new FailProcessException();
        }
        return encryptedMessage;

    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method this method decrypts a string and returns the decrypted
     *                     result
     * @param message
     * @return decrypted message
     */
    public String decrypt(String message) throws FailProcessException {

        String decryptedMessage = null;

        try {

            String key = EncryptionKeysEnum.MIN_2018.getValue();
            AlgorithmData algorithmData = new AlgorithmData(key);
            decryptedMessage = algorithmData.decrypt(message);
        } catch (Exception e) {
            LOG.error("... BlockEncrypterDecrypter : decrypt issue " + Utilities.convertStacktraceErrorToString(e));
            throw new FailProcessException();
        }
        return decryptedMessage;
    }

}
