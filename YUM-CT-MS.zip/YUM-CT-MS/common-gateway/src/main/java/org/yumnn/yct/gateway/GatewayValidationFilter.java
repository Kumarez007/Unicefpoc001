package org.yumnn.yct.gateway;


import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.uploadInfo.UploadInformationCodesEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.ErrorResponse;
import org.yumnn.yct.common.util.PaymentErrorResponse;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.gateway.repository.UserRepository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono; 
/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */



@Component
public class GatewayValidationFilter implements GlobalFilter {

 @Autowired
 UserRepository userRepository;

@Autowired
private AuthenticationValidator authenticationValidator;

  private static Logger logger = LoggerFactory.getLogger(GatewayValidationFilter.class);
  static final String baseUri = "/yct/api/v1/";
  String apiUrl=null;
  
	@Value("${mis-base-url-ws}")        
	private String misBaseUrlWs; 

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
      ServerHttpRequest request = exchange.getRequest();

  	apiUrl = request.getURI().toString();
    

  	logger.info("GatewayFilter: "+apiUrl);

  	try {
      	 if(apiUrl.contains(baseUri+"authcontrol/login") || apiUrl.contains(baseUri+"authcontrol/logout")) {

      		return chain.filter(exchange); //forward to route

      	 }
      	 else if (apiUrl.contains(baseUri) && request.getHeaders().get("sessiontoken")!=null) {

      		User user=userRepository.findBySessionToken(request.getHeaders().get("sessiontoken").get(0));

      		if(user==null) {

      			logger.info("GatewayValidationFilter: Invalid Token.");
      			
      			return this.gatewayAuthError(exchange, ConstantsUtil.STATUS_CODE_UNAUTHORIZED, "Invalid Token");

      		}
      		else if (!user.getIsActive().equals(YesNoEnum.YES)) {

      			logger.info("GatewayValidationFilter: Inactive User");
      			return this.gatewayAuthError(exchange, ConstantsUtil.STATUS_CODE_UNAUTHORIZED, "Inactive User");
      		}
      		else {

      			return chain.filter(exchange); //forward to route

      		}
      	 }else if(request.getHeaders().get("internalCall")!=null) {
      		return enableUserSession(exchange, chain);
      	 }
      	else if(request.getHeaders().get("invalidProject")!=null) {
  			return this.gatewayInvalidPathError(exchange);

      	 }
      	 else {
					 	
      			try {
					logger.info("Request received 1 " + exchange.getRequest().getPath());

					if (!exchange.getRequest().getPath().toString().contains(misBaseUrlWs)) {
						authenticationValidator.validate(
								exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION),
								exchange.getRequest().getPath());
					}
					logger.info("Request received 2 " + exchange.getRequest().getPath());
					return chain.filter(exchange);
      			} catch (IOException e) {
      				logger.info("GatewayValidationFilter: Gateway Authentication Failed!");
      				return this.gatewayAuthError(exchange, ConstantsUtil.STATUS_CODE_UNAUTHORIZED, "Gateway Authentication Failed");
				}
      	 	}
  		}
  		catch(Exception e) {
  			logger.error("Error In Gateway",e);
  		}
	return null;
      	 
  	}
 
  /**
   * 
   * @author WQ
   * @date Jun 6, 2021
   * @description_method 
   * @param request
   */
  private Mono<Void> enableUserSession(ServerWebExchange exchange,GatewayFilterChain chain) {
	  User user=userRepository.findByUsername("system");
	  if(!Utilities.isNULL(user) && !Utilities.isNULL(user.getSessionToken())) {
		  return chain.filter(
				  exchange.mutate().request(
						  exchange.getRequest().mutate()
						  .header("sessiontoken", user.getSessionToken()).header("userid", user.getId()+"")
						  .build())
				  .build());
	  }
	  return null;
  } 
  
  private Mono<Void> gatewayAuthError(ServerWebExchange exchange,Integer statusCode,String message) throws JsonProcessingException {
	  exchange.getResponse().getHeaders().add("Content-Type", "application/json");
      exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

      DataBuffer responseBodyBuffer = exchange.getResponse()
    		  .bufferFactory()
    		  .wrap(new ObjectMapper()
    				  .writeValueAsBytes(new ErrorResponse(statusCode,message,"API Gateway Authorization")));
      
      return exchange.getResponse().writeWith(Mono.just(responseBodyBuffer));

  } 
  
  private Mono<Void> gatewayInvalidPathError(ServerWebExchange exchange) throws JsonProcessingException {
	  exchange.getResponse().getHeaders().add("Content-Type", "application/json");
      exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);

  	PaymentErrorResponse paymentErrorResponse = new PaymentErrorResponse();
	paymentErrorResponse.setStatus(ConstantsUtil.ERROR_MESSAGE);
	paymentErrorResponse.setErrorCode(UploadInformationCodesEnum.NULL_INVALID_PROJECT_NAME.getValue());
	paymentErrorResponse.setMessageDetails(UploadInformationCodesEnum.NULL_INVALID_PROJECT_NAME.name());

	
      DataBuffer responseBodyBuffer = exchange.getResponse()
    		  .bufferFactory()
    		  .wrap(new ObjectMapper()
    				  .writeValueAsBytes(paymentErrorResponse));
      
      return exchange.getResponse().writeWith(Mono.just(responseBodyBuffer));

  } 
  
}
