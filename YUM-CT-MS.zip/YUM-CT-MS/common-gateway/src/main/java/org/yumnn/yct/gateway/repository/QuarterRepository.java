package org.yumnn.yct.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Quarter;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name QuarterRepository.java
 * @class_description 
 * @create_date Oct 3, 2021
 * @last_Update Oct 3, 2021
 */
@Repository
public interface QuarterRepository extends JpaRepository<Quarter, Long> {
	
	Quarter findByShortName(String shortName) throws FailProcessException;
	Quarter findByIsActive(YesNoEnum isActive) throws FailProcessException;
}
