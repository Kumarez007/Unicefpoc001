/*
 * Copyright 2018 UNICEF PMU.
 *
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 *
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package  org.yumnn.yct.gateway.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Christian Alvarez
 * @department PMU - MIS
 * @owner UNICEF
 * @class_name AlgorithmData.java
 * @class_description
 * @create_date Apr 24, 2019
 * @last_Update Apr 24, 2019
 */

public class AlgorithmData {

    List<Integer> primeNumberList;
    List<Letter> dictionary;
    Integer[] spaceNumbers;
    int keyNumber;
    String key;

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method initialize all the data necessary for the algorithm to
     *                     work correctly
     * @param key
     * @return spaceNumbers
     */
    public AlgorithmData(String key) {
        this.key = key;
        dictionary = new ArrayList<>();
        primeNumberList = new ArrayList<>();
        initLetterDictionary();
        initKeyNumber(key);

    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method default constructor
     * @param key
     * @return spaceNumbers
     */
    protected AlgorithmData() {

        // no implementation needed , added for JBOSS deployment.

    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method initKeyNumber
     * @param key
     */
    private void initKeyNumber(String key) {
        List<Integer> keyNumbers = getNumbersFromDictionary(key);
        int total = 0;
        for (Integer number : keyNumbers) {
            total = total + number;
        }
        keyNumber = total % key.length();
        calculateSpaceNumbers(total);
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method calculateSpaceNumbers
     * @param total
     */
    private void calculateSpaceNumbers(int total) {
        spaceNumbers = new Integer[keyNumber];
        Integer calculation = total / keyNumber;
        List<Integer> filledNumberList = new ArrayList<>();
        filledNumberList = fillSpaceNumbers(calculation, filledNumberList, 0);
        int counter = 0;
        for (int i = 0; i < spaceNumbers.length; i++) {
            spaceNumbers[i] = filledNumberList.get(counter);
            counter++;
            if (counter == filledNumberList.size()) {
                counter = 0;
            }

        }
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method fillSpaceNumbers
     * @param calculation
     * @param spaceNumbers2
     * @param index
     *
     * @return list of integers
     */
    private List<Integer> fillSpaceNumbers(Integer calculation, List<Integer> spaceNumbers2, int index) {

        if (calculation != 0) {
            int value = calculation % 10;
            if (value < 3) {
                value = 5 - value;
            }
            spaceNumbers2.add(value);
            calculation = calculation / 10;
            index++;
            fillSpaceNumbers(calculation, spaceNumbers2, index);
        }
        return spaceNumbers2;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method encodes a string message into numbers using the
     *                     dictionary and the algorithm
     * @param message
     *
     * @return encrypted message
     */
    public String encrypt(String message) {
        List<Integer> numberList = getNumbersFromDictionary(message);

        return encodeMessage(numberList);

    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method encodeMessage
     * @param numberList
     *
     * @return encrypted message
     */
    private String encodeMessage(List<Integer> numberList) {
        if (numberList.size() % 2 != 0) {
            numberList.add(null);
        }
        List<Integer> encodedNumbers = prepareMatrix(numberList);
        String message = convertToString(encodedNumbers);
        return message;

    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method prepareMatrix
     * @param numberList
     *
     * @return list of integers
     */
    private List<Integer> prepareMatrix(List<Integer> numberList) {
        List<Integer> encodedMessage = new ArrayList<>();
        int columns = numberList.size() / 2;
        for (int i = 0; i < columns; i++) {
            encodedMessage.add(numberList.get(i));
            encodedMessage.add(numberList.get(i + columns));
        }
        return encodedMessage;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method convertToString
     * @param encodedMessage
     *
     * @return encoded string
     */
    private String convertToString(List<Integer> encodedMessage) {
        String message = "";
        int spaceNumber = 0;
        int spaceNumbersSize = spaceNumbers.length;
        for (Integer integer : encodedMessage) {
            if (spaceNumber == spaceNumbersSize) {
                spaceNumber = 0;
            }
            String zeros = getAmoutOfZeros(spaceNumbers[spaceNumber]);
            if (integer != null) {
                String convertedNumber = (zeros + integer.toString()).substring(integer.toString().length());
                message = message + convertedNumber;
                spaceNumber++;
            }
        }

        return message;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method getAmoutOfZeros
     * @param spaceNumber
     *
     * @return amount of zeros string
     */
    private String getAmoutOfZeros(int spaceNumber) {
        String zeros = "";
        for (int i = 0; i < spaceNumber; i++) {
            zeros = zeros + "0";
        }
        return zeros;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method getNumbersFromDictionary
     * @param message
     *
     * @return list of integers
     */
    private List<Integer> getNumbersFromDictionary(String message) {
        int messageSize = message.length();
        List<Integer> numbersFromDictionary = new ArrayList<>();
        for (int i = 0; i < messageSize; i++) {
            Letter letter = new Letter(message.charAt(i));
            int index = dictionary.indexOf(letter);
            numbersFromDictionary.add(dictionary.get(index).getNumber() + keyNumber);
        }
        return numbersFromDictionary;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method method which receives numbers and decodes it into a
     *                     readable message
     * @param numbers
     *
     * @return decoded message
     */
    public String decrypt(String numbers) {

        String decodedMessage = "";
        List<Integer> numbersList = new ArrayList<>();
        int spaceNumber = -1;
        int spaceNumbersSize = spaceNumbers.length;
        numbersList = getNumberList(numbers, numbersList, spaceNumber, spaceNumbersSize);
        List<Integer> orderedList = getOriginalMatrix(numbersList);

        decodedMessage = convertNumbersToMessage(decodedMessage, orderedList);
        return decodedMessage;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method convertNumbersToMessage
     * @param decodedMessage
     * @param orderedList
     *
     * @return decoded numbers
     */
    private String convertNumbersToMessage(String decodedMessage, List<Integer> orderedList) {
        for (Integer number : orderedList) {
            for (Letter letter : dictionary) {
                if (isNumberInDictionary(number, letter)) {
                    decodedMessage = decodedMessage + letter.getCharacter();
                }
            }

        }
        return decodedMessage;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method isNumberInDictionary
     * @param number
     * @param letter
     *
     * @return boolean
     */
    private boolean isNumberInDictionary(Integer number, Letter letter) {
        return number != null && number == letter.getNumber();
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method getOriginalMatrix
     * @param numbersList
     *
     * @return list of integers
     */
    private List<Integer> getOriginalMatrix(List<Integer> numbersList) {
        int size = numbersList.size();
        List<Integer> orderedList = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            orderedList.add(null);
        }
        int columns = numbersList.size() / 2;
        int index = 0;
        for (int i = 0; i < size; i = i + 2) {
            orderedList.set(index, numbersList.get(i));
            orderedList.set(index + columns, numbersList.get(i + 1));
            index++;
        }

        return orderedList;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method getNumberList
     * @param numbers
     * @param numbersList
     * @param spaceNumber
     *
     * @return list of integers
     */
    private List<Integer> getNumberList(String numbers, List<Integer> numbersList, int spaceNumber,
                                        int spaceNumbersSize) {
        int size = numbers.length();
        if (size > 1) {
            if (spaceNumber == (spaceNumbersSize - 1)) {
                spaceNumber = -1;
            }
            spaceNumber++;
            String editedNumber = numbers.substring(0, spaceNumbers[spaceNumber]);
            Integer number = Integer.parseInt(editedNumber);
            numbersList.add(number - keyNumber);

            getNumberList(numbers.substring(spaceNumbers[spaceNumber], size), numbersList, spaceNumber,
                    spaceNumbersSize);

        }
        if (numbersList.size() % 2 != 0) {
            numbersList.add(null);
        }
        return numbersList;
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method initLetterDictionary
     *
     */
    private void initLetterDictionary() {
        char character = 'A';
        AddBlankSpace();
        fillPrimeNumbers();
        for (int i = 1; i <= 58; i++) {
            Letter letter = new Letter(primeNumberList.get(i), character);
            dictionary.add(letter);
            character++;
        }
        addSpecialCharacters();
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method addSpecialCharacters
     *
     */
    private void addSpecialCharacters() {
        Letter letter1 = new Letter(primeNumberList.get(59), '.');
        dictionary.add(letter1);
        Letter letter2 = new Letter(primeNumberList.get(60), '?');
        dictionary.add(letter2);
        Letter letter3 = new Letter(primeNumberList.get(61), ',');
        dictionary.add(letter3);
        Letter letter4 = new Letter(primeNumberList.get(62), '!');
        dictionary.add(letter4);
        Letter letter5 = new Letter(primeNumberList.get(63), '-');
        dictionary.add(letter5);
        Letter letter6 = new Letter(primeNumberList.get(64), '"');
        dictionary.add(letter6);
        Letter letter7 = new Letter(primeNumberList.get(65), '\'');
        dictionary.add(letter7);
        Letter letter8 = new Letter(primeNumberList.get(66), 'á');
        dictionary.add(letter8);
        Letter letter9 = new Letter(primeNumberList.get(67), 'é');
        dictionary.add(letter9);
        Letter letter10 = new Letter(primeNumberList.get(68), 'í');
        dictionary.add(letter10);
        Letter letter11 = new Letter(primeNumberList.get(69), 'ó');
        dictionary.add(letter11);
        Letter letter12 = new Letter(primeNumberList.get(70), 'ú');
        dictionary.add(letter12);
        Letter letter13 = new Letter(primeNumberList.get(71), 'Á');
        dictionary.add(letter13);
        Letter letter14 = new Letter(primeNumberList.get(72), 'É');
        dictionary.add(letter14);
        Letter letter15 = new Letter(primeNumberList.get(73), 'Í');
        dictionary.add(letter15);
        Letter letter16 = new Letter(primeNumberList.get(74), 'Ó');
        dictionary.add(letter16);
        Letter letter17 = new Letter(primeNumberList.get(75), 'Ú');
        dictionary.add(letter17);
        Letter letter18 = new Letter(primeNumberList.get(76), '(');
        dictionary.add(letter18);
        Letter letter19 = new Letter(primeNumberList.get(77), ')');
        dictionary.add(letter19);
        Letter letter20 = new Letter(primeNumberList.get(78), ';');
        dictionary.add(letter20);
        Letter letter21 = new Letter(primeNumberList.get(79), ':');
        dictionary.add(letter21);
        Letter letter22 = new Letter(primeNumberList.get(80), '@');
        dictionary.add(letter22);
        Letter letter23 = new Letter(primeNumberList.get(81), '+');
        dictionary.add(letter23);
        Letter letter24 = new Letter(primeNumberList.get(82), '*');
        dictionary.add(letter24);
        Letter letter25 = new Letter(primeNumberList.get(83), '/');
        dictionary.add(letter25);
        Letter letter26 = new Letter(primeNumberList.get(84), 'ñ');
        dictionary.add(letter26);
        Letter letter27 = new Letter(primeNumberList.get(85), '#');
        dictionary.add(letter27);
        Letter letter28 = new Letter(primeNumberList.get(86), '%');
        dictionary.add(letter28);
        Letter letter29 = new Letter(primeNumberList.get(87), '$');
        dictionary.add(letter29);
        Letter letter30 = new Letter(primeNumberList.get(88), '¡');
        dictionary.add(letter30);
        Letter letter31 = new Letter(primeNumberList.get(89), '¿');
        dictionary.add(letter31);

        for (Integer i = 0; i < 10; i++) {
            Letter letter = new Letter(primeNumberList.get(90 + i), i.toString().charAt(0));
            dictionary.add(letter);
        }
        Letter letter32 = new Letter(primeNumberList.get(100), '<');
        dictionary.add(letter32);
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method AddBlankSpace
     *
     */
    private void AddBlankSpace() {
        Letter initialLetter = new Letter(0, ' ');
        primeNumberList.add(0);
        dictionary.add(initialLetter);
    }

    /**
     * @author Christian Alvarez
     * @date Apr 24, 2019
     * @description_method fillPrimeNumbers
     *
     */
    private void fillPrimeNumbers() {
        int i = 0;
        while (true) {
            if (i > 600) {
                break;
            }
            if (i > 0) {
                String str = String.valueOf(i);

                if (new BigInteger(str).isProbablePrime(i / 2)) {
                    primeNumberList.add(new BigInteger(str).intValue());
                }
            }
            i++;
        }
    }

}
