package org.yumnn.yct.gateway.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Quarter;

@Entity
@Table(name = "user_access.adm_ws_token_by_quarter")
public class WebServiceTokenByQuarter extends BaseEntity implements Serializable {


    private static final long serialVersionUID = 1L;

    @ManyToOne
    @JoinColumn(name = "id_ws_info_fk", referencedColumnName = "ID")
    private WebServiceInfo webServiceInfo;

    @ManyToOne
    @JoinColumn(name = "id_quarter_fk", referencedColumnName = "ID")
    private Quarter currentQuarter;
    
    @Column(name = "generated_token")
    private String generatedToken;

    @ManyToOne
    @JoinColumn(name = "updated_by", referencedColumnName = "ID")
    private User updatedBy;

    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    /**
     * @return the webServiceInfo
     */
    public WebServiceInfo getWebServiceInfo() {
        return webServiceInfo;
    }

    /**
     * @param webServiceInfo the webServiceInfo to set
     */
    public void setWebServiceInfo(WebServiceInfo webServiceInfo) {
        this.webServiceInfo = webServiceInfo;
    }

   
    /**
	 * @return the currentQuarter
	 */
	public Quarter getCurrentQuarter() {
		return currentQuarter;
	}

	/**
	 * @param currentQuarter the currentQuarter to set
	 */
	public void setCurrentQuarter(Quarter currentQuarter) {
		this.currentQuarter = currentQuarter;
	}

	/**
     * @return the generatedToken
     */
    public String getGeneratedToken() {
        return generatedToken;
    }

    /**
     * @param generatedToken the generatedToken to set
     */
    public void setGeneratedToken(String generatedToken) {
        this.generatedToken = generatedToken;
    }

    /**
     * @return the updatedBy
     */
    public User getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(User updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }


}
