package org.yumnn.yct.gateway.enumeration;

public enum EncryptionKeysEnum {

    MIN_2018("min2018");
    String value;

    EncryptionKeysEnum(String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

}