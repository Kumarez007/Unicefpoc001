package org.yumnn.yct.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;

public interface CycleByProjectRepository extends JpaRepository<CycleByProject, Long> {

    @Query("SELECT t.cycle FROM CycleByProject t WHERE t.project.shortName = :projectName  and t.endingDate is null")
    public Cycle findActiveCycleByProject(@Param("projectName") ProjectNameEnum projectNameEnum);
}
