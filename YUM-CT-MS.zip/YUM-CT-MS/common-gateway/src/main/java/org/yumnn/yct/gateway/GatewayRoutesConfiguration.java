package org.yumnn.yct.gateway;

import java.util.function.Predicate;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Configuration;
import org.yumnn.yct.common.enumeration.project.ProjectPmuShortNameEnum;
import org.yumnn.yct.common.util.RequestJsonObject;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name GatewayRoutesConfiguration.java
 * @create_date Jan 31, 2022
 * @last_Update Jan 31, 2022
 */
@Configuration
public class GatewayRoutesConfiguration {

	@Value("${yct-uri}")
	private String yctMisUrl;
	
	@Value("${hn-uri}")
	private String hnMisUrl;

	@Value("${edu-uri}")
	private String eduMisUrl;

	@Value("${hct-uri}")
	private String hctMisUrl;

	@Value("${mis-base-url-ws}")
	private String misBaseUrlWs;
	

	@Value("${yct-base-url-ws}")
	private String yctBaseUrlWs;
	

	private static final String UPLOAD_PAYMENT_SITE_WS = "uploadPaymentSites";
	private static final String UPLOAD_PAID_BENEFICIARY_WS = "uploadPaidBeneficiary";
	private static final String UPLOAD_NOT_PAID_BENEFICIARY_WS = "uploadNotPaidBeneficiary";
	

	private static final String UPLOAD_PAYMENT_SITE_CONTROLLER = "paymentSiteControl";
	private static final String UPLOAD_PAID_BENEFICIARY_CONTROLLER = "paidBeneficiaryControl";
	private static final String UPLOAD_NOT_PAID_BENEFICIARY_CONTROLLER = "notPaidBeneficiaryControl";

	public RouteLocator generateRoutesByProject(RouteLocatorBuilder builder) {

		return builder.routes()
				.route(UPLOAD_PAYMENT_SITE_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS).and()
								.readBody(RequestJsonObject.class, isRequestHCT())
								.uri(hctMisUrl + misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS))

				.route((UPLOAD_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestHCT())
								.uri(hctMisUrl + misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS))

				.route((UPLOAD_NOT_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestHCT())
								.uri(hctMisUrl + misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS))

				// Routes for health projects
				.route(UPLOAD_PAYMENT_SITE_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS).and()
								.readBody(RequestJsonObject.class, isRequestHN())
								.uri(hnMisUrl + misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS))

				.route((UPLOAD_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestHN())
								.uri(hnMisUrl + misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS))

				.route((UPLOAD_NOT_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestHN())
								.uri(hnMisUrl + misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS))

				// Routes for education projects
				.route(UPLOAD_PAYMENT_SITE_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS).and()
								.readBody(RequestJsonObject.class, isRequestEDU())
								.uri(eduMisUrl + misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS))

				.route((UPLOAD_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestEDU())
								.uri(eduMisUrl + misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS))

				.route((UPLOAD_NOT_PAID_BENEFICIARY_WS),
						r -> r.path(misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestEDU())
								.uri(eduMisUrl + misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS))

				// Routes for NVS
				.route(UPLOAD_PAYMENT_SITE_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS).and()
								.readBody(RequestJsonObject.class, isRequestNVS())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_PAYMENT_SITE_CONTROLLER + "/"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_PAYMENT_SITE_CONTROLLER + UPLOAD_PAYMENT_SITE_WS))
				
				.route(UPLOAD_PAID_BENEFICIARY_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestNVS())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_PAID_BENEFICIARY_CONTROLLER + "/"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_PAID_BENEFICIARY_CONTROLLER + UPLOAD_PAID_BENEFICIARY_WS))
				
				.route(UPLOAD_NOT_PAID_BENEFICIARY_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isRequestNVS())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_CONTROLLER + "/"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_CONTROLLER + UPLOAD_NOT_PAID_BENEFICIARY_WS))
				
				
				
				.route(UPLOAD_PAYMENT_SITE_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAYMENT_SITE_WS).and()
								.readBody(RequestJsonObject.class, isNullProject())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_PAYMENT_SITE_CONTROLLER + "/")
										.addRequestHeader("invalidProject", "invalidProject"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_PAYMENT_SITE_CONTROLLER + UPLOAD_PAYMENT_SITE_WS))
				
				
				.route(UPLOAD_PAID_BENEFICIARY_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isNullProject())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_PAID_BENEFICIARY_CONTROLLER + "/")
										.addRequestHeader("invalidProject", "invalidProject"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_PAID_BENEFICIARY_CONTROLLER + UPLOAD_PAID_BENEFICIARY_WS))
				
				.route(UPLOAD_NOT_PAID_BENEFICIARY_WS,
						r -> r.path(misBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_WS).and()
								.readBody(RequestJsonObject.class, isNullProject())
								.filters(f -> f.rewritePath(misBaseUrlWs, yctBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_CONTROLLER + "/")
										.addRequestHeader("invalidProject", "invalidProject"))
								.uri(yctMisUrl + yctBaseUrlWs + UPLOAD_NOT_PAID_BENEFICIARY_CONTROLLER + UPLOAD_NOT_PAID_BENEFICIARY_WS))


				.build();
	}

	private Predicate<RequestJsonObject> isNullProject() {
		return r ->r.getProjectName() == null || r.getProjectName().equals("")|| isInvalidProject(r);

	}

	private boolean isInvalidProject(RequestJsonObject r) {
		return !EnumUtils.isValidEnum(ProjectPmuShortNameEnum.class, r.getProjectName());

	}

	private Predicate<RequestJsonObject> isRequestNVS() {
		return r -> r.getProjectName().equals(ProjectPmuShortNameEnum.nvs.toString());
	}

	private Predicate<RequestJsonObject> isRequestHCT() {
		return r -> r.getProjectName().equals(ProjectPmuShortNameEnum.hct.toString());
	}

	private Predicate<RequestJsonObject> isRequestHN() {
		return r -> r.getProjectName().equals(ProjectPmuShortNameEnum.hwp.toString())
				|| r.getProjectName().equals(ProjectPmuShortNameEnum.ehn_unicef.toString())
				|| r.getProjectName().equals(ProjectPmuShortNameEnum.hai.toString());
				
	}

	private Predicate<RequestJsonObject> isRequestEDU() {
		return r -> r.getProjectName().equals(ProjectPmuShortNameEnum.sgp.toString())
				|| r.getProjectName().equals(ProjectPmuShortNameEnum.tti.toString())
				|| r.getProjectName().equals(ProjectPmuShortNameEnum.eti.toString())
				|| r.getProjectName().equals(ProjectPmuShortNameEnum.rft.toString());

	}
}