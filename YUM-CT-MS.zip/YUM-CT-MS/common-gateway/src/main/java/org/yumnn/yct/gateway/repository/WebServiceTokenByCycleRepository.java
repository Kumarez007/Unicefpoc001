package org.yumnn.yct.gateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.gateway.entity.WebServiceTokenByCycle;

public interface WebServiceTokenByCycleRepository extends JpaRepository<WebServiceTokenByCycle, Long> {

@Query("SELECT t FROM WebServiceTokenByCycle t WHERE t.cycle = :activeCycle and t.webServiceInfo.name = :serviceName ")
    public WebServiceTokenByCycle getByWebServiceAndCycle(Cycle activeCycle, String serviceName);
}
