/*
 * Copyright 2018 UNICEF PMU.
 *
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 *
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.gateway.entity;

import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 *
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name WebServiceModule.java
 * @class_description
 * @create_date Aug 13, 2019
 * @last_Update Aug 13, 2019
 */
@Entity
@Table(name = "user_access.adm_web_service_module")
public class WebServiceModule extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "name")
    private String name;

    @Column(name = "status")
    private String status;

    @Column(name = "status_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date statusDate;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the status_date
     */
    public Date getStatusDate() {
        return statusDate;
    }

    /**
     * @param status_date the status_date to set
     */
    public void setStatusDate(Date statusDate) {
        this.statusDate = statusDate;
    }
}
