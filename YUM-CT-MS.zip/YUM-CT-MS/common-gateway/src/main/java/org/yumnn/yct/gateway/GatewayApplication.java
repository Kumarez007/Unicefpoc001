package org.yumnn.yct.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.yumnn.yct.common.CommonApplicationStarter;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@SpringBootApplication
@Import({CommonApplicationStarter.class})
public class GatewayApplication { 

	public static void main(String[] args) {
		SpringApplication.run(GatewayApplication.class, args);
	}

}
