package org.yumnn.yct.beneficiaryservice.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.yumnn.yct.beneficiaryservice.model.StatisticsModel;
import org.yumnn.yct.beneficiaryservice.model.UserLoggingModel;
import org.yumnn.yct.beneficiaryservice.service.StatisticsService;
import org.yumnn.yct.beneficiaryservice.service.UserLoginService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

@CrossOrigin("**")
@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/statistics")
public class BeneficiaryStatisticsController {

	private static Logger logger = LogManager.getLogger(EnrollController.class);
	
	@Autowired
	StatisticsService statisticsService;
	
	@Autowired
	UserLoginService userLoginService;

	@Operation(summary  = "Post operation for save beneficiary statistics")
	@PostMapping(value = "/savestatistics")
	public ResponseEntity<?> saveBeneficiaryStatistics(@RequestHeader Map<String, String> requestHeader,
			@RequestBody StatisticsModel statisticsModel) throws Exception {
		logger.debug("Entered: saveBeneficiaryStatistics");
		logger.debug("Request Body: ==> "+statisticsModel.toString());
		try {
			Map<String, Object> map = statisticsService.saveStatisticDetails(statisticsModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In saveBeneficiaryStatistics: ",e);
			throw e;
		} 
	}
	
	@Operation(summary  = "Post operation for validate beneficiary statistics")
	@PostMapping(value = "/validatestatistics")
	public ResponseEntity<?> validateStatistics(@RequestHeader Map<String, String> requestHeader,
			@RequestBody String requestObject) throws Exception {
		logger.debug("Entered: validateStatistics");
		logger.debug("Request Body: ==> "+ requestObject);
		try {
			JSONObject jsonObject = new JSONObject(requestObject);
			String uniqueId = jsonObject.getString("uniqueId");
			Map<String, Object> map = statisticsService.validateStatisticsCount(uniqueId);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In validateStatistics: ",e);
			throw e;
		} 
	}

	//minaj code
	@Operation(summary  = "Post operation for save user logging")
	@PostMapping(value = "/saveuserapiloggindetails")
	public ResponseEntity<?> saveUserLogging(@RequestHeader Map<String, String> requestHeader,
			@RequestBody UserLoggingModel loggingModel) throws Exception {
		logger.debug("Entered: saveUserLogging");
		logger.debug("Request Body: ==> "+loggingModel.toString());
		try {
			Map<String, Object> map = userLoginService.saveUserLoggingAPIDetails(loggingModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In saveUserLogging: ",e);
			throw e;
		} 
	}
	
}
