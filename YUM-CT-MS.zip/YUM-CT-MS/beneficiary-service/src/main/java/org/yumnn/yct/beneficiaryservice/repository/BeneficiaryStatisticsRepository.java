package org.yumnn.yct.beneficiaryservice.repository;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Statistics;

@Repository
public class BeneficiaryStatisticsRepository {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	EntityManager em ;
	
	public Statistics getStatisticsByUniqueIdAndDate(String uniqueId) {
		em = entityManagerFactory.createEntityManager();
	    
		Statistics statistics = null;
		
		try {
			em.getTransaction().begin();
			Query query = em.createNativeQuery("SELECT * FROM beneficiary.hst_statistics WHERE unique_id = '" + uniqueId + "' AND date >= cast(Date(Now()) as Date)", Statistics.class);
			//query.setParameter("id", uniqueId);
			statistics = (Statistics) query.getSingleResult();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return statistics;		
	}
	
	
	public long getEnrollmentCount(long enrollmentCount) {
		em = entityManagerFactory.createEntityManager();

		long count = 0;
		try {
			em.getTransaction().begin();
			Query query = em.createNativeQuery("select count(*) as enrlCount from beneficiary.hst_enrollment where created_at >= cast(Date(Now()) as Date)");
			count = ((BigInteger) query.getSingleResult()).longValue();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return count;		
	}
	
	public long getAdmissionCount(long enrollmentCount) {
		em = entityManagerFactory.createEntityManager();

		long count = 0;
		try {
			em.getTransaction().begin();
			Query query = em.createNativeQuery("select count(*) from beneficiary.hst_admission where created_at >= cast(Date(Now()) as Date)");
			count = ((BigInteger) query.getSingleResult()).longValue();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return count;		
	}
	
	public long getValidationCount(long enrollmentCount) {
		em = entityManagerFactory.createEntityManager();

		long count = 0;
		try {
			em.getTransaction().begin();
			Query query = em.createNativeQuery("select count(*) from beneficiary.hst_validation where created_at >= cast(Date(Now()) as Date)");
			count = ((BigInteger) query.getSingleResult()).longValue();
		} catch (Exception e) {
			em.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		return count;		
	}
}
