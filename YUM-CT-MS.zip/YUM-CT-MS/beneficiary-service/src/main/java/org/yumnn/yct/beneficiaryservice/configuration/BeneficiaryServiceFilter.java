package org.yumnn.yct.beneficiaryservice.configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.yumnn.yct.common.util.ConstantsUtil;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 15, 2021
 *
 */

@Component
public class BeneficiaryServiceFilter implements Filter {
	
	private static Logger logger = LoggerFactory.getLogger(BeneficiaryServiceFilter.class);
		
		static final String ROUTE_GATEWAY = "common-gateway";
		String forwardedRouteGateway=null;

		@Override
		public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
				throws IOException, ServletException {
			HttpServletRequest request = (HttpServletRequest) req;
			HttpServletResponse response = (HttpServletResponse) res;
			
			try {
				
				logger.debug("BeneficiaryServiceFilter URL: "+request.getRequestURL());
				
				forwardedRouteGateway=request.getHeader("api-route-gateway")==null?"":request.getHeader("api-route-gateway");
				
				Boolean isSwagger=matchSwagger(request.getRequestURI());
				
				//FIXME reverse condition to reduce complexity  //Fixed
				if(isSwagger || (forwardedRouteGateway.equals(ROUTE_GATEWAY) &&  request.getHeader("sessiontoken")!=null)) {
						
					chain.doFilter(request, response);
				}
				else {
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid Header Or Missing Token.");
				}
										
     		}
     		catch(Exception e) {
     			response.setStatus(HttpStatus.FORBIDDEN.value());
				response.sendError(HttpServletResponse.SC_FORBIDDEN, e.getMessage());
     		}
		
	}
		
	private Boolean matchSwagger(String  requestUri) {
		Boolean isSwagger=false;
		List<String> whiteList= new ArrayList<String>();
		whiteList.add("/v2/api-docs");
		whiteList.add("/swagger-resources");
		whiteList.add("/configuration/ui");
		whiteList.add("/configuration/security");
		whiteList.add("/swagger-ui.html");
		whiteList.add("/webjars");
		whiteList.add("/v3/api-docs");
		whiteList.add("/swagger-ui");
		
		for(String endpoint:whiteList) {
			
			if(requestUri.contains(endpoint)) {
				
				return true;
			}
			
		}
		
		return isSwagger;
		
	}	

}
