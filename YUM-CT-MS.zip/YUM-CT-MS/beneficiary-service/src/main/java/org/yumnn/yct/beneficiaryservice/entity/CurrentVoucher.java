package org.yumnn.yct.beneficiaryservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

@Entity
@Table(name = "beneficiary.cur_voucher")
public class CurrentVoucher extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_enrollment_fk")
	private Enrollment enrollment;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expiry_date")
	private Date expiryDate;

	@Column(name = "is_validated")
	private Boolean isValidated;

	@Column(name = "validation_code")
	private String validationCode;

	@Column(name = "has_redeemed")
	private Boolean has_redeemed;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "estimated_expiry_date")
	private Date estimatedExpiryDate;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = true)
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_updated_by_fk", nullable = true)
	private User updatedBy;

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
	

	public Enrollment getEnrollment() {
		return enrollment;
	}

	public void setEnrollment(Enrollment enrollment) {
		this.enrollment = enrollment;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Boolean getIsValidated() {
		return isValidated;
	}

	public void setIsValidated(Boolean isValidated) {
		this.isValidated = isValidated;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public Boolean getHas_redeemed() {
		return has_redeemed;
	}

	public void setHas_redeemed(Boolean has_redeemed) {
		this.has_redeemed = has_redeemed;
	}

	public Date getEstimatedExpiryDate() {
		return estimatedExpiryDate;
	}

	public void setEstimatedExpiryDate(Date estimatedExpiryDate) {
		this.estimatedExpiryDate = estimatedExpiryDate;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
}
