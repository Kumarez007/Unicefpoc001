package org.yumnn.yct.beneficiaryservice.service;

import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.yumnn.yct.beneficiaryservice.controller.BeneficiaryViewController;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.history.HistoricalBeneficiaryMilestone;
import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryTimelineModel;
import org.yumnn.yct.beneficiaryservice.model.HouseholdCardInfoModel;
import org.yumnn.yct.beneficiaryservice.repository.HistoricalBeneficiaryMilestoneRepository;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModelData;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.Utilities;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name HistoricalBeneficiaryMilestoneService.java
 * @class_description 
 * @create_date May 13, 2021
 * @last_Update May 13, 2021
 */
@Service
public class HistoricalBeneficiaryMilestoneService {

	private static Logger logger = LogManager.getLogger(HistoricalBeneficiaryMilestoneService.class);

	@Autowired
	private HistoricalBeneficiaryMilestoneRepository historicalBeneficiaryMilestoneRepository;

	/**
	 * 
	 * @author WQ
	 * @date May 13, 2021
	 * @description_method 
	 * @param historicalBeneficiaryModel
	 * @throws Exception 
	 */
	@Transactional
	public void saveHistoricalBeneficiaryModel(HistoricalBeneficiaryModel historicalBeneficiaryModel) throws Exception {
		HistoricalBeneficiaryMilestone historicalBeneficiaryMilestone = new HistoricalBeneficiaryMilestone();
		
		if(historicalBeneficiaryModel.getCreatedDate()!=null) {
			historicalBeneficiaryMilestone.setCreationDate(historicalBeneficiaryModel.getCreatedDate());
		}
		else {
			historicalBeneficiaryMilestone.setCreationDate(new Date());
		}
		
		if(!Utilities.isNULL(historicalBeneficiaryModel.getCurrentFormId())) {
			CurrentForm currentForm = new CurrentForm();
			currentForm.setId(historicalBeneficiaryModel.getCurrentFormId());
			historicalBeneficiaryMilestone.setCurrentForm(currentForm);
		}
		if(!Utilities.isNULL(historicalBeneficiaryModel.getBookletId())) {
			Booklet booklet = new Booklet();
			booklet.setId(historicalBeneficiaryModel.getBookletId());
			historicalBeneficiaryMilestone.setBooklet(booklet);
		}
		if(!Utilities.isNULL(historicalBeneficiaryModel.getCycleId())) {
			Cycle cycle = new Cycle();
			cycle.setId(historicalBeneficiaryModel.getCycleId());
			historicalBeneficiaryMilestone.setCycle(cycle);
		}
		if(!Utilities.isNULL(historicalBeneficiaryModel.getCycleByProjectId())) {
			CycleByProject cycleByProject = new CycleByProject();
			cycleByProject.setId(historicalBeneficiaryModel.getCycleByProjectId());
			historicalBeneficiaryMilestone.setCycleByProject(cycleByProject);
		}
		historicalBeneficiaryMilestone.setMilestoneReferenceId(historicalBeneficiaryModel.getMilestoneReferenceId());
		if(Utilities.isNotNullAndNotEmpty(historicalBeneficiaryModel.getMilestoneType())) {
			historicalBeneficiaryMilestone.setMilestoneType(MilestoneTypeEnum.valueOf(historicalBeneficiaryModel.getMilestoneType()));
		}
		saveHistoricalBeneficiaryMilestone(historicalBeneficiaryMilestone);
	}

	@Transactional
	public void saveHistoricalBeneficiaryModelList(HistoricalBeneficiaryModelData historicalBeneficiaryData) throws Exception {
		List<HistoricalBeneficiaryMilestone> historicalBeneficiaryMilestoneList = new ArrayList<>();
		for(HistoricalBeneficiaryModel historicalBeneficiaryModel : historicalBeneficiaryData.getData()){
			HistoricalBeneficiaryMilestone historicalBeneficiaryMilestone = new HistoricalBeneficiaryMilestone();

			if(historicalBeneficiaryModel.getCreatedDate()!=null) {
				historicalBeneficiaryMilestone.setCreationDate(historicalBeneficiaryModel.getCreatedDate());
			}
			else {
				historicalBeneficiaryMilestone.setCreationDate(new Date());
			}

			if(!Utilities.isNULL(historicalBeneficiaryModel.getCurrentFormId())) {
				CurrentForm currentForm = new CurrentForm();
				currentForm.setId(historicalBeneficiaryModel.getCurrentFormId());
				historicalBeneficiaryMilestone.setCurrentForm(currentForm);
			}
			if(!Utilities.isNULL(historicalBeneficiaryModel.getBookletId())) {
				Booklet booklet = new Booklet();
				booklet.setId(historicalBeneficiaryModel.getBookletId());
				historicalBeneficiaryMilestone.setBooklet(booklet);
			}
			if(!Utilities.isNULL(historicalBeneficiaryModel.getCycleId())) {
				Cycle cycle = new Cycle();
				cycle.setId(historicalBeneficiaryModel.getCycleId());
				historicalBeneficiaryMilestone.setCycle(cycle);
			}
			if(!Utilities.isNULL(historicalBeneficiaryModel.getCycleByProjectId())) {
				CycleByProject cycleByProject = new CycleByProject();
				cycleByProject.setId(historicalBeneficiaryModel.getCycleByProjectId());
				historicalBeneficiaryMilestone.setCycleByProject(cycleByProject);
			}
			historicalBeneficiaryMilestone.setMilestoneReferenceId(historicalBeneficiaryModel.getMilestoneReferenceId());
			if(Utilities.isNotNullAndNotEmpty(historicalBeneficiaryModel.getMilestoneType())) {
				historicalBeneficiaryMilestone.setMilestoneType(MilestoneTypeEnum.valueOf(historicalBeneficiaryModel.getMilestoneType()));
			}
			historicalBeneficiaryMilestoneList.add(historicalBeneficiaryMilestone);
		}
		System.out.println("historicalBeneficiaryMilestoneList size: "+historicalBeneficiaryMilestoneList.size());
		historicalBeneficiaryMilestoneRepository.saveAll(historicalBeneficiaryMilestoneList);

	}
	
	private void saveHistoricalBeneficiaryMilestone(HistoricalBeneficiaryMilestone historicalBeneficiaryMilestone) {
		try {
			historicalBeneficiaryMilestoneRepository.save(historicalBeneficiaryMilestone);
		}
		catch (Exception e)
		{
			throw new FailProcessException();
		}
	}
	
	public Map<String, Object> getBeneficiaryTimelineData(Long curFormId){
		logger.debug("Inside Service getBeneficiaryTimelineData");
		
		Map<String, Object> map = new LinkedHashMap<>();
		
		List<BeneficiaryTimelineModel> beneficiaryTimelineModelList = historicalBeneficiaryMilestoneRepository.getBeneficiaryTimelineData(curFormId);
		
		
		map.put(ConstantsUtil.BENEFICIARY_TIMELINE_DATA, beneficiaryTimelineModelList);
		
		return map;
	}


}


