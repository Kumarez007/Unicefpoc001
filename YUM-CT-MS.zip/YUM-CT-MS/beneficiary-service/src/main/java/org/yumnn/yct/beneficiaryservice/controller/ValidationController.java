package org.yumnn.yct.beneficiaryservice.controller;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 16, 2021
 *
 */

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.model.VcaMonitoringDataModel;
import org.yumnn.yct.beneficiaryservice.service.ValidationService;
import org.yumnn.yct.common.model.payment.PaidBeneficiaryModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/validationControl")
public class ValidationController {

	@Autowired
	private ValidationService validationService;
	
	private static final Logger logger = LoggerFactory.getLogger(ValidationController.class);

	@Operation(summary  = "Post operation to Validate Beneficiary")
	@PostMapping(value = "/validateBeneficiary")
	public ResponseEntity<?> validateBeneficiary(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.ID_DOCUMENT_FILE1, required = false) MultipartFile idDocumentFile1,
			@RequestParam(value = ConstantsUtil.ID_DOCUMENT_FILE2, required = false) MultipartFile idDocumentFile2,
			@RequestParam(value = ConstantsUtil.TREATMENT_DOC_FILE1, required = false) MultipartFile treatmentDocFile1,
			@RequestParam(value = ConstantsUtil.TREATMENT_DOC_FILE2, required = false) MultipartFile treatmentDocFile2,
			@RequestParam(value = ConstantsUtil.UPLOAD_VCA_FILE1, required = false) MultipartFile uploadVcaFile1,
			@RequestParam(value = ConstantsUtil.UPLOAD_VCA_FILE2, required = false) MultipartFile uploadVcaFile2,
			ValidationModel validationModel) throws Exception {

		logger.debug("Entered: validateBeneficiary");
		logger.debug("Request Body: ==> "+validationModel.toString());
		Map<String, MultipartFile> filesMap=createValidationFileMap(idDocumentFile1,idDocumentFile2,treatmentDocFile1,treatmentDocFile2,
				uploadVcaFile1,uploadVcaFile2);
		try {
	    	Map<String, Object> map=validationService.validateBeneficiary(requestHeader,filesMap,validationModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		} catch(Exception e) {
			logger.error("Error In validateBeneficiary: ",e);
			throw e;
		}
	}

	@Operation(summary  = "Post operation to Validate Beneficiary")
	@PostMapping(value = "/validateBeneficiaryWeb")
	public ResponseEntity<?> validateBeneficiaryWeb(@RequestHeader Map<String, String> requestHeader, @RequestBody ValidationModel validationModel) throws Exception {

		logger.debug("Entered: validateBeneficiary");
		logger.debug("Request Body: ==> "+validationModel.toString());
		try {
			Map<String, Object> map=validationService.validateBeneficiary(requestHeader,null,validationModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		} catch(Exception e) {
			logger.error("Error In validateBeneficiary: ",e);
			throw e;
		}
	}
	
	
	@Operation(summary  = "Get operation to retrieve validation Codes")
	@GetMapping(value = "/getValidationCodeByVca")
	public ResponseEntity<?> getValidationCodeByVca(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "vca", required = true) String vca) throws Exception {
		logger.debug("Entered: getValidationCodeByVca");

		try {
	    	Map<String, Object> map=validationService.getValidationCodeByVca(vca);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getValidationCodeByVca: ",e);
			throw e;
		} 
	}
	
	@Operation(summary  = "Post operation to redeem Validation Code")
	@PostMapping(value = "/redeemValidationCodeList")
	public ResponseEntity<?> redeemValidationCodeList(@RequestHeader Map<String, String> requestHeader,
			@RequestBody PaidBeneficiaryModel paidBeneficiaryModel)throws Exception {
		
		logger.debug("Entered: getValidationCodeByVca");

		try {
			validationService.redeemValidationCode(paidBeneficiaryModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, null);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In redeemValidationCodeList: ",e);
			throw e;
		}
	}
	
	private Map<String, MultipartFile> createValidationFileMap(MultipartFile idDocumentFile1, MultipartFile idDocumentFile2,
			MultipartFile treatmentDocFile1, MultipartFile treatmentDocFile2,MultipartFile uploadVcaFile1, MultipartFile uploadVcaFile2) {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		if (idDocumentFile1 != null)
			filesMap.put(ConstantsUtil.ID_DOCUMENT_FILE1, idDocumentFile1);
		if (idDocumentFile2 != null)
			filesMap.put(ConstantsUtil.ID_DOCUMENT_FILE2, idDocumentFile2);
		if (treatmentDocFile1 != null)
			filesMap.put(ConstantsUtil.TREATMENT_DOC_FILE1, treatmentDocFile1);
		if (treatmentDocFile2 != null)
			filesMap.put(ConstantsUtil.TREATMENT_DOC_FILE2, treatmentDocFile2);
		if (uploadVcaFile1 != null)
			filesMap.put(ConstantsUtil.UPLOAD_VCA_FILE1, uploadVcaFile1);
		if (uploadVcaFile2 != null)
			filesMap.put(ConstantsUtil.UPLOAD_VCA_FILE2, uploadVcaFile2);
		return filesMap;
	}
	
	@Operation(summary  = "Post operation to add Vca Monitoring Log")
	@PostMapping(value = "/addVcaMonitoringLog")
	public ResponseEntity<?> addVcaMonitoringLog(@RequestHeader Map<String, String> requestHeader,
			@RequestBody VcaMonitoringDataModel vcaMonitoringDataModel)throws Exception {
		
		logger.debug("Entered: addVcaMonitoringLog");

		try {
			validationService.saveVcaMonitoringLog(vcaMonitoringDataModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, null);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addVcaMonitoringLog: ",e);
			throw e;
		}
	}

	@Operation(summary  = "Get operation to retrieve all service types")
	@GetMapping(value = "/getAllServiceTypes")
	public ResponseEntity<?> getAllServiceTypes(@RequestHeader Map<String, String> requestHeader) throws Exception {
		logger.debug("Entered: getAllServiceTypes");

		try {
			Map<String, Object> map=validationService.getAllServiceTypes();
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getAllServiceTypes: ",e);
			throw e;
		}
	}

}
