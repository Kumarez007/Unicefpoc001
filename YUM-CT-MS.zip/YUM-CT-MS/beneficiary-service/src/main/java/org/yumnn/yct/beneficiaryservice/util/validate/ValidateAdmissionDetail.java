package org.yumnn.yct.beneficiaryservice.util.validate;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.CustomException;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;


@Service
public class ValidateAdmissionDetail {

	private static Logger logger = LogManager.getLogger();

	@Autowired
	private EnrollmentService enrollmentService;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	private AdmissionRepository admissionRepository;
	
	public void validateAdmissionDetails(final Map<String, MultipartFile> filesMap,BeneficiaryAdmissionModel beneficiaryAdmissionModel) throws Exception {
	
		logger.debug("Inside validateAdmissionDetails");
		
		if(beneficiaryAdmissionModel.getUniqueId()!=null) {
			Admission admission = admissionRepository.findByUniqueId(beneficiaryAdmissionModel.getUniqueId());
			commonValidationUtil.checkDuplicateRequest("Unique Id",admission);
		}
		
		commonValidationUtil.validateIsNullOrEmpty("Is Admitted",beneficiaryAdmissionModel.getIsAdmitted());
		
		commonValidationUtil.validateIsNullOrEmpty("Enrollment Code",beneficiaryAdmissionModel.getEnrollmentCode());
		
		validateProofOfReferral(filesMap.get(ConstantsUtil.REFERRAL_FILE1), filesMap.get(ConstantsUtil.REFERRAL_FILE2), beneficiaryAdmissionModel);
		
		commonValidationUtil.validateIsNullOrEmpty("Is Validation Code Used Flag",beneficiaryAdmissionModel.getIsValidationCodeUsed());
		
		if(ConstantsUtil.YES_VAL.equalsIgnoreCase(beneficiaryAdmissionModel.getIsAdmitted())) {
			
			commonValidationUtil.validateMultipartFile("Proof of admission File1 or Proof of admission File2",filesMap.get(ConstantsUtil.ADMISSION_FILE1), filesMap.get(ConstantsUtil.ADMISSION_FILE2));
			
			if(ConstantsUtil.NO.equalsIgnoreCase(beneficiaryAdmissionModel.getIsValidationCodeUsed())) {
				commonValidationUtil.validateIsNullOrEmpty("OTP Validation Code",beneficiaryAdmissionModel.getOtpValidationCode());
				commonValidationUtil.validateIsNullOrEmpty("Expiry Date",beneficiaryAdmissionModel.getExpiryDate());
			} 
			
		}else if(ConstantsUtil.NO.equalsIgnoreCase(beneficiaryAdmissionModel.getIsAdmitted())) {

			commonValidationUtil.validateIsNullOrEmpty("Reason of non admission",beneficiaryAdmissionModel.getNonAdmissionReasonShortName());
			
			if(ConstantsUtil.NO.equalsIgnoreCase(beneficiaryAdmissionModel.getIsValidationCodeUsed())) {
				commonValidationUtil.validateIsNullOrEmpty("OTP Validation Code",beneficiaryAdmissionModel.getOtpValidationCode());
				commonValidationUtil.validateIsNullOrEmpty("TFC Validation Code",beneficiaryAdmissionModel.getTfcValidationCode());
				
				commonValidationUtil.validateIsNullOrEmpty("Expiry Date",beneficiaryAdmissionModel.getExpiryDate());
			}
		}
		
	}

	private void validateProofOfReferral(MultipartFile admissionFile1, MultipartFile admissionFile2,
			BeneficiaryAdmissionModel beneficiaryAdmissionModel) throws CustomException, NoSuchMessageException, IOException,FailProcessException {
		if(Utilities.isValidString(beneficiaryAdmissionModel.getEnrollmentCode())) {
			Enrollment enrollment = enrollmentService.getEnrollmentByCode(beneficiaryAdmissionModel.getEnrollmentCode());
			if(enrollment != null && YesNoEnum.YES.equals(enrollment.getIsRefferdFromOtherTFC())) {
				commonValidationUtil.validateMultipartFile("Proof of referral File1 or Proof of referral File2",admissionFile1, admissionFile2);
			}
		}
	}

}
