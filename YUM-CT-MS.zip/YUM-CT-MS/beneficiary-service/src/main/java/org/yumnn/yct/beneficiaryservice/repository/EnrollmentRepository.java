package org.yumnn.yct.beneficiaryservice.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.FacilityCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.GrievanceAndInquiriesCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.HouseholdCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByCycleCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByServiceCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.SearchModel;
import org.yumnn.yct.common.exception.FailProcessException; 

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
	
	@Override
	Optional<Enrollment> findById(Long id) throws FailProcessException;

	Enrollment findByEnrollmentCode(String enrollmentCode) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId  FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ "  WHERE cb.short_name =:vcaNumber and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByBookletAndVCA(@Param("vcaNumber") String vcaNumber) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name, ' ', chm.last_name) as fullName, cf.id_project_fk as projectId  FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " where upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getAllEnrollmentData() throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join user_access.cat_program_entity cpe on (he.id_program_entity_fk = cpe.id) "
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " join user_access.cat_geolocation cg on (cpe.id_geolocation_fk=cg.id)"
			+ " WHERE (chm.first_name ilike %:firstName% or chm.last_name ilike %:lastName%) and cg.id=:geoLocationId and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByNameAndGeolocation(@Param("firstName") String firstName,@Param("lastName") String lastName, @Param("geoLocationId") Long geoLocationId) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join user_access.cat_program_entity cpe on (he.id_program_entity_fk = cpe.id) "
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " join user_access.cat_geolocation cg on (cpe.id_geolocation_fk=cg.id)"
			+ " WHERE chm.first_name ilike %:firstName% and cg.id=:geoLocationId and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByFirstNameAndGeolocation(@Param("firstName") String firstName, @Param("geoLocationId") Long geoLocationId) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " WHERE chm.first_name ilike %:firstName% or chm.last_name ilike %:lastName% and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByName(@Param("firstName") String firstName, @Param("lastName") String lastName) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " WHERE chm.first_name ilike %:firstName% and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByFirstName(@Param("firstName") String firstName) throws FailProcessException;
	
	@Query( value = "SELECT he.id as enrollmentId ,cf.id as beneficiaryId, cb.short_name as vcaNumber, TO_CHAR(he.created_at, 'dd-Mon-yyyy HH:mm:ss') as dateOfEnrollment,CONCAT(chm.first_name,' ', chm.last_name) as fullName, cf.id_project_fk as projectId FROM beneficiary.hst_enrollment he join beneficiary.cur_form cf on (he.id_form_fk=cf.id)"
			+ " join user_access.cat_program_entity cpe on cpe.id = COALESCE (he.id_program_entity_fk, (select id from user_access.cat_program_entity where short_name = he.otp_ref_number)) "
			+ " join beneficiary.cur_household_member chm on (cf.id=chm.id_form_fk)"
			+ " join beneficiary.cat_household_member_type chmt on (chm.id_household_member_type_fk = chmt.id and upper(chmt.short_name) = 'HMCG') "
			+ " join beneficiary.cat_booklet cb on (he.id_booklet_fk=cb.id)"
			+ " join user_access.cat_geolocation cg on (cpe.id_geolocation_fk=cg.id)"
			+ " WHERE cg.id=:geoLocationId and upper(chm.is_primary)='YES'", nativeQuery = true)
	List<SearchModel> getEnrollmentDataByGeolocation(@Param("geoLocationId") Long geoLocationId) throws FailProcessException;
	
	@Query( value = "select booklet.name as vcaNumber,he.created_at as dateOfEnrollment,cpe.name as tfcName,cpe2.zone_type as zoneName from beneficiary.hst_enrollment he " + 
			"join beneficiary.cat_booklet booklet on booklet.id=he.id_booklet_fk " + 
			"join user_access.adm_user us on us.id=he.id_user_created_by_fk " + 
			"join user_access.cat_program_entity cpe on  cpe.id=us.id_program_entity_fk " + 
			"join user_access.cat_program_entity cpe2 on  cpe2.code=he.otp_ref_number " + 
			"where he.id_form_fk=:curFormId", nativeQuery = true)
	List<HouseholdCardInfoModel> getHouseholdCardInfo(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	
	@Query( value = "SELECT CONCAT(chm.first_name,' ',chm.last_name) as fullName FROM beneficiary.cur_household_member chm "
			+ " WHERE id_form_fk=:curFormId and upper(chm.is_primary)='YES' order by id desc limit 1", nativeQuery = true)
	String getPrimaryMemberName(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = "SELECT CONCAT(chm.first_name,' ',chm.last_name) as fullName FROM beneficiary.cur_household_member chm "
			+ " WHERE id_form_fk=:curFormId and id_household_member_type_fk=2 order by id desc limit 1", nativeQuery = true)
	String getPrimaryMemberNameForNVS(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = "SELECT id_geolocation_fk FROM beneficiary.cur_location WHERE id_cur_form_fk=:curFormId", nativeQuery = true)
	Long getBeneficiaryGeoLocation(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = "SELECT max(id_geolocation_fk) FROM beneficiary.hst_enrollment WHERE id_form_fk=:curFormId", nativeQuery = true)
	Long getBeneficiaryGeoLocationForNVS(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = "select distinct cb.name as vcaNumber , tevc.created_at as dateOfService, replace(sbbvc.validation_code_type,'PERDIEM','PER DIEM ') as serviceType , anplu.paid_amount as paymentAmount, "
			+ " sbbvc.validation_code as validationCode, anplu.payment_date as paymentDate, sbbvc.is_used as isUsed, sbbvc.is_redeemed as isRedeemed , he.created_at as enrollmentDate "
			+ " from beneficiary.hst_enrollment he"
			+ " left outer join beneficiary.cat_booklet cb on he.id_booklet_fk =cb.id"
			+ " left outer join beneficiary.stp_booklet_by_validation_code sbbvc on cb.id =sbbvc.id_cat_booklet_fk"
			+ " left outer join beneficiary.tra_enable_validation_code tevc on sbbvc.id=tevc.id_booklet_by_validation_fk"
			+ " left outer join payment.hst_payment_information_validation_code anplu on sbbvc.validation_code = anplu.paid_validation_code"
			+ " where he.id_form_fk =:curFormId order by tevc.created_at asc", nativeQuery = true)
	List<PaymentByServiceCardInfoModel> getPaymentByServiceCardInfo(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query(value = "SELECT * FROM beneficiary.hst_enrollment order by id asc",nativeQuery = true)
	List<Enrollment> getEnrollmentList() throws FailProcessException;
	
	Enrollment findByUniqueId(String uniqueId) throws FailProcessException;

//	@Query( value = "select ac.display_name as cycle,ca.en_name  as paymentAgencyEn,ca.ar_name  as paymentAgencyAr,hpi.sent_amount as amountToBePaidInYER,hpi.sent_amount_usd as amountToBePaidInUSD ,"
//            + " hpi.collected_amount as paidAmountInYER,case when payment_status='PAID' then 'YES' else 'NO' end as hasReceivedPayment,hpi.program_name as program from payment.hst_payment_information hpi "
//            + " left outer join user_access.adm_cycle ac on ac.id= hpi.id_cycle_fk"
//            + " left outer join payment.cat_agency ca on ca.id=hpi.id_assigned_agency_fk"
//			+ " left outer join user_access.adm_cycle_by_project cp on cp.id = hpi.id_cycle_by_project_fk"
//			+ " left outer join user_access.adm_project pr on pr.id = cp.id_project_fk"
//            + " where id_cur_form_fk =:curFormId and pr.facility_project = 'YES' ", nativeQuery = true)

	@Query( value = "select ac.display_name as cycle,ca.en_name  as paymentAgencyEn,ca.ar_name  as paymentAgencyAr,hpi.sent_amount as amountToBePaidInYER,hpi.sent_amount_usd as amountToBePaidInUSD ,"
			+ " hpi.collected_amount as paidAmountInYER, hpi.collected_amount_usd as paidAmountInUSD,"
			+ " hpi.donor_name as donor, hpi.grant_name as grant,hpi.targeted_period as targetedPeriod,"
			+ " ap.id_payment_review_scheme_fk as idPaymentReviewScheme, case when payment_status='PAID' then 'YES' else 'NO' end as hasReceivedPayment,hpi.program_name as program,hpi.face_no as faceNo, hpi.field_office as fieldOffice, hpi.section as section from payment.hst_payment_information hpi "
			+ " left outer join user_access.adm_cycle ac on ac.id= hpi.id_cycle_fk"
			+ " left outer join payment.cat_agency ca on ca.id=hpi.id_assigned_agency_fk"
			+ " left outer join user_access.adm_cycle_by_project acp on acp.id_cycle_fk=hpi.id_cycle_fk and hpi.id_cycle_by_project_fk=acp.id"
			+ " left outer join user_access.adm_project ap on ap.id=acp.id_project_fk "
			+ " where id_cur_form_fk =:curFormId ", nativeQuery = true)
	List<PaymentByCycleCardInfoModel> getPaymentByCycleCardInfo(@Param("curFormId") Long curFormId) throws FailProcessException;

	@Query( value = "select ac.display_name as cycle,ca.en_name  as paymentAgencyEn,ca.ar_name  as paymentAgencyAr," +
			"hpi.sent_amount as amountToBePaidInYER,hpi.sent_amount_usd as amountToBePaidInUSD ,hpi.collected_amount_usd as paidAmountInUSD," +
			"hpi.donor_name as donor, hpi.grant_name as grant,hpi.targeted_period as targetedPeriod," +
			" hpi.collected_amount as paidAmountInYER," +
			" pr.id_payment_review_scheme_fk as idPaymentReviewScheme,  " +
			" case when payment_status='PAID' then 'YES' else 'NO' end as hasReceivedPayment,hpi.program_name as program,hpi.face_no as faceNo, hpi.field_office as fieldOffice, hpi.section as section from payment.hst_payment_information hpi\n" +
			" left outer join user_access.cat_program_entity pe on pe.id = hpi.id_program_entity_fk" +
			" left outer join user_access.adm_cycle ac on ac.id= hpi.id_cycle_fk" +
			" left outer join payment.cat_agency ca on ca.id=hpi.id_assigned_agency_fk" +
			" left outer join user_access.adm_cycle_by_project cp on cp.id = hpi.id_cycle_by_project_fk" +
			" left outer join user_access.adm_project pr on pr.id = cp.id_project_fk" +
			" where pe.short_name=:curFormId and pr.facility_project = 'YES' ", nativeQuery = true)
	List<PaymentByCycleCardInfoModel> getPaymentByCycleCardInfo(@Param("curFormId") String curFormId) throws FailProcessException;

	
	@Query( value = "select tg.id as grievanceId, grievance_code as grievanceCode,event_description as specifications,"
			+ "cat.en_name as categoryEn,cat.ar_name as categoryAr,tg.creation_date as date,tgs.status as status from grievance.tra_grievance tg "
			+ " join grievance.cat_grievance_category cat  on cat.id=tg.id_grievance_category_fk "
			+" join grievance.tra_grievance_status tgs on tgs.id_grievance_fk=tg.id and  ending_date is null "
			+ " where id_cur_form_fk =:curFormId  and tgs.status != 'CANCELED_BY_CHANGING_CATEGORY' and tgs.status != 'CANCELLED_BY_CHANGING_GRIEVANCE_LOCATION_OR_FACILITY'", nativeQuery = true)
	List<GrievanceAndInquiriesCardInfoModel> getGrievancesCardInfo(Long curFormId);
	
	@Query(value = "select id as inquiryId,observation as comments,creation_date as dateOfRegistration from grievance.cur_register_inquiry "
			+ " where unique_code =:uniqueCode ", nativeQuery = true)
	List<GrievanceAndInquiriesCardInfoModel> getInquiriesCardInfo(String uniqueCode);
	
	@Query( value = "select id_register_inquiry_fk as inquiryId,string_agg(cit.en_name, ',') as typeEn,string_agg(cit.ar_name, ',') as typeAr,string_agg(cic.en_name, ',') as inquiryCategoryEn,string_agg(cic.ar_name, ',') as inquiryCategoryAr from grievance.tra_inquiry_by_type  tibt "
			+ " join grievance.cat_inquiry_type cit on cit.id=tibt.id_inquiry_type_fk "
			+ " join grievance.cat_inquiry_category cic on cic.id=cit.id_inquiry_category_fk "
			+ " where id_register_inquiry_fk=:inquiryId group by id_register_inquiry_fk", nativeQuery = true)
	GrievanceAndInquiriesCardInfoModel getInquiryTypeAndCategory(Long inquiryId);
	
	@Query(value="select ap.en_name as projectNameEn,ap.ar_name as projectNameAr, cpe.short_name as uniquecode, cpe.id_geolocation_fk as geolocation, "
			+ "cpet.en_name as facilityTypeEn,cpet.ar_name as facilityTypeAr, chfi.contact_full_name as contactPersonNameEn, "
			+ "chfi.contact_full_name as contactPersonNameAr, chfi.contact_role as contactPersonRole, cpe.en_name as programNameEn, cpe.ar_name as programNameAr "
			+ "FROM user_access.cat_program_entity cpe "
			+ "left join user_access.cat_health_facility_information chfi on chfi.id_program_entity_fk = cpe.id "
			+ "join user_access.cat_program_entity_type cpet on cpet.id=cpe.id_program_entity_type_fk "
			+ "join beneficiary.cur_form cf on cpe.id_form_fk = cf.id "
			+ "join user_access.adm_project ap on cf.id_project_fk=ap.id "
			+ "where cpe.id_form_fk =:curFormId limit 1", nativeQuery = true)
	 FacilityCardInfoModel findFacilityCodeByVca(@Param("curFormId")Long curFormId) throws FailProcessException;
}
