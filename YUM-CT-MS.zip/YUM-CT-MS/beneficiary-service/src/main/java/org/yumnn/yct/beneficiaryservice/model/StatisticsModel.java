package org.yumnn.yct.beneficiaryservice.model;

import org.yumnn.yct.common.entity.administration.User;

public class StatisticsModel {

    private Long enrollmentCount;

    private Long admissionCount;

    private Long validationCount;

    private Long enrollmentIsUploadedCount;

    private Long admissionIsUploadedCount;

    private Long validationIsUploadedCount;

    private String uploaded;

    private String userName;

    private String uniqueId;

    private String androidOs;

    private String androidVersionName;

    public Long getEnrollmentCount() {
        return enrollmentCount;
    }

    public void setEnrollmentCount(Long enrollmentCount) {
        this.enrollmentCount = enrollmentCount;
    }

    public Long getAdmissionCount() {
        return admissionCount;
    }

    public void setAdmissionCount(Long admissionCount) {
        this.admissionCount = admissionCount;
    }

    public Long getValidationCount() {
        return validationCount;
    }

    public void setValidationCount(Long validationCount) {
        this.validationCount = validationCount;
    }

    public Long getEnrollmentIsUploadedCount() {
        return enrollmentIsUploadedCount;
    }

    public void setEnrollmentIsUploadedCount(Long enrollmentIsUploadedCount) {
        this.enrollmentIsUploadedCount = enrollmentIsUploadedCount;
    }

    public Long getAdmissionIsUploadedCount() {
        return admissionIsUploadedCount;
    }

    public void setAdmissionIsUploadedCount(Long admissionIsUploadedCount) {
        this.admissionIsUploadedCount = admissionIsUploadedCount;
    }

    public Long getValidationIsUploadedCount() {
        return validationIsUploadedCount;
    }

    public void setValidationIsUploadedCount(Long validationIsUploadedCount) {
        this.validationIsUploadedCount = validationIsUploadedCount;
    }

    public String getUploaded() {
        return uploaded;
    }

    public void setUploaded(String uploaded) {
        this.uploaded = uploaded;
    }    

    public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getAndroidOs() {
        return androidOs;
    }

    public void setAndroidOs(String androidOs) {
        this.androidOs = androidOs;
    }

    public String getAndroidVersionName() {
        return androidVersionName;
    }

    public void setAndroidVersionName(String androidVersionName) {
        this.androidVersionName = androidVersionName;
    }
}
