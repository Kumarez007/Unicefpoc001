package org.yumnn.yct.beneficiaryservice.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.administration.DeviceDetail;
import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Oct 6, 2021 7:20:42 PM
 */

@Entity
@Table(name = "beneficiary.gen_device_downloaded_data")
public class DeviceDownloadedData extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@OneToOne
	@JoinColumn(name = "id_device_fk", nullable = false)
	private DeviceDetail deviceDetail;
	
	@OneToOne
	@JoinColumn(name = "id_records_to_download_fk", nullable = false)
	private RecordDownload recordDownload;

	public DeviceDetail getDeviceDetail() {
		return deviceDetail;
	}

	public void setDeviceDetail(DeviceDetail deviceDetail) {
		this.deviceDetail = deviceDetail;
	}

	public RecordDownload getRecordDownload() {
		return recordDownload;
	}

	public void setRecordDownload(RecordDownload recordDownload) {
		this.recordDownload = recordDownload;
	}

}
