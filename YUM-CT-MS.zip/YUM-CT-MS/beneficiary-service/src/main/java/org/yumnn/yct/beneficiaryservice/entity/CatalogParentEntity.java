package org.yumnn.yct.beneficiaryservice.entity;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@MappedSuperclass
public abstract class CatalogParentEntity extends BaseEntity {


	private static final long serialVersionUID = 1L;

	@Column(name = "name")
	protected String name;

	@Column(name = "short_name", unique = true)
	protected String shortName;
	
	@Column(name = "en_name",nullable = false)
	private String enName;
	
	@Column(name = "ar_name",nullable = false)
	private String arName;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	@Override
	public String toString() {
		return this.name;
	}
	
	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getArName() {
		return arName;
	}

	public void setArName(String arName) {
		this.arName = arName;
	}


}
