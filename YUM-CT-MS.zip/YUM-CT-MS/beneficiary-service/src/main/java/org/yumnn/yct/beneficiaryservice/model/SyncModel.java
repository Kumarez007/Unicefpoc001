package org.yumnn.yct.beneficiaryservice.model;

import java.io.Serializable;

public class SyncModel implements Serializable {

	private static final long serialVersionUID = 1L;
		
	private String username;
		
	private String lastSyncId;
		  
	private String batchSize;
	
	private String deviceId;

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getLastSyncId() {
		return lastSyncId;
	}
	
	public void setLastSyncId(String lastSyncId) {
		this.lastSyncId = lastSyncId;
	}
	
	public String getBatchSize() {
		return batchSize;
	}
	
	public void setBatchSize(String batchSize) {
		this.batchSize = batchSize;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
}
