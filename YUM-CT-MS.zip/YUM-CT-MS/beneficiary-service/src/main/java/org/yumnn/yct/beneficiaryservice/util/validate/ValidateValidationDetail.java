package org.yumnn.yct.beneficiaryservice.util.validate;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.CustomException;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ValidateValidationDetail {

	private static Logger logger = LogManager.getLogger(ValidateValidationDetail.class);

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	ValidationRepository validationRepository;

	public void validateValidationDetails(Map<String, MultipartFile> filesMap,ValidationModel validationModel) throws Exception {
		
		if(validationModel.getUniqueId()!=null) {
			Validation validation = validationRepository.findByUniqueId(validationModel.getUniqueId());
			commonValidationUtil.checkDuplicateRequest("Unique Id",validation);
		}
		
		commonValidationUtil.validateMultipartFile("Treatment document File1 or Treatment document File2",filesMap.get(ConstantsUtil.TREATMENT_DOC_FILE1), filesMap.get(ConstantsUtil.TREATMENT_DOC_FILE2));
		commonValidationUtil.validateMultipartFile("VCA document File1 or VCA document File2",filesMap.get(ConstantsUtil.UPLOAD_VCA_FILE1), filesMap.get(ConstantsUtil.UPLOAD_VCA_FILE2));
		
		commonValidationUtil.validateIsNullOrEmpty("Service Type",validationModel.getServiceTypeShortName());
		
		commonValidationUtil.validateIsNullOrEmpty("Name of doctor",validationModel.getDoctorName());

		validateValidationCodeDetails(validationModel);
		
	}
	
	
	private void validateValidationCodeDetails(ValidationModel validationModel)
			throws CustomException, JsonProcessingException, JsonMappingException {
		
		List<ValidationCodeModel> validationCodeList = null;
		if (validationModel.getValidationCodeDetails() == null || validationModel.getValidationCodeDetails().isEmpty()) {
			logger.error("ValidationCodeDetails are empty or null");
			throw new IllegalArgumentException(messageSource.getMessage("validate.param", null,"Validation Failed", LocaleContextHolder.getLocale())+": Validation Code Details");
		} else {
			validationCodeList = new ObjectMapper().readValue(validationModel.getValidationCodeDetails(),
					new TypeReference<List<ValidationCodeModel>>() {
					});
			
			for (ValidationCodeModel validationCodeModel : validationCodeList) {
				
				commonValidationUtil.validateIsNullOrEmpty("Is Validation Code Used Flag",validationCodeModel.getIsValidationCodeUsed());
				
				if(validationCodeModel.getIsValidationCodeUsed().equalsIgnoreCase(YesNoEnum.NO.getValue())) {
					commonValidationUtil.validateIsNullOrEmpty("Validation Code",validationCodeModel.getValidationCode());
					
					commonValidationUtil.validateIsNullOrEmpty("Validation Code Type",validationCodeModel.getValidationCodeType());
					
					commonValidationUtil.validateIsNullOrEmpty("Expiry date",validationCodeModel.getExpirydate());
					
					commonValidationUtil.validateIsNullOrEmpty("Reference Type",validationCodeModel.getReferenceType());
				}
			} 
		}
	}

}
