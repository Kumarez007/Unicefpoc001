package org.yumnn.yct.beneficiaryservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.yumnn.yct.common.util.entityobject.ParentEntityObject;

@Entity
public class CatBookletModel  extends ParentEntityObject {
	
	@Id
	@Column(name = "id")
	private String id;
	@Column(name = "name")
	private String name;
	@Column(name = "short_name")
	private String shortName;
	@Column(name = "orderItem")
	private String orderItem;
	@Column(name = "enName")
	private String enName;
	@Column(name = "arName")
	private String arName;
	@Column(name = "isActive")
	private String isActive;
	@Column(name = "isPrinted")
	private String isPrinted;
	@Column(name = "IsUsed")
	private String isUsed;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getOrderItem() {
		return orderItem;
	}
	public void setOrderItem(String orderItem) {
		this.orderItem = orderItem;
	}
	public String getEnName() {
		return enName;
	}
	public void setEnName(String enName) {
		this.enName = enName;
	}
	public String getArName() {
		return arName;
	}
	public void setArName(String arName) {
		this.arName = arName;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getIsPrinted() {
		return isPrinted;
	}
	public void setIsPrinted(String isPrinted) {
		this.isPrinted = isPrinted;
	}
	public String getIsUsed() {
		return isUsed;
	}
	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}
}
