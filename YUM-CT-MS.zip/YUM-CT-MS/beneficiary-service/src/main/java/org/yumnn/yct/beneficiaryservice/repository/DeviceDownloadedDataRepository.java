package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.yumnn.yct.beneficiaryservice.entity.DeviceDownloadedData;
import org.yumnn.yct.common.entity.administration.DeviceDetail;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Oct 6, 2021 7:26:00 PM
 */
public interface DeviceDownloadedDataRepository extends JpaRepository<DeviceDownloadedData, Long>{
	
	DeviceDownloadedData findByDeviceDetail(DeviceDetail deviceDetail);

}
