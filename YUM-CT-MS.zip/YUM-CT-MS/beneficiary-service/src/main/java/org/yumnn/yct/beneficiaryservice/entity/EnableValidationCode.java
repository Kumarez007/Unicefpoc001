package org.yumnn.yct.beneficiaryservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;


@Entity
@Table(name = "beneficiary.tra_enable_validation_code")
public class EnableValidationCode extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "reference_id")
	private Long referenceId;

	@Column(name = "reference_type")
	private String referenceType;

	@OneToOne
	@JoinColumn(name = "id_booklet_by_validation_fk")
	private BookletByValidationCode bookletByValidationCode;

	@Column(name = "validation_type")
	private String validationType;

	@Column(name = "expiry_date")
	private Date expiryDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;
	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	
	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}


	public Long getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(Long referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public BookletByValidationCode getSetupBookletByValidationCode() {
		return bookletByValidationCode;
	}

	public void setSetupBookletByValidationCode(BookletByValidationCode bookletByValidationCode) {
		this.bookletByValidationCode = bookletByValidationCode;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

}
