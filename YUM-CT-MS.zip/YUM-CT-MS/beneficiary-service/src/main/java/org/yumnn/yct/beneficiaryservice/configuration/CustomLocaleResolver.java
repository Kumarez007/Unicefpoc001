package org.yumnn.yct.beneficiaryservice.configuration;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
import org.yumnn.yct.common.util.ConstantsUtil;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

public class CustomLocaleResolver extends AcceptHeaderLocaleResolver {

  private static Logger logger = LogManager.getLogger();

  /**
   * @param request
   * @return locale
   */
  @Override
  public Locale resolveLocale(HttpServletRequest request) {
    String headerLang = request.getHeader("language");
    logger.debug("Selected language header: " + headerLang);
    return headerLang == null || headerLang.isEmpty() || headerLang.equals(ConstantsUtil.ENGLISH)
        ? new Locale(ConstantsUtil.LOCALE_EN)
        : new Locale(ConstantsUtil.LOCALE_AR);
  }
}
