package org.yumnn.yct.beneficiaryservice.util.validate;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.service.BeneficiaryApiCallService;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.model.administration.UserModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

@Service
public class ValidateUserDetail {

	private static Logger logger = LogManager.getLogger();

	@Autowired
	CommonValidationUtil commonValidationUtil;

	@Autowired
	private BeneficiaryApiCallService apiCallService;

	public User validateAndGetUser(Map<String, String> requestHeader) throws Exception {
		logger.debug("isUserIdValid: ");
		
		commonValidationUtil.validateIsNullOrEmpty("Request Header User Id", requestHeader.get(ConstantsUtil.USER_ID_HEADER));
		
		UserModel userModel = apiCallService.getUserDetails(requestHeader);
		
		logger.debug("API Returned User Model ----> "+userModel.getId());
		
		commonValidationUtil.validateIsNullOrEmpty("User Id", userModel.getId().toString());
		
		// Validate userId field
		commonValidationUtil.validateUserId(requestHeader.get(ConstantsUtil.USER_ID_HEADER),userModel.getId().toString());

		User user = new User();
		user.setId(userModel.getId());
		return user;
	}
	
	public Long validateAndGetDeviceId(Map<String, String> requestHeader, String deviceId) throws Exception {
		logger.debug("validateAndGetDeviceId: ");
		
		commonValidationUtil.validateIsNullOrEmpty("Request Header User Id", requestHeader.get(ConstantsUtil.USER_ID_HEADER));
		commonValidationUtil.validateIsNullOrEmpty("Request Device Id", deviceId);
		
		Long deviceDetailId = apiCallService.getDeviceDetailId(requestHeader,deviceId);
		
		logger.debug("API Returned Response ----> "+deviceDetailId);
		
		commonValidationUtil.validateIsNullOrEmpty("Response Device Id", deviceDetailId.toString());

		return deviceDetailId;
	}
}
