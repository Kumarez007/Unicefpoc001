package org.yumnn.yct.beneficiaryservice.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.yumnn.yct.common.entity.administration.User;

public interface UserRepository extends JpaRepository<User, Long>{
	User findByUsername(String username);
}
