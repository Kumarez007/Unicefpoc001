package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.exception.FailProcessException;

@Repository
public interface BookletRepository extends JpaRepository<Booklet, Long> {

	Booklet findByShortName(String bookletShortName) throws FailProcessException;

}
