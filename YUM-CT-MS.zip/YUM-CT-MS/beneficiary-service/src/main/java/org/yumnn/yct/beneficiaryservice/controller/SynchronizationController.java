/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Apr 24, 2021 12:27:05 AM
 */
package org.yumnn.yct.beneficiaryservice.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.beneficiaryservice.service.SynchronizationService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/synchronizationControl")
public class SynchronizationController {
	
	private static final Logger logger = LoggerFactory.getLogger(SynchronizationController.class);
	
	@Autowired
	SynchronizationService synchronizationService;
	
	@Operation(summary = "Post operation to get list of pending records for sync.")
	@PostMapping(value = "/getPendingRecordsForSync")
	public ResponseEntity<?> getPendingRecordsForSync(@RequestHeader Map<String, String> requestHeader, @RequestBody SyncModel syncModel) 
			throws Exception {

		logger.debug("Entered: getPendingRecordsForSync");
		try {
	    	Map<String, Object> map=synchronizationService.getPendingRecordsForSync(requestHeader,syncModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getPendingRecordsForSync: ",e);
			throw e;
		}
	    
	}
	
	@Operation(summary = "Post operation to download list of Beneficiary Data for sync.")	
	@PostMapping(value = "/downloadBeneficiarySyncData")
	public ResponseEntity<?> downloadBeneficiarySyncData(
	@RequestHeader Map<String, String> requestHeader, @RequestBody SyncModel syncModel) throws Exception {
		try {
			Map<String, Object> map=synchronizationService.downloadBeneficiarySyncData(requestHeader,syncModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In downloadBeneficiarySyncData: ",e);
			throw e;
		} 
	     
	}
	  
	  
}
