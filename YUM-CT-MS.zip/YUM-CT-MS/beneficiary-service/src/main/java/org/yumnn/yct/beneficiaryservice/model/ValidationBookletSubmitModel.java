package org.yumnn.yct.beneficiaryservice.model;

import java.util.List;
import java.util.Map;

public class ValidationBookletSubmitModel {

    private Long validationId;

    private Map<String, String> treatmentFile1Map;

    private Map<String, String> treatmentFile2Map;

    private List<ValidationBookletModel> bookletModelList;

    public Long getValidationId() {
        return validationId;
    }

    public void setValidationId(Long validationId) {
        this.validationId = validationId;
    }

    public Map<String, String> getTreatmentFile1Map() {
        return treatmentFile1Map;
    }

    public void setTreatmentFile1Map(Map<String, String> treatmentFile1Map) {
        this.treatmentFile1Map = treatmentFile1Map;
    }

    public Map<String, String> getTreatmentFile2Map() {
        return treatmentFile2Map;
    }

    public void setTreatmentFile2Map(Map<String, String> treatmentFile2Map) {
        this.treatmentFile2Map = treatmentFile2Map;
    }

    public List<ValidationBookletModel> getBookletModelList() {
        return bookletModelList;
    }

    public void setBookletModelList(List<ValidationBookletModel> bookletModelList) {
        this.bookletModelList = bookletModelList;
    }

    @Override
    public String toString() {
        return "ValidationBookletSubmitModel{" +
                "treatmentFile1Map=" + treatmentFile1Map +
                ", treatmentFile2Map=" + treatmentFile2Map +
                ", bookletModelList=" + bookletModelList +
                '}';
    }
}
