package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface DocumentsRepository extends JpaRepository<Documents, Long> {
	
	Documents findByShortName(String shortName) throws FailProcessException;
}
