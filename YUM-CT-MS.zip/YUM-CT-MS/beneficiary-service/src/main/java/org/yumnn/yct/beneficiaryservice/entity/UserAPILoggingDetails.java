package org.yumnn.yct.beneficiaryservice.entity;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "beneficiary.hst_user_api_logging_details")
public class UserAPILoggingDetails extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "hst_android_device_name")
    private String androidDeviceName;

    @Column(name = "hst_android_os_name")
    private String androidOsName;

    @Column(name = "hst_android_os_version")
    private String androidOsVersion;

    @Column(name = "hst_device_id")
    private String deviceId;

    @Column(name = "hst_request_type")
    private String requestType;

    @Column(name = "hst_request_json")
    private String requestJSON;

    @Column(name = "hst_exeception_details")
    private String execeptionDetails;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_user_fk", nullable = false)
    private User user;

	public String getAndroidDeviceName() {
		return androidDeviceName;
	}

	public void setAndroidDeviceName(String androidDeviceName) {
		this.androidDeviceName = androidDeviceName;
	}

	public String getAndroidOsName() {
		return androidOsName;
	}

	public void setAndroidOsName(String androidOsName) {
		this.androidOsName = androidOsName;
	}

	public String getAndroidOsVersion() {
		return androidOsVersion;
	}

	public void setAndroidOsVersion(String androidOsVersion) {
		this.androidOsVersion = androidOsVersion;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestJSON() {
		return requestJSON;
	}

	public void setRequestJSON(String requestJSON) {
		this.requestJSON = requestJSON;
	}

	public String getExeceptionDetails() {
		return execeptionDetails;
	}

	public void setExeceptionDetails(String execeptionDetails) {
		this.execeptionDetails = execeptionDetails;
	}


	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
   
}
