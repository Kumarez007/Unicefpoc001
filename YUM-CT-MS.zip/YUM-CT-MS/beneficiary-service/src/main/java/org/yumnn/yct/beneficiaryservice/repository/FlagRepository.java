package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Flag;
import org.yumnn.yct.common.enumeration.flag.FlagTypeEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface FlagRepository extends JpaRepository<Flag, Long> {
	
	@Query("SELECT f from Flag f where upper(f.flagType) in ('MAIN' , 'SUB') and f.cycleByProject.project.id = :projectId and f.cycleByProject.cycle.endingDate is null")
	List<Flag> retrieveHouseholdAndMemberFlagsByProjectActiveCycle(Long projectId) throws FailProcessException;
	
	@Query("SELECT f from Flag f where f.flagType = :flagType and f.cycleByProject.project.id = :projectId and f.cycleByProject.cycle.endingDate is null")
	List<Flag> retrieveFlagsByProjectActiveCycle(FlagTypeEnum flagType, Long projectId) throws FailProcessException;
}
