package org.yumnn.yct.beneficiaryservice;

import javax.servlet.MultipartConfigElement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.util.unit.DataSize;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.LocaleResolver;
import org.yumnn.yct.beneficiaryservice.configuration.CustomLocaleResolver;
import org.yumnn.yct.beneficiaryservice.service.SynchronizationService;
import org.yumnn.yct.common.CommonApplicationStarter;
import org.yumnn.yct.commonswagger.CommonSwaggerApplication;

import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@SpringBootApplication
@Import({CommonSwaggerApplication.class, CommonApplicationStarter.class})
public class BeneficiaryServiceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext app =SpringApplication.run(BeneficiaryServiceApplication.class, args);
		
		SynchronizationService synchronizationService = (SynchronizationService)app.getBean("synchronizationService");

		try {
			synchronizationService.migrateInitialRecordJson();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}

	@Bean
	public LocaleResolver localeResolver() {
		return new CustomLocaleResolver();
	}

	/**
	 * @return ResouorceBundleMessageSource
	 */
	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource rs = new ResourceBundleMessageSource();
		rs.setBasename("messages");
		rs.setDefaultEncoding("UTF-8");
		rs.setUseCodeAsDefaultMessage(true);
		return rs;
	}

	/**
	 * @param messageSource
	 * @return
	 */
	@Bean
	public LocalValidatorFactoryBean validator(MessageSource messageSource) {
		LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
		bean.setValidationMessageSource(messageSource);
		return bean;
	}
	
	@Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        factory.setMaxFileSize(DataSize.ofBytes(-1)); 
        factory.setMaxRequestSize(DataSize.ofBytes(-1));
        return factory.createMultipartConfig();
    }
	
	@Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
	


}
