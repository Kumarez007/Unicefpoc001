package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;

@Repository
public interface AttachmentRepository extends JpaRepository<Attachment, Long>{
	
	Attachment findByReferenceIdAndReferenceTypeAndIsActive(Long referenceId,String referenceType,YesNoEnum isActive) throws FailProcessException;

	@Query("SELECT t FROM Attachment t where t.referenceId = :referenceId and t.referenceType like %:referenceType% ")
	List<Attachment> getAttachmentByReferenceIdAndReferenceType(@Param("referenceId") Long referenceId, @Param("referenceType") String referenceType) throws FailProcessException;
}
