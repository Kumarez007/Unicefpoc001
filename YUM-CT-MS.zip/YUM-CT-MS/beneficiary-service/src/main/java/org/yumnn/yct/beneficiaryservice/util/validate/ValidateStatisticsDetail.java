package org.yumnn.yct.beneficiaryservice.util.validate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.Statistics;
import org.yumnn.yct.beneficiaryservice.model.StatisticsModel;
import org.yumnn.yct.beneficiaryservice.repository.StatisticsRepository;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

import java.util.Map;

@Service
public class ValidateStatisticsDetail {

    private static Logger logger = LogManager.getLogger();

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private StatisticsRepository statisticsRepository;

    @Autowired
    private CommonValidationUtil commonValidationUtil;

    public void validateStatisticsDetails(StatisticsModel statisticsModel){

        commonValidationUtil.validateIsNull("Is enrollmentCount",statisticsModel.getEnrollmentCount());

        commonValidationUtil.validateIsNull("Is admissionCount",statisticsModel.getAdmissionCount());

        commonValidationUtil.validateIsNull("Is validationCount",statisticsModel.getValidationCount());

        commonValidationUtil.validateIsNull("Is enrollmentIsUploadedCount",statisticsModel.getEnrollmentIsUploadedCount());

        commonValidationUtil.validateIsNull("Is enrollmentCount",statisticsModel.getEnrollmentCount());

        commonValidationUtil.validateIsNull("Is enrollmentCount",statisticsModel.getEnrollmentCount());


    }

}
