package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface CurrentFormRepository extends JpaRepository<CurrentForm, Long> {

	CurrentForm findByFormNumber(String formNumber) throws FailProcessException;
	
	@Query("SELECT t.currentForm FROM Enrollment t where t.booklet.shortName = :vca")
	List<CurrentForm> findFormByVca(@Param("vca")String vca) throws FailProcessException;
	
	@Query("SELECT t FROM Booklet t where t.shortName = :vca")
	Booklet findBookletByVca(@Param("vca")String vca) throws FailProcessException;
	
	@Query(value = "SELECT max(c.id) FROM CurrentForm c")
    public Long getMaxId();
	
}
