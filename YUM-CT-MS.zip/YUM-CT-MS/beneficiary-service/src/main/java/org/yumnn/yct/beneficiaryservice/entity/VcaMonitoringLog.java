package org.yumnn.yct.beneficiaryservice.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 27, 2021 7:43:00 PM
 */

@Entity
@Table(name = "beneficiary.vca_monitoring_log")
public class VcaMonitoringLog extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "failed_attempt")
	private Long failedAttempt;

	@Column(name = "viewed_attempt")
	private Long viewedAttempt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	public Long getFailedAttempt() {
		return failedAttempt;
	}

	public void setFailedAttempt(Long failedAttempt) {
		this.failedAttempt = failedAttempt;
	}

	public Long getViewedAttempt() {
		return viewedAttempt;
	}

	public void setViewedAttempt(Long viewedAttempt) {
		this.viewedAttempt = viewedAttempt;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	
}
