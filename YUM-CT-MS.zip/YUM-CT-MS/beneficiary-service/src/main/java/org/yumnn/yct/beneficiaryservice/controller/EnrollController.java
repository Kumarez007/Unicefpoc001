package org.yumnn.yct.beneficiaryservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.ReferToAnotherTFCModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationBookletSubmitModel;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/enrollcontrol")
public class EnrollController {

	private static Logger logger = LogManager.getLogger(EnrollController.class);

	@Autowired
	private EnrollmentService enrollmentService;

	@Autowired
	private ValidateUserDetail validateUserDetail;

	@Operation(summary  = "Post operation for beneficiary enrollment")
	@PostMapping(value = "/enrollBeneficiary")
	public ResponseEntity<?> enrollBeneficiary(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE1, required = false) MultipartFile caregiverFile1,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE1, required = false) MultipartFile nomineeFile1,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE2, required = false) MultipartFile caregiverFile2,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE2, required = false) MultipartFile nomineeFile2,
			EnrollmentModel enrollmentAPIModel) throws Exception {
		
		logger.debug("Entered: enrollBeneficiary");
		logger.debug("Request Body: ==> "+enrollmentAPIModel.toString());
		Map<String, MultipartFile> filesMap = createEnrollmentFileMap(caregiverFile1,caregiverFile2,nomineeFile1,nomineeFile2);
		try {
			enrollmentAPIModel.setWebCall(false);
			Map<String, Object> map = enrollmentService.enrollBeneficiary(requestHeader,filesMap,enrollmentAPIModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In enrollBeneficiary: ",e);
			throw e;
		} 
	}
	
	@Operation(summary  = "Post operation for beneficiary enrollment")
	@PostMapping(value = "/enrollBeneficiaryWeb")
	public ResponseEntity<?> enrollBeneficiaryWeb(@RequestHeader Map<String, String> requestHeader,
			@RequestBody EnrollmentModel enrollmentAPIModel) throws Exception {
		
		logger.debug("Entered: enrollBeneficiary");
		logger.debug("Request Body: ==> "+enrollmentAPIModel.toString());
		try {
			enrollmentAPIModel.setWebCall(true);
			Map<String, Object> map = enrollmentService.enrollBeneficiary(requestHeader,null,enrollmentAPIModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In enrollBeneficiary: ",e);
			throw e;
		}
	}

	@Operation(summary  = "Get for enrollment Data")
	@GetMapping(value = "/getEnrollmentData")
	public ResponseEntity<?> getEnrollmentData(@RequestHeader Map<String, String> requestHeader,
											   @RequestParam(value = "enrollmentId", required = true) Long enrollmentId)
			throws Exception {

		final String method = "enrollmentId";
		logger.debug("Entering: " + method);
		logger.debug("RequestHeader: " + requestHeader.toString());
		logger.debug("enrollmentId: " +enrollmentId);
		try {
			Map<String, Object> map = enrollmentService.getEnrollmentById(enrollmentId);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		} catch(Exception e) {
			logger.error("Error In getEnrollmentData: ",e);
			throw e;
		}
	}


	@Operation(summary  = "Post operation for beneficiary enrollment")
	@PostMapping(value = "/validateEnrollmentData")
	public ResponseEntity<?> validateEnrollmentData(@RequestHeader Map<String, String> requestHeader,
													@RequestBody ValidationBookletSubmitModel bookletSubmitModel) throws Exception {

		User user = validateUserDetail.validateAndGetUser(requestHeader);

		logger.debug("Entered: enrollBeneficiary");
		logger.debug("Request Body: ==> "+bookletSubmitModel.toString());
		try {
			Map<String, Object> map = enrollmentService.validateEnrollmentData(bookletSubmitModel, user);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In enrollBeneficiary: ",e);
			throw e;
		}
	}

	private Map<String, MultipartFile> createEnrollmentFileMap(MultipartFile caregiverFile1, MultipartFile caregiverFile2,
			MultipartFile nomineeFile1, MultipartFile nomineeFile2) {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		if(caregiverFile1 != null)
			filesMap.put(ConstantsUtil.CAREGIVER_FILE1, caregiverFile1);
	    if(nomineeFile1 != null)
	    	filesMap.put(ConstantsUtil.NOMINEE_FILE1, nomineeFile1);
	    if(caregiverFile2 != null)
	    	filesMap.put(ConstantsUtil.CAREGIVER_FILE2, caregiverFile2);
	    if(nomineeFile2 != null)
	    	filesMap.put(ConstantsUtil.NOMINEE_FILE2, nomineeFile2);
		return filesMap;
	}
	
	@Operation(summary  = "Post operation for referring beneficiary to another TFC")
	@PostMapping(value = "/referToAnotherTFCWeb")
	public ResponseEntity<?> referToAnotherTFCWeb(@RequestHeader Map<String, String> requestHeader,
			@RequestBody ReferToAnotherTFCModel referToAnotherTFCModel) throws Exception {
		
		logger.debug("Entered: referToAnotherTFCWeb");
		try {
			Map<String, Object> map = enrollmentService.referToAnotherTFCWeb(requestHeader,referToAnotherTFCModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In referToAnotherTFCWeb: ",e);
			throw e;
		} 
	}
}
