package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.SearchForm;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 10, 2021 1:57:01 AM
 */
@Repository
public interface SearchFormRepository extends JpaRepository<SearchForm, Long>{

	@Query("SELECT t FROM SearchForm t where t.curFormId = :curFormId and t.houseHoldMemberTypeId =:houseHoldMemberTypeId ")
	SearchForm getSearchFormByCurFormAndHouseHoldMemberType(@Param("curFormId") Long referenceId, @Param("houseHoldMemberTypeId") Long houseHoldMemberTypeId) throws FailProcessException;
}
