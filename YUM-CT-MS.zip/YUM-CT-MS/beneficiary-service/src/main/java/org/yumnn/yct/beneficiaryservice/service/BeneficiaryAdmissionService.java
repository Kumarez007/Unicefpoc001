package org.yumnn.yct.beneficiaryservice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.EnableValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.ReasonsNonAdmission;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.BookletByValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnableValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberRepository;
import org.yumnn.yct.beneficiaryservice.repository.ReasonOfNonAdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateAdmissionDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateEnrollmentDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.repository.ProgramEntityRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.SourceTypeEnum;
import org.yumnn.yct.common.util.Utilities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 16, 2021
 *
 */

@Service
public class BeneficiaryAdmissionService {

	private static final Logger logger = LoggerFactory.getLogger(BeneficiaryAdmissionService.class);
	
	@Autowired
	AdmissionRepository admissionRepository;

	@Autowired
	EnrollmentRepository enrollmentRepository;

	@Autowired
	ProgramEntityRepository programEntityRepository;

	@Autowired
	ReasonOfNonAdmissionRepository reasonOfNonAdmissionRepository;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private AttachmentRepository attachmentRepository;
	
	@Autowired
	private EnableValidationCodeRepository enableValidationCodeRepository;

	@Autowired
	private BookletByValidationCodeRepository bookletByValidationCodeRepository;

	@Autowired
	private HouseholdMemberService householdMemberService;
	
	@Autowired
	private CurrentFormRepository currentFormRepository;

	@Autowired
	private ValidateEnrollmentDetail validateEnrollmentDetail;
	
	@Autowired
	private ValidateAdmissionDetail validateAdmissionDetail;
	
	@Autowired
	private ValidateUserDetail validateUserDetail;
	
	@Autowired
	private HouseholdMemberRepository householdMemberRepository;

	@Autowired
	private BeneficiaryApiCallService beneficiaryApiCallService;
	
	@Autowired
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;
	
	@Autowired
	ValidationRepository validationRepository;
	
	@Autowired
	private ValidationService validationService;
	
	@Autowired
	private EnrollmentService enrollmentService;
	
	@Autowired
	private SynchronizationService synchronizationService;
	
	@Transactional
	public Map<String, Object> addBeneficiaryAdmission(Map<String, String> requestHeader,Map<String, MultipartFile> filesMap,
			BeneficiaryAdmissionModel admissionModel) throws Exception{
		
		User user = validateUserDetail.validateAndGetUser(requestHeader);
		if(!admissionModel.isWebCall()) {
			validateAdmissionDetail.validateAdmissionDetails(filesMap, admissionModel);			
		}
		Map<String, Attachment> attachmentMap = null;
		if(!admissionModel.isWebCall()) {
			attachmentMap = getListOfAttachments(filesMap);			
		}else {
			attachmentMap = getListOfAttachmentsWeb(admissionModel);
		}
	
		Admission admission = saveAdmissionData(admissionModel, user);
	
		saveAdmissionAndRelatedTables(attachmentMap, admissionModel, admission, user);
		
		addHistoricalBeneficiaryMilestone(requestHeader,admission);
		
		saveLatestRecordJsonForAdmission(admission);
	
		Map<String, Object> map = new HashMap<>();
		map.put(ConstantsUtil.ENROLLMENT_CODE, admissionModel.getEnrollmentCode());
		map.put(ConstantsUtil.ADMISSION_ID, admission.getId());
	
		return map;
		
	}
	
	private Admission saveAdmissionData(BeneficiaryAdmissionModel beneficiaryAdmissionModel, User user)
			throws Exception {

		Admission admission = new Admission();
		admission.setIsAdmitted(YesNoEnum.valueOf(beneficiaryAdmissionModel.getIsAdmitted().toUpperCase()));
		admission.setNonAdmissionOtherReasons(beneficiaryAdmissionModel.getNonAdmissionOtherReasons());
		admission.setCreatedAt(DateFormatterUtil.dateUtil(beneficiaryAdmissionModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
		admission.setSyncDate(new Date());
		
		admission.setCreatedBy(user);
		
		if(Utilities.isValidString(beneficiaryAdmissionModel.getTfcShortName())) {
				admission.setProgramEntity(programEntityRepository.findByShortName(beneficiaryAdmissionModel.getTfcShortName()));
		}
		
		if(Utilities.isValidString(beneficiaryAdmissionModel.getEnrollmentCode())) {
			Enrollment enrollment = enrollmentRepository.findByEnrollmentCode(beneficiaryAdmissionModel.getEnrollmentCode());
			if(enrollment != null) {
				admission.setEnrollment(enrollment);
			} else {
				logger.error("Enrollment code does not exist. Enrollment Code ::"+beneficiaryAdmissionModel.getEnrollmentCode());
				throw new IllegalArgumentException(messageSource.getMessage("validate.enrollmentCode", null, "Enrollment code does not exist",LocaleContextHolder.getLocale()));
			}
		}
			
		if(Utilities.isValidString(beneficiaryAdmissionModel.getNonAdmissionReasonShortName())
				&& ConstantsUtil.NO.equalsIgnoreCase(beneficiaryAdmissionModel.getIsAdmitted())) {
			ReasonsNonAdmission reasonsNonAdmission = reasonOfNonAdmissionRepository
					.findByShortName(beneficiaryAdmissionModel.getNonAdmissionReasonShortName());
			if(reasonsNonAdmission != null) {
				admission.setNonAdmissionReason(reasonsNonAdmission);
			} else {
				logger.error("Short name of reasons of non admission does not exist. Short Name::"+beneficiaryAdmissionModel.getNonAdmissionReasonShortName());
				throw new IllegalArgumentException(messageSource.getMessage("validate.reasonsNonAdmission", null, "Reasons of non admission does not exist",LocaleContextHolder.getLocale()));
			}
		}
		
		admission.setUniqueId(beneficiaryAdmissionModel.getUniqueId());

		admission = saveAdmission(admission);

		updateAdmissionRelatedTables(beneficiaryAdmissionModel, admission);

		return admission;
	}

	private void updateAdmissionRelatedTables(BeneficiaryAdmissionModel beneficiaryAdmissionModel, Admission admission)
			throws Exception {

		EnableValidationCode enableValidationCode = new EnableValidationCode();
		BookletByValidationCode bookletByValidationCode = null;
		
		if(Utilities.isValidString(beneficiaryAdmissionModel.getOtpValidationCode())) {
			
			try {
				enableValidationCode.setExpiryDate(DateFormatterUtil.dateUtil(beneficiaryAdmissionModel.getExpiryDate(),
						ConstantsUtil.DATE_FORMAT_ONLY_FOR_VIEWS));
			}catch(Exception e) {

			}
			enableValidationCode.setReferenceId(admission.getId());

			if (Utilities.isValidString(beneficiaryAdmissionModel.getIsAdmitted())
					&& beneficiaryAdmissionModel.getIsAdmitted().equalsIgnoreCase(ConstantsUtil.NO)) {
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_NON_ADMISSION);
			} else {
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_ADMISSION);
			}
			enableValidationCode.setValidationType(ConstantsUtil.VALIDATION_TYPE_OTP);
			enableValidationCode.setCreatedAt(admission.getCreatedAt());
			enableValidationCode.setCreatedBy(admission.getCreatedBy());

			bookletByValidationCode = bookletByValidationCodeRepository
					.findByValidationCodeAndIsActiveAndIsUsed(beneficiaryAdmissionModel.getOtpValidationCode(), YesNoEnum.YES, YesNoEnum.NO);
			if(bookletByValidationCode != null) {
				
				enableValidationCode.setSetupBookletByValidationCode(bookletByValidationCode);
				enableValidationCodeRepository.save(enableValidationCode);
				
				bookletByValidationCode.setIsUsed(YesNoEnum.YES);
				bookletByValidationCodeRepository.save(bookletByValidationCode);
				
			} 
			else {
				logger.debug("OTP validation code is invalid or already used.");
				return;
			}
			
		}
		
		if(Utilities.isValidString(beneficiaryAdmissionModel.getIsAdmitted()) 
				&& beneficiaryAdmissionModel.getIsAdmitted().equalsIgnoreCase(ConstantsUtil.NO)) {
			updatedTfcValidationCode(beneficiaryAdmissionModel, admission);
		}
	}

	private void updatedTfcValidationCode(BeneficiaryAdmissionModel beneficiaryAdmissionModel, Admission admission)
			throws Exception {
		
		EnableValidationCode enableValidationCode = new EnableValidationCode();;
		BookletByValidationCode bookletByValidationCode = null;
		
		if (Utilities.isValidString(beneficiaryAdmissionModel.getTfcValidationCode())) { 

			try {
				enableValidationCode.setExpiryDate(DateFormatterUtil.dateUtil(beneficiaryAdmissionModel.getExpiryDate(),
						ConstantsUtil.DATE_FORMAT_ONLY_FOR_VIEWS));
			}catch(Exception e) {

			}
			
			enableValidationCode.setReferenceId(admission.getId());
			enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_NON_ADMISSION);
			enableValidationCode.setValidationType(ConstantsUtil.VALIDATION_TYPE_TFC);
			enableValidationCode.setCreatedAt(admission.getCreatedAt());
			enableValidationCode.setCreatedBy(admission.getCreatedBy());
			
			bookletByValidationCode = bookletByValidationCodeRepository
					.findByValidationCodeAndIsActiveAndIsUsed(beneficiaryAdmissionModel.getTfcValidationCode(), YesNoEnum.YES, YesNoEnum.NO);
			if(bookletByValidationCode != null) {
				
				enableValidationCode.setSetupBookletByValidationCode(bookletByValidationCode);
				enableValidationCode(enableValidationCode);
				
				bookletByValidationCode.setIsUsed(YesNoEnum.YES);
				saveBookletByValidationCode(bookletByValidationCode);
			} 
			else {
				logger.debug("TFC validation code is invalid or already used.");
				return;
			}
		}
	}


	private void saveAdmissionAndRelatedTables(Map<String, Attachment> attachmentMap,
			BeneficiaryAdmissionModel beneficiaryAdmissionModel, Admission admission, User user) throws Exception {

		if (attachmentMap.get(ConstantsUtil.ADMISSION_FILE1) != null) {

			Attachment attachment = attachmentMap.get(ConstantsUtil.ADMISSION_FILE1);

			attachment.setSourceType(SourceTypeEnum.ADMISSION);
			attachment.setReferenceId(admission.getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setCreatedAt(admission.getCreatedAt());
			attachment.setCreatedBy(user);
			attachment.setReferenceType(ConstantsUtil.ADMISSION_FILE1);
			saveAttachment(attachment);
		}
		if (attachmentMap.get(ConstantsUtil.ADMISSION_FILE2) != null) {
			Attachment attachment = attachmentMap.get(ConstantsUtil.ADMISSION_FILE2);

			attachment.setSourceType(SourceTypeEnum.ADMISSION);
			attachment.setReferenceId(admission.getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setCreatedAt(admission.getCreatedAt());
			attachment.setCreatedBy(user);
			attachment.setReferenceType(ConstantsUtil.ADMISSION_FILE2);
			saveAttachment(attachment);
		}

		if (attachmentMap.get(ConstantsUtil.REFERRAL_FILE1) != null) {
			Attachment attachment = attachmentMap.get(ConstantsUtil.REFERRAL_FILE1);

			attachment.setSourceType(SourceTypeEnum.ADMISSION);
			attachment.setReferenceId(admission.getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setCreatedAt(admission.getCreatedAt());
			attachment.setCreatedBy(user);
			attachment.setReferenceType(ConstantsUtil.REFERRAL_FILE1);
			saveAttachment(attachment);
		}
		if (attachmentMap.get(ConstantsUtil.REFERRAL_FILE2) != null) {
			Attachment attachment = attachmentMap.get(ConstantsUtil.REFERRAL_FILE2);

			attachment.setSourceType(SourceTypeEnum.ADMISSION);
			attachment.setReferenceId(admission.getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setCreatedAt(admission.getCreatedAt());
			attachment.setCreatedBy(user);
			attachment.setReferenceType(ConstantsUtil.REFERRAL_FILE2);
			saveAttachment(attachment);
		}

	}

	private Map<String, Attachment> getListOfAttachments(Map<String, MultipartFile> filesMap) throws IOException {

		Map<String, Attachment> attachmentsMap = new HashMap<>();
		for (Entry<String, MultipartFile> file : filesMap.entrySet()) {
			if(file.getValue().getSize()>0 && file.getValue().getOriginalFilename().toString()!=null) {
				Attachment attachment = new Attachment();
				attachment.setFile(base64Encode(file.getValue()));
				attachment.setFileMimeType(file.getValue().getContentType());
				String extension = FilenameUtils.getExtension(file.getValue().getOriginalFilename()).toString();
				attachment.setExtension(extension);
				attachment.setFileSize(file.getValue().getSize());
				attachment.setName(file.getValue().getOriginalFilename().toString());
				attachmentsMap.put(file.getKey(), attachment);
			}
		}
		return attachmentsMap;
	}
	
	private Map<String, Attachment> getListOfAttachmentsWeb(BeneficiaryAdmissionModel admissionModel) throws IOException {

		Map<String, Attachment> attachmentsMap = new HashMap<>();
		
		if(!Utilities.isNULL(admissionModel.getAdmissionFile1Map()) && !Utilities.isNULLOrEmpty(admissionModel.getAdmissionFile1Map().get("size")) && !admissionModel.getAdmissionFile1Map().get("size").equals("0")) {
			Attachment attachment = new Attachment();
			
			attachment.setFile(admissionModel.getAdmissionFile1Map().get("file"));
			attachment.setFileMimeType(admissionModel.getAdmissionFile1Map().get("contentType"));
			attachment.setExtension(admissionModel.getAdmissionFile1Map().get("fileExtension"));
			attachment.setFileSize(Long.parseLong(admissionModel.getAdmissionFile1Map().get("size")));
			attachment.setName(admissionModel.getAdmissionFile1Map().get("fileName"));
			
			attachmentsMap.put(admissionModel.getAdmissionFile1Map().get("referenceKey"), attachment);			
		}
		
		if(!Utilities.isNULL(admissionModel.getAdmissionFile2Map()) && !Utilities.isNULLOrEmpty(admissionModel.getAdmissionFile2Map().get("size")) && !admissionModel.getAdmissionFile2Map().get("size").equals("0")) {
			Attachment attachment = new Attachment();
			
			attachment.setFile(admissionModel.getAdmissionFile2Map().get("file"));
			attachment.setFileMimeType(admissionModel.getAdmissionFile2Map().get("contentType"));
			attachment.setExtension(admissionModel.getAdmissionFile2Map().get("fileExtension"));
			attachment.setFileSize(Long.parseLong(admissionModel.getAdmissionFile2Map().get("size")));
			attachment.setName(admissionModel.getAdmissionFile2Map().get("fileName"));
			
			attachmentsMap.put(admissionModel.getAdmissionFile2Map().get("referenceKey"), attachment);			
		}
		
		if(!Utilities.isNULL(admissionModel.getReferralFile1Map()) && !Utilities.isNULLOrEmpty(admissionModel.getReferralFile1Map().get("size")) && !admissionModel.getReferralFile1Map().get("size").equals("0")) {
			Attachment attachment = new Attachment();
			
			attachment.setFile(admissionModel.getReferralFile1Map().get("file"));
			attachment.setFileMimeType(admissionModel.getReferralFile1Map().get("contentType"));
			attachment.setExtension(admissionModel.getReferralFile1Map().get("fileExtension"));
			attachment.setFileSize(Long.parseLong(admissionModel.getReferralFile1Map().get("size")));
			attachment.setName(admissionModel.getReferralFile1Map().get("fileName"));
			
			attachmentsMap.put(admissionModel.getReferralFile1Map().get("referenceKey"), attachment);			
		}
		
		if(!Utilities.isNULL(admissionModel.getReferralFile2Map()) && !Utilities.isNULLOrEmpty(admissionModel.getReferralFile2Map().get("size")) && !admissionModel.getReferralFile2Map().get("size").equals("0")) {
			Attachment attachment = new Attachment();
			
			attachment.setFile(admissionModel.getReferralFile2Map().get("file"));
			attachment.setFileMimeType(admissionModel.getReferralFile2Map().get("contentType"));
			attachment.setExtension(admissionModel.getReferralFile2Map().get("fileExtension"));
			attachment.setFileSize(Long.parseLong(admissionModel.getReferralFile2Map().get("size")));
			attachment.setName(admissionModel.getReferralFile2Map().get("fileName"));
			
			attachmentsMap.put(admissionModel.getReferralFile2Map().get("referenceKey"), attachment);			
		}
		
		return attachmentsMap;
	}
	

	private String base64Encode(MultipartFile file) throws IOException {
		return Base64.getEncoder().encodeToString(file.getBytes());
	}

	private List<ValidationCodeModel> getValidationCodeDetails(Admission admission) throws FailProcessException {
		
		List<ValidationCodeModel> validationCodeDetailsList = new ArrayList<ValidationCodeModel>();
		
		List<Long> admissionIdList=admissionRepository.getAdmissionIdListByEnrollment(admission.getEnrollment().getId());
		for(Long admissionId: admissionIdList) {
			
			List<EnableValidationCode> enableValidationCodeList = enableValidationCodeRepository.findByReferenceIdAndReferenceType(admissionId, ConstantsUtil.REFERENCE_TYPE_ADMISSION);
			for (EnableValidationCode enableValidationCode : enableValidationCodeList) {
				ValidationCodeModel validationCodeDetails = new ValidationCodeModel();
				validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_ADMISSION);
				validationCodeDetails.setValidationCodeType(enableValidationCode.getValidationType());
				validationCodeDetails.setValidationCode(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getValidationCode());
				validationCodeDetails.setExpirydate(DateFormatterUtil.formDateUtil(enableValidationCode.getExpiryDate()));
				validationCodeDetails.setIsUsed(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getIsUsed().getValue());
				validationCodeDetails.setIsActive(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getIsActive().getValue());
				validationCodeDetailsList.add(validationCodeDetails);
			}
		}
		return validationCodeDetailsList;
	}
	
	@Transactional
	public Map<String, Object> addAdmissionUpdateHouseholdMember(Map<String, String> requestHeader, List<Map<String, MultipartFile>> fileList,BeneficiaryAdmissionModel admissionModel) 
	throws Exception {
		User user = validateUserDetail.validateAndGetUser(requestHeader);

		validateAdmissionDetail.validateAdmissionDetails(fileList.get(0), admissionModel);

		Map<String, Attachment> attachmentMap = getListOfAttachments(fileList.get(0));

		Admission admission = saveAdmissionData(admissionModel, user);
		
		saveAdmissionAndRelatedTables(attachmentMap, admissionModel, admission, user);
		
		addHistoricalBeneficiaryMilestone(requestHeader,admission);
		
		admissionModel.setAdmissionId(admission.getId().toString());
		
		updateHouseholdMemberList(admissionModel,fileList.get(1),admission);

		saveLatestRecordJsonForAdmission(admission);

		Map<String, Object> map = new HashMap<>();
		map.put(ConstantsUtil.ENROLLMENT_CODE, admissionModel.getEnrollmentCode());
		map.put(ConstantsUtil.ADMISSION_ID, admission.getId());
		return map;
	}
	
	private void updateHouseholdMemberList(BeneficiaryAdmissionModel admissionModel,Map<String, MultipartFile> hhmfilesMap,Admission admission)
			throws Exception {
		
		if(Utilities.isValidString(admissionModel.getHouseholdMemberList())) {
			CurrentForm currentForm=getCurrentFormbyId(Long.parseLong(admissionModel.getEnrollmentCode()));
			List<HouseholdMemberModel> householdMemberList = new ObjectMapper()
					.readValue(admissionModel.getHouseholdMemberList(), new TypeReference<List<HouseholdMemberModel>>() {
					});
			
			validateEnrollmentDetail.validateHouseholdDetails(hhmfilesMap, householdMemberList);
			
			for (HouseholdMemberModel householdMemberModel : householdMemberList) {
				householdMemberModel.setCurrentFormId(currentForm.getId().toString());
				householdMemberModel.setCreatedDate(admissionModel.getCreatedDate());
			}
			householdMemberService.updateHouseholdMemberDetails(householdMemberList, hhmfilesMap,admission);
		} else {
			logger.debug("HouseholdMemberList is empty or null");
		}
	}
	
	private Admission saveAdmission(Admission admission) {
		try {
			Admission admissionNew=admissionRepository.save(admission);
			return admissionNew;
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
	}
	
	private void enableValidationCode(EnableValidationCode enableValidationCode) {
		try {
			enableValidationCodeRepository.save(enableValidationCode);
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
	}
	
	private void saveBookletByValidationCode(BookletByValidationCode bookletByValidationCode){
		try {
			bookletByValidationCodeRepository.save(bookletByValidationCode);
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
	}
	
	private void saveAttachment(Attachment attachment){
		try {
			attachmentRepository.save(attachment);
		}
		catch (Exception e) {
			logger.error("Error while saving",e);
			throw new FailProcessException();
		}
		
	}
	
	private CurrentForm getCurrentFormbyId(Long id) {
		try {
			Optional<CurrentForm> currentFormOpt = currentFormRepository.findById(id);
			CurrentForm currentForm=currentFormOpt.get();
		    return currentForm;
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
		
	}
	
	@SuppressWarnings("unused") // to be used for milestone
	private List<HouseholdMemberModel> getHouseholdMemberList(CurrentForm currentForm,Long admissionId)  throws FailProcessException{
		
		List<HouseholdMemberModel> hhmModelList=new ArrayList<HouseholdMemberModel>();
		HouseholdMemberModel hhmModel;
		List<HouseholdMember> hhmList =householdMemberRepository.getAdmissionHouseholdDetails(currentForm.getId(),admissionId,SourceTypeEnum.ADMISSION.toString());
		
		for (HouseholdMember hmm:hhmList) {
			
			hhmModel = setHouseholdMemberModel(hmm);
			
			hhmModelList.add(hhmModel);
		}
		
		return hhmModelList;
	}
	
	private HouseholdMemberModel setHouseholdMemberModel(HouseholdMember hmm) {
		HouseholdMemberModel hhmModel;
		hhmModel=new HouseholdMemberModel();
		
		hhmModel.setId(hmm.getId().toString());
		hhmModel.setFullName(hmm.getFirstName()==null?"":(hmm.getFirstName().concat(hmm.getLastName()==null?"":ConstantsUtil.SPACE_DELIMETER+hmm.getLastName())));
		hhmModel.setCurrentFormId(hmm.getCurrentForm()==null?null:hmm.getCurrentForm().getId().toString());
		hhmModel.setPhoneNumber(hmm.getPhoneNumber());
		hhmModel.setDocumentReferenceNumber(hmm.getDocumentReferenceNumber());
		hhmModel.setIsAssignedAsPaymentReceiver(hmm.getIsAssignedAsPaymentReceiver()==null?YesNoEnum.NO.getValue():hmm.getIsAssignedAsPaymentReceiver().getValue());
		//hhmModel.setIsRequireInvestigation(hmm.getIsRequireInvestigation()==null?YesNoEnum.NO.getValue():hmm.getIsRequireInvestigation().getValue());
		hhmModel.setIsPrimary(hmm.getIsPrimary()==null?YesNoEnum.NO.getValue():hmm.getIsPrimary().getValue());
		hhmModel.setGenderShortName(hmm.getGender()==null?"":hmm.getGender().getShortName());
		hhmModel.setDateOfBirth(DateFormatterUtil.formDateUtil(hmm.getDateOfBirth()));
		hhmModel.setCatDocShortName(hmm.getDocument()==null?"":hmm.getDocument().getShortName());
		hhmModel.setRelationshipShortName(hmm.getRelationship()==null?"":hmm.getRelationship().getShortName());
		hhmModel.setHouseholdMemberTypeShortName(hmm.getHouseholdMemberType()==null?"":hmm.getHouseholdMemberType().getShortName());
		hhmModel.setCreatedBy(hmm.getCreatedBy()==null?"":hmm.getCreatedBy().getId().toString());
		hhmModel.setCreatedDate(DateFormatterUtil.creationDateUtil(hmm.getCreatedAt()));
		return hhmModel;
	}
	
	private void addHistoricalBeneficiaryMilestone(Map<String, String> requestHeader, Admission admission) 
			throws Exception {
		
		String projectShortName=admission.getEnrollment()
				.getCurrentForm()
				.getProject()
				.getShortName()
				.toString();
		
		CycleByProjectModel cycleByProjectModel =beneficiaryApiCallService.getCycleByProjectName(requestHeader,projectShortName);
		
		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setCurrentFormId(admission.getEnrollment().getCurrentForm().getId());
		historicalBeneficiaryModel.setBookletId(admission.getEnrollment().getBooklet().getId());
		historicalBeneficiaryModel.setMilestoneReferenceId(admission.getId());
		historicalBeneficiaryModel.setCycleId(cycleByProjectModel.getCycleId());
		historicalBeneficiaryModel.setCreatedDate(admission.getCreatedAt());
		historicalBeneficiaryModel.setMilestoneType(MilestoneTypeEnum.ADMISSION.toString());
			
		historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);
		
	}
	
	public Map<String, Object> addAdmissionDetailsToMap(Admission admission)  throws FailProcessException {
		Map<String, Object> map = new LinkedHashMap<>();
        
        map.put(ConstantsUtil.ADMISSION_ID, admission.getId());
        map.put(ConstantsUtil.IS_AdMITTED, admission.getIsAdmitted());
        map.put(ConstantsUtil.NON_ADMISSION_OTHER_REASONS, admission.getNonAdmissionOtherReasons());
        map.put(ConstantsUtil.ENROLLMENT_ID, (admission.getEnrollment()==null?null:admission.getEnrollment().getId()));
        map.put(ConstantsUtil.ENROLLMENT_CODE, (admission.getEnrollment()==null?null:admission.getEnrollment().getEnrollmentCode()));
        map.put(ConstantsUtil.PROGRAM_ENTITY_SHORT_NAME, (admission.getProgramEntity()==null?null:admission.getProgramEntity().getShortName()));
        map.put(ConstantsUtil.NON_ADMISSION_REASON, (admission.getNonAdmissionReason()==null?null:admission.getNonAdmissionReason().getShortName()));
        map.put(ConstantsUtil.CREATED_AT, DateFormatterUtil.creationDateUtil(admission.getCreatedAt()));
        map.put(ConstantsUtil.CREATED_BY, (admission.getCreatedBy()==null?null:admission.getCreatedBy().getId()));
        map.put(ConstantsUtil.UPDATED_AT, DateFormatterUtil.creationDateUtil(admission.getUpdatedAt()));
        map.put(ConstantsUtil.UPDATED_BY, (admission.getUpdatedBy()==null?null:admission.getUpdatedBy().getId()));
        map.put(ConstantsUtil.TFC_SHORT_NAME, (admission.getProgramEntity()==null?null:admission.getProgramEntity().getShortName()));
        map.put(ConstantsUtil.VALIDATION_CODE_DETAILS, getValidationCodeDetails(admission));
        map.put(ConstantsUtil.RECORD_UNIQUE_ID, admission.getUniqueId());
		return map;
	}
	
	private void saveLatestRecordJsonForAdmission(Admission admission) throws JsonProcessingException {
		
		logger.debug("===== saveLatestRecordJsonForAdmission Start ======");
			
		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		Map<String, Object> validationDataMap = null;
		
		Date syncDate=admission.getSyncDate();
		
		Optional<Enrollment> enrollmentOpt = enrollmentRepository.findById(admission.getEnrollment().getId());
		Enrollment enrollment=enrollmentOpt.orElse(null);
		Map<String, Object> enrollmentDataMap = enrollmentService.addEnrollmentDetailsToMap(enrollment.getId(),enrollment);
		
		Map<String, Object> admissionDataMap = addAdmissionDetailsToMap(admission);
		
		Validation validation = validationRepository.getValidationByAdmission(admission.getId());
		if(validation!=null) {
			validationDataMap = validationService.addValidationDetailsToMap(validation.getId(),validation);
		}
			
		beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);	
		beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);	
		beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);
			
		synchronizationService.saveLatestJsonRecordForDownload(enrollment.getCurrentForm(),syncDate,beneficiaryJsonMap);
		
		logger.debug("======= saveLatestRecordJsonForAdmission End =======");
	}
	
}
