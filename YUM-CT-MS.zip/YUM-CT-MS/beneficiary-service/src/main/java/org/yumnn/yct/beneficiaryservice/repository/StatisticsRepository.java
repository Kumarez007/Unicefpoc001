package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.Statistics;
import org.yumnn.yct.common.exception.FailProcessException;

@Repository
public interface StatisticsRepository extends JpaRepository<Statistics, Long> {

    Statistics findByUniqueId(String uniqueId) throws FailProcessException;
}
