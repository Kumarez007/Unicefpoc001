package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.VcaMonitoringLog;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 27, 2021 7:50:06 PM
 */

@Repository
public interface VcaMonitoringLogRepository extends JpaRepository<VcaMonitoringLog, Long>{
	
	@Query(value = "SELECT t FROM VcaMonitoringLog t where t.createdBy.id=:userId")
	VcaMonitoringLog getVcaLogByUser(@Param("userId") Long userId) throws FailProcessException;
	
}
