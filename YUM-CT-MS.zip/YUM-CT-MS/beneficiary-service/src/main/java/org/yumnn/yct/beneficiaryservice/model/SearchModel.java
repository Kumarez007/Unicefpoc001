package org.yumnn.yct.beneficiaryservice.model;


/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt May 10, 2021 7:21:22 PM
 */
public interface SearchModel {

   
	Long getBeneficiaryId();
	Long getAdmissionId();
	Long getValidationId();
	String getVcaNumber();
	String getDateOfEnrollment();
	String getFullName();
	Long getProjectId();
	

}
