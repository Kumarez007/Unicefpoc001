package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.util.ConstantsUtil;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class NewEnrollmentRepository {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	
	EntityManager em ;
	
	public void insertEnrolmentData(EnrollmentModel enrollmentAPIModel) throws Exception {
		try {
			em = entityManagerFactory.createEntityManager();
			HouseholdMemberModel householdMemberModelData=new HouseholdMemberModel();

			em.getTransaction().begin();

			List<HouseholdMemberModel> householdMemberList = new ObjectMapper()
					.readValue(enrollmentAPIModel.getHouseholdMemberList(), new TypeReference<List<HouseholdMemberModel>>() {
					});
			for (HouseholdMemberModel householdMemberModel : householdMemberList) {
				if(householdMemberModel.getHouseholdMemberTypeShortName().equals(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER)) {
					householdMemberModelData.setFullName(householdMemberModel.getFullName());
					householdMemberModelData.setPhoneNumber(householdMemberModel.getPhoneNumber());
					householdMemberModelData.setDocumentReferenceNumber(householdMemberModel.getDocumentReferenceNumber());
					break;
				}
			}
			Query query = em.createNativeQuery("INSERT INTO beneficiary.trc_hst_enrollment (project_short_name,comments_data,tfc_short_name,place_of_admission_short_name,otp_nut_officer_name,otp_geoarea_short_name,otp_nut_officer_ref_number,otp_nut_officer_phone_number,is_require_investigation,is_ref_from_other_tfc,household_member_fullname,document_ref_number,household_phonenumber,otp_ref_number,created_at,id_user_created_by,id_booklet_shortname,unique_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			query.setParameter(1, enrollmentAPIModel.getProjectShortName());
			query.setParameter(2, enrollmentAPIModel.getComments());
			query.setParameter(3, enrollmentAPIModel.getTfcShortName());
			query.setParameter(4, enrollmentAPIModel.getPlaceOfAdmissionShortName());
			query.setParameter(5, enrollmentAPIModel.getOtpNutritionOfficerName());
			query.setParameter(6, enrollmentAPIModel.getOtpGeoAreaShortName());
			query.setParameter(7, enrollmentAPIModel.getOtpNutritionOfficerRefrenceNumber());
			query.setParameter(8, enrollmentAPIModel.getOtpNutritionOfficerPhoneNumber());
			query.setParameter(9, enrollmentAPIModel.getIsRequireInvestigation());
			query.setParameter(10, enrollmentAPIModel.getIsRefferdFromOtherTFC());
			query.setParameter(11, householdMemberModelData.getFullName());
			query.setParameter(12, householdMemberModelData.getDocumentReferenceNumber());
			query.setParameter(13, householdMemberModelData.getPhoneNumber());
			query.setParameter(14, enrollmentAPIModel.getOtpReferenceNumber());
			query.setParameter(15, enrollmentAPIModel.getCreatedDate());
			query.setParameter(16, enrollmentAPIModel.getCreatedBy());
			query.setParameter(17, enrollmentAPIModel.getBookletShortName());
			query.setParameter(18, enrollmentAPIModel.getUniqueId());
			query.executeUpdate();
			
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new Exception(e);
		} finally {
			em.close();
		}
	}
	
	public void insertValidationData(ValidationModel validationModel) throws Exception {
		try {
			em = entityManagerFactory.createEntityManager();

			em.getTransaction().begin();
			Query query = em.createNativeQuery("INSERT INTO beneficiary.trc_hst_validation (doucment_ref_number,document_short_name,no_of_periods,no_of_days,date_from,date_to,servicetype_shortname,doctor_name,created_at,id_user_created_by,admission_id,unique_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
			query.setParameter(1, validationModel.getDocumentReferenceNo());
			query.setParameter(2, validationModel.getDocumentShortName());
			query.setParameter(3, validationModel.getNumberOfPeriods());
			query.setParameter(4, validationModel.getNumberOfDays());
			query.setParameter(5, validationModel.getDateFrom());
			query.setParameter(6, validationModel.getDateTo());
			query.setParameter(7, validationModel.getServiceTypeShortName());
			query.setParameter(8, validationModel.getDoctorName());
			query.setParameter(9, validationModel.getCreatedDate());
			query.setParameter(10, validationModel.getCreatedBy());
			query.setParameter(11, validationModel.getAdmissionId());
			query.setParameter(12, validationModel.getUniqueId());
			query.executeUpdate();
			
			insertValidationCodeData(validationModel);
			
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new Exception(e);
		} finally {
			em.close();
		}
	}
	
	public void insertValidationCodeData(ValidationModel validationModel) throws Exception {

		List<ValidationCodeModel> validationCodeDetails = new ObjectMapper()
				.readValue(validationModel.getValidationCodeDetails(), new TypeReference<List<ValidationCodeModel>>() {
				});
			for (ValidationCodeModel validationCodeModel : validationCodeDetails) {
				Query query = em.createNativeQuery("INSERT INTO beneficiary.trc_stp_booklet_by_validation_code (validation_code,expiry_date,is_validationcode_used,validation_code_type,reference_type) VALUES (?,?,?,?,?)");
				query.setParameter(1, validationCodeModel.getValidationCode());
				query.setParameter(2, validationCodeModel.getExpirydate());
				query.setParameter(3, validationCodeModel.getIsValidationCodeUsed());
				query.setParameter(4, validationCodeModel.getValidationCodeType());
				query.setParameter(5, validationCodeModel.getReferenceType());
				query.executeUpdate();
			}
	}
	
	public void insertBeneficiaryAdmissionData(BeneficiaryAdmissionModel admissionModel) throws Exception {
		try {
			em = entityManagerFactory.createEntityManager();

			em.getTransaction().begin();
			Query query = em.createNativeQuery("INSERT INTO beneficiary.trc_hst_admission (otp_validation_code,is_validation_code_used,tfc_short_name,non_admission_other_reasons,non_admission_reason_shortname,enrollment_code,expiry_date,tfc_validation_code,created_at,id_user_created_by,program_entity_shortname,unique_id,is_admitted) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
			query.setParameter(1, admissionModel.getOtpValidationCode());
			query.setParameter(2, admissionModel.getIsValidationCodeUsed());
			query.setParameter(3, admissionModel.getTfcShortName());
			query.setParameter(4, admissionModel.getNonAdmissionOtherReasons());
			query.setParameter(5, admissionModel.getNonAdmissionReasonShortName());
			query.setParameter(6, admissionModel.getEnrollmentCode());
			query.setParameter(7, admissionModel.getExpiryDate());
			query.setParameter(8, admissionModel.getTfcValidationCode());
			query.setParameter(9, admissionModel.getCreatedDate());
			query.setParameter(10, admissionModel.getCreatedBy());
			query.setParameter(11, admissionModel.getProgramEntityShortName());
			query.setParameter(12, admissionModel.getUniqueId());
			query.setParameter(13, admissionModel.getIsAdmitted());
			query.executeUpdate();
			
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new Exception(e);
		} finally {
			em.close();
		}
	}
}
