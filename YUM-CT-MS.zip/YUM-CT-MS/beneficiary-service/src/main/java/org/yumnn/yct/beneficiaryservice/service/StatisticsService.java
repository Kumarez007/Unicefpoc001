package org.yumnn.yct.beneficiaryservice.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.entity.Statistics;
import org.yumnn.yct.beneficiaryservice.model.StatisticsModel;
import org.yumnn.yct.beneficiaryservice.repository.BeneficiaryStatisticsRepository;
import org.yumnn.yct.beneficiaryservice.repository.StatisticsRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateStatisticsDetail;

@Service
public class StatisticsService {

    @Autowired
    private StatisticsRepository statisticsRepository;

    @Autowired
    private ValidateStatisticsDetail validateStatisticsDetail;
    
    @Autowired
    private BeneficiaryStatisticsRepository beneficiaryStatisticsRepository;
      
    @Autowired
    private UserRepository userRepository;
    
    public Map<String, Object> saveStatisticDetails(StatisticsModel statisticsModel){
    	
    	validateStatisticsDetail.validateStatisticsDetails(statisticsModel);
    	
    	Statistics statistics = convertModelToEntityObject(statisticsModel);
    	statistics = statisticsRepository.save(statistics);
    	
    	Map<String, Object> map = new HashMap<>();
    	
    	if(statistics != null) {
    		map.put("200", "Success");
    	}else {
    		map.put("201", "Failed");  
    	}
    	
		return map;    	
    }

	private Statistics convertModelToEntityObject(StatisticsModel statisticsModel) {
		Statistics statistics = new Statistics();
    	statistics.setAdmissionCount(statisticsModel.getAdmissionCount());
    	statistics.setAdmissionIsUploadedCount(statisticsModel.getAdmissionIsUploadedCount());
    	statistics.setAndroidOs(statisticsModel.getAndroidOs());
    	statistics.setAndroidVersionName(statisticsModel.getAndroidVersionName());
    	java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
    	statistics.setDate(date);
    	statistics.setEnrollmentCount(statisticsModel.getEnrollmentCount());
    	statistics.setEnrollmentIsUploadedCount(statisticsModel.getEnrollmentIsUploadedCount());
    	statistics.setUniqueId(statisticsModel.getUniqueId());
    	statistics.setUploaded(statisticsModel.getUploaded());
    	statistics.setUser(userRepository.findByUsername(statisticsModel.getUserName()));
    	statistics.setValidationCount(statisticsModel.getValidationCount());
    	statistics.setValidationIsUploadedCount(statisticsModel.getValidationIsUploadedCount());
    	
    	return statistics;
	}
	
	public Map<String, Object> validateStatisticsCount(String uniqueId) {
		Map<String, Object> responseMap = new HashMap<String, Object>();
		Statistics statistics = this.beneficiaryStatisticsRepository.getStatisticsByUniqueIdAndDate(uniqueId);
		if(statistics != null) {
			long admissionCount = this.beneficiaryStatisticsRepository.getAdmissionCount(statistics.getAdmissionCount());
			long enrollmentCount = this.beneficiaryStatisticsRepository.getEnrollmentCount(statistics.getEnrollmentCount());
			long validationCount = this.beneficiaryStatisticsRepository.getValidationCount(statistics.getValidationCount());
					
			if(statistics.getAdmissionCount() != admissionCount) {
				responseMap.put("Admission count", "Count mismatched");
			}
			
			if(statistics.getEnrollmentCount() != enrollmentCount) {
				responseMap.put("Enrollment count", "Count mismatched");
			}
			
			if(statistics.getValidationCount() != validationCount) {
				responseMap.put("Validation count", "Count mismatched"); 
			}
		}
		return responseMap;
	}


}
