package org.yumnn.yct.beneficiaryservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.yumnn.yct.beneficiaryservice.entity.CurrentVoucher;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.CurrentVoucherModel;
import org.yumnn.yct.beneficiaryservice.repository.CurrentVoucherRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.Utilities;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Service
public class CurrentVoucherService {

	private static Logger logger = LogManager.getLogger(CurrentVoucherService.class);
  
	@Autowired
	private CurrentVoucherRepository currentVoucherRepository;

	@Autowired
	private EnrollmentRepository enrollmentRepository;

	/**
	 * @param List<CurrentVoucherModel>
	 * @return List<CurrentVoucherModel>
	 * @throws Exception
	 */
	@Transactional
	public List<CurrentVoucherModel> saveCurrentVoucherDetails(List<CurrentVoucherModel> currentVoucherModelDetails,User user)
			throws Exception {
		logger.debug("Entrering into saveCurrentVoucherDetails()");
		List<CurrentVoucherModel> responseModelList = new ArrayList<CurrentVoucherModel>();
		for (CurrentVoucherModel currentVoucherModel : currentVoucherModelDetails) {
			CurrentVoucherModel responseModel = saveCurrentVoucher(currentVoucherModel,user);
			responseModelList.add(responseModel);
		}
		logger.debug("Exiting from saveCurrentVoucherDetails()");
		return responseModelList;
	}

	/**
	 * @param CurrentVoucherModel
	 * @return CurrentVoucherModel
	 * @throws Exception
	 */
	private CurrentVoucherModel saveCurrentVoucher(CurrentVoucherModel currentVoucherModel, User user) throws Exception {

		CurrentVoucher currentVoucher = convertToCurrentVoucherEntity(currentVoucherModel,user);
		currentVoucher = saveCurrentVoucher(currentVoucher);
		currentVoucherModel.setId(currentVoucher.getId().toString());

		return currentVoucherModel;
	}

	/**
	 * @param CurrentVoucherModel
	 * @return CurrentVoucher
	 * @throws Exception
	 */
	private CurrentVoucher convertToCurrentVoucherEntity(CurrentVoucherModel currentVoucherModel,User user) throws Exception {

		CurrentVoucher currentVoucher = new CurrentVoucher();
		setEnrollment(currentVoucherModel, currentVoucher);
		setCreatedDate(currentVoucherModel, currentVoucher);
		setCreatedBy(user, currentVoucher);
		setIsActive(currentVoucher);
		return currentVoucher;
	}

	/**
	 * @param CurrentVoucher
	 * @return void
	 * @throws Exception
	 */
	private void setIsActive(CurrentVoucher currentVoucher) throws Exception {
		currentVoucher.setIsActive(YesNoEnum.YES);
	}

	/**
	 * @param CurrentVoucherModel, @param CurrentVoucher
	 * @return void
	 * @throws Exception
	 */
	private void setCreatedDate(CurrentVoucherModel currentVoucherModel, CurrentVoucher currentVoucher)
			throws Exception {
		currentVoucher.setCreatedAt(DateFormatterUtil.dateUtil(currentVoucherModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
	}

	/**
	 * @param CurrentVoucherModel, @param CurrentVoucher
	 * @return void
	 */
	private void setCreatedBy(User user, CurrentVoucher currentVoucher) {
			currentVoucher.setCreatedBy(user);
	}

	/**
	 * @param CurrentVoucherModel, @param CurrentVoucher
	 * @return void
	 * @throws Exception
	 */
	private void setEnrollment(CurrentVoucherModel currentVoucherModel, CurrentVoucher currentVoucher) {
		String enrolId = currentVoucherModel.getEnrollmentId();
		if (Utilities.isValidString(enrolId)) {
			Optional<Enrollment> enrollment = enrollmentRepository.findById(Long.parseLong(enrolId));
			currentVoucher.setEnrollment(enrollment.get());
		}
	}
	
	private CurrentVoucher saveCurrentVoucher(CurrentVoucher currentVoucher) {
		try {
			CurrentVoucher currentVoucherNew = currentVoucherRepository.save(currentVoucher);
		    return currentVoucherNew;
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
		
	}
	
	
	
}


