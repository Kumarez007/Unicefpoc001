package org.yumnn.yct.beneficiaryservice.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.service.NewEnrollService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/newenrollcontrol")
public class NewEnrollController {

	private static Logger logger = LogManager.getLogger(NewEnrollController.class);
	
	@Autowired
	NewEnrollService newEnrollService;
	
	@Operation(summary  = "Post operation for new beneficiary enrollment")
	@PostMapping(value = "/newEnrollBeneficiary")
	public ResponseEntity<?> newEnrollBeneficiary(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE1, required = false) MultipartFile caregiverFile1,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE1, required = false) MultipartFile nomineeFile1,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE2, required = false) MultipartFile caregiverFile2,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE2, required = false) MultipartFile nomineeFile2,
			EnrollmentModel enrollmentAPIModel) throws Exception {
		
		logger.debug("Entered: newEnrollBeneficiary");
		logger.debug("Request Body: ==> "+enrollmentAPIModel.toString());
		try {
			Map<String, Object> map = newEnrollService.insertEnrolmentData(enrollmentAPIModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In newEnrollBeneficiary: ",e);
			throw e;
		} 
	}
	
	@Operation(summary  = "Post operation for new beneficiary enrollment")
	@PostMapping(value = "/newValidateBeneficiary")
	public ResponseEntity<?> newValidateBeneficiary(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.ID_DOCUMENT_FILE1, required = false) MultipartFile idDocumentFile1,
			@RequestParam(value = ConstantsUtil.ID_DOCUMENT_FILE2, required = false) MultipartFile idDocumentFile2,
			@RequestParam(value = ConstantsUtil.TREATMENT_DOC_FILE1, required = false) MultipartFile treatmentDocFile1,
			@RequestParam(value = ConstantsUtil.TREATMENT_DOC_FILE2, required = false) MultipartFile treatmentDocFile2,
			@RequestParam(value = ConstantsUtil.UPLOAD_VCA_FILE1, required = false) MultipartFile uploadVcaFile1,
			@RequestParam(value = ConstantsUtil.UPLOAD_VCA_FILE2, required = false) MultipartFile uploadVcaFile2,
			ValidationModel validationModel) throws Exception {
		
		logger.debug("Entered: newValidateBeneficiary");
		logger.debug("Request Body: ==> "+validationModel.toString());
		try {
			Map<String, Object> map = newEnrollService.insertValidationData(validationModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In newValidateBeneficiary: ",e);
			throw e;
		} 
	}
	
	@Operation(summary  = "Post operation for new beneficiary enrollment")
	@PostMapping(value = "/newAddAdmissionUpdateHouseholdMember")
	public ResponseEntity<?> newAddAdmissionUpdateHouseholdMember(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE1, required = false) MultipartFile admissionFile1,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE2, required = false) MultipartFile admissionFile2,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE1, required = false) MultipartFile referralFile1,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE2, required = false) MultipartFile referralFile2,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE1, required = false) MultipartFile caregiverFile1,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE1, required = false) MultipartFile nomineeFile1,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE2, required = false) MultipartFile caregiverFile2,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE2, required = false) MultipartFile nomineeFile2,
			BeneficiaryAdmissionModel admissionModel) throws Exception {

		logger.debug("Entered: newEnrollBeneficiary");
		logger.debug("Request Body: ==> "+admissionModel.toString());
		try {
			Map<String, Object> map = newEnrollService.insertAdmissionData(admissionModel);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In newAddAdmissionUpdateHouseholdMember: ",e);
			throw e;
		} 
	}
}
