package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 14, 2021 5:33:20 PM
 */
public interface PaymentByServiceCardInfoModel {
	
	public String getVcaNumber();

	public String getDateOfService();
	
	public String getServiceType();
	
	public String getPaymentAmount();
	
	public String getIsUsed();
	
	public String getIsRedeemed();
	
	public String getPaymentDate();
	
	public String getValidationCode();
	
	public String getEnrollmentDate();
	

}
