package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.HouseholdMemberLog;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 9, 2021 2:10:57 PM
 */

@Repository
public interface HouseholdMemberLogRepository extends JpaRepository<HouseholdMemberLog, Long>{

}
