package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.SearchForm;
import org.yumnn.yct.beneficiaryservice.model.ContactCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.SourceTypeEnum;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface HouseholdMemberRepository extends JpaRepository<HouseholdMember, Long> {

	HouseholdMember findByMemberCode(String memberCode) throws FailProcessException;
	
	@Query( value = "SELECT chm.id as hhmId from beneficiary.cur_household_member chm where chm.id_form_fk=:curFormId "
			+ " and chm.id_household_member_type_fk=:hhmTypeId ", nativeQuery = true)
	Long getHouseholdMemberId(@Param("curFormId") Long curFormId,@Param("hhmTypeId") Long hhmTypeId) throws FailProcessException;
	
	List<HouseholdMember> findByCurrentForm(CurrentForm currentForm) throws FailProcessException;
	
	HouseholdMember findByCurrentFormAndHouseholdMemberType(CurrentForm currentForm,HouseholdMemberType householdMemberType);
	
	//to be used for milestone
	@Query( value = "SELECT * FROM beneficiary.cur_household_member chm where chm.id_form_fk=:curFormId and (chm.source_type is null or upper(chm.source_type)=:sourceType)", nativeQuery = true)
	List<HouseholdMember> getEnrollmentHouseholdDetails(@Param("curFormId") Long curFormId, @Param("sourceType") String sourceType ) throws FailProcessException;

	@Query( value = "SELECT * FROM beneficiary.cur_household_member chm where chm.id_form_fk=:curFormId and chm.source_id=:sourceId and upper(chm.source_type)=:sourceType", nativeQuery = true)
	List<HouseholdMember> getAdmissionHouseholdDetails(@Param("curFormId") Long curFormId, @Param("sourceId") Long sourceId,@Param("sourceType") String sourceType ) throws FailProcessException;
	
	
	@Modifying
	@Query("update HouseholdMember t set sourceId = :sourceId, sourceType=:sourceType  where" + 
			"	 t.currentForm = :currentForm")
	public void updateHouseholdSource(@Param("sourceId") Long sourceId,@Param("sourceType") SourceTypeEnum sourceType,CurrentForm currentForm) throws FailProcessException;
	
	@Query( value = "SELECT replace(concat(bchm.first_name,' ',bchm.last_name),' null','') as fullName, bcr.name as relationship, bg.name as gender, bcd.name as idType,bchm.document_reference_number as idReference, bchm.is_primary as isPrimary  "
			+ " FROM beneficiary.cur_household_member bchm "
			+ " left outer join beneficiary.cat_gender bg on bg.id=bchm.id_gender_fk"
			+ " left outer join beneficiary.cat_relationship bcr on bcr.id=bchm.id_relationship_fk"
			+ " left outer join beneficiary.cat_documents bcd on bcd.id=bchm.id_documents_fk"
			+ " where bchm.id_form_fk=:curFormId ", nativeQuery = true)
	List<MemberCardInfoModel> getMemberCardInfo(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = "SELECT replace(concat(bchm.first_name,' ',bchm.last_name),' null','') as fullName, bcr.name as relationship, bg.name as gender, bcd.name as idType,bchm.document_reference_number as idReference, bchm.is_primary as isPrimary  "
			+ " FROM beneficiary.cur_household_member bchm "
			+ " left outer join beneficiary.cat_gender bg on bg.id=bchm.id_gender_fk"
			+ " left outer join beneficiary.cat_relationship bcr on bcr.id=bchm.id_relationship_fk"
			+ " left outer join beneficiary.cat_documents bcd on bcd.id=bchm.id_documents_fk"
			+ " where bchm.id_form_fk=:curFormId and id_household_member_type_fk in (1,2,3) ", nativeQuery = true)
	List<MemberCardInfoModel> getMemberCardInfoForNVS(@Param("curFormId") Long curFormId) throws FailProcessException;
	
	@Query( value = " (select phone_number as phoneNo, phone_source as phoneSource from messages.cur_contact_information_by_form ccibf "
			+ "where ccibf.id_cur_form_fk =:curFormId and phone_source<>:phoneSource) "
			+ "union all "
			+ "(select phone_number as phoneNo, phone_source as phoneSource from messages.cur_contact_information_by_form ccibf "
			+ "where ccibf.id_cur_form_fk=:curFormId and phone_source=:phoneSource and phone_type='CELLPHONE' order by ccibf.id desc limit 1) ", nativeQuery = true)
	List<ContactCardInfoModel> getBeneficiaryContacts(@Param("curFormId") Long curFormId, @Param("phoneSource") String phoneSource) throws FailProcessException;
	
	@Query( value = "SELECT ccibf.phone_number as ccibf FROM beneficiary.cur_contact_information_by_form ccibf where ccibf .id_cur_form_fk =:curFormId and coalesce(phone_number, '') != '' order by ccibf.id desc limit 1", nativeQuery = true)
	String getContactDetailsFromPaymentList(@Param("curFormId") Long curFormId ) throws FailProcessException;
	
	@Query( value = "SELECT chm.phone_number FROM beneficiary.cur_household_member chm where chm.id_form_fk =:curFormId and coalesce(phone_number, '') != '' order by chm.id desc limit 1", nativeQuery = true)
	String getContactDetailsFromOriginal(@Param("curFormId") Long curFormId ) throws FailProcessException;
	
	@Query( value = "select chfi.contact_phone_number from user_access.cat_health_facility_information chfi where id_program_entity_fk = (select id from user_access.cat_program_entity where id_form_fk =:curFormId) order by chfi.id desc limit 1", nativeQuery = true)
	String getFacilityContactDetailsFromOriginal(@Param("curFormId") Long curFormId ) throws FailProcessException;
	
	@Query( value = "select cellphone from grievance.cur_register_inquiry where unique_code=:uniqueCode and coalesce(cellphone, '') != '' order by id  desc limit 1", nativeQuery = true)
	String getContactDetailsFromInquiry(@Param("uniqueCode") String uniqueCode ) throws FailProcessException;
	
	@Query( value = "SELECT tg.cellphone FROM grievance.tra_grievance tg where tg.id_cur_form_fk =:curFormId and coalesce(cellphone, '') != '' order by tg.id desc limit 1", nativeQuery = true)
	String getContactDetailsFromGrievance(@Param("curFormId") Long curFormId ) throws FailProcessException;
	
	@Query( value = "select updated_phone_number from grievance.tra_grievance_followup_action gfa left join grievance.tra_grievance tg on tg.id=gfa.id_grievance_fk where tg.id_cur_form_fk =:curFormId and coalesce(updated_phone_number, '') != '' order by gfa.id desc  limit 1", nativeQuery = true)
	String getContactDetailsFromFollowup(@Param("curFormId") Long curFormId ) throws FailProcessException;
	


}
