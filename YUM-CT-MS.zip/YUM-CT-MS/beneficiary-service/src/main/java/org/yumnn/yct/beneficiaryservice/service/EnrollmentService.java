package org.yumnn.yct.beneficiaryservice.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import org.yumnn.yct.beneficiaryservice.entity.*;
import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.beneficiaryservice.model.*;
import org.yumnn.yct.beneficiaryservice.repository.*;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateEnrollmentDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.CurrentFormModel;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.repository.GeographicalAreaRepository;
import org.yumnn.yct.common.repository.ProgramEntityRepository;
import org.yumnn.yct.common.repository.ProjectRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.SourceTypeEnum;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Service
public class EnrollmentService {

	private static Logger logger = LogManager.getLogger(EnrollmentService.class);

	@Autowired
	private EnrollmentRepository enrollmentRepository;

	@Autowired
	private ProgramEntityRepository programEntityRepository;

	@Autowired
	private GeographicalAreaRepository geographicalAreaRepository;

	@Autowired
	private HouseholdMemberService householdMemberService;

	@Autowired
	private CurrentFormService currentFormService;

	@Autowired
	private CurrentFormRepository currentFormRepository;

	@Autowired
	private CurrentVoucherService currentVoucherService;

	@Autowired
	private BookletRepository bookletRepository;

	@Autowired
	private HouseholdMemberRepository householdMemberRepository;

	@Autowired
	private ValidateEnrollmentDetail validateEnrollmentDetail;

	@Autowired
	private ValidateUserDetail validateUserDetail;

	@Autowired
	CommonValidationUtil commonValidationUtil;

	@Autowired
	MessageSource messageSource;

	@Autowired
	HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;

	@Autowired
	BeneficiaryApiCallService beneficiaryApiCallService;

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	private BeneficiaryAdmissionService admissionService;

	@Autowired
	private ValidationService validationService;

	@Autowired
	private AdmissionRepository admissionRepository;

	@Autowired
	private ValidationRepository validationRepository;

	@Autowired
	private SynchronizationService synchronizationService;

	@Autowired
	private BookletByValidationCodeService bookletByValidationCodeService;
	
	@Autowired
	private BeneficiaryReferralDetailsRepository beneficiaryReferralDetailsRepository;
	
	@Autowired
	private BookletByValidationCodeRepository bookletByValidationCodeRepository;

	@Autowired
	private AttachmentRepository attachmentRepository;
	
	@Autowired
	private EnableValidationCodeRepository enableValidationCodeRepository;

	/**
	 *
	 * @param enrollmentCode
	 * @return
	 */
	public Enrollment getEnrollmentByCode(String enrollmentCode)  throws FailProcessException {
		return enrollmentRepository.findByEnrollmentCode(enrollmentCode);
	}

	/**
	 * @param EnrollmentModel
	 * @return EnrollmentModel
	 * @throws Exception
	 */
	private EnrollmentModel saveEnrollment(EnrollmentModel enrollmentModel, Map<String, MultipartFile> filesMap, User user)
			throws Exception {
		logger.debug("Entering into saveEnrollment()");

		CurrentFormModel currentFormModel = saveCurrentForm(enrollmentModel,user);

		saveHouseholdMemberDetails(enrollmentModel, currentFormModel, filesMap,user); //sequence changed due to trigger

		Enrollment enrollment = convertToEnrollmentEntity(enrollmentModel, currentFormModel,user);
		enrollment=saveEnrollment(enrollment);

		enrollmentModel.setId(enrollment.getId().toString());
		enrollmentModel.setEnrollmentCode(enrollment.getEnrollmentCode());

		householdMemberService.updateHouseholdSource(enrollment);

		enrollmentModel.setCurFormId(enrollment.getCurrentForm().getId());
		enrollmentModel.setProjectShortName(enrollment.getCurrentForm().getProject().getShortName().toString());
		enrollmentModel.setBookletId(enrollment.getBooklet().getId());

		saveCurrentVoucherDetails(enrollmentModel,user);

		saveLatestRecordJsonForEnrollment(enrollment);

		logger.debug("Exiting from saveEnrollment()");
		return enrollmentModel;
	}

	/**
	 * @param EnrollmentModel
	 * @return void
	 * @throws Exception
	 */
	private void saveCurrentVoucherDetails(EnrollmentModel enrollmentModel,User user) throws Exception {

		if(Utilities.isValidString(enrollmentModel.getCurrentVoucherDetails())) {
			List<CurrentVoucherModel> currentVoucherDetails = new ObjectMapper()
					.readValue(enrollmentModel.getCurrentVoucherDetails(), new TypeReference<List<CurrentVoucherModel>>() {
					});
			for (CurrentVoucherModel currentVoucherModel : currentVoucherDetails) {
				currentVoucherModel.setEnrollmentId(enrollmentModel.getId());
				currentVoucherModel.setCreatedBy(enrollmentModel.getCreatedBy());
				currentVoucherModel.setCreatedDate(enrollmentModel.getCreatedDate());
			}
			currentVoucherService
					.saveCurrentVoucherDetails(currentVoucherDetails,user);
//		enrollmentModel.setCurrentVoucherDetails(responseCurrentVoucherModel);
		}
	}

	/**
	 * @param EnrollmentModel, @param CurrentFormModel, @param Map<String,
	 *                         MultipartFile>
	 * @return void
	 * @throws Exception
	 */
	private void saveHouseholdMemberDetails(EnrollmentModel enrollmentModel, CurrentFormModel currentFormModel,
			Map<String, MultipartFile> filesMap,User user) throws Exception {
		List<HouseholdMemberModel> householdMemberList = new ObjectMapper()
				.readValue(enrollmentModel.getHouseholdMemberList(), new TypeReference<List<HouseholdMemberModel>>() {
				});

		System.out.println("Befour");
		householdMemberList.forEach(p -> System.out.println(p.toString()));

		for (HouseholdMemberModel householdMemberModel : householdMemberList) {
			householdMemberModel.setCurrentFormId(currentFormModel.getId());
			householdMemberModel.setCreatedBy(enrollmentModel.getCreatedBy());
			householdMemberModel.setCreatedDate(enrollmentModel.getCreatedDate());
		}
		householdMemberService
				.saveHouseholdMemberDetails(householdMemberList, filesMap,user, enrollmentModel);

//		enrollmentModel.setHouseholdMemberList(responseHouseholdMemberModel);
	}

	/**
	 * @param EnrollmentModel
	 * @return CurrentFormModel
	 * @throws Exception
	 */
	private CurrentFormModel saveCurrentForm(EnrollmentModel enrollmentModel,User user) throws Exception {
		CurrentFormModel currentFormModel=new CurrentFormModel();

		currentFormModel.setProjectShortName(enrollmentModel.getProjectShortName());
		currentFormModel.setCreatedBy(enrollmentModel.getCreatedBy());
		currentFormModel.setCreatedDate(enrollmentModel.getCreatedDate());
		currentFormModel = currentFormService.saveCurrentForm(currentFormModel,user);

		return currentFormModel;
	}

	/**
	 * @param EnrollmentModel
	 * @return Enrollment
	 * @throws Exception
	 */
	private Enrollment convertToEnrollmentEntity(EnrollmentModel enrollmentModel, CurrentFormModel currentFormModel,User user)
			throws Exception {
		Enrollment enrollment = new Enrollment();
		setIsRefferedFromOtherTFC(enrollmentModel, enrollment);
		setTfcProgramEntity(enrollmentModel, enrollment);
		setCurrentForm(currentFormModel, enrollment);
		setEnrollmentCode(currentFormModel, enrollment);
		setOtpReferenceNumber(enrollmentModel, enrollment);
		setOtpGeoLocation(enrollmentModel, enrollment);
		setNutritionOfficerName(enrollmentModel, enrollment);
		setNutritionOfficerReferenceNumber(enrollmentModel, enrollment);
		setNutritionOfficerPhoneNumber(enrollmentModel, enrollment);
		setCreatedBy(user, enrollment);
		setCreatedDate(enrollmentModel,enrollment);
		setPlaceOfAdmission(enrollmentModel, enrollment);
		setComments(enrollmentModel, enrollment);
		setBooklet(enrollmentModel, enrollment);
		setIsRequireInvestigation(enrollmentModel, enrollment);
		enrollment.setSyncDate(new Date());
		enrollment.setUniqueId(enrollmentModel.getUniqueId());
		return enrollment;
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 * @throws Exception
	 */
	private void setCreatedDate(EnrollmentModel enrollmentModel, Enrollment enrollment) throws Exception {
		enrollment.setCreatedAt(DateFormatterUtil.dateUtil(enrollmentModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setCreatedBy(User user, Enrollment enrollment) {
		enrollment.setCreatedBy(user);
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setNutritionOfficerPhoneNumber(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String otpNutritionOfficerPhoneNumber = enrollmentModel.getOtpNutritionOfficerPhoneNumber();
		if (Utilities.isValidString(otpNutritionOfficerPhoneNumber)) {
			enrollment.setOtpNutritionOfficerPhoneNumber(otpNutritionOfficerPhoneNumber);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setNutritionOfficerReferenceNumber(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String otpNutritionOfficerRefrenceNumber = enrollmentModel.getOtpNutritionOfficerRefrenceNumber();
		if (Utilities.isValidString(otpNutritionOfficerRefrenceNumber)) {
			enrollment.setOtpNutritionOfficerRefrenceNumber(otpNutritionOfficerRefrenceNumber);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setNutritionOfficerName(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String otpNutritionOfficerName = enrollmentModel.getOtpNutritionOfficerName();
		if (Utilities.isValidString(otpNutritionOfficerName)) {
			enrollment.setOtpNutritionOfficerName(otpNutritionOfficerName);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setOtpGeoLocation(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String otpGeoAreaShortName = enrollmentModel.getOtpGeoAreaShortName();
		if (Utilities.isValidString(otpGeoAreaShortName)) {
			enrollment.setGeoLocationOTP(geographicalAreaRepository.findByShortName(otpGeoAreaShortName).orElse(null));
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setOtpReferenceNumber(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String otpReferenceNumber = enrollmentModel.getOtpReferenceNumber();
		if (Utilities.isValidString(otpReferenceNumber)) {
			enrollment.setOtpReferenceNumber(otpReferenceNumber);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setEnrollmentCode(CurrentFormModel currentFormModel, Enrollment enrollment) {
		String enrollmentCode = currentFormModel.getId();
		if (Utilities.isValidString(enrollmentCode)) {
			enrollment.setEnrollmentCode(enrollmentCode);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 */
	private void setTfcProgramEntity(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String tfcShortName = enrollmentModel.getTfcShortName();
		if (Utilities.isValidString(tfcShortName)) {
			enrollment.setProgramEntity(programEntityRepository.findByShortName(tfcShortName));
		}
	}

	/**
	 * @param CurrentFormModel, @param Enrollment
	 * @return void
	 */
	private void setCurrentForm(CurrentFormModel currentFormModel, Enrollment enrollment) throws FailProcessException {
		String currentFormId = currentFormModel.getId();
		if (Utilities.isValidString(currentFormId)) {
			enrollment.setCurrentForm(getCurrentFormbyId(Long.parseLong(currentFormId)));
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 * @throws Exception
	 */
	private void setIsRefferedFromOtherTFC(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String isRefferdFromOtherTFC = enrollmentModel.getIsRefferdFromOtherTFC();
		if (Utilities.isValidString(isRefferdFromOtherTFC)) {
			enrollment.setIsRefferdFromOtherTFC(YesNoEnum.valueOf(isRefferdFromOtherTFC.toUpperCase()));
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 * @throws Exception
	 */
	private void setPlaceOfAdmission(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String placeOfAdmission = enrollmentModel.getPlaceOfAdmissionShortName();
		if (Utilities.isValidString(placeOfAdmission)) {
			enrollment.setPlaceOfAdmission(programEntityRepository.findByShortName(placeOfAdmission));
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 * @throws Exception
	 */
	private void setComments(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String comments = enrollmentModel.getComments();
		if (Utilities.isValidString(comments)) {
			enrollment.setComments(comments);
		}
	}

	/**
	 * @param EnrollmentModel, @param Enrollment
	 * @return void
	 * @throws Exception
	 */
	private void setBooklet(EnrollmentModel enrollmentModel, Enrollment enrollment) throws FailProcessException {
		String bookletShortName = enrollmentModel.getBookletShortName();
		if (Utilities.isValidString(bookletShortName)) {
			enrollment.setBooklet(bookletRepository.findByShortName(bookletShortName));
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setIsRequireInvestigation(EnrollmentModel enrollmentModel, Enrollment enrollment) {
		String isRequireInvestigation = enrollmentModel.getIsRequireInvestigation();
		if(isRequireInvestigation == null) {
			enrollment.setIsRequireInvestigation(null);
		}else {
			if (Utilities.isValidString(isRequireInvestigation)) {
				enrollment.setIsRequireInvestigation(YesNoEnum.valueOf(isRequireInvestigation.toUpperCase()));
			} else {
				enrollment.setIsRequireInvestigation(YesNoEnum.NO);
			}
		}
	}

	/**
	 *
	 * @param Long enrollmentId, @param Enrollment enrollment
	 * @return Map<String, Object>
	 */
	public Map<String, Object> addEnrollmentDetailsToMap(Long enrollmentId, Enrollment enrollment)  throws FailProcessException {
		Map<String, Object> map = new LinkedHashMap<>();

		map.put(ConstantsUtil.ENROLLMENT_ID, enrollmentId);
		map.put(ConstantsUtil.COMMENT, enrollment.getComments());
		map.put(ConstantsUtil.ENROLLMENT_CODE, enrollment.getEnrollmentCode());
		map.put(ConstantsUtil.IS_REFERRED_FROM_OTHER_TFC, (enrollment.getIsRefferdFromOtherTFC()==null?YesNoEnum.NO.getValue():enrollment.getIsRefferdFromOtherTFC().getValue()));
		map.put(ConstantsUtil.TFC_GEOLOCATION, (enrollment.getProgramEntity()==null?null:enrollment.getProgramEntity().getShortName()));
		map.put(ConstantsUtil.OTP_GEOLOCATION, (enrollment.getGeoLocationOTP()==null?null:enrollment.getGeoLocationOTP().getShortName()));
		map.put(ConstantsUtil.OTP_REFERENCE_NUMBER, enrollment.getOtpReferenceNumber());
		map.put(ConstantsUtil.OTP_NUTRITION_OFFICER_NAME, enrollment.getOtpNutritionOfficerName());
		map.put(ConstantsUtil.OTP_NUTRITION_OFFICER_REFERENCE_NUMBER,enrollment.getOtpNutritionOfficerRefrenceNumber());
		map.put(ConstantsUtil.OTP_NUTRITION_OFFICER_PHONE_NUMBER,enrollment.getOtpNutritionOfficerPhoneNumber());
		map.put(ConstantsUtil.BOOKLET, (enrollment.getBooklet()==null?null:enrollment.getBooklet().getShortName()));
		map.put(ConstantsUtil.CURRENT_FORM, (enrollment.getCurrentForm()==null?null:enrollment.getCurrentForm().getId()));
		map.put(ConstantsUtil.CREATED_AT, DateFormatterUtil.creationDateUtil(enrollment.getCreatedAt()));
		map.put(ConstantsUtil.CREATED_BY, (enrollment.getCreatedBy()==null?null:enrollment.getCreatedBy().getId()));
		map.put(ConstantsUtil.UPDATED_AT, DateFormatterUtil.creationDateUtil(enrollment.getUpdatedAt()));
		map.put(ConstantsUtil.UPDATED_BY, (enrollment.getUpdatedBy()==null?null:enrollment.getUpdatedBy().getId()));
		map.put(ConstantsUtil.PLACE_OF_ADMSN_SHORT_NAME, enrollment.getPlaceOfAdmission()==null?"":enrollment.getPlaceOfAdmission().getShortName());
		map.put(ConstantsUtil.IS_REQUIRED_INVESTIGATION, enrollment.getIsRequireInvestigation()==null?YesNoEnum.NO.getValue():enrollment.getIsRequireInvestigation().getValue());
		List<HouseholdMemberModel> hhmListModel=getHouseholdMemberList(enrollment.getCurrentForm());
		map.put(ConstantsUtil.HOUSEHOLD_MEMBER_LIST, hhmListModel);
		map.put(ConstantsUtil.RECORD_UNIQUE_ID, enrollment.getUniqueId());
		return map;
	}

	private List<SearchModel> searchEnrollmentDetails(Map<String, String> body) throws FailProcessException {
		List<SearchModel> searchModelList = null;
		if(body.get(ConstantsUtil.SEARCH_TYPE_PARAM).equals(ConstantsUtil.SEARCH_BY_VCA_NUMBER)) {
			searchModelList = searchByVCA(body);
		} else if (body.get(ConstantsUtil.SEARCH_TYPE_PARAM).equals(ConstantsUtil.SEARCH_BY_NAME_AND_GEOLOCATION)) {
			searchModelList = searchByNameAndGeolocation(body);
		} else if (body.get(ConstantsUtil.SEARCH_TYPE_PARAM).equals(ConstantsUtil.SEARCH_BY_NAME)) {
			searchModelList = searchByName(body);
		} else if (body.get(ConstantsUtil.SEARCH_TYPE_PARAM).equals(ConstantsUtil.SEARCH_BY_GEOLOCATION)) {
			searchModelList = searchByGeolocation(body);
		} else if(body.get(ConstantsUtil.SEARCH_TYPE_PARAM).equals(ConstantsUtil.SEARCH_ALL)) {
			searchModelList = searchAll();
		}
		return searchModelList;
	}

	private List<SearchModel> searchAll() throws FailProcessException {
		List<SearchModel> searchModelList = enrollmentRepository.getAllEnrollmentData();
		return searchModelList;
	}

	private List<SearchModel> searchByGeolocation(Map<String, String> body) throws FailProcessException {
		String geoLocation = getGeolocation(body);
		List<SearchModel> searchModelList = enrollmentRepository.getEnrollmentDataByGeolocation(Long.parseLong(geoLocation));
		return searchModelList;
	}

	private List<SearchModel> searchByName(Map<String, String> body) throws FailProcessException {
		List<SearchModel> searchModelList = null;
		String[] nameArr = body.get("fullName").split(ConstantsUtil.SPACE_DELIMETER);
		if(nameArr.length == 1) {
			searchModelList=enrollmentRepository.getEnrollmentDataByName(nameArr[0], nameArr[0]);
		} else if(nameArr.length > 1) {
			searchModelList=enrollmentRepository.getEnrollmentDataByName(nameArr[0], nameArr[1]);
		}
		return searchModelList;
	}

	private List<SearchModel> searchByNameAndGeolocation(Map<String, String> body) throws FailProcessException {
		List<SearchModel> searchModelList = null;
		String geoLocation = getGeolocation(body);
		String[] nameArr = body.get("fullName").split(ConstantsUtil.SPACE_DELIMETER);
		if(nameArr.length == 1) {
			searchModelList=enrollmentRepository.getEnrollmentDataByNameAndGeolocation(nameArr[0], nameArr[0], Long.parseLong(geoLocation));
		} else if (nameArr.length > 1) {
			searchModelList=enrollmentRepository.getEnrollmentDataByNameAndGeolocation(nameArr[0], nameArr[1], Long.parseLong(geoLocation));
		}
		return searchModelList;
	}

	private List<SearchModel> searchByVCA(Map<String, String> body) throws FailProcessException {
		List<SearchModel> searchModelList = enrollmentRepository.getEnrollmentDataByBookletAndVCA(body.get("vcaNumber"));
		return searchModelList;
	}

	private String getGeolocation(Map<String, String> body) {
		String geoLocation=null;

		if(body.get("village")!=null) {
			geoLocation=body.get("village");
		} else if(body.get("ozla")!=null) {
			geoLocation=body.get("ozla");
		} else if(body.get("district")!=null) {
			geoLocation=body.get("district");
		} else if(body.get("governorate")!=null) {
			geoLocation=body.get("governorate");
		}
		return geoLocation;
	}

	/**
	 *
	 * @param currentForm
	 * @return List<HouseholdMemberModel>
	 */
	private List<HouseholdMemberModel> getHouseholdMemberList(CurrentForm currentForm)  throws FailProcessException{

		List<HouseholdMemberModel> hhmModelList=new ArrayList<HouseholdMemberModel>();
		HouseholdMemberModel hhmModel;
		List<HouseholdMember> hhmList =householdMemberRepository.findByCurrentForm(currentForm);

		for (HouseholdMember hmm:hhmList) {

			hhmModel = setHouseholdMemberModel(hmm);

			hhmModelList.add(hhmModel);
		}

		return hhmModelList;
	}

	private HouseholdMemberModel setHouseholdMemberModel(HouseholdMember hmm) {
		HouseholdMemberModel hhmModel;
		hhmModel=new HouseholdMemberModel();

		hhmModel.setId(hmm.getId().toString());
		hhmModel.setFullName(hmm.getFirstName()==null?"":(hmm.getFirstName().concat(hmm.getLastName()==null?"":ConstantsUtil.SPACE_DELIMETER+hmm.getLastName())));
		hhmModel.setCurrentFormId(hmm.getCurrentForm()==null?null:hmm.getCurrentForm().getId().toString());
		hhmModel.setPhoneNumber(hmm.getPhoneNumber());
		hhmModel.setDocumentReferenceNumber(hmm.getDocumentReferenceNumber());
		hhmModel.setIsAssignedAsPaymentReceiver(hmm.getIsAssignedAsPaymentReceiver()==null?YesNoEnum.NO.getValue():hmm.getIsAssignedAsPaymentReceiver().getValue());
		//hhmModel.setIsRequireInvestigation(hmm.getIsRequireInvestigation()==null?YesNoEnum.NO.getValue():hmm.getIsRequireInvestigation().getValue());
		hhmModel.setIsPrimary(hmm.getIsPrimary()==null?YesNoEnum.NO.getValue():hmm.getIsPrimary().getValue());
		hhmModel.setGenderShortName(hmm.getGender()==null?"":hmm.getGender().getShortName());
		hhmModel.setDateOfBirth(DateFormatterUtil.formDateUtil(hmm.getDateOfBirth()));
		hhmModel.setCatDocShortName(hmm.getDocument()==null?"":hmm.getDocument().getShortName());
		hhmModel.setRelationshipShortName(hmm.getRelationship()==null?"":hmm.getRelationship().getShortName());
		hhmModel.setHouseholdMemberTypeShortName(hmm.getHouseholdMemberType()==null?"":hmm.getHouseholdMemberType().getShortName());
		hhmModel.setCreatedBy(hmm.getCreatedBy()==null?"":hmm.getCreatedBy().getId().toString());
		hhmModel.setCreatedDate(DateFormatterUtil.creationDateUtil(hmm.getCreatedAt()));
		return hhmModel;
	}

	public Map<String, Object> searchBeneficaryInfo(Map<String, String> body) throws Exception{

		commonValidationUtil.validateIsNull("Search Request Params",body);

		Map<String, Object> map = new LinkedHashMap<>();

		List<SearchModel> searchList = searchEnrollmentDetails(body);

		map.put("searchBeneficiaryResponse", searchList);

		return map;

	}

	@Transactional
	public Map<String, Object> enrollBeneficiary(Map<String, String> requestHeader, Map<String, MultipartFile> filesMap,EnrollmentModel enrollmentAPIModel)
			throws Exception {
		try {
			User user = validateUserDetail.validateAndGetUser(requestHeader);
			if(!enrollmentAPIModel.isWebCall()) {
				validateEnrollmentDetail.validateEnrollmentDetails(filesMap, enrollmentAPIModel);
			}

			EnrollmentModel enrollmentModel = saveEnrollment(enrollmentAPIModel, filesMap, user);

			addHistoricalBeneficiaryMilestone(requestHeader,enrollmentModel);

			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.ENROLLMENT_CODE, enrollmentModel.getEnrollmentCode());
			map.put(ConstantsUtil.ENROLLMENT_ID, enrollmentModel.getId());
			return map;
		} catch(Exception e) {
			logger.error("Error In enrollBeneficiary, "+e);
			throw e;
		}
	}

	private Enrollment saveEnrollment(Enrollment enrollment) {
		try {
			enrollment = enrollmentRepository.save(enrollment);
			return enrollment;
		} catch(Exception e) {
			logger.debug("Error In Save: ", e);
			throw new FailProcessException();
		}
	}

	private CurrentForm getCurrentFormbyId(Long id) {
		try {
			Optional<CurrentForm> currentFormOpt = currentFormRepository.findById(id);
			CurrentForm currentForm=currentFormOpt.get();
			return currentForm;
		} catch (Exception e) {
			throw new FailProcessException();
		}

	}

	private void addHistoricalBeneficiaryMilestone(Map<String, String> requestHeader, EnrollmentModel enrollmentModel)
			throws Exception {

		CycleByProjectModel cycleByProjectModel =beneficiaryApiCallService.getCycleByProjectName(requestHeader,enrollmentModel.getProjectShortName());

		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setCurrentFormId(enrollmentModel.getCurFormId());
		historicalBeneficiaryModel.setBookletId(enrollmentModel.getBookletId());
		historicalBeneficiaryModel.setMilestoneReferenceId(Long.parseLong(enrollmentModel.getId()));
		historicalBeneficiaryModel.setCycleId(cycleByProjectModel.getCycleId());
		historicalBeneficiaryModel.setCreatedDate(DateFormatterUtil.dateUtil(enrollmentModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
		historicalBeneficiaryModel.setMilestoneType(MilestoneTypeEnum.ENROLLMENT.toString());
		historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);

	}

	public Map<String, Object> getHouseholdCardInfo(Long curFormId, String projectShortName) throws Exception{

		commonValidationUtil.validateIsNull("Current Form Id",curFormId);

		Map<String, Object> map = new LinkedHashMap<>();
		List<HouseholdCardInfoModel> householdCardInfoList =new ArrayList<HouseholdCardInfoModel>();
		Long geoLocationId=0L;
		String primaryMemberName="";

		if(projectShortName.equals(ProjectNameEnum.NVS.getValue())) {
			householdCardInfoList = enrollmentRepository.getHouseholdCardInfo(curFormId);
			Enrollment enrollment=enrollmentRepository.findByEnrollmentCode(curFormId.toString());
			geoLocationId=enrollmentRepository.getBeneficiaryGeoLocationForNVS(curFormId);
			primaryMemberName=enrollmentRepository.getPrimaryMemberNameForNVS(curFormId);
			map.put(ConstantsUtil.UNIQUE_CODE, enrollment.getBooklet().getShortName());
		}else {
			primaryMemberName=enrollmentRepository.getPrimaryMemberName(curFormId);
			geoLocationId=enrollmentRepository.getBeneficiaryGeoLocation(curFormId);
			map.put(ConstantsUtil.UNIQUE_CODE, curFormId.toString());
		}

		map.put(ConstantsUtil.HOUSEHOLD_CARD_INFO_LIST, householdCardInfoList);
		map.put(ConstantsUtil.PRIMARY_MEMBER, primaryMemberName);
		map.put(ConstantsUtil.GEOLOCATION_ID_PARAM, geoLocationId);

		return map;

	}

	public Map<String, Object> getFacilityCardInfo(Long curFormId) throws Exception{

		commonValidationUtil.validateIsNull("Current Form Id",curFormId);
		Map<String, Object> map = new LinkedHashMap<>();
		FacilityCardInfoModel facilityCardInfoList = enrollmentRepository.findFacilityCodeByVca(curFormId);
		map.put(ConstantsUtil.FACILITY_CARD_INFO_LIST, facilityCardInfoList);
		return map;
	}


	public Map<String, Object> getPaymentByServiceCardInfo(Long curFormId) throws Exception{

		commonValidationUtil.validateIsNull("Current Form Id",curFormId);

		Map<String, Object> map = new LinkedHashMap<>();

		List<PaymentByServiceCardInfoModel> paymentByServiceCardInfoModel = enrollmentRepository.getPaymentByServiceCardInfo(curFormId);

		map.put(ConstantsUtil.PAYMENT_BY_SERVICE_CARD_INFO_LIST, paymentByServiceCardInfoModel);

		return map;

	}

	private void saveLatestRecordJsonForEnrollment(Enrollment enrollment) throws JsonProcessingException {

		logger.debug("===== saveLatestRecordJsonForEnrollment Start ======");

		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		Map<String, Object> admissionDataMap = null;
		Map<String, Object> validationDataMap = null;

		Date syncDate=enrollment.getSyncDate();

		Map<String, Object> enrollmentDataMap = addEnrollmentDetailsToMap(enrollment.getId(),enrollment);

		Admission admission = admissionRepository.getAdmissionByEnrollment(enrollment.getId());
		if(admission!=null) {
			admissionDataMap = admissionService.addAdmissionDetailsToMap(admission);

			Validation validation = validationRepository.getValidationByAdmission(admission.getId());
			if(validation!=null) {
				validationDataMap = validationService.addValidationDetailsToMap(validation.getId(),validation);
			}
		}

		beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);

		synchronizationService.saveLatestJsonRecordForDownload(enrollment.getCurrentForm(),syncDate,beneficiaryJsonMap);

		logger.debug("======= saveLatestRecordJsonForEnrollment End =======");
	}

	public Map<String, Object> getPaymentByCycleCardInfo(String curFormId, String unicode) {

		Map<String, Object> map = new LinkedHashMap<>();

		List<PaymentByCycleCardInfoModel> paymentByCycleCardInfoModel = null;
		if(unicode != null && !unicode.trim().isEmpty())
			paymentByCycleCardInfoModel = enrollmentRepository.getPaymentByCycleCardInfo(curFormId);
		else
			paymentByCycleCardInfoModel = enrollmentRepository.getPaymentByCycleCardInfo(Long.valueOf(curFormId));

		map.put(ConstantsUtil.PAYMENT_BY_CYCLE_CARD_INFO_LIST, paymentByCycleCardInfoModel);
		return map;
	}

	public Map<String, Object> getGrievancesAndInquiriesCardInfo(Long curFormId, String uniqueCode) {
		Map<String, Object> map = new LinkedHashMap<>();

		List<GrievanceAndInquiriesCardInfoModel> grievancesCardInfoModel = enrollmentRepository.getGrievancesCardInfo(curFormId);

		List<GrievanceAndInquiriesCardInfoModel> inquiriesCardInfoModel = enrollmentRepository.getInquiriesCardInfo(uniqueCode);

		List<GrievanceAndInquiriesCardInfoModel> inquiriesTypeList = new ArrayList<GrievanceAndInquiriesCardInfoModel>();

		GrievanceAndInquiriesCardInfoModel inquiryModelData=null;
		for(GrievanceAndInquiriesCardInfoModel inquiryModel:inquiriesCardInfoModel) {
			inquiryModelData=enrollmentRepository.getInquiryTypeAndCategory(Long.valueOf(inquiryModel.getInquiryId()));
			inquiriesTypeList.add(inquiryModelData);
		}

		map.put(ConstantsUtil.GRIEVANCES_CARD_INFO_LIST, grievancesCardInfoModel);

		map.put(ConstantsUtil.INQUIRIES_CARD_INFO_LIST, inquiriesCardInfoModel);

		map.put(ConstantsUtil.INQUIRIES_LIST, inquiriesTypeList);

		return map;
	}

	public Map<String, Object> getEnrollmentById(Long id){
		Map<String, Object> map =new HashMap<>();

		Enrollment enrollment = enrollmentRepository.findById(id).get();
		EnrollmentModel enrollmentModel = new EnrollmentModel();
		if(enrollment != null){
			enrollmentModel.setId(String.valueOf(enrollment.getId()));
			enrollmentModel.setEnrollmentCode(enrollment.getEnrollmentCode());
			if(enrollment.getCurrentForm() != null)
				enrollmentModel.setCurFormId(enrollment.getCurrentForm().getId());
			if(enrollment.getBooklet() != null)
				enrollmentModel.setBookletId(enrollment.getBooklet().getId());

			enrollmentModel.setUniqueId(enrollment.getUniqueId());
			enrollmentModel.setCreatedBy(String.valueOf(enrollment.getCreatedBy().getId()));
			enrollmentModel.setCreatedDate(String.valueOf(enrollment.getCreatedAt()));

			List<Long> admissionIds = admissionRepository.getAdmissionIdListByEnrollment(enrollment.getId());
			if(admissionIds != null && !admissionIds.isEmpty() && admissionIds.size() > 0)
				enrollmentModel.setAdmissionId(admissionIds.get(0));

			List<BookletByValidationCode> bookletByValidationCodeList = null;
			List<HouseholdMember> documentModelList = null;
			if(enrollment.getBooklet() != null)
				bookletByValidationCodeList = bookletByValidationCodeService.findAllByBookletId(enrollment.getBooklet().getId());
			if(enrollment.getCurrentForm() != null)
				documentModelList = householdMemberService.findHouseholdMemberListByFormId(enrollment.getCurrentForm().getId());

			List<ValidationBookletModel> bookletModels = new ArrayList<>();
			if(bookletByValidationCodeList != null &&  !bookletByValidationCodeList.isEmpty() && bookletByValidationCodeList.size() > 0){
				for(BookletByValidationCode code : bookletByValidationCodeList){
					ValidationBookletModel model = new ValidationBookletModel();
					model.setId(code.getId());
					model.setValidationCode(code.getValidationCode());
					model.setValidationCodeType(code.getValidationCodeType().toString());
					model.setIsUsed(code.getIsUsed().getValue());
					bookletModels.add(model);
				}
			}
			enrollmentModel.setValidationBookletModel(bookletModels);

			List<HouseholdMemberDocumentModel> documentModels = new ArrayList<>();
			if(documentModelList != null &&  !documentModelList.isEmpty() && documentModelList.size() > 0){
				documentModelList = documentModelList.stream().filter(p -> p.getHouseholdMemberType().getId() == 2).collect(Collectors.toList());
				for(HouseholdMember member : documentModelList){
					HouseholdMemberDocumentModel model = new HouseholdMemberDocumentModel();
					model.setId(member.getId());
					model.setReferenceId(member.getDocument().getShortName());
					model.setReferenceNumber(member.getDocumentReferenceNumber());
					documentModels.add(model);
				}
			}
			enrollmentModel.setMemberDocumentModelList(documentModels);
		}
		map.put("enrollmentModel",enrollmentModel);
		return map;
	}
	
	public Map<String, Object> referToAnotherTFCWeb(Map<String, String> requestHeader,
			ReferToAnotherTFCModel referToAnotherTFCModel) throws ParseException {
		Map<String, Object> map = new LinkedHashMap<>();
		BeneficiaryReferralDetails beneficiaryReferralDetails=convertToBeneficiaryReferralDetails(referToAnotherTFCModel);
		beneficiaryReferralDetails = beneficiaryReferralDetailsRepository.save(beneficiaryReferralDetails);
		
		if(!Utilities.isNULL(referToAnotherTFCModel.getOtpValidationCode())) {
			String validationCode=referToAnotherTFCModel.getOtpValidationCode();
			BookletByValidationCode validationCodeModel=bookletByValidationCodeRepository.findByValidationCode(validationCode);
			validationCodeModel.setIsUsed(YesNoEnum.YES);
			validationCodeModel=bookletByValidationCodeRepository.save(validationCodeModel);
			map.put("otpValidationCode", validationCode);
			SimpleDateFormat format = new SimpleDateFormat("dd-MMMM-yyyy");
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.MONTH, 1);
			map.put("otpExpiryDate", format.format(calendar.getTime()));
			
			EnableValidationCode enableValidationCode = new EnableValidationCode();
			enableValidationCode.setExpiryDate(format.parse(format.format(calendar.getTime())));
			enableValidationCode.setReferenceId(beneficiaryReferralDetails.getId());
			enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_REFERTOANOTHERTFC);
			enableValidationCode.setValidationType(ConstantsUtil.VALIDATION_TYPE_OTP);
			enableValidationCode.setCreatedAt(beneficiaryReferralDetails.getCreatedAt());
			User user = new User();
			user.setId(beneficiaryReferralDetails.getCreatedBy());
			enableValidationCode.setCreatedBy(user);
			enableValidationCode.setSetupBookletByValidationCode(validationCodeModel);
			enableValidationCodeRepository.save(enableValidationCode);
		}
		return map;
	}
	private BeneficiaryReferralDetails convertToBeneficiaryReferralDetails(
			ReferToAnotherTFCModel referToAnotherTFCModel) {
		BeneficiaryReferralDetails beneficiaryReferralDetails=new BeneficiaryReferralDetails();
		beneficiaryReferralDetails.setCreatedAt(new Date());
		beneficiaryReferralDetails.setCreatedBy(referToAnotherTFCModel.getCreatedBy());
		beneficiaryReferralDetails.setDistrictId(referToAnotherTFCModel.getSelectedDistrict());
		beneficiaryReferralDetails.setGovernorateId(referToAnotherTFCModel.getSelectedGovernorate());
		beneficiaryReferralDetails.setIsTFCWithInUNICEF(referToAnotherTFCModel.getIsReferredToAnotherTFCWithInUNICEF());
		beneficiaryReferralDetails.setNonNVSFacilityName(referToAnotherTFCModel.getNonNVSFacilityName());
		beneficiaryReferralDetails.setOtherReason(referToAnotherTFCModel.getOtherReason());
		beneficiaryReferralDetails.setReferralReason(referToAnotherTFCModel.getReasonForReferral());
		beneficiaryReferralDetails.setReferralTFCId(referToAnotherTFCModel.getSelectedTFC());
		beneficiaryReferralDetails.setOfficerDistrictId(referToAnotherTFCModel.getOfficerDistrict());
		beneficiaryReferralDetails.setOfficerGovernorateId(referToAnotherTFCModel.getOfficerGovernorate());
		beneficiaryReferralDetails.setOfficerTFCId(referToAnotherTFCModel.getOfficerTFC());
		beneficiaryReferralDetails.setEnrollmentId(referToAnotherTFCModel.getEnrollmentId());
		return beneficiaryReferralDetails;
	}

	public Map<String, Object> validateEnrollmentData(ValidationBookletSubmitModel bookletSubmitModel, User user) throws ParseException{

//		Validation validation=validationRepository.getById(bookletSubmitModel.getValidationId());
//		bookletByValidationCodeService.updateBookletValidationCodeStatus(bookletSubmitModel.getBookletModelList(),validation);


		List<Map<String, String>> lists = new ArrayList<>();
		if(bookletSubmitModel.getTreatmentFile1Map() != null && !bookletSubmitModel.getTreatmentFile1Map().isEmpty())
			lists.add(bookletSubmitModel.getTreatmentFile1Map());
		if(bookletSubmitModel.getTreatmentFile2Map() != null && !bookletSubmitModel.getTreatmentFile2Map().isEmpty())
			lists.add(bookletSubmitModel.getTreatmentFile2Map());

		if(lists != null && !lists.isEmpty() && lists.size() > 0) {

			List<Attachment> allAttachment = new ArrayList<>();

			for(Map<String, String> fileMap : lists) {
				if(fileMap != null && !fileMap.isEmpty()) {
					Attachment attachment = new Attachment();
					attachment.setReferenceId(bookletSubmitModel.getValidationId());
					attachment.setIsActive(YesNoEnum.YES);
					attachment.setFile(fileMap.get("file"));
					attachment.setFileMimeType(fileMap.get("contentType"));
					attachment.setExtension(fileMap.get("fileExtension"));
					attachment.setFileSize(Long.parseLong(fileMap.get("size")));
					attachment.setName(fileMap.get("fileName"));
					attachment.setReferenceType(fileMap.get("referenceKey"));
					attachment.setSourceType(SourceTypeEnum.VALIDATION);
					attachment.setCreatedBy(user);
					attachment.setCreatedAt(new Date());
					allAttachment.add(attachment);
				}
			}
			if(allAttachment != null && !allAttachment.isEmpty() && allAttachment.size() > 0)
				saveAllAttachment(allAttachment);
		}

		return null;
	}


	private void saveAllAttachment(List<Attachment> attachmentList) {
		try {
			attachmentRepository.saveAll(attachmentList);
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

}


