package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.ServiceType;
import org.yumnn.yct.common.exception.FailProcessException;

@Repository
public interface ServiceTypeRepository extends JpaRepository<ServiceType, Long> {
	ServiceType findByShortName(String shortName) throws FailProcessException;
	
	@Query("SELECT s FROM ServiceType s where s.isActive = 'YES'")
	List<ServiceType> getAllServiceTypesByStatus();
}
