package org.yumnn.yct.beneficiaryservice.util.param;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.model.HouseholdMemberModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt May 20, 2021 6:34:59 PM
 */
public class HouseholdMemberServiceParam {
	
	private HouseholdMemberModel householdMemberModel;
	
	private HouseholdMember householdMember;
	
	private Map<String, MultipartFile> filesMap;
	
	private User user;
	
	private String enrollmentCode;
	
	private String fileReferenceType;
	
	private Map<String, String> caregiverFile1Map;
	private Map<String, String> caregiverFile2Map;
	private Map<String, String> nomineeFile1Map;
	private Map<String, String> nomineeFile2Map;
	
	private boolean isWebCall;
	
	public boolean isWebCall() {
		return isWebCall;
	}

	public void setWebCall(boolean isWebCall) {
		this.isWebCall = isWebCall;
	}

	public Map<String, String> getCaregiverFile1Map() {
		return caregiverFile1Map;
	}

	public void setCaregiverFile1Map(Map<String, String> caregiverFile1Map) {
		this.caregiverFile1Map = caregiverFile1Map;
	}

	public Map<String, String> getCaregiverFile2Map() {
		return caregiverFile2Map;
	}

	public void setCaregiverFile2Map(Map<String, String> caregiverFile2Map) {
		this.caregiverFile2Map = caregiverFile2Map;
	}

	public Map<String, String> getNomineeFile1Map() {
		return nomineeFile1Map;
	}

	public void setNomineeFile1Map(Map<String, String> nomineeFile1Map) {
		this.nomineeFile1Map = nomineeFile1Map;
	}

	public Map<String, String> getNomineeFile2Map() {
		return nomineeFile2Map;
	}

	public void setNomineeFile2Map(Map<String, String> nomineeFile2Map) {
		this.nomineeFile2Map = nomineeFile2Map;
	}

	public HouseholdMemberModel getHouseholdMemberModel() {
		return householdMemberModel;
	}

	public void setHouseholdMemberModel(HouseholdMemberModel householdMemberModel) {
		this.householdMemberModel = householdMemberModel;
	}

	public HouseholdMember getHouseholdMember() {
		return householdMember;
	}

	public void setHouseholdMember(HouseholdMember householdMember) {
		this.householdMember = householdMember;
	}

	public Map<String, MultipartFile> getFilesMap() {
		return filesMap;
	}

	public void setFilesMap(Map<String, MultipartFile> filesMap) {
		this.filesMap = filesMap;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getEnrollmentCode() {
		return enrollmentCode;
	}

	public void setEnrollmentCode(String enrollmentCode) {
		this.enrollmentCode = enrollmentCode;
	}

	public String getFileReferenceType() {
		return fileReferenceType;
	}

	public void setFileReferenceType(String fileReferenceType) {
		this.fileReferenceType = fileReferenceType;
	}

	
	
	
	
	
	
	
	
	
	
}
