package org.yumnn.yct.beneficiaryservice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.*;
import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.beneficiaryservice.model.ServiceTypeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.model.VcaMonitoringDataModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.BookletByValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.DocumentsRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnableValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.ServiceTypeRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.repository.VcaMonitoringLogRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateValidationDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.model.payment.BookletValidationCodeModel;
import org.yumnn.yct.common.model.payment.PaidBeneficiaryModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.SourceTypeEnum;
import org.yumnn.yct.common.util.Utilities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 16, 2021
 *
 */

@Service
public class ValidationService {

	private static final Logger logger = LoggerFactory.getLogger(ValidationService.class);

	@Autowired
	private AdmissionRepository admissionRepository;

	@Autowired
	private ServiceTypeRepository serviceTypeRepository;

	@Autowired
	private AttachmentRepository attachmentRepository;

	@Autowired
	private ValidationRepository validationRepository;

	@Autowired
	private BookletByValidationCodeRepository bookletByValidationCodeRepository;

	@Autowired
	private EnableValidationCodeRepository enableValidationCodeRepository;

	@Autowired
	DocumentsRepository DocumentsRepository;

	@Autowired
	private BookletByValidationCodeService bookletByValidationCodeService;

	@Autowired
	private ValidateValidationDetail validateValidationDetail;

	@Autowired
	private ValidateUserDetail validateUserDetail;

	@Autowired
	private BeneficiaryApiCallService beneficiaryApiCallService;

	@Autowired
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private VcaMonitoringLogRepository vcaMonitoringLogRepository;

	@Autowired
	private BeneficiaryAdmissionService admissionService;

	@Autowired
	private EnrollmentRepository enrollmentRepository;

	@Autowired
	private EnrollmentService enrollmentService;

	@Autowired
	private SynchronizationService synchronizationService;


	/**
	 *
	 * @param validationModel
	 * @param filesMap
	 * @return
	 * @throws Exception
	 */
	private ValidationModel saveValidationDetails(ValidationModel validationModel, Map<String, MultipartFile> filesMap,User user) throws Exception {
		logger.debug("Entering into saveValidationDetails()");

		Validation validation = saveValidation(validationModel,user);

		validationModel.setId(validation.getId().toString());

		Enrollment enrollment=validation.getAdmission().getEnrollment();
		validationModel.setCurFormId(enrollment.getCurrentForm().getId());
		validationModel.setProjectShortName(enrollment.getCurrentForm().getProject().getShortName().toString());
		validationModel.setBookletId(enrollment.getBooklet().getId());

		if(!validationModel.isWebCall())
			saveAttachmentDetails(validation, filesMap, user);
		else
			saveAttachmentDetailsWeb(validation, validationModel, user);

		if(!validationModel.isWebCall())
			saveValidationCodeDetails(validationModel, validation);
		else
			saveValidationCodeDetails(validationModel, validation);


		saveLatestRecordJsonForValidation(validation);

		logger.debug("Exit from saveValidationDetails()");

		return validationModel;
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws Exception
	 */
	private void saveValidationCodeDetails(ValidationModel validationModel, Validation validation)
			throws JsonProcessingException, JsonMappingException, Exception {


		List<ValidationCodeModel> validationCodeDetails = new ObjectMapper()
				.readValue(validationModel.getValidationCodeDetails(), new TypeReference<List<ValidationCodeModel>>() {
				});

		for (ValidationCodeModel validationCodeModel : validationCodeDetails) {
			EnableValidationCode enableValidationCode = new EnableValidationCode();
			enableValidationCode.setReferenceId(validation.getId());
			switch (validationModel.getServiceTypeShortName()) {
			case "TREAT":
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_TREATMENT);
				break;
			case "DISCG":
			case "DISCGTFC":
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_OF_DISCHARGE);
				break;
			case "TREATDIS":
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_TREATMENT_AND_DISCHARGE);
				break;
			case "DISCGPLS":
				enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_DISCHARGE_PLUS);
				break;
			default:
				break;
			}
			enableValidationCode.setValidationType(validationCodeModel.getValidationCodeType());

			BookletByValidationCode bookletByValidationCode = null;
			String validationCode = validationCodeModel.getValidationCode();
			String isValidationCodeUsed = validationCodeModel.getIsValidationCodeUsed()==null?"":validationCodeModel.getIsValidationCodeUsed();

			if(Utilities.isValidString(validationCode) && isValidationCodeUsed.equalsIgnoreCase(YesNoEnum.NO.getValue())) {
				bookletByValidationCode = bookletByValidationCodeRepository.
						findByValidationCodeAndIsActiveAndIsUsed(validationCode, YesNoEnum.YES, YesNoEnum.NO);
				if(bookletByValidationCode != null) {
					enableValidationCode.setSetupBookletByValidationCode(bookletByValidationCode);
				} else {
					logger.error("Validation code Already Used. Validation Code::"+validationCode);
					throw new IllegalArgumentException(messageSource.getMessage(
							"validate.validationCode", null, "Validation code already used", LocaleContextHolder.getLocale()));
				}

				String expiryDateStr = validationCodeModel.getExpirydate();
				Date expiryDate = DateFormatterUtil.dateUtil(expiryDateStr, ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
				enableValidationCode.setExpiryDate(expiryDate);

				enableValidationCode.setCreatedAt(validation.getCreatedAt());
				enableValidationCode.setCreatedBy(validation.getCreatedBy());

				enableValidationCode(enableValidationCode);

				bookletByValidationCode.setIsUsed(YesNoEnum.YES);
				saveBookletByValidationCode(bookletByValidationCode);
			}

		}
	}

	/**
	 *
	 * @param validationModel
	 * @return
	 * @throws Exception
	 */
	private Validation saveValidation(ValidationModel validationModel,User user) throws Exception {
		Validation validation = convertToValidationEntity(validationModel, user);
		return saveValidation(validation);
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @param filesMap
	 * @throws IOException
	 * @throws Exception
	 */
	private void saveAttachmentDetails(Validation validation,
									   Map<String, MultipartFile> filesMap,User user) throws IOException, Exception {

		for (Entry<String, MultipartFile> fileEntry : filesMap.entrySet()) {
			MultipartFile file = fileEntry.getValue();
			if(file.getSize()>0 && file.getOriginalFilename().toString()!=null) {
				Attachment attachment = new Attachment();
				attachment.setFile(base64Encode(file));
				attachment.setFileMimeType(file.getContentType());
				String extension = FilenameUtils.getExtension(file.getOriginalFilename()).toString();
				attachment.setExtension(extension);
				attachment.setFileSize(file.getSize());
				attachment.setSourceType(SourceTypeEnum.VALIDATION);
				attachment.setName(file.getOriginalFilename().toString());
				attachment.setReferenceType(fileEntry.getKey());
				attachment.setReferenceId(validation.getId());
				attachment.setCreatedBy(user);
				attachment.setCreatedAt(validation.getCreatedAt());
				attachment.setIsActive(YesNoEnum.YES);
				saveAttachment(attachment);
			}
		}
	}

	private void saveAttachmentDetailsWeb(Validation validation, ValidationModel validationModel, User user) throws IOException, Exception {

		List<Map<String, String>> lists = new ArrayList<>();
		if(validationModel.getValidate1File1Map() != null && !validationModel.getValidate1File1Map().isEmpty())
			lists.add(validationModel.getValidate1File1Map());
		if(validationModel.getValidate1File2Map() != null && !validationModel.getValidate1File2Map().isEmpty())
			lists.add(validationModel.getValidate1File2Map());
		if(validationModel.getValidate2File1Map() != null && !validationModel.getValidate2File1Map().isEmpty())
			lists.add(validationModel.getValidate2File1Map());
		if(validationModel.getValidate2File2Map() != null && !validationModel.getValidate2File2Map().isEmpty())
			lists.add(validationModel.getValidate2File2Map());

		if(lists != null && !lists.isEmpty() && lists.size() > 0) {

			List<Attachment> allAttachment = new ArrayList<>();

			for(Map<String, String> fileMap : lists) {
				if(fileMap != null && !fileMap.isEmpty()) {
					Attachment attachment = new Attachment();
					attachment.setReferenceId(Long.valueOf(validationModel.getId()));
					attachment.setIsActive(YesNoEnum.YES);
					attachment.setFile(fileMap.get("file"));
					attachment.setFileMimeType(fileMap.get("contentType"));
					attachment.setExtension(fileMap.get("fileExtension"));
					attachment.setFileSize(Long.parseLong(fileMap.get("size")));
					attachment.setName(fileMap.get("fileName"));
					attachment.setReferenceType(fileMap.get("referenceKey"));
					attachment.setSourceType(SourceTypeEnum.VALIDATION);
					attachment.setCreatedBy(user);
					attachment.setCreatedAt(validation.getCreatedAt());
					allAttachment.add(attachment);
				}
			}
			if(allAttachment != null && !allAttachment.isEmpty() && allAttachment.size() > 0)
				saveAllAttachment(allAttachment);
		}
	}

	/**
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public String base64Encode(MultipartFile file) throws IOException {
		return Base64.getEncoder().encodeToString(file.getBytes());
	}

	/**
	 *
	 * @param validationModel
	 * @return
	 * @throws Exception
	 */
	private Validation convertToValidationEntity(ValidationModel validationModel,User user) throws Exception{
		Validation validation = new Validation();
		setAdmission(validationModel, validation);
		setServiceType(validationModel, validation);
		setDateFrom(validationModel, validation);
		setDateTo(validationModel, validation);
		setNumberOfDays(validationModel, validation);
		setNumberOfPeriods(validationModel, validation);
		setDoctorName(validationModel, validation);
		setCreatedBy(user, validation);
		setCreatedDate(validationModel,validation);
		setUpdatedBy(user, validation);
		setUpdatedDate(validationModel, validation);
		setDocumentReference(validationModel, validation);
		setDocumentId(validationModel, validation);
		validation.setSyncDate(new Date());
		validation.setUniqueId(validationModel.getUniqueId());
		return validation;
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @throws Exception
	 */
	private void setUpdatedDate(ValidationModel validationModel, Validation validation) throws Exception{
		String updatedDateStr = validationModel.getUpdatedDate();
		if(Utilities.isValidString(updatedDateStr)) {
			Date updatedDate = DateFormatterUtil.dateUtil(updatedDateStr, ConstantsUtil.CREATION_TIMESTAMP_FORMAT);
			validation.setUpdatedAt(updatedDate);
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setUpdatedBy(User user, Validation validation) {
		validation.setUpdatedBy(user);
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @throws Exception
	 */
	private void setCreatedDate(ValidationModel validationModel,Validation validation) throws Exception{
		validation.setCreatedAt(DateFormatterUtil.dateUtil(validationModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setCreatedBy(User user, Validation validation) {
		validation.setCreatedBy(user);
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setDoctorName(ValidationModel validationModel, Validation validation) {
		String doctorName = validationModel.getDoctorName();
		if(Utilities.isValidString(doctorName)) {
			validation.setDoctorName(doctorName);
		}
	}


	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setNumberOfPeriods(ValidationModel validationModel, Validation validation) {
		String numberOfPeriods = validationModel.getNumberOfPeriods();
		if(Utilities.isValidString(numberOfPeriods)) {
			validation.setNumberOfPeriods(Integer.parseInt(numberOfPeriods));
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setNumberOfDays(ValidationModel validationModel, Validation validation) {
		String numberOfDays = validationModel.getNumberOfDays();
		if(Utilities.isValidString(numberOfDays)) {
			validation.setNumberOfDays(Integer.parseInt(numberOfDays));
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @throws Exception
	 */
	private void setDateTo(ValidationModel validationModel, Validation validation) throws Exception {
		String dateTo = validationModel.getDateTo();
		if(Utilities.isValidString(dateTo)) {
			validation.setDateTo(DateFormatterUtil.dateUtil(dateTo, ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW));
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 * @throws Exception
	 */
	private void setDateFrom(ValidationModel validationModel, Validation validation) throws Exception {
		String dateFrom = validationModel.getDateFrom();
		if(Utilities.isValidString(dateFrom)) {
			validation.setDateFrom(DateFormatterUtil.dateUtil(dateFrom, ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW));
		}
	}


	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setServiceType(ValidationModel validationModel, Validation validation) throws FailProcessException {
		String serviceTypeShortName = validationModel.getServiceTypeShortName();
		if(Utilities.isValidString(serviceTypeShortName)) {
			validation.setServiceType(serviceTypeRepository.findByShortName(serviceTypeShortName));
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setAdmission(ValidationModel validationModel, Validation validation) {
		String admissionId = validationModel.getAdmissionId();
		if(Utilities.isValidString(admissionId)) {
			Optional<Admission> admissionOptional = admissionRepository.findById(Long.parseLong(admissionId));
			validation.setAdmission(admissionOptional.get());
		}
	}

	/**
	 *
	 * @param validationId
	 * @param validation
	 * @return
	 */
	public Map<String, Object> addValidationDetailsToMap(Long validationId, Validation validation) throws FailProcessException {
		Map<String, Object> map;
		map = new LinkedHashMap<>();
		map.put(ConstantsUtil.VALIDATION_ID, validationId);
		map.put(ConstantsUtil.ADMISSION_ID, (validation.getAdmission()==null?"":validation.getAdmission().getId()));
		map.put(ConstantsUtil.SERVICE_TYPE, getServiceTypes(validation));
		map.put(ConstantsUtil.DATE_FROM, DateFormatterUtil.formDateUtil(validation.getDateFrom()));
		map.put(ConstantsUtil.DATE_TO,  DateFormatterUtil.formDateUtil(validation.getDateTo()));
		map.put(ConstantsUtil.NUMBER_OF_DAYS, validation.getNumberOfDays());
		map.put(ConstantsUtil.NUMBER_OF_PERIODS, validation.getNumberOfPeriods());
		map.put(ConstantsUtil.DOCTOR_NAME, validation.getDoctorName());
		map.put(ConstantsUtil.CREATED_AT, DateFormatterUtil.creationDateUtil(validation.getCreatedAt()));
		map.put(ConstantsUtil.CREATED_BY, (validation.getCreatedBy()==null?"":validation.getCreatedBy().getId()));
		map.put(ConstantsUtil.UPDATED_AT,  DateFormatterUtil.creationDateUtil(validation.getUpdatedAt()));
		map.put(ConstantsUtil.UPDATED_BY, (validation.getUpdatedBy()==null?"":validation.getUpdatedBy().getId()));
		map.put(ConstantsUtil.DOC_SHORT_NAME, validation.getDocuments()==null?"":validation.getDocuments().getShortName());
		map.put(ConstantsUtil.DOC_SHORT_REF, validation.getDocReferenceNo()==null?"":validation.getDocReferenceNo());
		List<ValidationCodeModel> validationCodeDetails = getValidationCodeDetails(validation);
		map.put(ConstantsUtil.VALIDATION_CODE_DETAILS, validationCodeDetails);
		map.put(ConstantsUtil.RECORD_UNIQUE_ID, validation.getUniqueId());
		return map;
	}

	/**
	 *
	 * @param validation
	 * @return
	 */
	private List<ValidationCodeModel> getValidationCodeDetails(Validation validation) throws FailProcessException {

		List<ValidationCodeModel> validationCodeDetailsList = new ArrayList<ValidationCodeModel>();

		List<Long> admissionIdList=admissionRepository.getAdmissionIdListByEnrollmentByCreatedOrder(validation.getAdmission().getEnrollment().getId());

		for(Long admissionId:admissionIdList) {
			List<Long> validationIdList=validationRepository.getValidationIdListByAdmissionByCreatedOrder(admissionId);
			if(validationIdList!=null & validationIdList.size()>0) {
				for(Long validationId: validationIdList) {

					List<EnableValidationCode> enableValidationCodeList = enableValidationCodeRepository.findByReferenceIdAndReferenceType(validationId, ConstantsUtil.REFERENCE_TYPE_VALIDATION);
					for (EnableValidationCode enableValidationCode : enableValidationCodeList) {
						ValidationCodeModel validationCodeDetails = new ValidationCodeModel();
						validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION);
						validationCodeDetails.setValidationCodeType(enableValidationCode.getValidationType());
						validationCodeDetails.setValidationCode(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getValidationCode());
						validationCodeDetails.setExpirydate(DateFormatterUtil.formDateUtil(enableValidationCode.getExpiryDate()));
						validationCodeDetails.setIsUsed(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getIsUsed().getValue());
						validationCodeDetails.setIsActive(enableValidationCode.getSetupBookletByValidationCode()==null?"":enableValidationCode.getSetupBookletByValidationCode().getIsActive().getValue());
						validationCodeDetailsList.add(validationCodeDetails);
					}
				}
			}
		}

		return validationCodeDetailsList;
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setDocumentReference(ValidationModel validationModel, Validation validation) {
		String docReference = validationModel.getDocumentReferenceNo();
		if(Utilities.isValidString(docReference)) {
			validation.setDocReferenceNo(docReference);
		}
	}

	/**
	 *
	 * @param validationModel
	 * @param validation
	 */
	private void setDocumentId(ValidationModel validationModel, Validation validation) throws FailProcessException {
		String docIdShortName = validationModel.getDocumentShortName();
		if(Utilities.isValidString(docIdShortName)) {
			validation.setDocuments(DocumentsRepository.findByShortName(docIdShortName));
		}
	}

	@Transactional
	public Map<String, Object> validateBeneficiary(Map<String, String> requestHeader, Map<String, MultipartFile> filesMap,ValidationModel validationModel)
			throws Exception {

		User user = validateUserDetail.validateAndGetUser(requestHeader);

		if(!validationModel.isWebCall()) {
			validateValidationDetail.validateValidationDetails(filesMap, validationModel);
		}

		ValidationModel respValidationModel = saveValidationDetails(validationModel, filesMap,user);

		addHistoricalBeneficiaryMilestone(requestHeader,respValidationModel);

		Map<String, Object> map = new HashMap<>();
		map.put(ConstantsUtil.VALIDATION_ID, respValidationModel.getId());
		return map;
	}

	public Map<String, Object> getValidationCodeByVca(String vca)
			throws Exception {
		List<BookletValidationCodeModel> validationCodeList = bookletByValidationCodeService.getValidationCodeModelByVca(vca);
		Map<String, Object> map = new HashMap<>();
		map.put(ConstantsUtil.VALIDATION_CODE_LIST, validationCodeList);
		return map;
	}

	@Transactional
	public void redeemValidationCode(PaidBeneficiaryModel paidBeneficiaryModel)
			throws Exception {
		List<String> validationCodeList = paidBeneficiaryModel.getValidationCodesList();
		bookletByValidationCodeService.redeemValidationCodeList(validationCodeList);
	}

	private Validation saveValidation(Validation validation) {
		try {
			Validation validationNew=validationRepository.save(validation);
			return validationNew;
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	private void enableValidationCode(EnableValidationCode enableValidationCode) {
		try {
			enableValidationCodeRepository.save(enableValidationCode);
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	private void saveBookletByValidationCode(BookletByValidationCode bookletByValidationCode) {
		try {
			bookletByValidationCodeRepository.save(bookletByValidationCode);
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	private void saveAttachment(Attachment attachment) {
		try {
			attachmentRepository.save(attachment);
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	private void saveAllAttachment(List<Attachment> attachmentList) {
		try {
			attachmentRepository.saveAll(attachmentList);
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	private void addHistoricalBeneficiaryMilestone(Map<String, String> requestHeader, ValidationModel validationModel)
			throws Exception {

		CycleByProjectModel cycleByProjectModel =beneficiaryApiCallService.getCycleByProjectName(requestHeader,validationModel.getProjectShortName());

		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setCurrentFormId(validationModel.getCurFormId());
		historicalBeneficiaryModel.setBookletId(validationModel.getBookletId());
		historicalBeneficiaryModel.setMilestoneReferenceId(Long.parseLong(validationModel.getId()));
		historicalBeneficiaryModel.setCycleId(cycleByProjectModel.getCycleId());
		historicalBeneficiaryModel.setCreatedDate(DateFormatterUtil.dateUtil(validationModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
		historicalBeneficiaryModel.setMilestoneType(MilestoneTypeEnum.VALIDATION.toString());

		historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);

	}


	@Transactional
	public void saveVcaMonitoringLog(VcaMonitoringDataModel vcaMonitoringDataModel) throws Exception {
		User user = new User();
		user.setId(Long.parseLong(vcaMonitoringDataModel.getCreatedBy()));

		VcaMonitoringLog vcaMonitoringLog=vcaMonitoringLogRepository.getVcaLogByUser(user.getId());

		vcaMonitoringLog =(vcaMonitoringLog==null?new VcaMonitoringLog():vcaMonitoringLog);

		Long viewedAttempt=Long.parseLong(vcaMonitoringDataModel.getViewedAttempt());
		viewedAttempt=viewedAttempt+(vcaMonitoringLog.getViewedAttempt()==null?0L:vcaMonitoringLog.getViewedAttempt());

		vcaMonitoringLog.setFailedAttempt(Long.parseLong(vcaMonitoringDataModel.getFailedAttempt()));
		vcaMonitoringLog.setViewedAttempt(viewedAttempt);
		vcaMonitoringLog.setCreatedAt(DateFormatterUtil.dateUtil(vcaMonitoringDataModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));

		if(vcaMonitoringDataModel.getUpdatedDate()!=null && !vcaMonitoringDataModel.getUpdatedDate().isEmpty()) {
			vcaMonitoringLog.setUpdatedAt(DateFormatterUtil.dateUtil(vcaMonitoringDataModel.getUpdatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
		}

		vcaMonitoringLog.setCreatedBy(user);

		try {
			vcaMonitoringLogRepository.save(vcaMonitoringLog);
		} catch(Exception e) {
			logger.debug("Error In saveVcaMonitoringLog",e);
			throw new FailProcessException(e);
		}
	}

	private void saveLatestRecordJsonForValidation(Validation validation) throws JsonProcessingException {

		logger.debug("===== saveLatestRecordJsonForValidation Start ======");

		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();

		Date syncDate=validation.getSyncDate();

		Map<String, Object> validationDataMap = addValidationDetailsToMap(validation.getId(),validation);

		Admission admission = admissionRepository.getLatestAdmissionById(validation.getAdmission().getId());
		Map<String, Object> admissionDataMap = admissionService.addAdmissionDetailsToMap(admission);

		Optional<Enrollment> enrollmentOpt = enrollmentRepository.findById(admission.getEnrollment().getId());
		Enrollment enrollment=enrollmentOpt.orElse(null);
		Map<String, Object> enrollmentDataMap = enrollmentService.addEnrollmentDetailsToMap(enrollment.getId(),enrollment);

		beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);

		synchronizationService.saveLatestJsonRecordForDownload(enrollment.getCurrentForm(),syncDate,beneficiaryJsonMap);

		logger.debug("======= saveLatestRecordJsonForValidation End =======");
	}

	private String getServiceTypes(Validation validation) throws FailProcessException {

		List<String> finalServiceTypeList=new ArrayList<String>();

		List<Long> admissionIdList=admissionRepository.getAdmissionIdListByEnrollmentByCreatedOrder(validation.getAdmission().getEnrollment().getId());

		for(Long id:admissionIdList) {

			List<String> serviceTypeList=validationRepository.getAllServiceTypes(id);

			if(serviceTypeList!=null && serviceTypeList.size()>0) {
				for(String serviceType: serviceTypeList) {
					if(finalServiceTypeList.contains(serviceType)) {
						finalServiceTypeList.remove(serviceType);
					}
					finalServiceTypeList.add(serviceType);
				}
			}
		}

		return getServiceTypeString(finalServiceTypeList);
	}

	private String getServiceTypeString(List<String> finalServiceTypeList) {

		StringBuilder serviceTypeSb=new StringBuilder();

		for(String serviceType:finalServiceTypeList) {
			serviceTypeSb.append(serviceType);
			serviceTypeSb.append(ConstantsUtil.RECORD_DELIMETER);
		}

		if(serviceTypeSb.toString().endsWith(ConstantsUtil.RECORD_DELIMETER)) {
			serviceTypeSb.setLength(serviceTypeSb.length()-1);
		}

		return serviceTypeSb.toString();
	}

	public Map<String, Object> getAllServiceTypes(){
		List<ServiceTypeModel> serviceTypeModels = new ArrayList<>();
		List<ServiceType> list = serviceTypeRepository.getAllServiceTypesByStatus();
		if(list != null && !list.isEmpty()){
			for(ServiceType type : list){
				ServiceTypeModel typeModel = new ServiceTypeModel();
				typeModel.setId(type.getId());
				typeModel.setShortName(type.getShortName());
				typeModel.setEnName(type.getEnName());
				typeModel.setArName(type.getArName());
				serviceTypeModels.add(typeModel);
			}
		}
		Map<String, Object> map = new HashMap<>();
		map.put(ConstantsUtil.SERVICE_TYPE_LIST, serviceTypeModels);
		return map;
	}

}
