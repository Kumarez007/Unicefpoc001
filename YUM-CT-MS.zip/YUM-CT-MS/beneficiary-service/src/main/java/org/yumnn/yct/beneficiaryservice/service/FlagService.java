package org.yumnn.yct.beneficiaryservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.repository.FlagRepository;
import org.yumnn.yct.common.entity.catalog.Flag;
import org.yumnn.yct.common.enumeration.flag.FlagTypeEnum;
import org.yumnn.yct.common.model.administration.FlagModel;
import org.yumnn.yct.common.util.Utilities;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FlagService.java
 * @class_description 
 * @create_date Aug 17, 2021
 * @last_Update Aug 17, 2021
 */
@Service
public class FlagService {


	@Autowired
	private FlagRepository flagRepository;

	/**
	 * 
	 * @author WQ
	 * @date Aug 17, 2021
	 * @description_method 
	 * @param flagType
	 * @param projectId
	 * @return
	 */
	public List<Flag> retrieveHouseholdAndMemberFlagsByActiveCycle(FlagTypeEnum flagType, Long projectId) {
		return flagRepository.retrieveFlagsByProjectActiveCycle(flagType, projectId);
	}
	/**
	 * 
	 * @author WQ
	 * @date Aug 30, 2021
	 * @description_method 
	 * @param projectId
	 * @return
	 */
	public List<Flag> retrieveHouseholdAndMemberFlagsByProjectActiveCycle(Long projectId ) {
		return flagRepository.retrieveHouseholdAndMemberFlagsByProjectActiveCycle(projectId);
	}
	/**
	 * 
	 * @author WQ
	 * @date Aug 17, 2021
	 * @description_method 
	 * @param flagType
	 * @param projectId
	 * @return
	 */
	public List<FlagModel> retrieveHouseholdAndMemberFlagsModelByActiveCycle(FlagTypeEnum flagType, Long projectId) {
		List<FlagModel> modelList = new ArrayList<>();
		List<Flag> list = flagRepository.retrieveFlagsByProjectActiveCycle(flagType,projectId);
		if(!Utilities.isNULL(list) && !list.isEmpty()) {
			list.forEach(item -> {
				modelList.add(item.getFlagModel());
			});
		}
		return modelList;
	}
	
	/**
	 * 
	 * @author WQ
	 * @date Aug 17, 2021
	 * @description_method 
	 * @param flagType
	 * @param projectId
	 * @return
	 */
	public List<FlagModel> retrieveHouseholdAndMemberFlagsModelByActiveCycle(Long projectId) {
		List<FlagModel> modelList = new ArrayList<>();
		List<Flag> list = flagRepository.retrieveHouseholdAndMemberFlagsByProjectActiveCycle(projectId);
		if(!Utilities.isNULL(list) && !list.isEmpty()) {
			list.forEach(item -> {
				modelList.add(item.getFlagModel());
			});
		}
		return modelList;
	}

}
