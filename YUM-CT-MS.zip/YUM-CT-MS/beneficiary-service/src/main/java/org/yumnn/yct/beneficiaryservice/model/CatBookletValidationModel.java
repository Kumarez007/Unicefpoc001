package org.yumnn.yct.beneficiaryservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.yumnn.yct.common.util.entityobject.ParentEntityObject;

@Entity
public class CatBookletValidationModel  extends ParentEntityObject{

	
	@Id
	@Column(name = "id")
	private String id;
	
	@Column(name = "orderItem")
	private String orderItem;
	
	@Column(name = "isActive")
	private String isActive;
	
	
	@Column(name = "IsUsed")
	private String isUsed;
	
	@Column(name = "idCatBookletfk")
	private String idCatBookletfk;
	
	@Column(name = "validationCode")
	private String validationCode;
	
	@Column(name = "isRedeemed")
	private String isRedeemed;
	
	@Column(name = "validationCodeType")
	private String validationCodeType;
	
	@Column(name = "isPrinted")
	private String isPrinted;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(String orderItem) {
		this.orderItem = orderItem;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}

	public String getIdCatBookletfk() {
		return idCatBookletfk;
	}

	public void setIdCatBookletfk(String idCatBookletfk) {
		this.idCatBookletfk = idCatBookletfk;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public String getIsRedeemed() {
		return isRedeemed;
	}

	public void setIsRedeemed(String isRedeemed) {
		this.isRedeemed = isRedeemed;
	}

	public String getValidationCodeType() {
		return validationCodeType;
	}

	public void setValidationCodeType(String validationCodeType) {
		this.validationCodeType = validationCodeType;
	}

	public String getIsPrinted() {
		return isPrinted;
	}

	public void setIsPrinted(String isPrinted) {
		this.isPrinted = isPrinted;
	}
	
	
}
