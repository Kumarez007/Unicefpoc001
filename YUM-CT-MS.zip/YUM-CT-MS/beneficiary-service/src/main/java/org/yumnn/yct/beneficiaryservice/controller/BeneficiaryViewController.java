package org.yumnn.yct.beneficiaryservice.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;
import org.yumnn.yct.beneficiaryservice.service.HistoricalBeneficiaryMilestoneService;
import org.yumnn.yct.beneficiaryservice.service.HouseholdMemberService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt May 10, 2021 6:44:05 PM
 */

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/beneficiaryViewcontrol")
public class BeneficiaryViewController {

	private static Logger logger = LogManager.getLogger(BeneficiaryViewController.class);

	@Autowired
	private EnrollmentService enrollmentService;
	
	@Autowired
	private HouseholdMemberService householdMemberService;
	
	@Autowired
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;

	@Operation(summary  = "Post operation for beneficiary enrollment")
	@PostMapping(value = "/searchBeneficaryInfo")
	public ResponseEntity<?> searchBeneficaryInfo(@RequestHeader Map<String, String> requestHeader,@RequestBody Map<String, String> body) 
			throws Exception {

		final String method = "searchBeneficaryInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("RequestBody: " + body.toString());
	    try {
	    	Map<String, Object> map=enrollmentService.searchBeneficaryInfo(body);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In searchBeneficaryInfo: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for HouseHold Card Info")
	@GetMapping(value = "/getHouseholdCardInfo")
	public ResponseEntity<?> getHouseholdCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId,
			@RequestParam(value = "projectShortName", required = true) String projectShortName) 
			throws Exception {

		final String method = "getHouseholdCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=enrollmentService.getHouseholdCardInfo(curFormId,projectShortName);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getHouseholdCardInfo: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for HouseHold Card Info")
	@GetMapping(value = "/getFacilityCardInfo")
	public ResponseEntity<?> getFacilityCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId) 
			throws Exception {

		final String method = "getFacilityCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=enrollmentService.getFacilityCardInfo(curFormId);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getFacilityCardInfo: ",e);
			throw e;
		}
		
	}

	
	@Operation(summary  = "Get operation for Payment By Service Card Info")
	@GetMapping(value = "/getPaymentByServiceCardInfo")
	public ResponseEntity<?> getPaymentByServiceCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId) 
			throws Exception {

		final String method = "getPaymentByServiceCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=enrollmentService.getPaymentByServiceCardInfo(curFormId);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getPaymentByServiceCardInfo: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for Member Card Info")
	@GetMapping(value = "/getMemberCardInfo")
	public ResponseEntity<?> getMemberCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId,
			@RequestParam(value = "projectShortName", required = true) String projectShortName) 
			throws Exception {

		final String method = "getMemberCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=householdMemberService.getMemberCardInfo(curFormId,projectShortName);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getMemberCardInfo: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for Beneficiary Timeline Data")
	@GetMapping(value = "/getBeneficiaryTimelineData")
	public ResponseEntity<?> getBeneficiaryTimelineData(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId) 
			throws Exception {

		final String method = "getBeneficiaryTimelineData";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=historicalBeneficiaryMilestoneService.getBeneficiaryTimelineData(curFormId);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getBeneficiaryTimelineData: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for Contact Card Info")
	@GetMapping(value = "/getContactCardInfo")
	public ResponseEntity<?> getContactCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId,
			@RequestParam(value = "uniqueCode", required = true) String uniqueCode) 
			throws Exception {

		final String method = "getContactCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=householdMemberService.getContactCardInfo(curFormId,uniqueCode);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getContactCardInfo: ",e);
			throw e;
		}
		
	}
	@Operation(summary  = "Get operation for Contact Card Info")
	@GetMapping(value = "/getFacilityContactCardInfo")
	public ResponseEntity<?> getFacilityContactCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId,
			@RequestParam(value = "uniqueCode", required = true) String uniqueCode) 
			throws Exception {

		final String method = "getContactCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=householdMemberService.getFacilityContactCardInfo(curFormId,uniqueCode);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getContactCardInfo: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary  = "Get operation for Payment By Cycle Card Info")
	@GetMapping(value = "/getPaymentByCycleCardInfo")
	public ResponseEntity<?> getPaymentByCycleCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) String curFormId, @RequestParam(value = "unicode", required = true) String unicode)
			throws Exception {

		final String method = "getPaymentByCycleCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=enrollmentService.getPaymentByCycleCardInfo(curFormId, unicode);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getPaymentByCycleCardInfo: ",e);
			throw e;
		}
	}
	
	@Operation(summary  = "Get operation for Grievances and Inquiries Card Info")
	@GetMapping(value = "/getGrievancesAndInquiriesCardInfo")
	public ResponseEntity<?> getGrievancesAndInquiriesCardInfo(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "curFormId", required = true) Long curFormId,
			@RequestParam(value = "uniqueCode", required = true) String uniqueCode) 
			throws Exception {

		final String method = "getGrievancesAndInquiriesCardInfo";
	    logger.debug("Entering: " + method);
	    logger.debug("RequestHeader: " + requestHeader.toString());
	    logger.debug("curFormId: " +curFormId);
	    try {
	    	Map<String, Object> map=enrollmentService.getGrievancesAndInquiriesCardInfo(curFormId,uniqueCode);
	    	SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getGrievancesAndInquiriesCardInfo: ",e);
			throw e;
		}
	}
		
	
}