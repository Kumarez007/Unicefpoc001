package org.yumnn.yct.beneficiaryservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.ProgramEntity;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "beneficiary.hst_enrollment")
public class Enrollment extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "code")
	private String enrollmentCode;

	@Column(name = "is_ref_from_other_tfc")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isRefferdFromOtherTFC;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_program_entity_fk")
	private ProgramEntity programEntity;

	@Column(name = "otp_ref_number")
	private String otpReferenceNumber;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_geolocation_fk")
	private Geolocation geoLocationOTP;

	@Column(name = "otp_nut_officer_name")
	private String otpNutritionOfficerName;

	@Column(name = "otp_nut_officer_ref_number")
	private String otpNutritionOfficerRefrenceNumber;

	@Column(name = "otp_nut_officer_phone_number")
	private String otpNutritionOfficerPhoneNumber;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_form_fk")
	private CurrentForm currentForm;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_booklet_fk")
	private Booklet booklet;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_program_entity_place_of_admission_fk")
	private ProgramEntity placeOfAdmission;

	@Column(name = "comments")
	private String comments;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = true)
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_updated_by_fk", nullable = true)
	private User updatedBy;
	
	@Column(name = "is_require_investigation")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isRequireInvestigation;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "synchronization_date", nullable = true)
	private Date syncDate;
	
	@Column(name = "unique_id")
	private String uniqueId;
	
	

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public YesNoEnum getIsRefferdFromOtherTFC() {
		return isRefferdFromOtherTFC;
	}

	public void setIsRefferdFromOtherTFC(YesNoEnum isRefferdFromOtherTFC) {
		this.isRefferdFromOtherTFC = isRefferdFromOtherTFC;
	}

	public ProgramEntity getProgramEntity() {
		return programEntity;
	}

	public void setProgramEntity(ProgramEntity programEntity) {
		this.programEntity = programEntity;
	}

	public String getOtpReferenceNumber() {
		return otpReferenceNumber;
	}

	public void setOtpReferenceNumber(String otpReferenceNumber) {
		this.otpReferenceNumber = otpReferenceNumber;
	}

	public Geolocation getGeoLocationOTP() {
		return geoLocationOTP;
	}

	public void setGeoLocationOTP(Geolocation geoLocationOTP) {
		this.geoLocationOTP = geoLocationOTP;
	}

	public String getOtpNutritionOfficerName() {
		return otpNutritionOfficerName;
	}

	public void setOtpNutritionOfficerName(String otpNutritionOfficerName) {
		this.otpNutritionOfficerName = otpNutritionOfficerName;
	}

	public String getOtpNutritionOfficerRefrenceNumber() {
		return otpNutritionOfficerRefrenceNumber;
	}

	public void setOtpNutritionOfficerRefrenceNumber(String otpNutritionOfficerRefrenceNumber) {
		this.otpNutritionOfficerRefrenceNumber = otpNutritionOfficerRefrenceNumber;
	}

	public String getOtpNutritionOfficerPhoneNumber() {
		return otpNutritionOfficerPhoneNumber;
	}

	public void setOtpNutritionOfficerPhoneNumber(String otpNutritionOfficerPhoneNumber) {
		this.otpNutritionOfficerPhoneNumber = otpNutritionOfficerPhoneNumber;
	}

	public String getEnrollmentCode() {
		return enrollmentCode;
	}

	public void setEnrollmentCode(String enrollmentCode) {
		this.enrollmentCode = enrollmentCode;
	}

	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}
	
	public Booklet getBooklet() {
		return booklet;
	}

	public void setBooklet(Booklet booklet) {
		this.booklet = booklet;
	}

	public ProgramEntity getPlaceOfAdmission() {
		return placeOfAdmission;
	}

	public void setPlaceOfAdmission(ProgramEntity placeOfAdmission) {
		this.placeOfAdmission = placeOfAdmission;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public YesNoEnum getIsRequireInvestigation() {
		return isRequireInvestigation;
	}

	public void setIsRequireInvestigation(YesNoEnum isRequireInvestigation) {
		this.isRequireInvestigation = isRequireInvestigation;
	}

	public Date getSyncDate() {
		return syncDate;
	}

	public void setSyncDate(Date syncDate) {
		this.syncDate = syncDate;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	
}
