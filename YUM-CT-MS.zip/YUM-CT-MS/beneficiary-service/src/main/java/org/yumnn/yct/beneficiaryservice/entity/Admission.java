package org.yumnn.yct.beneficiaryservice.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.ProgramEntity;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 15, 2021
 *
 */

@Entity
@Table(name = "beneficiary.hst_admission")
public class Admission extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "is_admitted", nullable = false)
	@Enumerated(EnumType.STRING)
	private YesNoEnum isAdmitted;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_program_entity_fk")
	private ProgramEntity programEntity;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_reasons_of_non_admission_fk")
	private ReasonsNonAdmission nonAdmissionReason;

	@Column(name = "other_reasons_non_admission")
	private String nonAdmissionOtherReasons;

	@OneToOne
	@JoinColumn(name = "id_enrollment_fk", nullable = false)
	private Enrollment enrollment;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = true)
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_updated_by_fk", nullable = true)
	private User updatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "synchronization_date", nullable = true)
	private Date syncDate;
	
	@Column(name = "unique_id")
	private String uniqueId;

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public YesNoEnum getIsAdmitted() {
		return isAdmitted;
	}

	public void setIsAdmitted(YesNoEnum isAdmitted) {
		this.isAdmitted = isAdmitted;
	}

	public ProgramEntity getProgramEntity() {
		return programEntity;
	}

	public void setProgramEntity(ProgramEntity programEntity) {
		this.programEntity = programEntity;
	}

	public ReasonsNonAdmission getNonAdmissionReason() {
		return nonAdmissionReason;
	}

	public void setNonAdmissionReason(ReasonsNonAdmission nonAdmissionReason) {
		this.nonAdmissionReason = nonAdmissionReason;
	}

	public String getNonAdmissionOtherReasons() {
		return nonAdmissionOtherReasons;
	}

	public void setNonAdmissionOtherReasons(String nonAdmissionOtherReasons) {
		this.nonAdmissionOtherReasons = nonAdmissionOtherReasons;
	}

	public Enrollment getEnrollment() {
		return enrollment;
	}

	public void setEnrollment(Enrollment enrollment) {
		this.enrollment = enrollment;
	}

	public Date getSyncDate() {
		return syncDate;
	}

	public void setSyncDate(Date syncDate) {
		this.syncDate = syncDate;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

}
