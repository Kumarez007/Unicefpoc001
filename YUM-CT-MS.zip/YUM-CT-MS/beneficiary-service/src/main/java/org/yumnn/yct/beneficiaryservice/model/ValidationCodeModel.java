package org.yumnn.yct.beneficiaryservice.model;

public class ValidationCodeModel {

	private String validationCode;
	private String expirydate;
	private String validationCodeType;
	private String referenceType;
	private String isUsed;
	private String isActive;
    private String isValidationCodeUsed;
	
	public String getValidationCode() {
		return validationCode;
	}
	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}
	public String getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}
	public String getValidationCodeType() {
		return validationCodeType;
	}
	public void setValidationCodeType(String validationCodeType) {
		this.validationCodeType = validationCodeType;
	}
	public String getReferenceType() {
		return referenceType;
	}
	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	/**
	 * @return the isUsed
	 */
	public String getIsUsed() {
		return isUsed;
	}
	/**
	 * @param isUsed the isUsed to set
	 */
	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}
	
	
	
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	public String getIsValidationCodeUsed() {
		return isValidationCodeUsed;
	}
	public void setIsValidationCodeUsed(String isValidationCodeUsed) {
		this.isValidationCodeUsed = isValidationCodeUsed;
	}
	@Override
	public String toString() {
		return "ValidationCodeModel [validationCode=" + validationCode + ", expirydate=" + expirydate
				+ ", validationCodeType=" + validationCodeType + ", referenceType=" + referenceType + ", isUsed="
				+ isUsed + ", isActive=" + isActive + ", isValidationCodeUsed=" + isValidationCodeUsed + "]";
	}
}
