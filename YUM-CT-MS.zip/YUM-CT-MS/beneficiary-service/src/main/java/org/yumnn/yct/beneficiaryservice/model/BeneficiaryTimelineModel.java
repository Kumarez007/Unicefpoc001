package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Nov 19, 2021 11:55:53 AM
 */
public interface BeneficiaryTimelineModel {

	public Long getCurrentFormId();

	public String getCycleName();

	public String getCycleStyleClass();

	public Long getMilestoneReferenceId();
	
	public String getMilestoneType();

	public String getCreatedDate();

}
