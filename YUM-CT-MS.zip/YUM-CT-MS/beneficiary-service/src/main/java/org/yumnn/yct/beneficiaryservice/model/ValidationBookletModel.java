package org.yumnn.yct.beneficiaryservice.model;

public class ValidationBookletModel {

    private Long id;

    private String validationCode;

    private String validationCodeType;
    
    private String isUsed;

    private boolean selected;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getValidationCode() {
        return validationCode;
    }

    public void setValidationCode(String validationCode) {
        this.validationCode = validationCode;
    }

    public String getValidationCodeType() {
        return validationCodeType;
    }

    public void setValidationCodeType(String validationCodeType) {
        this.validationCodeType = validationCodeType;
    }

	public String getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}


    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
