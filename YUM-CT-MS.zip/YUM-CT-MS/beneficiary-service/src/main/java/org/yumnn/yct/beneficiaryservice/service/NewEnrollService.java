package org.yumnn.yct.beneficiaryservice.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.repository.NewEnrollmentRepository;

@Service
public class NewEnrollService {
	@Autowired
	private NewEnrollmentRepository newEnrollmentRepository;
	
	public Map<String, Object> insertEnrolmentData(EnrollmentModel enrollmentAPIModel) throws Exception {
		newEnrollmentRepository.insertEnrolmentData(enrollmentAPIModel);
		return null;
	}

	public Map<String, Object> insertValidationData(ValidationModel validationModel) throws Exception {
		newEnrollmentRepository.insertValidationData(validationModel);
		return null;
	}

	public Map<String, Object> insertAdmissionData(BeneficiaryAdmissionModel admissionModel) throws Exception {
		newEnrollmentRepository.insertBeneficiaryAdmissionData(admissionModel);
		return null;
	}
}
