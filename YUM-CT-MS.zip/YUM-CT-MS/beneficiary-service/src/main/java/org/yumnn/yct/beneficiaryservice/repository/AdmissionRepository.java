package org.yumnn.yct.beneficiaryservice.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.common.exception.FailProcessException;

@Repository
public interface AdmissionRepository extends JpaRepository<Admission, Long> {

	Optional<Admission> findById(Long admissionId) throws FailProcessException;
	
	@Query(value = "SELECT * FROM beneficiary.hst_admission where id_enrollment_fk=:enrollmentId order by synchronization_date desc limit 1",nativeQuery = true)
	Admission getAdmissionByEnrollment(@Param("enrollmentId") Long enrollmentId) throws FailProcessException;
	
	@Query(value = "SELECT id FROM beneficiary.hst_admission where id_enrollment_fk=:enrollmentId order by synchronization_date desc",nativeQuery = true)
	List<Long> getAdmissionIdListByEnrollment(@Param("enrollmentId") Long enrollmentId) throws FailProcessException;
	
	@Query(value = "SELECT * FROM beneficiary.hst_admission where id=:admissionId order by synchronization_date desc limit 1",nativeQuery = true)
	Admission getLatestAdmissionById(@Param("admissionId") Long admissionId) throws FailProcessException;
	
	Admission findByUniqueId(String uniqueId) throws FailProcessException;
	
	@Query(value = "SELECT id FROM beneficiary.hst_admission where id_enrollment_fk=:enrollmentId order by created_at asc",nativeQuery = true)
	List<Long> getAdmissionIdListByEnrollmentByCreatedOrder(@Param("enrollmentId") Long enrollmentId) throws FailProcessException;
	
}
