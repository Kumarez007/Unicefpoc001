package org.yumnn.yct.beneficiaryservice.model;

import javax.validation.constraints.NotEmpty;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 27, 2021 7:25:32 PM
 */
public class VcaMonitoringDataModel {

	@NotEmpty(message = "{validate.fields}")
	private String failedAttempt;
	
	@NotEmpty(message = "{validate.fields}")
	private String viewedAttempt;
	
	@NotEmpty(message = "{validate.fields}")
	private String createdBy;
	
	@NotEmpty(message = "{validate.fields}")
	private String createdDate;
	
	private String updatedDate;

	public String getFailedAttempt() {
		return failedAttempt;
	}

	public void setFailedAttempt(String failedAttempt) {
		this.failedAttempt = failedAttempt;
	}

	public String getViewedAttempt() {
		return viewedAttempt;
	}

	public void setViewedAttempt(String viewedAttempt) {
		this.viewedAttempt = viewedAttempt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "VcaMonitoringDataModel [failedAttempt=" + failedAttempt + ", viewedAttempt=" + viewedAttempt
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}
	
}
