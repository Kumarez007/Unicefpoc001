package org.yumnn.yct.beneficiaryservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 10, 2021 1:48:19 AM
 */

@Entity
@Table(name = "beneficiary.sch_beneficiary")
public class SearchForm extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "id_cur_form_fk")
	private Long curFormId;
	
	@Column(name = "ben_names")
	private String beneficiaryName;

	@Column(name = "e_document_number")
	private String documentNumber;

	@Column(name = "id_governorate_fk")
	private Long governorateId;

	@Column(name = "id_district_fk")
	private Long districtId;

	@Column(name = "contact_number")
	private String contactNumber;

	@Column(name = "old_ben_id")
	private String oldBenId;

	@Column(name = "id_household_member_fk")
	private Long houseHoldMemberId;

	@Column(name = "id_ozla_fk")
	private Long ozlaId;
	
	@Column(name = "id_village_fk")
	private Long villageId;
	
	@Column(name = "id_program_entity_fk")
	private Long programEntityId;
	
	@Column(name = "booklet_number")
	private String bookletNumber;
	
	@Column(name = "id_household_member_type_fk")
	private Long houseHoldMemberTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "enrollment_date", nullable = false)
	private Date enrollmentDate;

	public Long getCurFormId() {
		return curFormId;
	}

	public void setCurFormId(Long curFormId) {
		this.curFormId = curFormId;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Long getGovernorateId() {
		return governorateId;
	}

	public void setGovernorateId(Long governorateId) {
		this.governorateId = governorateId;
	}

	public Long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getOldBenId() {
		return oldBenId;
	}

	public void setOldBenId(String oldBenId) {
		this.oldBenId = oldBenId;
	}

	public Long getHouseHoldMemberId() {
		return houseHoldMemberId;
	}

	public void setHouseHoldMemberId(Long houseHoldMemberId) {
		this.houseHoldMemberId = houseHoldMemberId;
	}

	public Long getOzlaId() {
		return ozlaId;
	}

	public void setOzlaId(Long ozlaId) {
		this.ozlaId = ozlaId;
	}

	public Long getVillageId() {
		return villageId;
	}

	public void setVillageId(Long villageId) {
		this.villageId = villageId;
	}

	public Long getProgramEntityId() {
		return programEntityId;
	}

	public void setProgramEntityId(Long programEntityId) {
		this.programEntityId = programEntityId;
	}

	public String getBookletNumber() {
		return bookletNumber;
	}

	public void setBookletNumber(String bookletNumber) {
		this.bookletNumber = bookletNumber;
	}

	public Long getHouseHoldMemberTypeId() {
		return houseHoldMemberTypeId;
	}

	public void setHouseHoldMemberTypeId(Long houseHoldMemberTypeId) {
		this.houseHoldMemberTypeId = houseHoldMemberTypeId;
	}

	public Date getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(Date enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	
	

}
