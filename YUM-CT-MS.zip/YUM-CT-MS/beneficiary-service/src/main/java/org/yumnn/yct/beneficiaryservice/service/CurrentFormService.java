package org.yumnn.yct.beneficiaryservice.service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.yumnn.yct.beneficiaryservice.model.CatBookletModel;
import org.yumnn.yct.beneficiaryservice.model.CatBookletValidationModel;
import org.yumnn.yct.beneficiaryservice.repository.CatBookletRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.CurrentFormModel;
import org.yumnn.yct.common.repository.ProjectRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Service
public class CurrentFormService {

	//FIXME (RF) remove logger 
	private static Logger logger = LogManager.getLogger(CurrentFormService.class);

	@Autowired
	private CurrentFormRepository currentFormRepository;

	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	private CatBookletRepository catBookletRepository;

	/**
	 * @param AttachmentModel
	 * @return AttachmentModel
	 * @throws Exception
	 */
	@Transactional
	public CurrentFormModel saveCurrentForm(CurrentFormModel currentFormModel, User user) throws Exception {
		logger.debug("Entering into saveCurrentForm()");
		CurrentForm currentForm = convertToCurrentFormEntity(currentFormModel, user);		
		try {
		currentForm = currentFormRepository.save(currentForm);
		}
		catch(Exception e) {
			throw new FailProcessException();
		}
		currentFormModel.setId(currentForm.getId().toString());
		logger.debug("Exiting from saveCurrentForm()");
		return currentFormModel;
	}

	/**
	 * @param AttachmentModel
	 * @return Attachment
	 * @throws Exception
	 */
	private CurrentForm convertToCurrentFormEntity(CurrentFormModel currentFormModel, User user) throws Exception {

		CurrentForm currentForm = new CurrentForm();
		currentForm.setId(currentFormRepository.getMaxId() + 1);
		setProject(currentFormModel, currentForm);
		setCreatedDate(currentFormModel,currentForm);
		setCreatedBy(user, currentForm);
		return currentForm;
	}

	/**
	 * @param CurrentFormModel, @param CurrentForm
	 * @return void
	 * @throws ParseException 
	 */
	private void setCreatedDate(CurrentFormModel currentFormModel, CurrentForm currentForm) throws ParseException {
		currentForm.setCreatedAt(DateFormatterUtil.dateUtil(currentFormModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
	}

	/**
	 * @param CurrentFormModel, @param CurrentForm
	 * @return void
	 */
	private void setCreatedBy(User user, CurrentForm currentForm) {
		currentForm.setCreatedBy(user);
	}

	private void setProject(CurrentFormModel currentFormModel, CurrentForm currentForm) {
		String projectShortName = currentFormModel.getProjectShortName();
		if (Utilities.isValidString(projectShortName)) {
			currentForm.setProject(
					projectRepository.findByShortName(ProjectNameEnum.valueOf(projectShortName.toUpperCase())));
		}
	}

	public CurrentFormModel findByFormNumber(String formNumber) throws Exception {

		commonValidationUtil.validateIsNullOrEmpty("Form Number",formNumber);
		CurrentForm currentForm = currentFormRepository.findByFormNumber(formNumber);
	
		if (Utilities.isNULL(currentForm)) {
			return null;
		}
		CurrentFormModel currentFormModel = new CurrentFormModel();
		currentFormModel.setId(currentForm.getId().toString());
		currentFormModel.setProjectShortName(currentForm.getProject().getShortName().getValue());
	
		return currentFormModel;
		
	}
	/**
	 * 
	 * @author WQ
	 * @date Jun 15, 2021
	 * @description_method 
	 * @param vca
	 * @return
	 * @throws Exception
	 */
	public CurrentFormModel findFormByVca(String vca) throws Exception {
		Booklet booklet =null;
		CurrentFormModel currentFormModel = null;
		commonValidationUtil.validateIsNullOrEmpty("VCA Number",vca);
		booklet = currentFormRepository.findBookletByVca(vca);
		currentFormModel = new CurrentFormModel();
		currentFormModel.setId( null);
		currentFormModel.setBookletId(!Utilities.isNULL(booklet) ? booklet.getId() : null);
		currentFormModel.setProjectShortName(ProjectNameEnum.NVS.getValue());
		return currentFormModel;

	}
	
	public CurrentFormModel findCurrentFormById(String id) throws Exception {

		commonValidationUtil.validateIsNullOrEmpty("Current Form Id",id);
		Optional<CurrentForm> currentFormOpt = currentFormRepository.findById(Long.parseLong(id));
	
		CurrentForm currentForm =currentFormOpt.orElse(null);
		
		if (Utilities.isNULL(currentForm)) {
			return null;
		}
		CurrentFormModel currentFormModel = new CurrentFormModel();
		currentFormModel.setId(currentForm.getId().toString());
		currentFormModel.setProjectId(currentForm.getProject().getId());
		currentFormModel.setProjectShortName(currentForm.getProject().getShortName().getValue());
	
		return currentFormModel;
		
	}
	
	public List<CatBookletModel> getCatBookletData() {
		return catBookletRepository.getCatBookletData();
	}
	
	public List<CatBookletValidationModel> getCatBookletValidationData() {
		return catBookletRepository.getCatBookletValidationData();
	}
}
