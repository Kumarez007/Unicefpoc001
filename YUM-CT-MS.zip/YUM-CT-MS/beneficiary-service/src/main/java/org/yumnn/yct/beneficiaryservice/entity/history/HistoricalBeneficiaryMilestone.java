package org.yumnn.yct.beneficiaryservice.entity.history;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;

@Entity
@Table(name= "beneficiary.hst_beneficiary_milestone")
@NamedQueries({
	@NamedQuery(name = "HistoricalBeneficiaryMilestone.getByBenefeciaryForm",
			query = "SELECT h from HistoricalBeneficiaryMilestone h WHERE  h.currentForm = :currentForm order by h.cycle.id desc")})
public class HistoricalBeneficiaryMilestone extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name= "id_cur_form_fk", referencedColumnName= "ID")
	private CurrentForm currentForm;
	
	@ManyToOne
	@JoinColumn(name= "id_cycle_fk", referencedColumnName= "ID")
	private Cycle cycle;
	
	@Column(name= "milestone_reference_id")
	private Long milestoneReferenceId;
	
	@Column(name= "milestone_type")
	@Enumerated(EnumType.STRING)
	private MilestoneTypeEnum milestoneType;
	
	@ManyToOne
	@JoinColumn(name = "id_booklet_fk", referencedColumnName = "ID")
	private Booklet booklet;
	
	@Column(name= "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	@ManyToOne
	@JoinColumn(name = "id_cycle_by_project_fk", referencedColumnName = "ID")
	private CycleByProject cycleByProject;
	
	@Transient
	private String grievanceCategoryAr;
	
	@Transient
	private String grievanceCategoryEn;
	
	@Transient
	private String milestoneTitle;

	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}

	public Long getMilestoneReferenceId() {
		return milestoneReferenceId;
	}

	public void setMilestoneReferenceId(Long milestoneReferenceId) {
		this.milestoneReferenceId = milestoneReferenceId;
	}


	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	@Override
	public String toString() {
		return this.milestoneTitle;
	}

	public Cycle getCycle() {
		return cycle;
	}

	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	/**
	 * @return the grievanceCategoryAr
	 */
	public String getGrievanceCategoryAr() {
		return grievanceCategoryAr;
	}

	/**
	 * @param grievanceCategoryAr the grievanceCategoryAr to set
	 */
	public void setGrievanceCategoryAr(String grievanceCategoryAr) {
		this.grievanceCategoryAr = grievanceCategoryAr;
	}

	/**
	 * @return the grievanceCategoryEn
	 */
	public String getGrievanceCategoryEn() {
		return grievanceCategoryEn;
	}

	/**
	 * @param grievanceCategoryEn the grievanceCategoryEn to set
	 */
	public void setGrievanceCategoryEn(String grievanceCategoryEn) {
		this.grievanceCategoryEn = grievanceCategoryEn;
	}

	/**
	 * @return the milestoneTitle
	 */
	public String getMilestoneTitle() {
		return milestoneTitle;
	}

	/**
	 * @param milestoneTitle the milestoneTitle to set
	 */
	public void setMilestoneTitle(String milestoneTitle) {
		this.milestoneTitle = milestoneTitle;
	}

	/**
	 * @return the milestoneType
	 */
	public MilestoneTypeEnum getMilestoneType() {
		return milestoneType;
	}

	/**
	 * @param milestoneType the milestoneType to set
	 */
	public void setMilestoneType(MilestoneTypeEnum milestoneType) {
		this.milestoneType = milestoneType;
	}

	/**
	 * @return the booklet
	 */
	public Booklet getBooklet() {
		return booklet;
	}

	/**
	 * @param booklet the booklet to set
	 */
	public void setBooklet(Booklet booklet) {
		this.booklet = booklet;
	}

	public CycleByProject getCycleByProject() {
		return cycleByProject;
	}

	public void setCycleByProject(CycleByProject cycleByProject) {
		this.cycleByProject = cycleByProject;
	}
}
