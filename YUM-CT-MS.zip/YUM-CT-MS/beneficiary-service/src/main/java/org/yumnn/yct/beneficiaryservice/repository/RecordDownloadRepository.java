package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.yumnn.yct.beneficiaryservice.entity.RecordDownload;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 30, 2021 8:24:21 PM
 */
public interface RecordDownloadRepository extends JpaRepository<RecordDownload, Long>{
	
	
	@Query(value = "SELECT count(*) FROM RecordDownload t where t.isActive='YES' and t.referenceType='BENEFICIARY DATA'")
	Long getTotalBeneficiaryCount() throws FailProcessException;
	
	@Modifying
	@Query(value = "UPDATE RecordDownload t set t.isActive=:isActive where t.referenceId=:referenceId")
	public void updateBeneficiaryRecordIsActive(@Param("isActive") YesNoEnum isActive,@Param("referenceId") Long referenceId) throws FailProcessException;

	@Query(value = "SELECT count(*) FROM RecordDownload t where t.id > :lastSyncId and t.isActive='YES' and t.referenceType='BENEFICIARY DATA'")
	Long getTotalBeneficiaryCountAfterId(@Param("lastSyncId") Long lastSyncId) throws FailProcessException;
	
	@Query(value = "SELECT t FROM RecordDownload t where t.isActive='YES' and t.referenceType='BENEFICIARY DATA'"
			+ " ORDER BY t.id ")
	List<RecordDownload> getBeneficiaryRecordsForFirstBatch(Pageable pageable) throws FailProcessException;

	@Query(value = "SELECT t FROM RecordDownload t where t.id > :lastSyncId and t.isActive='YES' and t.referenceType='BENEFICIARY DATA'"
			+ " ORDER BY t.id ")
	List<RecordDownload> getBeneficiaryRecordsAfterId(@Param("lastSyncId") Long lastSyncId, Pageable pageable) throws FailProcessException;

}
