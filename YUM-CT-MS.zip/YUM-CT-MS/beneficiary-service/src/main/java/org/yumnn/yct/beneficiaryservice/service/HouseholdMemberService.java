package org.yumnn.yct.beneficiaryservice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.beneficiaryservice.entity.AttachmentLog;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.HouseholdMemberLog;
import org.yumnn.yct.beneficiaryservice.entity.SearchForm;
import org.yumnn.yct.beneficiaryservice.model.ContactCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentContactInformationByFormRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.beneficiaryservice.repository.DocumentsRepository;
import org.yumnn.yct.beneficiaryservice.repository.GenderRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberTypeRepository;
import org.yumnn.yct.beneficiaryservice.util.param.HouseholdMemberServiceParam;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.entity.messages.CurrentContactInformationByForm;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.messages.PhoneSourceEnum;
import org.yumnn.yct.common.enumeration.messages.PhoneTypeEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.repository.IGeolocationRepository;
import org.yumnn.yct.common.repository.RelationshipRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.util.GeolocationUtil;
import org.yumnn.yct.common.util.SourceTypeEnum;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberLogRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentLogRepository;
import org.yumnn.yct.beneficiaryservice.repository.SearchFormRepository;



/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Service
public class HouseholdMemberService {

	private static Logger logger = LogManager.getLogger(HouseholdMemberService.class);
  
	@Autowired
	private HouseholdMemberRepository householdMemberRepository;
	
	@Autowired 
	private GenderRepository genderRepository;
	
	@Autowired 
	private DocumentsRepository documentsRepository;
	
	@Autowired 
	private RelationshipRepository relationshipRepository;
	
	@Autowired 
	private HouseholdMemberTypeRepository householdMemberTypeRepository;
	
	@Autowired
	private AttachmentRepository attachmentRepository;
	
	@Autowired
	private CurrentFormRepository currentFormRepository;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	HouseholdMemberLogRepository householdMemberLogRepository;
	
	@Autowired
	AttachmentLogRepository attachmentLogRepository;
	
	@Autowired
	SearchFormRepository searchFormRepository;
	
	@Autowired
	IGeolocationRepository iGeolocationRepository;
	
	@Autowired
	CurrentContactInformationByFormRepository currentContactInformationByFormRepository;
	
	/**
	 * @param List<HouseholdMemberModel>
	 * @return List<HouseholdMemberModel>
	 * @throws Exception
	 */
	@Transactional
	public List<HouseholdMemberModel> saveHouseholdMemberDetails(List<HouseholdMemberModel> householdMemberDetails, Map<String, MultipartFile> filesMap,User user, EnrollmentModel enrollmentModel) throws Exception {
		logger.debug("Entering into saveHouseholdMemberDetails()");
		List<HouseholdMemberModel> responseModelList = new ArrayList<HouseholdMemberModel>();
		
		for (HouseholdMemberModel householdMemberModel : householdMemberDetails) {
			if(householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER)){
				householdMemberModel.setIsPrimary(YesNoEnum.YES.getValue());
			}
			
			//FIXME Reduce complexity by removing two if statements //Fixed
			if(!householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE) 
					|| isValidNominee(householdMemberModel)) {
				HouseholdMemberModel responseModel = saveHouseholdMember(householdMemberModel, filesMap, user, enrollmentModel);
				responseModelList.add(responseModel);
			}
		}
		logger.debug("Exiting from saveHouseholdMemberDetails()");
		return responseModelList;
	}
	
	/**
	 * @param HouseholdMemberModel
	 * @return HouseholdMemberModel
	 * @throws Exception
	 */
	private HouseholdMemberModel saveHouseholdMember(HouseholdMemberModel householdMemberModel, Map<String, MultipartFile> filesMap, User user, EnrollmentModel enrollmentModel) throws Exception {
		
		//FIXME extract method //Fixed
		HouseholdMember householdMember = saveHouseholdMemberDetails(householdMemberModel, user);
		
		HouseholdMemberServiceParam householdMemberServiceParam = setHouseholdMemberServiceParam(householdMemberModel,
				filesMap, user, householdMember, enrollmentModel);
		
		saveAttachmentsForHouseholdMember(householdMemberServiceParam);
		return householdMemberModel;
	}

	private HouseholdMember saveHouseholdMemberDetails(HouseholdMemberModel householdMemberModel, User user)
			throws Exception {
		HouseholdMember householdMember = convertToHouseholdMemberEntity(householdMemberModel,user);
		
		householdMember = saveHouseholdMember(householdMember);
		
		householdMemberModel.setId(householdMember.getId().toString());
		return householdMember;
	}

	private HouseholdMemberServiceParam setHouseholdMemberServiceParam(HouseholdMemberModel householdMemberModel,
			Map<String, MultipartFile> filesMap, User user, HouseholdMember householdMember, EnrollmentModel enrollmentModel) {
		HouseholdMemberServiceParam householdMemberServiceParam=new HouseholdMemberServiceParam();
		householdMemberServiceParam.setFilesMap(filesMap);
		householdMemberServiceParam.setHouseholdMember(householdMember);
		householdMemberServiceParam.setHouseholdMemberModel(householdMemberModel);
		householdMemberServiceParam.setUser(user);
		householdMemberServiceParam.setEnrollmentCode(householdMemberModel.getCurrentFormId());
		
		if(enrollmentModel != null && enrollmentModel.isWebCall()) {
			if(enrollmentModel.getCaregiverFile1Map() != null && enrollmentModel.getCaregiverFile1Map().size() > 0) {
				householdMemberServiceParam.setCaregiverFile1Map(enrollmentModel.getCaregiverFile1Map());
			}
			
			if(enrollmentModel.getCaregiverFile2Map() != null && enrollmentModel.getCaregiverFile2Map().size() > 0) {
				householdMemberServiceParam.setCaregiverFile2Map(enrollmentModel.getCaregiverFile2Map());
			}
				
			if(enrollmentModel.getNomineeFile1Map() != null && enrollmentModel.getNomineeFile1Map().size() > 0) {
				householdMemberServiceParam.setNomineeFile1Map(enrollmentModel.getNomineeFile1Map());
			}
					
			if(enrollmentModel.getNomineeFile2Map() != null && enrollmentModel.getNomineeFile2Map().size() > 0) {
				householdMemberServiceParam.setNomineeFile2Map(enrollmentModel.getNomineeFile2Map());
			}			
			householdMemberServiceParam.setWebCall(enrollmentModel.isWebCall());
		}		
		
		setFileReferenceType(householdMemberModel, householdMemberServiceParam);
		return householdMemberServiceParam;
	}

	private void setFileReferenceType(HouseholdMemberModel householdMemberModel,
			HouseholdMemberServiceParam householdMemberServiceParam) {
		if(householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER)) {
			householdMemberServiceParam.setFileReferenceType(ConstantsUtil.CAREGIVER_FILE);
		}
		else if (householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE)) {
			householdMemberServiceParam.setFileReferenceType(ConstantsUtil.NOMINEE_FILE);
		}
	}

	/**
	   * @param file
	   * @return
	   * @throws IOException
	   */
	  public String base64Encode(MultipartFile file) throws IOException {
	    return Base64.getEncoder().encodeToString(file.getBytes());
	  }
	  
	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void saveAttachmentsForHouseholdMember(HouseholdMemberServiceParam householdMemberServiceParam)
			throws Exception {
		
		String isUpdate=householdMemberServiceParam.getHouseholdMemberModel()
				.getIsUpdated()==null?"":householdMemberServiceParam.getHouseholdMemberModel().getIsUpdated();
		
		String hhmType=householdMemberServiceParam.getHouseholdMemberModel().getHouseholdMemberTypeShortName();
		
		if(!hhmType.equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CHILD)) {
			
			if(isUpdate.equalsIgnoreCase(YesNoEnum.YES.getValue())) {
				updateAttachments(householdMemberServiceParam);
			} else {
				saveOrUpdateAttchmentDetails(householdMemberServiceParam, null);
			}
		}
	}

	/**
	 * @param HouseholdMemberModel
	 * @return HouseholdMember
	 * @throws Exception
	 */
	private HouseholdMember convertToHouseholdMemberEntity(HouseholdMemberModel householdMemberModel,User user) throws Exception {
		
		HouseholdMember householdMember = new HouseholdMember();
		setName(householdMemberModel, householdMember);
		setCurrentForm(householdMemberModel, householdMember);
		setGender(householdMemberModel, householdMember);
		setDOB(householdMemberModel, householdMember);
		setPhoneNumber(householdMemberModel, householdMember);
		setIdDocuments(householdMemberModel, householdMember);
		setDocumentReferenceNumber(householdMemberModel, householdMember);
		setRelationship(householdMemberModel, householdMember);
		setIsAssignedAsPaymentReceiver(householdMemberModel, householdMember);
		setHouseholdMemberType(householdMemberModel, householdMember);
		setIsPrimary(householdMemberModel, householdMember);
		setCreatedBy(user, householdMember);
		setCreatedDate(householdMemberModel, householdMember);
		return householdMember;
	}

	/**
	 *  @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setCreatedDate(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) throws Exception{
		householdMember.setCreatedAt(DateFormatterUtil.dateUtil(householdMemberModel.getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
	}
	
	/**
	 *  @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 */
	private void setCreatedBy(User user, HouseholdMember householdMember) {
			householdMember.setCreatedBy(user);
	}
	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setIsPrimary(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) {
		String isPrimary = householdMemberModel.getIsPrimary();
		if(Utilities.isValidString(isPrimary)) {
			householdMember.setIsPrimary(YesNoEnum.valueOf(isPrimary.toUpperCase()));
		}else {
			householdMember.setIsPrimary(YesNoEnum.NO);
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setHouseholdMemberType(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) throws Exception {
		String householdMemberTypeShortName = householdMemberModel.getHouseholdMemberTypeShortName();
		if(Utilities.isValidString(householdMemberTypeShortName)) {
			householdMember.setHouseholdMemberType(householdMemberTypeRepository.findByShortName(householdMemberTypeShortName));
		}
	}



	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setIsAssignedAsPaymentReceiver(HouseholdMemberModel householdMemberModel,
			HouseholdMember householdMember) {
		String isAssignedAsPaymentReceiver = householdMemberModel.getIsAssignedAsPaymentReceiver();
		if(Utilities.isValidString(isAssignedAsPaymentReceiver)) {
			householdMember.setIsAssignedAsPaymentReceiver(YesNoEnum.valueOf(isAssignedAsPaymentReceiver.toUpperCase()));
		}else {
			householdMember.setIsAssignedAsPaymentReceiver(YesNoEnum.NO);
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setRelationship(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) {
		String relationshipShortName = householdMemberModel.getRelationshipShortName();
		
		if(Utilities.isValidString(relationshipShortName)) {
			householdMember.setRelationship(relationshipRepository.findByShortName(relationshipShortName));
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setDocumentReferenceNumber(HouseholdMemberModel householdMemberModel,
			HouseholdMember householdMember) {
		String documentReferenceNumber = householdMemberModel.getDocumentReferenceNumber();
		if(Utilities.isValidString(documentReferenceNumber)) {
			householdMember.setDocumentReferenceNumber(documentReferenceNumber);
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setIdDocuments(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) throws Exception {
		String catDocShortName = householdMemberModel.getCatDocShortName();
		if(Utilities.isValidString(catDocShortName)) {
			householdMember.setDocument(documentsRepository.findByShortName(catDocShortName));
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setPhoneNumber(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) {
		String phoneNumber = householdMemberModel.getPhoneNumber();
		if(Utilities.isValidString(phoneNumber)) {
			householdMember.setPhoneNumber(phoneNumber);
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setDOB(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) throws Exception {
		String dateOfBirthStr = householdMemberModel.getDateOfBirth();
		if(Utilities.isValidString(dateOfBirthStr)) {
			Date dateOfBirth = DateFormatterUtil.dateUtil(dateOfBirthStr, ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
			householdMember.setDateOfBirth(dateOfBirth);
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setGender(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) throws Exception {
		String genderShortName = householdMemberModel.getGenderShortName();
		if(Utilities.isValidString(genderShortName)) {
			householdMember.setGender(genderRepository.findByShortName(genderShortName));
		}
	}

	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setName(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember){
		
		String userFullName = householdMemberModel.getFullName();
		if(Utilities.isValidString(userFullName)) {
			userFullName = userFullName.trim();
			int splitStrIndex = userFullName.indexOf(" ");
			if(splitStrIndex > -1) {
				String firstName = userFullName.substring(0, splitStrIndex);
				String lastName = userFullName.substring((splitStrIndex + 1));
				householdMember.setFirstName(firstName);
				householdMember.setLastName(lastName);
			}else {
				householdMember.setFirstName(userFullName);
			}
		}
	}
	
	/**
	 * @param HouseholdMemberModel, @param HouseholdMember
	 * @return void
	 * @throws Exception
	 */
	private void setCurrentForm(HouseholdMemberModel householdMemberModel, HouseholdMember householdMember) {
		String currentFormId = householdMemberModel.getCurrentFormId();
		if(Utilities.isValidString(currentFormId)) {
			Optional<CurrentForm> currentFormOptional = currentFormRepository.findById(Long.parseLong(currentFormId));
			householdMember.setCurrentForm(currentFormOptional.get());
		}
	}
	
	/**
	 * 
	 * @param memberCode
	 * @return HouseholdMemberModel
	 */
	public HouseholdMemberModel getByMemberCode(String memberCode) throws Exception {

		commonValidationUtil.validateIsNullOrEmpty("Member Code",memberCode);
			
		HouseholdMember householdMember = householdMemberRepository.findByMemberCode(memberCode);

		if (Utilities.isNULL(householdMember)) {
			return null;
		}
		HouseholdMemberModel householdMemberModel = new HouseholdMemberModel();
		householdMemberModel.setId(householdMember.getId().toString());

		return householdMemberModel;
	}

	private void saveOrUpdateAttchmentDetails(HouseholdMemberServiceParam householdMemberServiceParam,
			Long existingHouseHoldMemberId) throws Exception, IOException {
		
		if(householdMemberServiceParam.isWebCall()) {
			if(householdMemberServiceParam.getCaregiverFile1Map() != null && householdMemberServiceParam.getCaregiverFile1Map().get("referenceKey") != null 
					&& householdMemberServiceParam.getCaregiverFile1Map().get("referenceKey").equals(householdMemberServiceParam.getFileReferenceType()) && householdMemberServiceParam.getCaregiverFile1Map() != null 
					&& householdMemberServiceParam.getCaregiverFile1Map().get("size") != null  && !householdMemberServiceParam.getCaregiverFile1Map().get("size").equals("0")) {
				saveOrUpdateAttachmentWeb(householdMemberServiceParam, existingHouseHoldMemberId, householdMemberServiceParam.getCaregiverFile1Map());
			}
			if(householdMemberServiceParam.getCaregiverFile2Map() != null && householdMemberServiceParam.getCaregiverFile2Map().get("referenceKey") != null 
					&& householdMemberServiceParam.getCaregiverFile2Map().get("referenceKey").equals(householdMemberServiceParam.getFileReferenceType()) && householdMemberServiceParam.getCaregiverFile2Map() != null 
					&& householdMemberServiceParam.getCaregiverFile2Map().get("size") != null  && !householdMemberServiceParam.getCaregiverFile2Map().get("size").equals("0")) {
				saveOrUpdateAttachmentWeb(householdMemberServiceParam, existingHouseHoldMemberId, householdMemberServiceParam.getCaregiverFile2Map());
			}
			if(householdMemberServiceParam.getNomineeFile1Map() != null && householdMemberServiceParam.getNomineeFile1Map().get("referenceKey") != null 
					&& householdMemberServiceParam.getNomineeFile1Map().get("referenceKey").equals(householdMemberServiceParam.getFileReferenceType()) && householdMemberServiceParam.getNomineeFile1Map() != null 
					&& householdMemberServiceParam.getNomineeFile1Map().get("size") != null  && !householdMemberServiceParam.getNomineeFile1Map().get("size").equals("0")) {
				saveOrUpdateAttachmentWeb(householdMemberServiceParam, existingHouseHoldMemberId, householdMemberServiceParam.getNomineeFile1Map());
			}
			if(householdMemberServiceParam.getNomineeFile2Map() != null && householdMemberServiceParam.getNomineeFile2Map().get("referenceKey") != null 
					&& householdMemberServiceParam.getNomineeFile2Map().get("referenceKey").equals(householdMemberServiceParam.getFileReferenceType()) && householdMemberServiceParam.getNomineeFile2Map() != null 
					&& householdMemberServiceParam.getNomineeFile2Map().get("size") != null  && !householdMemberServiceParam.getNomineeFile2Map().get("size").equals("0")) {
				saveOrUpdateAttachmentWeb(householdMemberServiceParam, existingHouseHoldMemberId, householdMemberServiceParam.getNomineeFile2Map());
			}
		}else {
			for(Map.Entry<String,MultipartFile> fileMap : householdMemberServiceParam.getFilesMap().entrySet()) {
				
				if(fileMap.getKey().contains(householdMemberServiceParam.getFileReferenceType()))
				{
					//FIXME extract method //Fixed
					saveOrUpdateAttachment(householdMemberServiceParam, existingHouseHoldMemberId, fileMap);
				}
			
			}
		}
		
		
	}
	
	private void saveOrUpdateAttachment(HouseholdMemberServiceParam householdMemberServiceParam,
			Long existingHouseHoldMemberId, Map.Entry<String, MultipartFile> fileMap)
			throws Exception, IOException {
		
		Attachment existingAttachment = null;
		
		if(existingHouseHoldMemberId!=null) {
			existingAttachment = attachmentRepository.findByReferenceIdAndReferenceTypeAndIsActive(
					existingHouseHoldMemberId,
					fileMap.getKey(),YesNoEnum.YES);
		}
		
		Attachment saveAttachment=setAttachmentDetails(householdMemberServiceParam, fileMap, existingAttachment);
		
		if(saveAttachment!=null) {
			saveAttachment(saveAttachment);
		}
	}
	
	private void saveOrUpdateAttachmentWeb(HouseholdMemberServiceParam householdMemberServiceParam,
			Long existingHouseHoldMemberId, Map<String, String> fileMap)
			throws Exception, IOException {
		
		Attachment existingAttachment = null;
		
		if(existingHouseHoldMemberId!=null) {
			existingAttachment = attachmentRepository.findByReferenceIdAndReferenceTypeAndIsActive(
					existingHouseHoldMemberId,
					fileMap.get("referenceKey"),YesNoEnum.YES);
		}
		if(fileMap != null) {
			Attachment saveAttachment=setAttachmentDetailsWeb(householdMemberServiceParam, fileMap, existingAttachment);
			
			if(saveAttachment!=null) {
				saveAttachment(saveAttachment);
			}
		}
		
	}

	private Attachment setAttachmentDetails(HouseholdMemberServiceParam householdMemberServiceParam,
			Map.Entry<String, MultipartFile> fileMap, Attachment existingAttachment) throws Exception, IOException {
		Attachment attachment=null;
		if(fileMap.getValue().getSize()>0 && fileMap.getValue().getOriginalFilename().toString()!=null) {
			
			attachment=(existingAttachment==null?new Attachment():existingAttachment);
			
			attachment.setReferenceId(householdMemberServiceParam.getHouseholdMember().getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setFile(base64Encode(fileMap.getValue()));
			attachment.setFileMimeType(fileMap.getValue().getContentType());
			String extension = FilenameUtils.getExtension(fileMap.getValue().getOriginalFilename()).toString();
			attachment.setExtension(extension);
			attachment.setFileSize(fileMap.getValue().getSize());
			attachment.setName(fileMap.getValue().getOriginalFilename().toString());
			attachment.setReferenceType(fileMap.getKey());
			
			String isUpdate=householdMemberServiceParam.getHouseholdMemberModel()
					.getIsUpdated()==null?"":householdMemberServiceParam.getHouseholdMemberModel().getIsUpdated();
			
			if(isUpdate.equalsIgnoreCase(YesNoEnum.YES.getValue())) {
				attachment.setSourceType(SourceTypeEnum.ADMISSION);
				attachment.setUpdatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
				attachment.setUpdatedBy(householdMemberServiceParam.getUser());
				
				if(attachment.getCreatedAt()==null) {
					attachment.setCreatedBy(householdMemberServiceParam.getUser());
					attachment.setCreatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
				}
			}
			else {
				attachment.setSourceType(SourceTypeEnum.ENROLLMENT);
				attachment.setCreatedBy(householdMemberServiceParam.getUser());
				attachment.setCreatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
			}
		}
		return attachment;
	}
	
	private Attachment setAttachmentDetailsWeb(HouseholdMemberServiceParam householdMemberServiceParam,
			Map<String, String> fileMap, Attachment existingAttachment) throws Exception, IOException {
		Attachment attachment=null;
			
			attachment=(existingAttachment==null?new Attachment():existingAttachment);
			
			attachment.setReferenceId(householdMemberServiceParam.getHouseholdMember().getId());
			attachment.setIsActive(YesNoEnum.YES);
			attachment.setFile(fileMap.get("file"));
			attachment.setFileMimeType(fileMap.get("contentType"));
			attachment.setExtension(fileMap.get("fileExtension"));
			attachment.setFileSize(Long.parseLong(fileMap.get("size")));
			attachment.setName(fileMap.get("fileName"));
			attachment.setReferenceType(fileMap.get("referenceKey"));
			
			String isUpdate=householdMemberServiceParam.getHouseholdMemberModel()
					.getIsUpdated()==null?"":householdMemberServiceParam.getHouseholdMemberModel().getIsUpdated();
			
			if(isUpdate.equalsIgnoreCase(YesNoEnum.YES.getValue())) {
				attachment.setSourceType(SourceTypeEnum.ADMISSION);
				attachment.setUpdatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
				attachment.setUpdatedBy(householdMemberServiceParam.getUser());
				
				if(attachment.getCreatedAt()==null) {
					attachment.setCreatedBy(householdMemberServiceParam.getUser());
					attachment.setCreatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
				}
			}
			else {
				attachment.setSourceType(SourceTypeEnum.ENROLLMENT);
				attachment.setCreatedBy(householdMemberServiceParam.getUser());
				attachment.setCreatedAt(DateFormatterUtil.dateUtil(householdMemberServiceParam.getHouseholdMemberModel().getCreatedDate(), ConstantsUtil.CREATION_TIMESTAMP_FORMAT));
			}
		
		return attachment;
	}
	
	private Boolean isValidNominee(HouseholdMemberModel householdMemberModel) {
		if(householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE)
				&& Utilities.isValidString(householdMemberModel.getFullName()) 
				&& Utilities.isValidString(householdMemberModel.getCatDocShortName())
				&& Utilities.isValidString(householdMemberModel.getDocumentReferenceNumber())) {
			return true;
		} else {
			
			return false;
		}
	}
	
	private void saveAttachment(Attachment attachment) {
		try {
			attachmentRepository.save(attachment);
		}
		catch (Exception e) {
			throw new FailProcessException();
		}
		
	}
	
	private HouseholdMember saveHouseholdMember(HouseholdMember householdMember)  {
		try {
			HouseholdMember householdMemberNew = householdMemberRepository.save(householdMember);
		    return householdMemberNew;
		}
		catch (Exception e) {
			logger.error("Error in save",e);
			throw new FailProcessException();
		}
		
	}
	
	@Transactional
	public void updateHouseholdMemberDetails(List<HouseholdMemberModel> householdMemberDetails, Map<String, MultipartFile> filesMap,Admission admission) throws Exception {
		logger.debug("Entering into updateHouseholdMemberDetails()");
		
		for (HouseholdMemberModel householdMemberModel : householdMemberDetails) {
			if(householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER)){
				householdMemberModel.setIsPrimary(YesNoEnum.YES.getValue());
			}
			
			if((!householdMemberModel.getHouseholdMemberTypeShortName().equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE) 
					|| isValidNominee(householdMemberModel)) && isUpdatedHouseholdMember(householdMemberModel)) {
				
				updateHouseholdMember(householdMemberModel, filesMap, admission);
			}
		}
		logger.debug("Exiting from updateHouseholdMemberDetails()");
	}
	
	private void updateHouseholdMember(HouseholdMemberModel householdMemberModel, Map<String, MultipartFile> filesMap,Admission admission ) throws Exception {
		
		HouseholdMember householdMember = updateHouseholdMemberDetails(householdMemberModel, admission);
		
		HouseholdMemberServiceParam householdMemberServiceParam = setHouseholdMemberServiceParam(householdMemberModel,
				filesMap, admission.getCreatedBy(), householdMember, null);
		
		saveAttachmentsForHouseholdMember(householdMemberServiceParam);
	}
	
	private HouseholdMember updateHouseholdMemberDetails(HouseholdMemberModel householdMemberModel, Admission admission)
			throws Exception {
		HouseholdMember householdMember = convertToHouseholdMemberEntity(householdMemberModel,admission.getCreatedBy());
			
		householdMember=updateHouseHoldDetails(householdMember,admission);
		
		householdMemberModel.setId(householdMember.getId().toString());
		
		return householdMember;
	}
	
	private HouseholdMember updateHouseHoldDetails(HouseholdMember householdMember,Admission admission) throws Exception {
		
		logger.debug("Entered: updateHouseHoldDetails");
		logger.debug("updateHouseHoldDetails Current Form == "+householdMember.getCurrentForm());
		logger.debug("updateHouseHoldDetails Member Type == "+householdMember.getHouseholdMemberType());
		
		HouseholdMember existingHouseholdMeber = householdMemberRepository
				.findByCurrentFormAndHouseholdMemberType(householdMember.getCurrentForm(),householdMember.getHouseholdMemberType());
		
		if(existingHouseholdMeber!=null) {
			
			logger.debug("updateHouseHoldDetails --- Household member exists ");
			saveHouseHoldMemberAndAttachmentLog(existingHouseholdMeber, admission.getId());
			householdMember.setId(existingHouseholdMeber.getId());
		}
		
		householdMember.setUpdatedAt(new Date());
		householdMember.setUpdatedBy(householdMember.getCreatedBy());
		householdMember.setSourceId(admission.getId());
		householdMember.setSourceType(SourceTypeEnum.ADMISSION);
		householdMember=saveHouseholdMember(householdMember);
		
		updateSearchForm(householdMember,admission.getEnrollment());
		
		updateCurrentPhoneByForm(householdMember);
		
		return householdMember;
	}
	
	private void saveHouseHoldMemberAndAttachmentLog(HouseholdMember householdMember, Long admissionId) throws Exception {
		
		HouseholdMemberLog householdMemberLog= convertToHouseholdMemberLog(householdMember);
		
		saveHouseHoldMemberLog(householdMemberLog);
	
		saveAttachmentLog(householdMemberLog,householdMember);
			
	}
	
	private void saveHouseHoldMemberLog(HouseholdMemberLog householdMemberLog) throws Exception {
		
		try {
			householdMemberLogRepository.save(householdMemberLog);
			
		}
		catch(Exception e) {
			logger.error("Error in saveHouseHoldMemberLog: ",e);
			throw new FailProcessException();
		}
		
	}
	
	private void saveAttachmentLog(HouseholdMemberLog householdMemberLog,HouseholdMember householdMember) throws Exception {
		String referenceType="";
		try {
			
			String houseHoldMeberType=householdMemberLog.getHouseholdMemberType().getShortName();
			
			if(houseHoldMeberType.equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER)){
				referenceType=ConstantsUtil.CAREGIVER_FILE;
			}
			else if(houseHoldMeberType.equalsIgnoreCase(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE)) {
				referenceType=ConstantsUtil.NOMINEE_FILE;
			}
			
			if(!referenceType.isEmpty()) {
				
				List<Attachment> attachmentList = attachmentRepository.getAttachmentByReferenceIdAndReferenceType(
						householdMember.getId(),referenceType);
				
				for(Attachment attachment: attachmentList) {
					
					AttachmentLog attachmentLog=convertToAttachmentLog(attachment);
					attachmentLog.setCurrentForm(householdMemberLog.getCurrentForm());
					attachmentLog.setSourceId(householdMember.getSourceId());
					
					attachmentLogRepository.save(attachmentLog);
				}
			}
		}
		catch(Exception e) {
			logger.error("Error in saveAttachmentLog: ",e);
			throw new FailProcessException();
		}
	}
	
	private HouseholdMemberLog convertToHouseholdMemberLog(HouseholdMember householdMember) {
		
		HouseholdMemberLog householdMemberLog = new HouseholdMemberLog();
		
		householdMemberLog.setCreatedAt(householdMember.getCreatedAt());;
		householdMemberLog.setCreatedBy(householdMember.getCreatedBy());
		householdMemberLog.setCurrentForm(householdMember.getCurrentForm());
		householdMemberLog.setDateOfBirth(householdMember.getDateOfBirth());
		householdMemberLog.setDocument(householdMember.getDocument());
		householdMemberLog.setDocumentReferenceNumber(householdMember.getDocumentReferenceNumber());
		householdMemberLog.setFirstName(householdMember.getFirstName());
		householdMemberLog.setGender(householdMember.getGender());
		householdMemberLog.setHouseholdMemberType(householdMember.getHouseholdMemberType());
		householdMemberLog.setIsAssignedAsPaymentReceiver(householdMember.getIsAssignedAsPaymentReceiver());
		householdMemberLog.setIsPrimary(householdMember.getIsPrimary());
		householdMemberLog.setLastName(householdMember.getLastName());
		householdMemberLog.setMemberCode(householdMember.getMemberCode());
		householdMemberLog.setPhoneNumber(householdMember.getPhoneNumber());
		householdMemberLog.setRelationship(householdMember.getRelationship());
		householdMemberLog.setUpdatedAt(householdMember.getUpdatedAt());
		householdMemberLog.setUpdatedBy(householdMember.getUpdatedBy());
		householdMemberLog.setSourceId(householdMember.getSourceId());
		householdMemberLog.setSourceType(householdMember.getSourceType());
		
		return householdMemberLog;
	}
	
	private AttachmentLog convertToAttachmentLog(Attachment attachment) {
		
		AttachmentLog attachmentLog = new AttachmentLog();
		
		attachmentLog.setCreatedAt(attachment.getCreatedAt());
		attachmentLog.setCreatedBy(attachment.getCreatedBy());
		attachmentLog.setExtension(attachment.getExtension());
		attachmentLog.setFile(attachment.getFile());
		attachmentLog.setFileMimeType(attachment.getFileMimeType());
		attachmentLog.setFileSize(attachment.getFileSize());
		attachmentLog.setIsActive(attachment.getIsActive());
		attachmentLog.setName(attachment.getName());
		attachmentLog.setReferenceId(attachment.getReferenceId());
		attachmentLog.setReferenceType(attachment.getReferenceType());
		attachmentLog.setSourceType(attachment.getSourceType());
		attachmentLog.setUpdatedAt(attachment.getUpdatedAt());
		attachmentLog.setUpdatedBy(attachment.getUpdatedBy());
		attachmentLog.setUpdatedBy(attachment.getUpdatedBy());
		
		return attachmentLog;
	}
	
	private void updateSearchForm(HouseholdMember householdMember,Enrollment enrollment) {
		
		SearchForm searchForm=searchFormRepository.getSearchFormByCurFormAndHouseHoldMemberType(
				householdMember.getCurrentForm().getId(),householdMember.getHouseholdMemberType().getId());
		
		if(searchForm==null && (householdMember.getHouseholdMemberType().getShortName().equals(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE) || 
				householdMember.getHouseholdMemberType().getShortName().equals(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER))) {
			
			searchForm=new SearchForm();
			searchForm.setContactNumber(householdMember.getPhoneNumber());
			searchForm.setCurFormId(householdMember.getCurrentForm().getId());
			searchForm.setDocumentNumber(householdMember.getDocumentReferenceNumber());
			searchForm.setEnrollmentDate(enrollment.getCreatedAt());
			searchForm.setBookletNumber(enrollment.getBooklet().getShortName());
			searchForm.setHouseHoldMemberTypeId(householdMember.getHouseholdMemberType().getId());
			searchForm.setProgramEntityId(enrollment.getProgramEntity()==null?null:enrollment.getProgramEntity().getId());
			
			GeolocationUtil geolocationUtil= iGeolocationRepository.geolocationDetails(enrollment.getGeoLocationOTP().getId());
			
			searchForm.setGovernorateId(geolocationUtil.getGovernorateId());
			searchForm.setDistrictId(geolocationUtil.getDistrictId());
			searchForm.setOzlaId(geolocationUtil.getOzlaId());
			searchForm.setVillageId(geolocationUtil.getCityId());
			
		}
		
		if(searchForm!=null) {
			
			searchForm.setBeneficiaryName(householdMember.getFirstName()+" "+householdMember.getLastName());
			searchForm.setHouseHoldMemberId(householdMember.getId());
			
			try {
				searchFormRepository.save(searchForm);
			}
			catch(Exception e) {
				logger.error("Error in updateSearchForm: ",e);	
				throw new FailProcessException(e);
			}
		}
	}
	
	private void updateAttachments(HouseholdMemberServiceParam householdMemberServiceParam) throws IOException, Exception {
		
		Long householdMemberType=householdMemberServiceParam.getHouseholdMember().getHouseholdMemberType().getId();
		Long existingHouseHoldMemberId=householdMemberRepository.getHouseholdMemberId(Long.parseLong(householdMemberServiceParam.getEnrollmentCode())
				,householdMemberType);
		saveOrUpdateAttchmentDetails(householdMemberServiceParam, existingHouseHoldMemberId);
		
	}
	
	private boolean isUpdatedHouseholdMember(HouseholdMemberModel householdMemberModel) {
		if(householdMemberModel.getIsUpdated()!=null && householdMemberModel.getIsUpdated().equalsIgnoreCase(YesNoEnum.YES.getValue())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@Transactional
	public void updateHouseholdSource(Enrollment enrollment){
		householdMemberRepository.updateHouseholdSource(enrollment.getId(),SourceTypeEnum.ENROLLMENT,enrollment.getCurrentForm());
	}
	
	public org.yumnn.yct.beneficiaryservice.model.HouseholdMemberType findHouseholdMemberTypeByShortName(String shortName) throws Exception {

		commonValidationUtil.validateIsNullOrEmpty("Household Member Type Short Name",shortName);
			
		HouseholdMemberType householdMemberType = householdMemberTypeRepository.findByShortName(shortName);
		
		if (Utilities.isNULL(householdMemberType)) {
			return null;
		}
		org.yumnn.yct.beneficiaryservice.model.HouseholdMemberType HouseholdMemberTypeModel = new org.yumnn.yct.beneficiaryservice.model.HouseholdMemberType();
		HouseholdMemberTypeModel.setId(householdMemberType.getId());
		HouseholdMemberTypeModel.setShortName(householdMemberType.getShortName());
		return HouseholdMemberTypeModel;
	}
	
	
	public Map<String, Object> getMemberCardInfo(Long curFormId, String projectShortName) throws Exception{
		
		commonValidationUtil.validateIsNull("Current Form Id",curFormId);
		
		Map<String, Object> map = new LinkedHashMap<>();
		List<MemberCardInfoModel> memberCardInfoModel =null;
		if(projectShortName.equals(ProjectNameEnum.NVS.getValue())) {
			memberCardInfoModel = householdMemberRepository.getMemberCardInfoForNVS(curFormId);
		}else {
			memberCardInfoModel = householdMemberRepository.getMemberCardInfo(curFormId);
		}
		
		map.put(ConstantsUtil.MEMBER_CARD_INFO_LIST, memberCardInfoModel);
		
		return map;
		
	}

	public List<HouseholdMember> findHouseholdMemberListByFormId(Long formId) {

		CurrentForm currentForm = new CurrentForm();
		currentForm.setId(formId);
		return householdMemberRepository.findByCurrentForm(currentForm);
	}
	
	public Map<String, Object> getContactCardInfo(Long curFormId, String uniqueCode) throws Exception{
		
		commonValidationUtil.validateIsNull("Current Form Id",curFormId);
		
		Map<String, Object> map = new LinkedHashMap<>();
		
		List<ContactCardInfoModel> ContactCardInfoModelList = getBeneficiaryContacts(curFormId,uniqueCode);
		
		map.put(ConstantsUtil.CONTACT_CARD_INFO_LIST, ContactCardInfoModelList);
		
		return map;
		
	}
	
	public Map<String, Object> getFacilityContactCardInfo(Long curFormId, String uniqueCode) throws Exception {

		commonValidationUtil.validateIsNull("Current Form Id", curFormId);

		Map<String, Object> map = new LinkedHashMap<>();

		List<ContactCardInfoModel> ContactCardInfoModelList = getFacilityContacts(curFormId, uniqueCode);

		map.put(ConstantsUtil.CONTACT_CARD_INFO_LIST, ContactCardInfoModelList);

		return map;

	}
	
	
	public List<ContactCardInfoModel>  getBeneficiaryContacts(Long curFormId, String uniqueCode) {
		
		List<ContactCardInfoModel> ContactCardInfoModelList=new ArrayList<ContactCardInfoModel>();
		ContactCardInfoModel contactCard=null;
		String contactNumber="";
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Payment List");
		contactNumber=householdMemberRepository.getContactDetailsFromPaymentList(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Grievance");
		contactNumber=householdMemberRepository.getContactDetailsFromGrievance(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Original");
		contactNumber=householdMemberRepository.getContactDetailsFromOriginal(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Inquiry");
		contactNumber=householdMemberRepository.getContactDetailsFromInquiry(uniqueCode);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Follow up on grievance");
		contactNumber=householdMemberRepository.getContactDetailsFromFollowup(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		return ContactCardInfoModelList;
		
	}
	
	public List<ContactCardInfoModel>  getFacilityContacts(Long curFormId, String uniqueCode) {
		
		List<ContactCardInfoModel> ContactCardInfoModelList=new ArrayList<ContactCardInfoModel>();
		ContactCardInfoModel contactCard=null;
		String contactNumber="";
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Grievance");
		contactNumber=householdMemberRepository.getContactDetailsFromGrievance(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Original");
		contactNumber=householdMemberRepository.getFacilityContactDetailsFromOriginal(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Inquiry");
		contactNumber=householdMemberRepository.getContactDetailsFromInquiry(uniqueCode);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		contactCard=new ContactCardInfoModel();
		contactCard.setPhoneSource("Follow up on grievance");
		contactNumber=householdMemberRepository.getContactDetailsFromFollowup(curFormId);
		contactCard.setPhoneNo(Utilities.isNULLOrEmpty(contactNumber)?"":contactNumber);
		ContactCardInfoModelList.add(contactCard);
		
		return ContactCardInfoModelList;
		
	}
	
	
	private void updateCurrentPhoneByForm(HouseholdMember householdMember) {
	
		logger.debug("Entered: updateCurrentPhoneByForm()");
		if(householdMember.getHouseholdMemberType().getShortName().equals(ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER) 
			&& Utilities.isNotNullAndNotEmpty(householdMember.getPhoneNumber())){
			logger.debug("Save Or Update Current Phone Number During Admission: "+householdMember.getPhoneNumber());
			
			CurrentContactInformationByForm currentContactInformationByForm=
					currentContactInformationByFormRepository.findByCurrentFormAndPhoneSource(householdMember.getCurrentForm(),PhoneSourceEnum.ADMISSION);
			
			if(currentContactInformationByForm==null) {
				currentContactInformationByForm= new CurrentContactInformationByForm();
				currentContactInformationByForm.setCurrentForm(householdMember.getCurrentForm());
				currentContactInformationByForm.setPhoneSource(PhoneSourceEnum.ADMISSION);
			}
			currentContactInformationByForm.setCellPhone(householdMember.getPhoneNumber());
			currentContactInformationByForm.setPhoneType(PhoneTypeEnum.CELLPHONE);
			
			try {
				currentContactInformationByFormRepository.save(currentContactInformationByForm);
			}
			catch(Exception e) {
				logger.error("Error in updateCurrentPhoneByForm: ",e);	
				throw new FailProcessException(e);
			}
		}
	}
	
}


