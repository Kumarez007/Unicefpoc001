package org.yumnn.yct.beneficiaryservice.model;

import java.io.Serializable;

public class ServiceTypeModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    protected String name;

    protected String shortName;
    private String enName;

    private String arName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getArName() {
        return arName;
    }

    public void setArName(String arName) {
        this.arName = arName;
    }
}
