package org.yumnn.yct.beneficiaryservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashMap;
import java.util.Map;

public class ValidationModel {

	private String id;
	private String admissionId;
	private String serviceTypeShortName;
	private String dateFrom;
	private String dateTo;
	private String numberOfDays;
	private String numberOfPeriods;
	private String doctorName;
	private String validationCodeDetails;
	private String createdBy;
	private String createdDate;
	private String updatedBy;
	private String updatedDate;
	private String documentShortName;
	private String documentReferenceNo;
	private String uniqueId; 
	
	@JsonIgnore
	private Long curFormId;
	
	@JsonIgnore
	private Long bookletId;
	
	@JsonIgnore
	private String projectShortName;

	private boolean isWebCall;

	private HashMap<String, String> validate1File1Map;

	private HashMap<String, String> validate2File2Map;

	private HashMap<String, String> validate2File1Map;

	private HashMap<String, String> validate1File2Map;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAdmissionId() {
		return admissionId;
	}
	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}
	public String getServiceTypeShortName() {
		return serviceTypeShortName;
	}
	public void setServiceTypeShortName(String serviceTypeShortName) {
		this.serviceTypeShortName = serviceTypeShortName;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getNumberOfDays() {
		return numberOfDays;
	}
	public void setNumberOfDays(String numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	public String getNumberOfPeriods() {
		return numberOfPeriods;
	}
	public void setNumberOfPeriods(String numberOfPeriods) {
		this.numberOfPeriods = numberOfPeriods;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getValidationCodeDetails() {
		return validationCodeDetails;
	}
	public void setValidationCodeDetails(String validationCodeDetails) {
		this.validationCodeDetails = validationCodeDetails;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	public String getDocumentShortName() {
		return documentShortName;
	}
	public void setDocumentShortName(String documentShortName) {
		this.documentShortName = documentShortName;
	}
	public String getDocumentReferenceNo() {
		return documentReferenceNo;
	}
	public void setDocumentReferenceNo(String documentReferenceNo) {
		this.documentReferenceNo = documentReferenceNo;
	}
	
	public Long getCurFormId() {
		return curFormId;
	}
	public void setCurFormId(Long curFormId) {
		this.curFormId = curFormId;
	}
	public Long getBookletId() {
		return bookletId;
	}
	public void setBookletId(Long bookletId) {
		this.bookletId = bookletId;
	}
	public String getProjectShortName() {
		return projectShortName;
	}
	public void setProjectShortName(String projectShortName) {
		this.projectShortName = projectShortName;
	}
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public HashMap<String, String> getValidate1File1Map() {
		return validate1File1Map;
	}

	public void setValidate1File1Map(HashMap<String, String> validate1File1Map) {
		this.validate1File1Map = validate1File1Map;
	}

	public HashMap<String, String> getValidate2File2Map() {
		return validate2File2Map;
	}

	public void setValidate2File2Map(HashMap<String, String> validate2File2Map) {
		this.validate2File2Map = validate2File2Map;
	}

	public HashMap<String, String> getValidate2File1Map() {
		return validate2File1Map;
	}

	public void setValidate2File1Map(HashMap<String, String> validate2File1Map) {
		this.validate2File1Map = validate2File1Map;
	}

	public HashMap<String, String> getValidate1File2Map() {
		return validate1File2Map;
	}

	public void setValidate1File2Map(HashMap<String, String> validate1File2Map) {
		this.validate1File2Map = validate1File2Map;
	}

	public boolean isWebCall() {
		return isWebCall;
	}

	public void setWebCall(boolean webCall) {
		isWebCall = webCall;
	}

	@Override
	public String toString() {
		return "ValidationModel [id=" + id + ", admissionId=" + admissionId + ", serviceTypeShortName="
				+ serviceTypeShortName + ", dateFrom=" + dateFrom + ", dateTo=" + dateTo + ", numberOfDays="
				+ numberOfDays + ", numberOfPeriods=" + numberOfPeriods + ", doctorName=" + doctorName
				+ ", validationCodeDetails=" + validationCodeDetails + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", documentShortName="
				+ documentShortName + ", documentReferenceNo=" + documentReferenceNo + ", uniqueId=" + uniqueId
				+ ", curFormId=" + curFormId + ", bookletId=" + bookletId + ", projectShortName=" + projectShortName
				+ "]";
	}
	
	
}
