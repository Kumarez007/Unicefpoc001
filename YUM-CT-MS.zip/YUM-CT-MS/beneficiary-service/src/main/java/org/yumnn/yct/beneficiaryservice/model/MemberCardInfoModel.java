package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 17, 2021 7:12:27 PM
 */
public interface MemberCardInfoModel {
	
	public String getFullName();

	public String getRelationship();
	
	public String getGender();
	
	public String getIdType();
	
	public String getIdReference();
	
	public String getIsPrimary();

}
