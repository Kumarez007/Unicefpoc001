package org.yumnn.yct.beneficiaryservice.controller;



import java.util.ArrayList;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 16, 2021
 *
 */

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.service.BeneficiaryAdmissionService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/admissionControl")
public class AdmissionController {

	@Autowired
	private BeneficiaryAdmissionService beneficiaryAdmissionService = null;
	
	private static final Logger logger = LoggerFactory.getLogger(AdmissionController.class);

	@Operation(summary  = "Post operation to add Beneficiary Admission")
	@PostMapping(value = "/addBeneficiaryAdmission")
	public ResponseEntity<?> addBeneficiaryAdmission(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE1, required = false) MultipartFile admissionFile1,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE2, required = false) MultipartFile admissionFile2,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE1, required = false) MultipartFile referralFile1,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE2, required = false) MultipartFile referralFile2,
			BeneficiaryAdmissionModel admissionModel) throws Exception {

		logger.debug("Entered: addBeneficiaryAdmission");
		logger.debug("Request Body: ==> "+admissionModel.toString());
		try {
			admissionModel.setWebCall(false);
			Map<String, MultipartFile> filesMap = createAdmissionFileMap(admissionFile1, admissionFile2, referralFile1,
					referralFile2);
			Map<String, Object> map=beneficiaryAdmissionService.addBeneficiaryAdmission(requestHeader,filesMap,admissionModel);
			
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addBeneficiaryAdmission: ",e);
			throw e;
		}
	}
	
	@Operation(summary  = "Post operation to add Beneficiary Admission")
	@PostMapping(value = "/addBeneficiaryAdmissionWeb")
	public ResponseEntity<?> addBeneficiaryAdmissionWeb(@RequestHeader Map<String, String> requestHeader,
			@RequestBody BeneficiaryAdmissionModel admissionModel) throws Exception {

		logger.debug("Entered: addBeneficiaryAdmission");
		logger.debug("Request Body: ==> "+admissionModel.toString());
		try {
			admissionModel.setWebCall(true);
			Map<String, Object> map=beneficiaryAdmissionService.addBeneficiaryAdmission(requestHeader,null,admissionModel);
			
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addBeneficiaryAdmission: ",e);
			throw e;
		}
	}
	
	@Operation(summary  = "Post operation to add Beneficiary Admission and Update Household Member Data")
	@PostMapping(value = "/addAdmissionUpdateHouseholdMember")
	public ResponseEntity<?> addAdmissionUpdateHouseholdMember(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE1, required = false) MultipartFile admissionFile1,
			@RequestParam(value = ConstantsUtil.ADMISSION_FILE2, required = false) MultipartFile admissionFile2,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE1, required = false) MultipartFile referralFile1,
			@RequestParam(value = ConstantsUtil.REFERRAL_FILE2, required = false) MultipartFile referralFile2,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE1, required = false) MultipartFile caregiverFile1,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE1, required = false) MultipartFile nomineeFile1,
			@RequestParam(value = ConstantsUtil.CAREGIVER_FILE2, required = false) MultipartFile caregiverFile2,
			@RequestParam(value = ConstantsUtil.NOMINEE_FILE2, required = false) MultipartFile nomineeFile2,
			BeneficiaryAdmissionModel admissionModel) throws Exception {

		logger.debug("Entered: addAdmissionUpdateHouseholdMember");
		logger.debug("Request Body: ==> "+admissionModel.toString());
		Map<String, MultipartFile> admissionfilesMap = createAdmissionFileMap(admissionFile1, admissionFile2, referralFile1,
				referralFile2);
		
		Map<String, MultipartFile> hhmfilesMap = createEnrollmentFileMap(caregiverFile1,caregiverFile2,nomineeFile1,nomineeFile2);
		
		List<Map<String, MultipartFile>> fileList=new ArrayList<Map<String, MultipartFile>>();
		fileList.add(admissionfilesMap);
		fileList.add(hhmfilesMap);
		try {
			Map<String, Object> map=beneficiaryAdmissionService.addAdmissionUpdateHouseholdMember(requestHeader,fileList,admissionModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addAdmissionUpdateHouseholdMember: ",e);
			throw e; 
		}
	}

	private Map<String, MultipartFile> createAdmissionFileMap(MultipartFile admissionFile1, MultipartFile admissionFile2,
			MultipartFile referralFile1, MultipartFile referralFile2) {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		if (admissionFile1 != null)
			filesMap.put(ConstantsUtil.ADMISSION_FILE1, admissionFile1);
		if (admissionFile2 != null)
			filesMap.put(ConstantsUtil.ADMISSION_FILE2, admissionFile2);
		if (referralFile1 != null)
			filesMap.put(ConstantsUtil.REFERRAL_FILE1, referralFile1);
		if (referralFile2 != null)
			filesMap.put(ConstantsUtil.REFERRAL_FILE2, referralFile2);
		return filesMap;
	}
	
	private Map<String, MultipartFile> createEnrollmentFileMap(MultipartFile caregiverFile1, MultipartFile caregiverFile2,
			MultipartFile nomineeFile1, MultipartFile nomineeFile2) {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		if(caregiverFile1 != null)
			filesMap.put(ConstantsUtil.CAREGIVER_FILE1, caregiverFile1);
	    if(nomineeFile1 != null)
	    	filesMap.put(ConstantsUtil.NOMINEE_FILE1, nomineeFile1);
	    if(caregiverFile2 != null)
	    	filesMap.put(ConstantsUtil.CAREGIVER_FILE2, caregiverFile2);
	    if(nomineeFile2 != null)
	    	filesMap.put(ConstantsUtil.NOMINEE_FILE2, nomineeFile2);
		return filesMap;
	}
	
	


}
