package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Nov 25, 2021 8:34:05 PM
 */
public class ContactCardInfoModel {
	
	private String phoneNo;

	private String phoneSource;

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPhoneSource() {
		return phoneSource;
	}

	public void setPhoneSource(String phoneSource) {
		this.phoneSource = phoneSource;
	}

}
