package org.yumnn.yct.beneficiaryservice.model;

import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;


public class CatalogDocuments {

	private Long id;
	private String name;
	private String shortName;
	private Integer orderItem;
	private String enName;
	private String arName;
	private YesNoEnum isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public Integer getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Integer orderItem) {
		this.orderItem = orderItem;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getArName() {
		return arName;
	}

	public void setArName(String arName) {
		this.arName = arName;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
}
