package org.yumnn.yct.beneficiaryservice.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.yumnn.yct.beneficiaryservice.model.CatBookletModel;
import org.yumnn.yct.beneficiaryservice.model.CatBookletValidationModel;
import org.yumnn.yct.beneficiaryservice.service.CurrentFormService;
import org.yumnn.yct.beneficiaryservice.service.DocumentService;
import org.yumnn.yct.beneficiaryservice.service.FlagService;
import org.yumnn.yct.beneficiaryservice.service.HistoricalBeneficiaryMilestoneService;
import org.yumnn.yct.beneficiaryservice.service.HouseholdMemberService;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.enumeration.flag.FlagTypeEnum;
import org.yumnn.yct.common.model.BeneficeriesNomineeModel;
import org.yumnn.yct.common.model.CurrentFormModel;
import org.yumnn.yct.common.model.DocumentModel;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.model.administration.FlagModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModelData;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;
import org.yumnn.yct.common.util.Utilities;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(value = "/api/" + ConstantsUtil.API_VERSION + "/commonBeneficiaryApiControl") 
public class CommonBeneficiaryApiController {
	
	private static final Logger logger = LoggerFactory.getLogger(CommonBeneficiaryApiController.class);

	@Autowired
	HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;
	@Autowired
	private CurrentFormService currentFormService;
	@Autowired
	private HouseholdMemberService householdMemberService;
	@Autowired
	private DocumentService documentService;
	@Autowired
	private FlagService flagService;

	@Operation(summary = "Post operation to add HistoricalBeneficiaryMilestone")
	@PostMapping(value = "/addHistoricalBeneficiaryMilestone")
	public ResponseEntity<?> addHistoricalBeneficiaryMilestone(@RequestHeader Map<String, String> requestHeader,
			@RequestBody HistoricalBeneficiaryModel historicalBeneficiaryModel) throws Exception {
		logger.debug("Entered addHistoricalBeneficiaryMilestone");
		try {
	    	historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, null);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addHistoricalBeneficiaryMilestone: ",e);
			throw e;
		}
	}

	@Operation(summary = "Post operation to add HistoricalBeneficiaryMilestone")
	@PostMapping(value = "/addHistoricalBeneficiaryMilestoneList")
	public ResponseEntity<?> addHistoricalBeneficiaryMilestoneList(@RequestHeader Map<String, String> requestHeader,
															   @RequestBody HistoricalBeneficiaryModelData historicalBeneficiaryData) throws Exception {
		logger.debug("Entered addHistoricalBeneficiaryMilestoneList");
		try {
			historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModelList(historicalBeneficiaryData);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, null);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In addHistoricalBeneficiaryMilestone: ",e);
			throw e;
		}
	}

	@Operation(summary = "Get operation to retrieve current form")
	@GetMapping(value = "/findFormByFormNumber")
	public ResponseEntity<?> findFormByFormNumber(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "formNumber", required = true) String formNumber) throws Exception {
		
		logger.debug("Entered findFormByFormNumber");
		try {
			CurrentFormModel currentFormModel = currentFormService.findByFormNumber(formNumber);
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.CURRENT_FORM_MODEL_OBJ, currentFormModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findFormByFormNumber: ",e);
			throw e;
		}
	    
	}
	
	@Operation(summary = "Get operation to retrieve current form")
	@GetMapping(value = "/findFormByVca")
	public ResponseEntity<?> findFormByVca(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "vca", required = true) String vca) throws Exception {
		logger.debug("Entered findFormByVca");
		try {
			CurrentFormModel currentFormModel = currentFormService.findFormByVca(vca);
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.CURRENT_FORM_MODEL_OBJ, currentFormModel);
			
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findFormByVca: ",e);
			throw e;
		}
		
	}
	
	@Operation(summary = "Get operation to retrieve household member")
	@GetMapping(value = "/findHouseholdMemberByCode")
	public ResponseEntity<?> findHouseholdMemberByCode(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "memberCode", required = true) String memberCode) throws Exception {
		
		logger.debug("Entered findHouseholdMemberByCode");
		try {
			HouseholdMemberModel householdMemberModel = householdMemberService.getByMemberCode(memberCode);
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.HOUSEHOLD_MEMBER__MODEL_OBJECT, householdMemberModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findHouseholdMemberByCode: ",e);
			throw e;
		}
	}
	
	
	
	@Operation(summary = "Get operation to get document By shortName")
	@GetMapping(value = "/getDocumentByShortName")
	public ResponseEntity<?> getDocumentByShortName(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "shortName", required = true) String shortName) throws Exception {
		logger.debug("Entered getDocumentByShortName");
		try {
			DocumentModel documentModel = documentService.retrieveByShortName(shortName);
			Map<String, Object> map = new LinkedHashMap<>();
			map.put(ConstantsUtil.DOCUMENT_MODEL_OBJECT, documentModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getDocumentByShortName: ",e);
			throw e;
		}
	}

	@Operation(summary = "Get operation to get flag by cycle")
	@GetMapping(value = "/flag/{flagType}/project/{projectId}")
	public ResponseEntity<?> getflagByProjectActiveCycle(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "flagType", required = true) String flagType, @RequestParam(value = "projectId", required = true) Long projectId ) throws Exception {

		try {
			List<FlagModel> flagList = flagService.retrieveHouseholdAndMemberFlagsModelByActiveCycle(FlagTypeEnum.valueOf(flagType), projectId);
			Map<String, Object> map = new LinkedHashMap<>();
			map.put(ConstantsUtil.FLAG_MODEL_LIST_OBJECT, flagList);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getDocumentByShortName: ",e);
			throw e;
		}
	}
	
	@Operation(summary = "Get operation to get flag by project")
	@GetMapping(value = "/flag/project")
	public ResponseEntity<?> getHouseholdAndMemberFlagByProjectActiveCycle(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "projectId", required = true) Long projectId ) throws Exception {

		try {
			List<FlagModel> flagList = flagService.retrieveHouseholdAndMemberFlagsModelByActiveCycle(projectId);
			Map<String, Object> map = new LinkedHashMap<>();
			map.put(ConstantsUtil.FLAG_MODEL_LIST_OBJECT, flagList);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getDocumentByShortName: ",e);
			throw e;
		}
	}
	
	@Operation(summary = "Get operation to retrieve household member Type")
	@GetMapping(value = "/findHouseholdMemberType")
	public ResponseEntity<?> findHouseholdMemberType(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "shortName", required = true) String shortName) throws Exception {
		
		logger.debug("Entered findHouseholdMemberType");
		try {
			org.yumnn.yct.beneficiaryservice.model.HouseholdMemberType householdMemberType = householdMemberService
					.findHouseholdMemberTypeByShortName(shortName);
			Map<String, Object> map = new HashMap<>();
			map.put("householdMemberType", householdMemberType);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findHouseholdMemberByCode: ",e);
			throw e;
		}
	}
	

	@Operation(summary = "Get operation to retrieve current form")
	@GetMapping(value = "/findCurrentFormById")
	public ResponseEntity<?> findCurrentFormById(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "id", required = true) String id) throws Exception {
		
		logger.debug("Entered findCurrentFormById");
		try {
			CurrentFormModel currentFormModel = currentFormService.findCurrentFormById(id);
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.CURRENT_FORM_MODEL_OBJ, currentFormModel);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findFormByFormNumber: ",e);
			throw e;
		}
	    
	}

	

	@GetMapping(value = "/findHouseholdMemberListByFormId")
	public ResponseEntity<?> findHouseholdMemberListByFormId(@RequestHeader Map<String, String> requestHeader,
			@RequestParam(value = "formId", required = true) Long formId) throws Exception {
		
		try {
			
			List<HouseholdMember>  householdMemberlList = householdMemberService.findHouseholdMemberListByFormId(formId);
			
			List<BeneficeriesNomineeModel> householdMemberModelList = new ArrayList<>();
			for (HouseholdMember member : householdMemberlList) {
				BeneficeriesNomineeModel model = new BeneficeriesNomineeModel();
				model.setName(member.getFirstName() + " " + (Utilities.isNULL(member.getLastName()) ? "" : member.getLastName()));
				model.setId(member.getId().toString());
				householdMemberModelList.add(model);
			}
			
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.HOUSEHOLD_MEMBER__MODEL_LIST_OBJECT, householdMemberModelList);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In findHouseholdMemberByCode: ",e);
			throw e;
		}
	}
	
	@Operation(summary = "Get cat booklet and booklet validation data")
	@GetMapping(value = "/getCatBookletData")
	public ResponseEntity<?> getCatBookletData(@RequestHeader Map<String, String> requestHeader) throws Exception {

		try {
			List<CatBookletModel> bookletData = currentFormService.getCatBookletData();
			List<CatBookletValidationModel> bookletValidationData = currentFormService.getCatBookletValidationData();
			Map<String, Object> map = new LinkedHashMap<>();
			map.put("bookletData", bookletData);
			map.put("bookletValidationData", bookletValidationData);
			SuccessResponse successResponse = new SuccessResponse(ConstantsUtil.STATUS_CODE_SUCCESS, ConstantsUtil.SUCCESS_MESSAGE, map);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
		catch(Exception e) {
			logger.error("Error In getDocumentByShortName: ",e);
			throw e;
		}
	}
	
	
}
