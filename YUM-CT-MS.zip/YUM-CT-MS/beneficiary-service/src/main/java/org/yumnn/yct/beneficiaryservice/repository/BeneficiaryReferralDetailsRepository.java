package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.BeneficiaryReferralDetails;

@Repository
public interface BeneficiaryReferralDetailsRepository  extends JpaRepository<BeneficiaryReferralDetails, Long>{

}
