package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 14, 2021 5:33:20 PM
 */
public interface PaymentByCycleCardInfoModel {
	
	public String getCycle();

	public String getPaymentAgencyEn();

	public String getPaymentAgencyAr();
	
	public String getAmountToBePaidInUSD();
	
	public String getAmountToBePaidInYER();
	
	public String getPaidAmountInYER();
	
	public String getProgram();
	
	public String getHasReceivedPayment();

	public String getPaidAmountInUSD();

	public String getGrant();

	public String getTargetedPeriod();
	
	public String getDonor();

	public String getIdPaymentReviewScheme();
	
	public String getFaceNo();

	public String getFieldOffice();
	
	public String getSection();

}
