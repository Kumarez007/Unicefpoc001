package org.yumnn.yct.beneficiaryservice.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.catalog.StatusEnum;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 30, 2021 8:24:44 PM
 */

@Entity
@Table(name = "beneficiary.gen_records_to_download")
public class RecordDownload extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "record_json")
	private String recordJson;
	
	@Column(name = "reference_id")
	private Long referenceId;
	
	@Column(name = "reference_type")
	private String referenceType;
	
	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;
	
	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private StatusEnum status;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "synchronization_date", nullable = true)
	private Date syncDate;

	public String getRecordJson() {
		return recordJson;
	}

	public void setRecordJson(String recordJson) {
		this.recordJson = recordJson;
	}

	public Long getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(Long referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	public Date getSyncDate() {
		return syncDate;
	}

	public void setSyncDate(Date syncDate) {
		this.syncDate = syncDate;
	}

}
