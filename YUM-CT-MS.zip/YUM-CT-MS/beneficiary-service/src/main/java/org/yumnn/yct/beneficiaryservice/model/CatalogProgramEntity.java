package org.yumnn.yct.beneficiaryservice.model;

import java.util.Date;

import org.yumnn.yct.common.model.GeographicalAreaJsonModel;
import org.yumnn.yct.common.model.User;

public class CatalogProgramEntity {

	private Long id;
	private String name;
	private String code;
	private GeographicalAreaJsonModel geolocation;
	private String enName;
	private String arName;
	private CatalogProgramEntityType catalogProgramEntityType;
	private Integer orderItem;
	private Date createdAt;
	private Date updatedAt;
	private User createdBy;
	private User updatedBy;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public GeographicalAreaJsonModel getGeolocation() {
		return geolocation;
	}

	public void setGeolocation(GeographicalAreaJsonModel geolocation) {
		this.geolocation = geolocation;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getArName() {
		return arName;
	}

	public void setArName(String arName) {
		this.arName = arName;
	}

	public CatalogProgramEntityType getCatalogProgramEntityType() {
		return catalogProgramEntityType;
	}

	public void setCatalogProgramEntityType(CatalogProgramEntityType catalogProgramEntityType) {
		this.catalogProgramEntityType = catalogProgramEntityType;
	}

	public Integer getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Integer orderItem) {
		this.orderItem = orderItem;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public User getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
