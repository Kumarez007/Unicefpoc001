package org.yumnn.yct.beneficiaryservice.model;

/*
 *  @Author :  Minaj Attar
 *  @Date : 24/11/2022
 */
public class UserLoggingModel {

	 
	
    private String androidDeviceName;

    private String androidOsName;

    private String androidOsVersion;

    private String deviceId;

    private String requestType;

    private String requestJSON;

    private String execeptionDetails;

    private String userName;

	public String getAndroidDeviceName() {
		return androidDeviceName;
	}

	public void setAndroidDeviceName(String androidDeviceName) {
		this.androidDeviceName = androidDeviceName;
	}

	public String getAndroidOsName() {
		return androidOsName;
	}

	public void setAndroidOsName(String androidOsName) {
		this.androidOsName = androidOsName;
	}

	public String getAndroidOsVersion() {
		return androidOsVersion;
	}

	public void setAndroidOsVersion(String androidOsVersion) {
		this.androidOsVersion = androidOsVersion;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestJSON() {
		return requestJSON;
	}

	public void setRequestJSON(String requestJSON) {
		this.requestJSON = requestJSON;
	}

	public String getExeceptionDetails() {
		return execeptionDetails;
	}

	public void setExeceptionDetails(String execeptionDetails) {
		this.execeptionDetails = execeptionDetails;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
    
}
