package org.yumnn.yct.beneficiaryservice.entity;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "beneficiary.hst_statistics")
public class Statistics extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "hst_enrollment_count")
    private Long enrollmentCount;

    @Column(name = "hst_admission_count")
    private Long admissionCount;

    @Column(name = "hst_validation_count")
    private Long validationCount;

    @Column(name = "hst_enrollment_is_uploaded_count")
    private Long enrollmentIsUploadedCount;

    @Column(name = "hst_admission_is_uploaded_count")
    private Long admissionIsUploadedCount;

    @Column(name = "hst_validation_is_uploaded_count")
    private Long validationIsUploadedCount;

    @Column(name = "is_uploaded")
    private String uploaded;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_user_fk", nullable = false)
    private User user;

    @Column(name = "unique_id")
    private String uniqueId;

    @Column(name = "android_os")
    private String androidOs;

    @Column(name = "android_version_name")
    private String androidVersionName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date", nullable = false)
    private Date date;

    public Long getEnrollmentCount() {
        return enrollmentCount;
    }

    public void setEnrollmentCount(Long enrollmentCount) {
        this.enrollmentCount = enrollmentCount;
    }

    public Long getAdmissionCount() {
        return admissionCount;
    }

    public void setAdmissionCount(Long admissionCount) {
        this.admissionCount = admissionCount;
    }

    public Long getValidationCount() {
        return validationCount;
    }

    public void setValidationCount(Long validationCount) {
        this.validationCount = validationCount;
    }

    public Long getEnrollmentIsUploadedCount() {
        return enrollmentIsUploadedCount;
    }

    public void setEnrollmentIsUploadedCount(Long enrollmentIsUploadedCount) {
        this.enrollmentIsUploadedCount = enrollmentIsUploadedCount;
    }

    public Long getAdmissionIsUploadedCount() {
        return admissionIsUploadedCount;
    }

    public void setAdmissionIsUploadedCount(Long admissionIsUploadedCount) {
        this.admissionIsUploadedCount = admissionIsUploadedCount;
    }

    public Long getValidationIsUploadedCount() {
        return validationIsUploadedCount;
    }

    public void setValidationIsUploadedCount(Long validationIsUploadedCount) {
        this.validationIsUploadedCount = validationIsUploadedCount;
    }

    public String getUploaded() {
        return uploaded;
    }

    public void setUploaded(String uploaded) {
        this.uploaded = uploaded;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getAndroidOs() {
        return androidOs;
    }

    public void setAndroidOs(String androidOs) {
        this.androidOs = androidOs;
    }

    public String getAndroidVersionName() {
        return androidVersionName;
    }

    public void setAndroidVersionName(String androidVersionName) {
        this.androidVersionName = androidVersionName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
