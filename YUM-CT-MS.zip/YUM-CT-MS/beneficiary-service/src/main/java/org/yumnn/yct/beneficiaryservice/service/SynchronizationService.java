package org.yumnn.yct.beneficiaryservice.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.DeviceDownloadedData;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.RecordDownload;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.RecordDownloadRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateSyncDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.DeviceDetail;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.Utilities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.yumnn.yct.beneficiaryservice.repository.DeviceDownloadedDataRepository;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jun 30, 2021 5:43:00 PM
 */
@Service
public class SynchronizationService {
	
	private static final Logger logger = LoggerFactory.getLogger(SynchronizationService.class);
	
	@Autowired
	EnrollmentRepository enrollmentRepository;
	
	@Autowired
	AdmissionRepository admissionRepository;
	
	@Autowired
	ValidationRepository validationRepository;
	
	@Autowired
	BeneficiaryAdmissionService admissionService;
	
	@Autowired
	EnrollmentService enrollmentService;
	
	@Autowired
	private ValidationService validationService;
	
	@Autowired
	private ValidateUserDetail validateUserDetail;
	
	@Autowired
	private ValidateSyncDetail validateSyncDetail;
	
	@Autowired
	private RecordDownloadRepository recordDownloadRepository;
	
	@Autowired
	private DeviceDownloadedDataRepository deviceDownloadedDataRepository;
	
	public Map<String, Object> getPendingRecordsForSync(Map<String, String> requestHeader, SyncModel syncModel) throws Exception{
		
		logger.debug("Entered Service method: getPendingRecordsForSync");
		try {	
			validateUserDetail.validateAndGetUser(requestHeader);
			validateSyncDetail.validateForPendingRecords(syncModel);
			
			Long pendingRecordList=0L;
			
			logger.debug("getPendingRecordsForSync - lastSyncId: "+syncModel.getLastSyncId());
				
			Map<String, Object> map = new LinkedHashMap<>();
			
			if(Utilities.isValidString(syncModel.getLastSyncId())) {
				pendingRecordList = recordDownloadRepository.getTotalBeneficiaryCountAfterId(Long.parseLong(syncModel.getLastSyncId()));
			}
			else {
				pendingRecordList = recordDownloadRepository.getTotalBeneficiaryCount();
			}
		
			map.put(ConstantsUtil.PENDING_RECORDS, pendingRecordList);
				
			return map;
		}
		catch(Exception e) {
			logger.error("Error In getPendingRecordsForSync, "+e);
			throw e;
		}
			
	}

	public Map<String, Object> downloadBeneficiarySyncData(Map<String, String> requestHeader,SyncModel syncModel) throws Exception{
		
		logger.debug("Entered Service method: downloadBeneficiarySyncData - lastSyncId: "+syncModel.getLastSyncId());
		logger.debug("downloadBeneficiarySyncData Batch Count: "+syncModel.getBatchSize());
		
		Map<String, Object> map=new HashMap<String, Object>();
		
		try {
			validateUserDetail.validateAndGetUser(requestHeader);
			Long deviceDetailId=validateUserDetail.validateAndGetDeviceId(requestHeader,syncModel.getDeviceId());
			validateSyncDetail.validateForDownloadRecords(syncModel);
		    
		    List<RecordDownload> beneficiaryDownloadList=null;
		    
		    Pageable pageable = PageRequest.of(0, Integer.parseInt(syncModel.getBatchSize())); 
		    
			if(Utilities.isValidString(syncModel.getLastSyncId())) {
				beneficiaryDownloadList = recordDownloadRepository.getBeneficiaryRecordsAfterId(Long.parseLong(syncModel.getLastSyncId()),pageable);
			}
			else {
				beneficiaryDownloadList = recordDownloadRepository.getBeneficiaryRecordsForFirstBatch(pageable);
			} 
			
			List<Map<String, Object>> batchList=prepareJsonDownloadBatch(beneficiaryDownloadList);
			
			if(batchList.size()>0) {
				Long lastSyncId=(Long) batchList.get(batchList.size()-1).get(ConstantsUtil.RECORD_ID);
				saveOrupdateDeviceDownloadedData(deviceDetailId,lastSyncId);
			}
			
			map.put(ConstantsUtil.BENEFICIARY_LIST, batchList);
			
			return map;
		}
		catch(Exception e) {
			logger.error("Error In downloadBeneficiarySyncData, "+e);
			throw e;
		}
		
	}
	
	@Transactional
	public void migrateInitialRecordJson() throws JsonProcessingException {
		
		Long recordCount= recordDownloadRepository.getTotalBeneficiaryCount();
		if(recordCount<1) {
			logger.debug("migrateInitialRecordJson: Loading Initial Json Records");
			
			List<RecordDownload> recordDownloadList=new ArrayList<RecordDownload>();
			RecordDownload recordDownload=null;
			
			Map<String, Object> beneficiaryJsonMap = null;
			Map<String, Object> enrollmentDataMap = null;
			Map<String, Object> admissionDataMap = null;
			Map<String, Object> validationDataMap = null;
			Date syncDate=null;
			
			List<Enrollment> enrollmentList = enrollmentRepository.getEnrollmentList();
			for(Enrollment enrollment:enrollmentList) {
				beneficiaryJsonMap = null;
				beneficiaryJsonMap = new HashMap<String, Object>();
				
				syncDate=enrollment.getSyncDate();
				enrollmentDataMap = null;
				enrollmentDataMap = enrollmentService.addEnrollmentDetailsToMap(enrollment.getId(),enrollment);
				beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);
				
				admissionDataMap = null;
				validationDataMap = null;
				Admission admission = admissionRepository.getAdmissionByEnrollment(enrollment.getId());
				if(admission!=null) {
					syncDate=admission.getSyncDate();
					admissionDataMap = admissionService.addAdmissionDetailsToMap(admission);
					
					Validation validation=validationRepository.getValidationByAdmission(admission.getId());
					if(validation!=null) {
						syncDate=validation.getSyncDate();
						validationDataMap = validationService.addValidationDetailsToMap(validation.getId(),validation);
					}
				}
				
				beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);	
				beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);	
				
				recordDownload=null;
				recordDownload=new RecordDownload();
				recordDownload.setReferenceId(enrollment.getCurrentForm().getId());
				recordDownload.setSyncDate(syncDate);
				recordDownload.setIsActive(YesNoEnum.YES);
				recordDownload.setRecordJson(new ObjectMapper().writeValueAsString(beneficiaryJsonMap));
				recordDownload.setReferenceType(ConstantsUtil.BENEFICIARY_DATA);
				recordDownloadList.add(recordDownload);
			}
			
			saveInitialJsonRecordForDownload(recordDownloadList);
			
			logger.debug("migrateInitialRecordJson: Completed - Total Records: "+recordDownloadList.size());
		}
	}
	
	
	private void saveInitialJsonRecordForDownload(List<RecordDownload> recordDownloadList) {
		try {
			recordDownloadRepository.saveAll(recordDownloadList);
		}
		catch(Exception e) {
			logger.debug("Error In saveInitialJsonRecordForDownload",e);
			throw new FailProcessException(e);
		}
	}
	
	@Transactional
	public void saveLatestJsonRecordForDownload(CurrentForm currentForm,Date syncDate, Map<String, Object> beneficiaryJsonMap) throws JsonProcessingException {
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setReferenceId(currentForm.getId());
		recordDownload.setSyncDate(syncDate);
		recordDownload.setIsActive(YesNoEnum.YES);
		recordDownload.setRecordJson(new ObjectMapper().writeValueAsString(beneficiaryJsonMap));
		recordDownload.setReferenceType(ConstantsUtil.BENEFICIARY_DATA);
		
		try {
			recordDownloadRepository.updateBeneficiaryRecordIsActive(YesNoEnum.NO,currentForm.getId());
			recordDownloadRepository.save(recordDownload);
		}
		catch(Exception e) {
			logger.debug("Error In saveLatestJsonRecordForDownload",e);
			throw new FailProcessException(e);
		}
	}
	
	private List<Map<String, Object>> prepareJsonDownloadBatch(List<RecordDownload> beneficiaryDownloadList) throws JsonMappingException, JsonProcessingException {
		
		Map<String, Object> dataMap=null;
		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, Object>> batchList= new ArrayList<Map<String,Object>>();
		
		for(RecordDownload recordDownload:beneficiaryDownloadList) {
			dataMap=null;
			dataMap = mapper.readValue(recordDownload.getRecordJson(), new TypeReference<Map<String, Object>>() {});
			dataMap.put(ConstantsUtil.RECORD_ID, recordDownload.getId());
			batchList.add(dataMap);
		}
		return batchList;
	}
	
	private void saveOrupdateDeviceDownloadedData(Long deviceId,Long lastDownloadedRecordId) {
		DeviceDetail deviceDetail=new DeviceDetail();
		deviceDetail.setId(deviceId);
		
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setId(lastDownloadedRecordId);
		
		DeviceDownloadedData deviceDownloadedData=deviceDownloadedDataRepository.findByDeviceDetail(deviceDetail);
		
		if(deviceDownloadedData==null) {
			deviceDownloadedData=new DeviceDownloadedData();
			deviceDownloadedData.setDeviceDetail(deviceDetail);
		}
			
		deviceDownloadedData.setRecordDownload(recordDownload);
		
		try {
			deviceDownloadedDataRepository.save(deviceDownloadedData);
		}
		catch(Exception e) {
			logger.debug("error in saveOrupdateDeviceDownloadedData: ",e);
			throw new FailProcessException(e);
		}
		
	}

}
