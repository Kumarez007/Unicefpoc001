package org.yumnn.yct.beneficiaryservice.service;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.yumnn.yct.common.model.administration.UserModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SSLClientFactory;
import org.yumnn.yct.common.util.SuccessResponse;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;


/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Service
public class BeneficiaryApiCallService {
	
	@Autowired
	RestTemplate rt;

	private static Logger logger = LogManager.getLogger(BeneficiaryApiCallService.class);
	
	SuccessResponse successResponse = null;
	Map<String, Object> map = null;
	
	@Value("${yct-api-gateway-uri}")        
    private String apiGatewayUri=null; 

	public UserModel getUserDetails(Map<String, String> requestHeader) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		
		logger.debug("Entered: getUserDetails");
		
		if(apiGatewayUri==null) {
			apiGatewayUri="http://localhost:9090"; //default local Property
		}
		
		String serviceUri=apiGatewayUri.trim().concat(ConstantsUtil.API_GATEWAY_BASE_PATH+ConstantsUtil.USER_DETAILS_API_ENDPOINT);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(requestHeader);
		
		successResponse = new SuccessResponse();
		
		HttpEntity<SuccessResponse> requestEntity = new HttpEntity<>(null, headers);
		
		setRestTemplateClient(serviceUri);// set Rest Template Object
		
		ResponseEntity<SuccessResponse> successResponse=rt.exchange(serviceUri, HttpMethod.GET, requestEntity, SuccessResponse.class);
		map = successResponse.getBody().getData();
		
		logger.debug("Response: Returned Size - "+map.size());
		
		ObjectMapper mapper = new ObjectMapper();
		UserModel user = mapper.convertValue(map.get(ConstantsUtil.USER_OBJ),new TypeReference<UserModel>(){});
		return user;
	}
	
	public CycleByProjectModel getCycleByProjectName(Map<String, String> requestHeader,String projectShortName) {

		String serviceUri=apiGatewayUri.trim().concat(ConstantsUtil.API_GATEWAY_BASE_PATH+ConstantsUtil.COMMON_GET_CYCLE_BY_PROJECT_URL);
		serviceUri=serviceUri.concat("?projectShortName="+ projectShortName);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(requestHeader);

		HttpEntity<SuccessResponse> requestEntity = new HttpEntity<>(null, headers);

		ResponseEntity<SuccessResponse>  response = rt.exchange(serviceUri, HttpMethod.GET, requestEntity, SuccessResponse.class);
		
		SuccessResponse successResponse = response.getBody();
		Map<String, Object> map = successResponse.getData();
		ObjectMapper mapper = new ObjectMapper();
		CycleByProjectModel cycleByProjectModel = mapper.convertValue(map.get(ConstantsUtil.CYCLE_BY_PROJECT_OBJECT),
				new TypeReference<CycleByProjectModel>() {
				});
		return cycleByProjectModel;
	}
	
	public Long getDeviceDetailId(Map<String, String> requestHeader,String deviceId) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		
		logger.debug("Entered: getGenDeviceDetailId");
		
		if(apiGatewayUri==null) {
			apiGatewayUri="http://localhost:9090"; //default local Property for JUnit
		}

		String serviceUri=apiGatewayUri.trim().concat(ConstantsUtil.API_GATEWAY_BASE_PATH+ConstantsUtil.DEVICE_DETAILS_API_ENDPOINT);
		serviceUri=serviceUri.concat("?deviceId="+ deviceId);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(requestHeader);
		
		successResponse = new SuccessResponse();
		
		HttpEntity<SuccessResponse> requestEntity = new HttpEntity<>(null, headers);
		
		setRestTemplateClient(serviceUri);
		
		ResponseEntity<SuccessResponse> successResponse=rt.exchange(serviceUri, HttpMethod.GET, requestEntity, SuccessResponse.class);
		map = successResponse.getBody().getData();
		
		logger.debug("Response: Returned Size - "+map.size());
		
		ObjectMapper mapper = new ObjectMapper();
		Long deviceDetailId = mapper.convertValue(map.get(ConstantsUtil.DEVICE_ID),new TypeReference<Long>(){});
		return deviceDetailId;
	}
	
	private void setRestTemplateClient(String uri) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		if (uri.startsWith(ConstantsUtil.SSL_PROTOCOL)) {
			rt = new RestTemplate(SSLClientFactory.getRequestFactory());
		}
		
	}
	
}


