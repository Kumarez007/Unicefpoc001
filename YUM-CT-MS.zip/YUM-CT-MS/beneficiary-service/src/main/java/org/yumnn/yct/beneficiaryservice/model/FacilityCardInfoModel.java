package org.yumnn.yct.beneficiaryservice.model;

public interface FacilityCardInfoModel {
	public String getShortName();
	public String getProjectNameEn();
	public String getProjectNameAr();
	public String getUniqueCode();
	public String getFacilityTypeEn();
	public String getFacilityTypeAr();
	public String getContactPersonNameEn();
	public String getContactPersonNameAr();
	public String getGeolocation();
	public String getContactPersonRole();

	public String getProgramNameEn();

	public String getProgramNameAr();
}
