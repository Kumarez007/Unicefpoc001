package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface BookletByValidationCodeRepository extends JpaRepository<BookletByValidationCode, Long> {
	BookletByValidationCode findByValidationCodeAndIsActive(String ValidationCode, YesNoEnum isActive) throws FailProcessException;
	BookletByValidationCode findByValidationCodeAndIsActiveAndIsUsed(String ValidationCode, YesNoEnum isActive, YesNoEnum isUsed) throws FailProcessException;
	
	@Query("SELECT t FROM BookletByValidationCode t where t.booklet.shortName = :vca")
	List<BookletByValidationCode> findByVca(@Param("vca") String vca) throws FailProcessException;
	
	@Modifying
	@Query("update BookletByValidationCode t set isRedeemed = :isRedeemed where" + 
			"	 t.id = :id")
	public void upadteRedeemedValue(@Param("isRedeemed") YesNoEnum isRedeemed, Long id) throws FailProcessException;
	
	@Modifying
	@Query("update BookletByValidationCode t set isRedeemed = :isRedeemed where" + 
			"	 t.validationCode = :code")
	public void upadteRedeemedValueByCode(@Param("isRedeemed") YesNoEnum isRedeemed, String code) throws FailProcessException;


	@Query(value = "select * from beneficiary.stp_booklet_by_validation_code \n" +
			"where id_cat_booklet_fk = :id", nativeQuery = true)
	List<BookletByValidationCode> findAllByBookletId(@Param("id") Long id);
	
	@Query( value = "select validation_code from beneficiary.stp_booklet_by_validation_code code "
			+ " join beneficiary.hst_enrollment enroll on enroll.id_booklet_fk=code.id_cat_booklet_fk "
			+ " where enroll.id=:enrollmentId and code.validation_code_type='OTP' ", nativeQuery = true)
	String getOTPValidationCode(@Param("enrollmentId")Long enrollmentId);
	
	BookletByValidationCode findByValidationCode(String ValidationCode) throws FailProcessException;
}
