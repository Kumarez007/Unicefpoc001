package org.yumnn.yct.beneficiaryservice.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 16, 2021
 *
 */

public class BeneficiaryAdmissionModel {
  
  private String isAdmitted;

  private String nonAdmissionOtherReasons;

  private String otpValidationCode;

  private String expiryDate;

  private String tfcValidationCode;
    
  @JsonIgnore
  private String enrollmentId;
  
  private String enrollmentCode;
  
  private String programEntityShortName;
  
  private String nonAdmissionReasonShortName;
  
  private String admissionId;
  
  private String createdBy;
  
  private String createdDate;
  
  private String householdMemberList;
  
  private String isValidationCodeUsed;
  
  private String tfcShortName;
  
  private String uniqueId; 

  private boolean isWebCall;
  private Map<String, String> admissionFile1Map;
  private Map<String, String> admissionFile2Map;
  private Map<String, String> referralFile1Map;
  private Map<String, String> referralFile2Map; 
  
  
	public Map<String, String> getAdmissionFile1Map() {
		return admissionFile1Map;
	}
	
	public void setAdmissionFile1Map(Map<String, String> admissionFile1Map) {
		this.admissionFile1Map = admissionFile1Map;
	}
	
	public Map<String, String> getAdmissionFile2Map() {
		return admissionFile2Map;
	}
	
	public void setAdmissionFile2Map(Map<String, String> admissionFile2Map) {
		this.admissionFile2Map = admissionFile2Map;
	}
	
	public Map<String, String> getReferralFile1Map() {
		return referralFile1Map;
	}
	
	public void setReferralFile1Map(Map<String, String> referralFile1Map) {
		this.referralFile1Map = referralFile1Map;
	}
	
	public Map<String, String> getReferralFile2Map() {
		return referralFile2Map;
	}
	
	public void setReferralFile2Map(Map<String, String> referralFile2Map) {
		this.referralFile2Map = referralFile2Map;
	}

	public boolean isWebCall() {
		return isWebCall;
	}
	
	public void setWebCall(boolean isWebCall) {
		this.isWebCall = isWebCall;
	}

	public String getIsAdmitted() {
		return isAdmitted;
	}
	
	public void setIsAdmitted(String isAdmitted) {
		this.isAdmitted = isAdmitted;
	}
	
	public String getNonAdmissionOtherReasons() {
		return nonAdmissionOtherReasons;
	}
	
	public void setNonAdmissionOtherReasons(String nonAdmissionOtherReasons) {
		this.nonAdmissionOtherReasons = nonAdmissionOtherReasons;
	}
	
	public String getOtpValidationCode() {
		return otpValidationCode;
	}
	
	public void setOtpValidationCode(String otpValidationCode) {
		this.otpValidationCode = otpValidationCode;
	}
	
	public String getTfcValidationCode() {
		return tfcValidationCode;
	}
	
	public void setTfcValidationCode(String tfcValidationCode) {
		this.tfcValidationCode = tfcValidationCode;
	}
	
	public String getEnrollmentId() {
		return enrollmentId;
	}
	
	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	
	
	
	public String getEnrollmentCode() {
		return enrollmentCode;
	}
	
	public void setEnrollmentCode(String enrollmentCode) {
		this.enrollmentCode = enrollmentCode;
	}
	
	public String getProgramEntityShortName() {
		return programEntityShortName;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public void setProgramEntityShortName(String programEntityShortName) {
		this.programEntityShortName = programEntityShortName;
	}
	
	public String getNonAdmissionReasonShortName() {
		return nonAdmissionReasonShortName;
	}
	
	public void setNonAdmissionReasonShortName(String nonAdmissionReasonShortName) {
		this.nonAdmissionReasonShortName = nonAdmissionReasonShortName;
	}
	
	
	
	public String getAdmissionId() {
		return admissionId;
	}
	
	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}
	
	
	
	public String getHouseholdMemberList() {
		return householdMemberList;
	}
	
	public void setHouseholdMemberList(String householdMemberList) {
		this.householdMemberList = householdMemberList;
	}
	
	public String getExpiryDate() {
		return expiryDate;
	}
	
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	
	public String getIsValidationCodeUsed() {
		return isValidationCodeUsed;
	}
	
	public void setIsValidationCodeUsed(String isValidationCodeUsed) {
		this.isValidationCodeUsed = isValidationCodeUsed;
	}
	
	public String getTfcShortName() {
		return tfcShortName;
	}
	
	public void setTfcShortName(String tfcShortName) {
		this.tfcShortName = tfcShortName;
	}
	
	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId; 
	}

	@Override
	public String toString() {
		return "BeneficiaryAdmissionModel [isAdmitted=" + isAdmitted + ", nonAdmissionOtherReasons="
				+ nonAdmissionOtherReasons + ", otpValidationCode=" + otpValidationCode + ", expiryDate=" + expiryDate
				+ ", tfcValidationCode=" + tfcValidationCode + ", enrollmentId=" + enrollmentId + ", enrollmentCode="
				+ enrollmentCode + ", programEntityShortName=" + programEntityShortName
				+ ", nonAdmissionReasonShortName=" + nonAdmissionReasonShortName + ", admissionId=" + admissionId
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", householdMemberList="
				+ householdMemberList + ", isValidationCodeUsed=" + isValidationCodeUsed + ", tfcShortName="
				+ tfcShortName + ", uniqueId=" + uniqueId + "]";
	}
}
