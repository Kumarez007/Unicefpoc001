package org.yumnn.yct.beneficiaryservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.repository.DocumentsRepository;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.model.DocumentModel;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {DocumentService.java
 * @create_date Jun 6, 2021
 * @last_Update Jun 6, 2021
 */
@Service
public class DocumentService {

	private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);
	
	@Autowired
	private DocumentsRepository documentsRepository;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	MessageSource messageSource;

	/**
	 * 
	 * @param shortName
	 * @return
	 */
	public DocumentModel retrieveByShortName(String shortName) throws Exception {
		
		commonValidationUtil.validateIsNullOrEmpty("Document Short name",shortName);
		Documents document = documentsRepository.findByShortName(shortName);

		if (Utilities.isNULL(document)) {
			return null;
		}
		DocumentModel documentModel = new DocumentModel();
		documentModel.setArabicName(document.getArabicName());
		documentModel.setEnglishName(document.getEnglishName());
		documentModel.setShortName(document.getShortName());
		documentModel.setId(document.getId());

		return documentModel;
	}

}
