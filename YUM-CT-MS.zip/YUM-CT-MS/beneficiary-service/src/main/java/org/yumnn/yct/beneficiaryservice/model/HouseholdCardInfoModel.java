package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 2, 2021 4:56:30 PM
 */
public interface HouseholdCardInfoModel {

	public String getVcaNumber();
	

	public String getDateOfEnrollment();
	
	public String getTfcName();
	
	public String getZoneName();
	
}
