package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.model.CatBookletModel;
import org.yumnn.yct.beneficiaryservice.model.CatBookletValidationModel;

@Repository
public class CatBookletRepository{

	@PersistenceContext
	EntityManager em ;
	
	public List<CatBookletModel> getCatBookletData() {
		
		String quertString="select id,name , name as short_name,0 orderItem,'' enName ,''arName, 'Yes' as isActive , 'Yes' as isPrinted , 'No' as IsUsed " + 
				"from beneficiary.cat_booklet " + 
				"where name in ( select assigned_vca_no from bb_temp_vcode3) ";
		Query query = this.em.createNativeQuery(quertString,CatBookletModel.class);
		return query.getResultList();
	}
	
	public List<CatBookletValidationModel> getCatBookletValidationData() {
		String quertString="select id , id_cat_booklet_fk as idCatBookletfk , validation_code as validationCode ,  order_item as orderItem , 'YES' as isActive ,null as isUsed ,'YES' as isPrinted,null isRedeemed , validation_code_type as validationCodeType " + 
				"from beneficiary.stp_booklet_by_validation_code " + 
				"where id_cat_booklet_fk  in ( select id from beneficiary.cat_booklet where name in (select assigned_vca_no from bb_temp_vcode3))";
		Query query = this.em.createNativeQuery(quertString,CatBookletValidationModel.class);
		return query.getResultList();
	}
	

}
