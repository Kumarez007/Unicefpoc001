package org.yumnn.yct.beneficiaryservice.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.EnableValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.model.ValidationBookletModel;
import org.yumnn.yct.beneficiaryservice.repository.BookletByValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnableValidationCodeRepository;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.payment.BookletValidationCodeModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.Utilities;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {BookletByValidationCodeService.java
 * @create_date Jun 8, 2021
 * @last_Update Jun 8, 2021
 */
@Service
public class BookletByValidationCodeService {
	private static Logger logger = LogManager.getLogger(BookletByValidationCodeService.class);

	@Autowired
	private BookletByValidationCodeRepository bookletByValidationCodeRepository;
	
	@Autowired
	private EnableValidationCodeRepository enableValidationCodeRepository;
	

	public BookletByValidationCode findByValidationCode(String validationCode) throws FailProcessException {
		return bookletByValidationCodeRepository.findByValidationCodeAndIsActive(validationCode, YesNoEnum.YES);
	}

	/**
	 *
	 * @author WQ
	 * @date Jun 9, 2021
	 * @description_method
	 * @param vca
	 * @return
	 */
	public List<BookletByValidationCode> findByVca(String vca) throws FailProcessException{
		return bookletByValidationCodeRepository.findByVca(vca);
	}

	/**
	 *
	 * @author WQ
	 * @date Jun 9, 2021
	 * @description_method
	 * @param vca
	 * @return
	 */
	public List<BookletValidationCodeModel> getValidationCodeModelByVca(String vca)throws FailProcessException{
		List<BookletByValidationCode> validationCodeList = findByVca( vca);
		if(!Utilities.isNULL(validationCodeList) && !validationCodeList.isEmpty()) {
			List<BookletValidationCodeModel> validationCodeModelList = new ArrayList<>();
			//FIXME extract method to create BookletValidationCodeModel //Fixed
			validationCodeList.forEach(code -> {
				BookletValidationCodeModel item = createBookletValidationCodeModel(code);
				validationCodeModelList.add(item);
			});
			return validationCodeModelList;
		}
		return null;
	}

	private BookletValidationCodeModel createBookletValidationCodeModel(BookletByValidationCode code) {
		BookletValidationCodeModel item = new BookletValidationCodeModel();
		item.setBookletId(code.getBooklet().getId());
		item.setValidationCode(code.getValidationCode());
		item.setIsActive(code.getIsActive());
		item.setValidationCodeId(code.getId());
		item.setIsRedeemed(code.getIsRedeemed());
		item.setIsUsed(code.getIsUsed());
		return item;
	}

	/**
	 * WQ
	 * @author Christian Alvarez
	 * @date Jun 9, 2021
	 * @description_method
	 * @param validationCodeList
	 */
	public void redeemValidationCode(List<BookletValidationCodeModel> validationCodeList) throws FailProcessException{
		if(!Utilities.isNULL(validationCodeList) && !validationCodeList.isEmpty()) {
			validationCodeList.forEach(code -> {
				try {
					bookletByValidationCodeRepository.upadteRedeemedValue(YesNoEnum.YES, code.getValidationCodeId());
				} catch (FailProcessException e) {
					logger.debug("Error in redeemValidationCode: ",e);
				}

			});
		}
	}

	/**
	 * WQ
	 * @author Christian Alvarez
	 * @date Jun 9, 2021
	 * @description_method
	 * @param validationCodeList
	 */
	public void redeemValidationCodeList(List<String> validationCodeList){
		if(!Utilities.isNULL(validationCodeList) && !validationCodeList.isEmpty()) {
			validationCodeList.forEach(code -> {
				try {
					bookletByValidationCodeRepository.upadteRedeemedValueByCode(YesNoEnum.YES, code);
				} catch (FailProcessException e) {
					logger.error("Error in redeemValidationCodeList: ",e);
				}

			});
		}
	}

	public List<BookletByValidationCode> findAllByBookletId(Long id){
		return bookletByValidationCodeRepository.findAllByBookletId(id);
	}

	public void updateBookletValidationCodeStatus(List<ValidationBookletModel> modelList, Validation validation) throws ParseException{
		if(modelList != null && !modelList.isEmpty() && modelList.size() > 0){
			for(ValidationBookletModel model : modelList){
				BookletByValidationCode code = bookletByValidationCodeRepository.findById(model.getId()).get();
				if(code != null){
					code.setIsUsed(YesNoEnum.YES);
					bookletByValidationCodeRepository.save(code);
					
					EnableValidationCode enableValidationCode = new EnableValidationCode();
					
					enableValidationCode.setReferenceId(validation.getId());
					switch (validation.getServiceType().getShortName()) {
					case "TREAT":
						enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_TREATMENT);
						break;
					case "DISCG":
					case "DISCGTFC":
						enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_DISCHARGE);
						break;
					case "TREATDIS":
						enableValidationCode.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION_TREATMENT_AND_DISCHARGE);
						break;
					default:
						break;
					}
					enableValidationCode.setValidationType(code.getValidationCodeType().getValue());
					enableValidationCode.setSetupBookletByValidationCode(code);
					SimpleDateFormat format = new SimpleDateFormat("dd-MMMM-yyyy");
					Calendar calendar = Calendar.getInstance();
					calendar.add(Calendar.MONTH, 1);
					enableValidationCode.setExpiryDate(format.parse(format.format(calendar.getTime())));

					enableValidationCode.setCreatedAt(validation.getCreatedAt());
					enableValidationCode.setCreatedBy(validation.getCreatedBy());
					enableValidationCodeRepository.save(enableValidationCode);
				}
			}
		}
	}

}
