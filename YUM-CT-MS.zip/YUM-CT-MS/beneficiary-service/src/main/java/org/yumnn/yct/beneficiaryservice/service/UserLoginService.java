package org.yumnn.yct.beneficiaryservice.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.entity.UserAPILoggingDetails;
import org.yumnn.yct.beneficiaryservice.model.UserLoggingModel;
import org.yumnn.yct.beneficiaryservice.repository.UserLoginRepository;
/*
 *  @Author :  Minaj Attar
 *  @Date : 24/11/2022
 */

@Service
public class UserLoginService {

    @Autowired
    private UserLoginRepository userLoginRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public Map<String, Object> saveUserLoggingAPIDetails(UserLoggingModel userLoggingAPIModel){
    	
    	//validateStatisticsDetail.validateStatisticsDetails(statisticsModel);
    	
    	UserAPILoggingDetails userLogin = convertModelToEntityObject(userLoggingAPIModel);
    	userLogin = userLoginRepository.save(userLogin);
    	   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss a");  
    	   LocalDateTime now = LocalDateTime.now();  
    	   
    	Map<String, Object> map = new HashMap<>();
    	
    	if(userLogin != null) {
    		map.put("responseCode", "SUCCESS");
    		map.put("responseMessage", "User logs data saved successfully!");
    		map.put("responseTimeStamp ",dtf.format(now));
    		map.put("responseData", "null");

    	}else {
    		map.put("201", "Failed");  
    	}
    	
		return map;    	
    }

	private UserAPILoggingDetails convertModelToEntityObject(UserLoggingModel userLoggingAPIModel) {
		UserAPILoggingDetails userAPILoggingDetail = new UserAPILoggingDetails();
		userAPILoggingDetail.setAndroidDeviceName(userLoggingAPIModel.getAndroidDeviceName());
		userAPILoggingDetail.setAndroidOsName(userLoggingAPIModel.getAndroidOsName());
		userAPILoggingDetail.setAndroidOsVersion(userLoggingAPIModel.getAndroidOsVersion());
		userAPILoggingDetail.setDeviceId(userLoggingAPIModel.getDeviceId());
		userAPILoggingDetail.setRequestType(userLoggingAPIModel.getRequestType());
		userAPILoggingDetail.setRequestJSON(userLoggingAPIModel.getRequestJSON());
		userAPILoggingDetail.setExeceptionDetails(userLoggingAPIModel.getExeceptionDetails());
		userAPILoggingDetail.setUser(userRepository.findByUsername(userLoggingAPIModel.getUserName()));
				
    	return userAPILoggingDetail;
	}

}
