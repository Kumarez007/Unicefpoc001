
package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.messages.CurrentContactInformationByForm;
import org.yumnn.yct.common.enumeration.messages.PhoneSourceEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Nov 26, 2021 7:50:06 PM
 */

@Repository
public interface CurrentContactInformationByFormRepository extends JpaRepository<CurrentContactInformationByForm, Long> {
	
	@Query(value = "SELECT t FROM CurrentContactInformationByForm t where t.currentForm=:currentForm and t.phoneSource=:phoneSource")
	CurrentContactInformationByForm findByCurrentFormAndPhoneSource(CurrentForm currentForm,
			@Param("phoneSource") PhoneSourceEnum phoneSource) throws FailProcessException;
	 

}
