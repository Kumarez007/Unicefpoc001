package org.yumnn.yct.beneficiaryservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.yumnn.yct.beneficiaryservice.enumeration.ValidationCodeTypeEnum;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;


@Entity
@Table(name = "beneficiary.stp_booklet_by_validation_code")
public class BookletByValidationCode extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_cat_booklet_fk")
	private Booklet booklet;

	@Column(name = "validation_code")
	private String validationCode;

	@Column(name = "order_item")
	private Integer orderItem;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;
	
	@Column(name = "is_printed")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isPrinted;
	
	@Column(name = "validation_code_type")
	@Enumerated(EnumType.STRING)
	private ValidationCodeTypeEnum validationCodeType;
	
	
	@Column(name = "is_used")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isUsed;
	
	@Column(name = "is_redeemed")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isRedeemed;
	
	
	public Booklet getBooklet() {
		return booklet;
	}

	public void setBooklet(Booklet booklet) {
		this.booklet = booklet;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public Integer getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Integer orderItem) {
		this.orderItem = orderItem;
	}
	
	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	public YesNoEnum getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(YesNoEnum isUsed) {
		this.isUsed = isUsed;
	}

	/**
	 * @return the isRedeemed
	 */
	public YesNoEnum getIsRedeemed() {
		return isRedeemed;
	}

	/**
	 * @param isRedeemed the isRedeemed to set
	 */
	public void setIsRedeemed(YesNoEnum isRedeemed) {
		this.isRedeemed = isRedeemed;
	}

	/**
	 * @return the isPrinted
	 */
	public YesNoEnum getIsPrinted() {
		return isPrinted;
	}

	/**
	 * @param isPrinted the isPrinted to set
	 */
	public void setIsPrinted(YesNoEnum isPrinted) {
		this.isPrinted = isPrinted;
	}

	/**
	 * @return the validationCodeType
	 */
	public ValidationCodeTypeEnum getValidationCodeType() {
		return validationCodeType;
	}

	/**
	 * @param validationCodeType the validationCodeType to set
	 */
	public void setValidationCodeType(ValidationCodeTypeEnum validationCodeType) {
		this.validationCodeType = validationCodeType;
	}
	
	
}
