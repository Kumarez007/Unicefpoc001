package org.yumnn.yct.beneficiaryservice.util.validate;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.CustomException;
import org.yumnn.yct.common.util.Utilities;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ValidateEnrollmentDetail {

	private static Logger logger = LogManager.getLogger();

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	CommonValidationUtil commonValidationUtil;
	
	@Autowired
	EnrollmentRepository enrollmentRepository;

	public void validateEnrollmentDetails(Map<String, MultipartFile> filesMap,EnrollmentModel enrollmentModel) throws Exception {

		if(enrollmentModel.getUniqueId()!=null) {
			Enrollment enrollment = enrollmentRepository.findByUniqueId(enrollmentModel.getUniqueId());
			commonValidationUtil.checkDuplicateRequest("Unique Id",enrollment);
		}
		
		commonValidationUtil.validateIsNullOrEmpty("Is referred from another TFC",enrollmentModel.getIsRefferdFromOtherTFC());

		commonValidationUtil.validateIsNullOrEmpty("OTP Reference Number",enrollmentModel.getOtpReferenceNumber());

		commonValidationUtil.validateIsNullOrEmpty("OTP GeoArea ShortName",enrollmentModel.getOtpGeoAreaShortName());

		commonValidationUtil.validateIsNullOrEmpty("OTP Nutrition Officer Name",enrollmentModel.getOtpNutritionOfficerName());

		commonValidationUtil.validateIsNullOrEmpty("OTP Nutrition Officer Reference Number",enrollmentModel.getOtpNutritionOfficerRefrenceNumber());

		commonValidationUtil.validateIsNullOrEmpty("OTP Nutrition Officer Phone Number",enrollmentModel.getOtpNutritionOfficerPhoneNumber());

		commonValidationUtil.validateIsNullOrEmpty("VCA number",enrollmentModel.getBookletShortName());

		commonValidationUtil.validateIsNullOrEmpty("Place of Admission",enrollmentModel.getPlaceOfAdmissionShortName());

		commonValidationUtil.validateIsNullOrEmpty("Comments",enrollmentModel.getComments());

		commonValidationUtil.validateIsNullOrEmpty("Is Required Investigation",enrollmentModel.getIsRequireInvestigation());
		
		validateCurrentForm(enrollmentModel);

		validateHouseholdMemberList(enrollmentModel, filesMap);

	}

	private void validateHouseholdMemberList(EnrollmentModel enrollmentModel, Map<String, MultipartFile> filesMap)
			throws CustomException, NoSuchMessageException, IOException {
		List<HouseholdMemberModel> householdMemberList = null;
		if (enrollmentModel.getHouseholdMemberList() == null) {
			logger.error("HouseholdMemberList is null or empty");
			throw new IllegalArgumentException(messageSource.getMessage("validate.param", null,"Validation Failed", LocaleContextHolder.getLocale())+": Household Member List");
		} else {
			householdMemberList = new ObjectMapper().readValue(enrollmentModel.getHouseholdMemberList(),
					new TypeReference<List<HouseholdMemberModel>>() {
					});
			
			validateHouseholdDetails(filesMap, householdMemberList);
		}
	}

	public void validateHouseholdDetails(Map<String, MultipartFile> filesMap,
			List<HouseholdMemberModel> householdMemberList) throws CustomException, NoSuchMessageException, IOException {
		
		Boolean isNomineeDocumentAvailable=false;
		for (HouseholdMemberModel hmm : householdMemberList) {
			if (ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE.equalsIgnoreCase(hmm.getHouseholdMemberTypeShortName())) {
				if(Utilities.isValidString(hmm.getCatDocShortName()) && Utilities.isValidString(hmm.getDocumentReferenceNumber())) {
					isNomineeDocumentAvailable=true;
					break;
				}
			}
		}

		for (HouseholdMemberModel hmm : householdMemberList) {
			if (ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CHILD.equalsIgnoreCase(hmm.getHouseholdMemberTypeShortName())) {

				commonValidationUtil.validateIsNullOrEmpty("Child Full Name",hmm.getFullName());

				commonValidationUtil.validateIsoDate("Date of birth",hmm.getDateOfBirth());

				commonValidationUtil.validateIsNullOrEmpty("Gender",hmm.getGenderShortName());
			}

			if (ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_CAREGIVER.equalsIgnoreCase(hmm.getHouseholdMemberTypeShortName())) {

				commonValidationUtil.validateIsNullOrEmpty("Caregiver Full Name",hmm.getFullName());

				commonValidationUtil.validateIsNullOrEmpty("Caregiver Phone Number",hmm.getPhoneNumber());

				commonValidationUtil.validateIsNullOrEmpty("Relationship",hmm.getRelationshipShortName());

				commonValidationUtil.validateIsNullOrEmpty("Is assigned as payment receiver",hmm.getIsAssignedAsPaymentReceiver());

				if(!isNomineeDocumentAvailable) {
					commonValidationUtil.validateIsNullOrEmpty("ID Type",hmm.getCatDocShortName());
	
					commonValidationUtil.validateIsNullOrEmpty("ID Reference Number",hmm.getDocumentReferenceNumber());
					
					commonValidationUtil.validateMultipartFile("Care Giver document File1 or Care Giver document File2",filesMap.get(ConstantsUtil.CAREGIVER_FILE1), filesMap.get(ConstantsUtil.CAREGIVER_FILE2));
				}
			}

			if (ConstantsUtil.HOUSEHOLD_MEMBER_TYPE_NOMINEE.equalsIgnoreCase(hmm.getHouseholdMemberTypeShortName())) {
				
				if(isNomineeDocumentAvailable) {

					commonValidationUtil.validateIsNullOrEmpty("Nominee Full Name",  hmm.getFullName());

					commonValidationUtil.validateIsNullOrEmpty("ID Type", hmm.getCatDocShortName());

					commonValidationUtil.validateIsNullOrEmpty("ID Reference Number",hmm.getDocumentReferenceNumber());

					commonValidationUtil.validateMultipartFile("Nominee document File1 or Nominee document File2",filesMap.get(ConstantsUtil.NOMINEE_FILE1), filesMap.get(ConstantsUtil.NOMINEE_FILE2));
				}
			}
		}
	}

	private void validateCurrentForm(EnrollmentModel enrollmentModel) {
		commonValidationUtil.validateIsNullOrEmpty("Project Short Name", enrollmentModel.getProjectShortName());
	}

	

}
