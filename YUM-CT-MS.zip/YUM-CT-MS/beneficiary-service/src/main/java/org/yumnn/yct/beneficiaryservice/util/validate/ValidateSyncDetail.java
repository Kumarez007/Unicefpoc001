package org.yumnn.yct.beneficiaryservice.util.validate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

@Service
public class ValidateSyncDetail {

	private static Logger logger = LogManager.getLogger();

	@Autowired
	CommonValidationUtil commonValidationUtil;

	public void validateForPendingRecords(SyncModel syncModel) throws Exception {
		logger.debug("Inside validateForPendingRecords");

		commonValidationUtil.validateIsNullOrEmpty("Username",syncModel.getUsername());
	}
	
	public void validateForDownloadRecords(SyncModel syncModel) throws Exception {
		logger.debug("Inside validateForDownloadRecords");

		commonValidationUtil.validateIsNullOrEmpty("Username",syncModel.getUsername());
		commonValidationUtil.validateIsNullOrEmpty("Batch Size",syncModel.getBatchSize());
		commonValidationUtil.validateIsNullOrEmpty("Device Id",syncModel.getDeviceId());

	}


}
