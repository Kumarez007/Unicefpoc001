package org.yumnn.yct.beneficiaryservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;

@Entity
@Table(name = "beneficiary.beneficiary_referral_details")
public class BeneficiaryReferralDetails extends BaseEntity {
	
	@Column(name = "is_tfc_within_unicef")
	private String isTFCWithInUNICEF;
	
	@Column(name = "governorate_id")
	private Long governorateId;
	
	@Column(name = "district_id")
	private Long districtId;
	
	@Column(name = "refferal_tfc_id")
	private Long referralTFCId;
	
	@Column(name = "officer_governorate_id")
	private Long officerGovernorateId;
	
	@Column(name = "officer_district_id")
	private Long officerDistrictId;
	
	@Column(name = "officer_tfc_id")
	private Long officerTFCId;
	
	@Column(name = "enrollment_id")
	private Long enrollmentId;
	
	@Column(name = "non_nvs_facility_name")
	private String nonNVSFacilityName;
	
	@Column(name = "id_referral_reason_fk")
	private Long referralReason;
	
	@Column(name = "other_reason")
	private String otherReason;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	private Date createdAt;
	
	@Column(name = "id_user_created_by_fk")
	private Long createdBy;

	public String getIsTFCWithInUNICEF() {
		return isTFCWithInUNICEF;
	}

	public void setIsTFCWithInUNICEF(String isTFCWithInUNICEF) {
		this.isTFCWithInUNICEF = isTFCWithInUNICEF;
	}

	public Long getGovernorateId() {
		return governorateId;
	}

	public void setGovernorateId(Long governorateId) {
		this.governorateId = governorateId;
	}

	public Long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}

	public Long getReferralTFCId() {
		return referralTFCId;
	}

	public void setReferralTFCId(Long referralTFCId) {
		this.referralTFCId = referralTFCId;
	}

	public String getNonNVSFacilityName() {
		return nonNVSFacilityName;
	}

	public void setNonNVSFacilityName(String nonNVSFacilityName) {
		this.nonNVSFacilityName = nonNVSFacilityName;
	}

	public Long getReferralReason() {
		return referralReason;
	}

	public void setReferralReason(Long referralReason) {
		this.referralReason = referralReason;
	}

	public String getOtherReason() {
		return otherReason;
	}

	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(Long enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public Long getOfficerGovernorateId() {
		return officerGovernorateId;
	}

	public void setOfficerGovernorateId(Long officerGovernorateId) {
		this.officerGovernorateId = officerGovernorateId;
	}

	public Long getOfficerDistrictId() {
		return officerDistrictId;
	}

	public void setOfficerDistrictId(Long officerDistrictId) {
		this.officerDistrictId = officerDistrictId;
	}

	public Long getOfficerTFCId() {
		return officerTFCId;
	}

	public void setOfficerTFCId(Long officerTFCId) {
		this.officerTFCId = officerTFCId;
	}

}
