package org.yumnn.yct.beneficiaryservice.enumeration;

import org.yumnn.yct.common.entity.base.Displayable;

public enum ValidationCodeTypeEnum implements Displayable{
	 OTP("OTP", "OTP"), 
	 TFC("TFC", "TFC"),
	 PERDIEM1("PERDIEM1", "PERDIEM1"), 
	 PERDIEM2("PERDIEM2", "PERDIEM2"), 
	 PERDIEM3("PERDIEM3", "PERDIEM3"), 
	 PERDIEM5("PERDIEM5", "PERDIEM5"), 
	 DISCHARGE("DISCHARGE", "DISCHARGE"), 
	 Discharge_Plus("Discharge_Plus", "Discharge_Plus");
	
    String value;
    String arValue;

    ValidationCodeTypeEnum(String value) {
        this.value = value;
    }

    ValidationCodeTypeEnum(String value, String arValue) {
        this.value = value;
        this.arValue = arValue;
    }

    public String getValue() {
        return value;
    }

    public String getArValue() {
        return this.arValue;
    }

  @Override
  public String getDisplayName() {
    return this.value + " - " + this.arValue;
  }

  @Override
  public Object getObject() {
    return this;
  }
}
