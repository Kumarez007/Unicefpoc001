package org.yumnn.yct.beneficiaryservice.model;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class EnrollmentModel {
	private String id;
	private String isRefferdFromOtherTFC;
	private String tfcShortName;
	private String projectShortName ;
	private String enrollmentCode;
	private String otpReferenceNumber;
	private String otpGeoAreaShortName;
	private String otpNutritionOfficerName;
	private String otpNutritionOfficerRefrenceNumber;
	private String otpNutritionOfficerPhoneNumber;
	private String householdMemberList;
	private String currentVoucherDetails;
	private String createdBy;
	private String createdDate;
	private String bookletShortName;
	private String placeOfAdmissionShortName;
	private String comments;
	private String isRequireInvestigation;
	private String uniqueId;
	
	private boolean isWebCall;
	
	private Map<String, String> caregiverFile1Map;
	private Map<String, String> caregiverFile2Map;
	private Map<String, String> nomineeFile1Map;
	private Map<String, String> nomineeFile2Map;
	
//	@JsonIgnore
	private Long curFormId;
	
//	@JsonIgnore
	private Long bookletId;

	private Long admissionId;

	private List<ValidationBookletModel> validationBookletModel;

	private List<HouseholdMemberDocumentModel> memberDocumentModelList;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsRefferdFromOtherTFC() {
		return isRefferdFromOtherTFC;
	}

	public void setIsRefferdFromOtherTFC(String isRefferdFromOtherTFC) {
		this.isRefferdFromOtherTFC = isRefferdFromOtherTFC;
	}

	public String getOtpReferenceNumber() {
		return otpReferenceNumber;
	}

	public void setOtpReferenceNumber(String otpReferenceNumber) {
		this.otpReferenceNumber = otpReferenceNumber;
	}

	public String getOtpNutritionOfficerName() {
		return otpNutritionOfficerName;
	}

	public void setOtpNutritionOfficerName(String otpNutritionOfficerName) {
		this.otpNutritionOfficerName = otpNutritionOfficerName;
	}

	public String getOtpNutritionOfficerRefrenceNumber() {
		return otpNutritionOfficerRefrenceNumber;
	}

	public void setOtpNutritionOfficerRefrenceNumber(String otpNutritionOfficerRefrenceNumber) {
		this.otpNutritionOfficerRefrenceNumber = otpNutritionOfficerRefrenceNumber;
	}

	public String getOtpNutritionOfficerPhoneNumber() {
		return otpNutritionOfficerPhoneNumber;
	}

	public void setOtpNutritionOfficerPhoneNumber(String otpNutritionOfficerPhoneNumber) {
		this.otpNutritionOfficerPhoneNumber = otpNutritionOfficerPhoneNumber;
	}

	public String getTfcShortName() {
		return tfcShortName;
	}

	public void setTfcShortName(String tfcShortName) {
		this.tfcShortName = tfcShortName;
	}

	public String getOtpGeoAreaShortName() {
		return otpGeoAreaShortName;
	}

	public void setOtpGeoAreaShortName(String otpGeoAreaShortName) {
		this.otpGeoAreaShortName = otpGeoAreaShortName;
	}

	public String getEnrollmentCode() {
		return enrollmentCode;
	}

	public void setEnrollmentCode(String enrollmentCode) {
		this.enrollmentCode = enrollmentCode;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public String getHouseholdMemberList() {
		return householdMemberList;
	}

	public void setHouseholdMemberList(String householdMemberList) {
		this.householdMemberList = householdMemberList;
	}

	public String getCurrentVoucherDetails() {
		return currentVoucherDetails;
	}

	public void setCurrentVoucherDetails(String currentVoucherDetails) {
		this.currentVoucherDetails = currentVoucherDetails;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getBookletShortName() {
		return bookletShortName;
	}

	public void setBookletShortName(String bookletShortName) {
		this.bookletShortName = bookletShortName;
	}

	public String getPlaceOfAdmissionShortName() {
		return placeOfAdmissionShortName;
	}

	public void setPlaceOfAdmissionShortName(String placeOfAdmissionShortName) {
		this.placeOfAdmissionShortName = placeOfAdmissionShortName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getProjectShortName() {
		return projectShortName;
	}

	public void setProjectShortName(String projectShortName) {
		this.projectShortName = projectShortName;
	}

	public String getIsRequireInvestigation() {
		return isRequireInvestigation;
	}

	public void setIsRequireInvestigation(String isRequireInvestigation) {
		this.isRequireInvestigation = isRequireInvestigation;
	}
	
	

	public Long getCurFormId() {
		return curFormId;
	}

	public void setCurFormId(Long curFormId) {
		this.curFormId = curFormId;
	}
	
	public Long getBookletId() {
		return bookletId;
	}

	public void setBookletId(Long bookletId) {
		this.bookletId = bookletId;
	}
	
	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}	

	public Map<String, String> getCaregiverFile1Map() {
		return caregiverFile1Map;
	}

	public void setCaregiverFile1Map(Map<String, String> caregiverFile1Map) {
		this.caregiverFile1Map = caregiverFile1Map;
	}

	public Map<String, String> getCaregiverFile2Map() {
		return caregiverFile2Map;
	}

	public void setCaregiverFile2Map(Map<String, String> caregiverFile2Map) {
		this.caregiverFile2Map = caregiverFile2Map;
	}

	public Map<String, String> getNomineeFile1Map() {
		return nomineeFile1Map;
	}

	public void setNomineeFile1Map(Map<String, String> nomineeFile1Map) {
		this.nomineeFile1Map = nomineeFile1Map;
	}

	public Map<String, String> getNomineeFile2Map() {
		return nomineeFile2Map;
	}

	public void setNomineeFile2Map(Map<String, String> nomineeFile2Map) {
		this.nomineeFile2Map = nomineeFile2Map;
	}

	public boolean isWebCall() {
		return isWebCall;
	}

	public void setWebCall(boolean isWebCall) {
		this.isWebCall = isWebCall;
	}

	public Long getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(Long admissionId) {
		this.admissionId = admissionId;
	}

	public List<ValidationBookletModel> getValidationBookletModel() {
		return validationBookletModel;
	}

	public void setValidationBookletModel(List<ValidationBookletModel> validationBookletModel) {
		this.validationBookletModel = validationBookletModel;
	}

	public List<HouseholdMemberDocumentModel> getMemberDocumentModelList() {
		return memberDocumentModelList;
	}

	public void setMemberDocumentModelList(List<HouseholdMemberDocumentModel> memberDocumentModelList) {
		this.memberDocumentModelList = memberDocumentModelList;
	}

	@Override
	public String toString() {
		return "EnrollmentModel [id=" + id + ", isRefferdFromOtherTFC=" + isRefferdFromOtherTFC + ", tfcShortName="
				+ tfcShortName + ", projectShortName=" + projectShortName + ", enrollmentCode=" + enrollmentCode
				+ ", otpReferenceNumber=" + otpReferenceNumber + ", otpGeoAreaShortName=" + otpGeoAreaShortName
				+ ", otpNutritionOfficerName=" + otpNutritionOfficerName + ", otpNutritionOfficerRefrenceNumber="
				+ otpNutritionOfficerRefrenceNumber + ", otpNutritionOfficerPhoneNumber="
				+ otpNutritionOfficerPhoneNumber + ", householdMemberList=" + householdMemberList
				+ ", currentVoucherDetails=" + currentVoucherDetails + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", bookletShortName=" + bookletShortName + ", placeOfAdmissionShortName="
				+ placeOfAdmissionShortName + ", comments=" + comments + ", isRequireInvestigation="
				+ isRequireInvestigation + ", uniqueId=" + uniqueId + ", curFormId=" + curFormId + ", bookletId="
				+ bookletId + "]";
	}
}
