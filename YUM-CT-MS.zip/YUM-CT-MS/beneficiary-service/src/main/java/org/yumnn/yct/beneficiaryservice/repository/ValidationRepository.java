/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Apr 24, 2021 1:44:51 AM
 */
package org.yumnn.yct.beneficiaryservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Apr 24, 2021 1:44:51 AM
 */

@Repository
public interface ValidationRepository extends JpaRepository<Validation, Long> {
	
	Optional<Validation> findById(Long validationId);
	
	@Query(value = "SELECT * FROM beneficiary.hst_validation where id_admission_fk=:admissionId order by synchronization_date desc limit 1",nativeQuery = true)
	Validation getValidationByAdmission(@Param("admissionId") Long admissionId) throws FailProcessException;
	
	@Query(value = "SELECT id FROM beneficiary.hst_validation where id_admission_fk=:admissionId order by synchronization_date desc",nativeQuery = true)
	List<Long> getValidationIdListByAdmission(@Param("admissionId") Long admissionId) throws FailProcessException;
	
	Validation findByUniqueId(String uniqueId) throws FailProcessException;
	
	@Query(value = "select t.shortname from (select distinct cst.short_name as shortname,hv.created_at from beneficiary.hst_validation hv"
			+ " inner join beneficiary.cat_service_type cst on cst.id=hv.id_service_type_fk"
			+ " where hv.id_admission_fk = :admissionId"
			+ " order by hv.created_at ) as t",nativeQuery = true)
	List<String> getAllServiceTypes(@Param("admissionId") Long admissionId) throws FailProcessException;
	
	@Query(value = "SELECT id FROM beneficiary.hst_validation where id_admission_fk=:admissionId order by created_at asc",nativeQuery = true)
	List<Long> getValidationIdListByAdmissionByCreatedOrder(@Param("admissionId") Long admissionId) throws FailProcessException;
	
	

}
