package org.yumnn.yct.beneficiaryservice.model;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 14, 2021 5:33:20 PM
 */
public interface GrievanceAndInquiriesCardInfoModel {
	
	public String getGrievanceId();
	
	public String getInquiryId() ;
	
	public String getGrievanceCode();
	

	public String getSpecifications();

	public String getStatus();

	public String getDate();

	public String getInquiryCategoryEn();
	
	public String getInquiryCategoryAr();

	public String getTypeEn();
	
	public String getTypeAr();

	public String getComments();

	public String getDateOfRegistration();
	
	public String getCategoryEn();
	
	public String getCategoryAr();

}
