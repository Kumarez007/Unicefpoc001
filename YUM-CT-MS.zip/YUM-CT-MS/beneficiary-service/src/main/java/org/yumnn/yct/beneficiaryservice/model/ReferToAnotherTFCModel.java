package org.yumnn.yct.beneficiaryservice.model;

public class ReferToAnotherTFCModel {
	
	private Long selectedGovernorate;
	private Long selectedDistrict;
	private Long selectedTFC;
	private String isReferredToAnotherTFCWithInUNICEF;
	private Long reasonForReferral;
	private String otherReason;
	private String nonNVSFacilityName;
	private Long createdBy;
	private Long enrollmentId;
	private Long officerGovernorate;
	private Long officerDistrict;
	private Long officerTFC;
	private String otpValidationCode;
	
	public Long getSelectedGovernorate() {
		return selectedGovernorate;
	}
	public void setSelectedGovernorate(Long selectedGovernorate) {
		this.selectedGovernorate = selectedGovernorate;
	}
	public Long getSelectedDistrict() {
		return selectedDistrict;
	}
	public void setSelectedDistrict(Long selectedDistrict) {
		this.selectedDistrict = selectedDistrict;
	}
	public Long getSelectedTFC() {
		return selectedTFC;
	}
	public void setSelectedTFC(Long selectedTFC) {
		this.selectedTFC = selectedTFC;
	}
	public String getIsReferredToAnotherTFCWithInUNICEF() {
		return isReferredToAnotherTFCWithInUNICEF;
	}
	public void setIsReferredToAnotherTFCWithInUNICEF(String isReferredToAnotherTFCWithInUNICEF) {
		this.isReferredToAnotherTFCWithInUNICEF = isReferredToAnotherTFCWithInUNICEF;
	}
	public Long getReasonForReferral() {
		return reasonForReferral;
	}
	public void setReasonForReferral(Long reasonForReferral) {
		this.reasonForReferral = reasonForReferral;
	}
	public String getOtherReason() {
		return otherReason;
	}
	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}
	public String getNonNVSFacilityName() {
		return nonNVSFacilityName;
	}
	public void setNonNVSFacilityName(String nonNVSFacilityName) {
		this.nonNVSFacilityName = nonNVSFacilityName;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getEnrollmentId() {
		return enrollmentId;
	}
	public void setEnrollmentId(Long enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	public Long getOfficerGovernorate() {
		return officerGovernorate;
	}
	public void setOfficerGovernorate(Long officerGovernorate) {
		this.officerGovernorate = officerGovernorate;
	}
	public Long getOfficerDistrict() {
		return officerDistrict;
	}
	public void setOfficerDistrict(Long officerDistrict) {
		this.officerDistrict = officerDistrict;
	}
	public Long getOfficerTFC() {
		return officerTFC;
	}
	public void setOfficerTFC(Long officerTFC) {
		this.officerTFC = officerTFC;
	}
	public String getOtpValidationCode() {
		return otpValidationCode;
	}
	public void setOtpValidationCode(String otpValidationCode) {
		this.otpValidationCode = otpValidationCode;
	}
}
