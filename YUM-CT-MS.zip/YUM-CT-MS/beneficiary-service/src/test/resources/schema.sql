
CREATE schema if not exists user_access;
CREATE schema if not exists beneficiary;
CREATE schema if not exists payment;

DROP table if exists user_access.adm_project cascade;
CREATE TABLE user_access.adm_project (
	id serial NOT NULL,
	name varchar(100) NOT NULL,
	short_name varchar(100) NOT NULL,
	id_parent_project_fk int8 NULL,
	CONSTRAINT adm_project_pk PRIMARY KEY (id)
);

DROP table if exists user_access.cat_geolocation_type cascade;
CREATE TABLE user_access.cat_geolocation_type (
	id serial NOT NULL,
	name varchar(200) NOT NULL,
	id_geolocation_type_parent_fk int8 NULL,
	short_name varchar(100) NULL,
	order_item int8 NULL,
	en_name varchar(200) NULL,
	ar_name varchar(200) NULL,
	CONSTRAINT cat_geolocation_type_pk PRIMARY KEY (id),
	CONSTRAINT cat_geolocation_type_fk_1 FOREIGN KEY (id_geolocation_type_parent_fk) REFERENCES user_access.cat_geolocation_type(id)
);

DROP table if exists user_access.adm_user cascade;
CREATE TABLE user_access.adm_user (
	id serial NOT NULL,
	first_name varchar(80) NULL,
	last_name varchar(100) NULL,
	is_active varchar(5) NOT NULL,
	user_name varchar(20) NOT NULL,
	user_password varchar(128) NOT NULL,
	user_email varchar(60) NULL,
	has_access_to_own_data_only varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	failed_attempts_for_login int4 NOT NULL DEFAULT 0,
	id_updated_by int8 NULL,
	session_token varchar(255) NULL,
	unique_user_signature varchar(255) NULL,
	id_program_entity_fk int8 NULL,
	id_geolocation_fk int8 NULL,
	phone_number varchar(255) NULL,
	CONSTRAINT adm_user_pk PRIMARY KEY (id),
	CONSTRAINT adm_user_uq UNIQUE (user_name)
);

DROP table if exists user_access.cat_geolocation cascade;
CREATE TABLE user_access.cat_geolocation (
	id serial NOT NULL,
	name varchar(255) NOT NULL,
	id_geolocation_parent_fk int4 NULL,
	id_geolocation_type_fk int4 NULL,
	code varchar(20) NULL,
	short_name varchar(255) NULL,
	order_item int8 NULL,
	area_type varchar(32) NULL,
	latitude numeric(15,2) NULL,
	longitude numeric(15,2) NULL,
	en_name varchar(64) NULL,
	ar_name varchar(64) NULL,
	security_level varchar(64) NULL,
	is_active varchar(3) NOT NULL DEFAULT 'Yes'::character varying,
	created_at timestamp NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int4 NULL,
	id_user_updated_by_fk int4 NULL,
	CONSTRAINT cat_geolocation_pk PRIMARY KEY (id)
);

DROP table if exists user_access.cat_geolocation_type cascade;
CREATE TABLE user_access.cat_geolocation_type (
	id serial NOT NULL,
	name varchar(200) NOT NULL,
	id_geolocation_type_parent_fk int8 NULL,
	short_name varchar(100) NULL,
	order_item int8 NULL,
	en_name varchar(200) NULL,
	ar_name varchar(200) NULL,
	CONSTRAINT cat_geolocation_type_pk PRIMARY KEY (id),
	CONSTRAINT cat_geolocation_type_fk_1 FOREIGN KEY (id_geolocation_type_parent_fk) REFERENCES user_access.cat_geolocation_type(id)
);

DROP table if exists user_access.cat_program_entity cascade;
CREATE TABLE user_access.cat_program_entity (
	id serial NOT NULL,
	name varchar(500) NOT NULL,
	code varchar(30) NULL,
	id_geolocation_fk int8 NULL,
	en_name varchar(64) NULL,
	ar_name varchar(64) NULL,
	order_item int8 NULL,
	id_program_entity_type_fk int8 NULL,
	created_at timestamp NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NULL,
	id_user_updated_by_fk int8 NULL,
	short_name varchar(64) NULL,
	CONSTRAINT cat_program_entity_pk PRIMARY KEY (id)
);

DROP table if exists user_access.cat_program_entity_type cascade;
CREATE TABLE user_access.cat_program_entity_type (
	id serial NOT NULL,
	name varchar(500) NOT NULL,
	en_name varchar(64) NULL,
	ar_name varchar(64) NULL,
	created_at timestamp NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NULL,
	id_user_updated_by_fk int8 NULL,
	short_name varchar(20) NULL,
	CONSTRAINT cat_program_entity_type_pk PRIMARY KEY (id)
);

DROP table if exists beneficiary.cat_booklet cascade;
CREATE TABLE beneficiary.cat_booklet (
	id bigserial NOT NULL,
	name varchar(100) NULL,
	short_name varchar(100) NOT NULL,
	order_item int4 NOT NULL,
	en_name varchar(100) NULL,
	ar_name varchar(100) NULL,
	is_active varchar(5) NOT NULL,
	CONSTRAINT cat_booklet_pk PRIMARY KEY (id)
);

DROP table if exists beneficiary.cat_documents cascade;
CREATE TABLE beneficiary.cat_documents (
	id serial NOT NULL,
	name varchar(255) NOT NULL,
	en_name varchar(255) NOT NULL,
	ar_name varchar(255) NOT NULL,
	is_active varchar(3) NOT NULL DEFAULT 'YES'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	order_item int8 NULL,
	short_name varchar(64) NULL,
	id_user_created_by_fk int8 NULL,
	id_user_updated_by_fk int8 NULL,
	CONSTRAINT cat_documents_pk PRIMARY KEY (id),
	CONSTRAINT cat_documents_uq UNIQUE (short_name),
	CONSTRAINT cat_documents_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cat_documents_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.cat_gender cascade;
CREATE TABLE beneficiary.cat_gender (
	id serial NOT NULL,
	name varchar(50) NOT NULL,
	short_name varchar(20) NOT NULL,
	order_item int8 NOT NULL,
	en_name varchar(20) NOT NULL,
	ar_name varchar(20) NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	CONSTRAINT cat_gender_pk PRIMARY KEY (id),
	CONSTRAINT cat_gender_uq UNIQUE (short_name)
);

DROP table if exists beneficiary.cat_household_member_type cascade;
CREATE TABLE beneficiary.cat_household_member_type (
	id serial NOT NULL,
	name varchar(100) NOT NULL,
	short_name varchar(64) NOT NULL,
	en_name varchar(64) NOT NULL,
	ar_name varchar(64) NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	order_item int8 NULL,
	CONSTRAINT cur_household_member_type_pk PRIMARY KEY (id),
	CONSTRAINT cur_household_member_type_uq UNIQUE (short_name),
	CONSTRAINT cur_household_member_type_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cur_household_member_type_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.cat_reasons_of_non_admission cascade;
CREATE TABLE beneficiary.cat_reasons_of_non_admission (
	id serial NOT NULL,
	name varchar(500) NOT NULL,
	short_name varchar(100) NOT NULL,
	en_name varchar(100) NOT NULL,
	ar_name varchar(100) NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	CONSTRAINT cat_reasons_of_non_admission_pk PRIMARY KEY (id),
	CONSTRAINT cat_reasons_of_non_admission_uq UNIQUE (short_name),
	CONSTRAINT cat_reasons_of_non_admission_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cat_reasons_of_non_admission_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.cat_relationship cascade;
CREATE TABLE beneficiary.cat_relationship (
	id serial NOT NULL,
	name varchar(100) NOT NULL,
	en_name varchar(64) NOT NULL,
	ar_name varchar(64) NOT NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	is_active varchar(3) NOT NULL DEFAULT 'YES'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	order_item int8 NOT NULL,
	short_name varchar(64) NOT NULL,
	CONSTRAINT cat_relationship_pk PRIMARY KEY (id),
	CONSTRAINT cat_relationship_uq UNIQUE (short_name),
	CONSTRAINT cat_relationship_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cat_relationship_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.cat_service_type cascade;
CREATE TABLE beneficiary.cat_service_type (
	id serial NOT NULL,
	name varchar(500) NOT NULL,
	short_name varchar(100) NOT NULL,
	en_name varchar(100) NOT NULL,
	ar_name varchar(100) NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	CONSTRAINT cat_service_type_pk PRIMARY KEY (id),
	CONSTRAINT cat_service_type_uq UNIQUE (short_name),
	CONSTRAINT cat_service_type_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cat_service_type_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.cur_form cascade;
CREATE TABLE beneficiary.cur_form (
	id serial NOT NULL,
	id_project_fk int8 NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	form_number varchar(100) NULL,
	CONSTRAINT cur_form_pk PRIMARY KEY (id),
	CONSTRAINT cur_form_fk_1 FOREIGN KEY (id_project_fk) REFERENCES user_access.adm_project(id),
	CONSTRAINT cur_form_fk_2 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cur_form_fk_3 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.hst_enrollment cascade;
CREATE TABLE beneficiary.hst_enrollment (
	id serial NOT NULL,
	is_ref_from_other_tfc varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	id_program_entity_fk int8 NULL,
	otp_ref_number varchar(50) NULL,
	id_geolocation_fk int8 NOT NULL,
	otp_nut_officer_name varchar(500) NOT NULL,
	otp_nut_officer_ref_number varchar(50) NOT NULL,
	otp_nut_officer_phone_number varchar(20) NOT NULL,
	id_form_fk int8 NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	code varchar(10) NULL,
	id_booklet_fk int8 NULL,
	comments varchar(500) NULL,
	id_program_entity_place_of_admission_fk int8 NULL,
	is_require_investigation varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	synchronization_date timestamp,
	unique_id varchar(255) NULL,
	CONSTRAINT hst_enrollment_pk PRIMARY KEY (id),
	CONSTRAINT hst_enrollment_fk_1 FOREIGN KEY (id_program_entity_fk) REFERENCES user_access.cat_program_entity(id) ,
	CONSTRAINT hst_enrollment_fk_2 FOREIGN KEY (id_geolocation_fk) REFERENCES user_access.cat_geolocation(id),
	CONSTRAINT hst_enrollment_fk_3 FOREIGN KEY (id_form_fk) REFERENCES beneficiary.cur_form(id),
	CONSTRAINT hst_enrollment_fk_4 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_enrollment_fk_5 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_enrollment_fk_6 FOREIGN KEY (id_booklet_fk) REFERENCES beneficiary.cat_booklet(id) ,
	CONSTRAINT hst_enrollment_fk_7 FOREIGN KEY (id_program_entity_place_of_admission_fk) REFERENCES user_access.cat_program_entity(id)
);

DROP table if exists beneficiary.cur_household_member cascade;
CREATE TABLE beneficiary.cur_household_member (
	id serial NOT NULL,
	id_form_fk int8 NOT NULL,
	first_name varchar(100) NULL,
	last_name varchar(100) NULL,
	id_gender_fk int8 NULL,
	date_of_birth timestamp NULL,
	phone_number varchar(15) NULL,
	id_documents_fk int8 NULL,
	document_reference_number varchar(100) NULL,
	id_relationship_fk int8 NULL,
	is_assigned_as_payment_receiver varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	id_household_member_type_fk int8 NOT NULL,
	is_primary varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	member_code varchar(200) NULL,
	source_id int8 NULL,
	source_type varchar(255) NULL,
	CONSTRAINT cur_household_member_pk PRIMARY KEY (id),
	CONSTRAINT cur_household_member_fk_1 FOREIGN KEY (id_gender_fk) REFERENCES beneficiary.cat_gender(id),
	CONSTRAINT cur_household_member_fk_2 FOREIGN KEY (id_form_fk) REFERENCES beneficiary.cur_form(id),
	CONSTRAINT cur_household_member_fk_3 FOREIGN KEY (id_relationship_fk) REFERENCES beneficiary.cat_relationship(id),
	CONSTRAINT cur_household_member_fk_4 FOREIGN KEY (id_documents_fk) REFERENCES beneficiary.cat_documents(id),
	CONSTRAINT cur_household_member_fk_6 FOREIGN KEY (id_household_member_type_fk) REFERENCES beneficiary.cat_household_member_type(id),
	CONSTRAINT cur_household_member_fk_7 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT cur_household_member_fk_8 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.hst_admission cascade;
CREATE TABLE beneficiary.hst_admission (
	id serial NOT NULL,
	is_admitted varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	id_program_entity_fk int8 NULL,
	id_reasons_of_non_admission_fk int8 NULL,
	other_reasons_non_admission varchar(500) NULL,
	id_enrollment_fk int8 NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	synchronization_date timestamp,
	unique_id varchar(255) NULL,
	CONSTRAINT hst_admission_pk PRIMARY KEY (id),
	CONSTRAINT hst_admission_fk_1 FOREIGN KEY (id_reasons_of_non_admission_fk) REFERENCES beneficiary.cat_reasons_of_non_admission(id),
	CONSTRAINT hst_admission_fk_2 FOREIGN KEY (id_enrollment_fk) REFERENCES beneficiary.hst_enrollment(id),
	CONSTRAINT hst_admission_fk_3 FOREIGN KEY (id_program_entity_fk) REFERENCES user_access.cat_program_entity(id) ,
	CONSTRAINT hst_admission_fk_4 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_admission_fk_5 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.hst_validation cascade;
CREATE TABLE beneficiary.hst_validation (
	id serial NOT NULL,
	id_admission_fk int8 NOT NULL,
	id_service_type_fk int8 NOT NULL,
	date_from timestamp NULL,
	date_to timestamp NULL,
	number_of_days int8 NOT NULL,
	number_of_periods int8 NOT NULL,
	doctor_name varchar(200) NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	document_reference_number varchar(200) NULL,
	id_documents_fk int8 NULL,
	synchronization_date timestamp,
	unique_id varchar(255) NULL,
	CONSTRAINT hst_validation_pk PRIMARY KEY (id),
	CONSTRAINT hst_validation_fk_1 FOREIGN KEY (id_admission_fk) REFERENCES beneficiary.hst_admission(id),
	CONSTRAINT hst_validation_fk_2 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_validation_fk_3 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_validation_fk_4 FOREIGN KEY (id_service_type_fk) REFERENCES beneficiary.cat_service_type(id),
	CONSTRAINT hst_validation_fk_5 FOREIGN KEY (id_documents_fk) REFERENCES beneficiary.cat_documents(id)
);

DROP table if exists beneficiary.stp_booklet_by_validation_code cascade;
CREATE TABLE beneficiary.stp_booklet_by_validation_code (
	id bigserial NOT NULL,
	id_cat_booklet_fk int8 NOT NULL,
	validation_code varchar(100) NOT NULL,
	order_item int4 NOT NULL,
	is_active varchar(5) NOT NULL,
	is_used varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	is_redeemed varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	validation_code_type varchar(50) NOT NULL,
	is_printed varchar(3) NOT NULL,
	CONSTRAINT order_date_unique UNIQUE (id_cat_booklet_fk, validation_code),
	CONSTRAINT stp_booklet_by_voucher_pk PRIMARY KEY (id),
	CONSTRAINT stp_booklet_by_voucher_fk_2 FOREIGN KEY (id_cat_booklet_fk) REFERENCES beneficiary.cat_booklet(id)
);

DROP table if exists beneficiary.tra_attachment cascade;
CREATE TABLE beneficiary.tra_attachment (
	id serial NOT NULL,
	file_mime_type varchar(255) NOT NULL,
	file_size int8 NOT NULL,
	file text NOT NULL,
	source_type varchar(255) NULL,
	reference_id int8 NOT NULL,
	reference_type varchar(64) NOT NULL,
	attachment_name varchar(255) NOT NULL,
	attachment_extension varchar(10) NULL,
	is_active varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	CONSTRAINT tra_attachment_pk PRIMARY KEY (id),
	CONSTRAINT tra_attachment_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT tra_attachment_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.tra_enable_validation_code cascade;
CREATE TABLE beneficiary.tra_enable_validation_code (
	id serial NOT NULL,
	reference_id int8 NOT NULL,
	reference_type varchar(50) NOT NULL,
	id_booklet_by_validation_fk int8 NOT NULL,
	validation_type varchar(50) NOT NULL,
	expiry_date timestamp NULL,
	created_at timestamp NOT NULL,
	id_user_created_by_fk int8 NOT NULL,
	CONSTRAINT enable_validation_code_pk PRIMARY KEY (id),
	CONSTRAINT enable_validation_code_fk_1 FOREIGN KEY (id_booklet_by_validation_fk) REFERENCES beneficiary.stp_booklet_by_validation_code(id),
	CONSTRAINT enable_validation_code_fk_2 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.sch_form cascade;
CREATE TABLE beneficiary.sch_form (
	id serial primary key,
	id_cur_form_fk int8 NOT NULL,
	ben_names varchar(300) NOT NULL,
	e_document_number varchar(64) NOT NULL,
	id_governorate_fk int8 NOT NULL,
	id_district_fk int8 NOT NULL,
	contact_number varchar(48) NULL,
	old_ben_id varchar(100) NULL,
	id_household_member_fk int4 NOT NULL,
	id_ozla_fk int8 NULL,
	id_village_fk int8 NULL,
	id_program_entity_fk int8 NULL,
	booklet_number varchar(48) NULL,
	enrollment_date timestamp NULL,
	id_household_member_type_fk int8 NOT NULL
);

DROP table if exists beneficiary.cur_household_member_log cascade;
CREATE TABLE beneficiary.cur_household_member_log (
	id serial NOT NULL,
	id_form_fk int8 NOT NULL,
	first_name varchar(100) NULL,
	last_name varchar(100) NULL,
	id_gender_fk int8 NULL,
	date_of_birth date NULL,
	phone_number varchar(15) NULL,
	id_documents_fk int8 NULL,
	document_reference_number varchar(100) NULL,
	id_relationship_fk int8 NULL,
	is_assigned_as_payment_receiver varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	id_household_member_type_fk int8 NOT NULL,
	is_primary varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	member_code varchar(200) NULL,
	source_id int8 NULL,
	source_type varchar(255) NULL,
	CONSTRAINT hst_household_member_pk PRIMARY KEY (id),
	CONSTRAINT hst_household_member_fk_1 FOREIGN KEY (id_gender_fk) REFERENCES beneficiary.cat_gender(id),
	CONSTRAINT hst_household_member_fk_2 FOREIGN KEY (id_form_fk) REFERENCES beneficiary.cur_form(id),
	CONSTRAINT hst_household_member_fk_3 FOREIGN KEY (id_relationship_fk) REFERENCES beneficiary.cat_relationship(id),
	CONSTRAINT hst_household_member_fk_4 FOREIGN KEY (id_documents_fk) REFERENCES beneficiary.cat_documents(id),
	CONSTRAINT hst_household_member_fk_6 FOREIGN KEY (id_household_member_type_fk) REFERENCES beneficiary.cat_household_member_type(id),
	CONSTRAINT hst_household_member_fk_7 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_household_member_fk_8 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id)
);

DROP table if exists beneficiary.tra_attachment_log cascade;
CREATE TABLE beneficiary.tra_attachment_log (
	id serial NOT NULL,
	file_mime_type varchar(255) NOT NULL,
	file_size int8 NOT NULL,
	file text NOT NULL,
	source_type varchar(255) NULL,
	source_id int8 NULL,
	reference_id int8 NOT NULL,
	reference_type varchar(64) NOT NULL,
	attachment_name varchar(255) NOT NULL,
	attachment_extension varchar(10) NULL,
	is_active varchar(3) NOT NULL DEFAULT 'NO'::character varying,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	id_user_updated_by_fk int8 NULL,
	id_form_fk int8 NOT NULL,
	CONSTRAINT hst_attachment_pk PRIMARY KEY (id),
	CONSTRAINT hst_attachment_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_attachment_fk_2 FOREIGN KEY (id_user_updated_by_fk) REFERENCES user_access.adm_user(id),
	CONSTRAINT hst_attachment_fk_3 FOREIGN KEY (id_form_fk) REFERENCES beneficiary.cur_form(id)
);

DROP table if exists beneficiary.vca_monitoring_log cascade;
CREATE TABLE beneficiary.vca_monitoring_log (
	id serial NOT NULL,
	failed_attempt int4 NOT NULL,
	viewed_attempt int4 NOT NULL,
	created_at timestamp NOT NULL,
	updated_at timestamp NULL,
	id_user_created_by_fk int8 NOT NULL,
	CONSTRAINT vca_monitoring_log_pk PRIMARY KEY (id),
	CONSTRAINT vca_monitoring_log_fk_1 FOREIGN KEY (id_user_created_by_fk) REFERENCES user_access.adm_user(id)
);


DROP table if exists beneficiary.cur_location cascade;
CREATE TABLE beneficiary.cur_location (
	id serial NOT NULL,
	id_cur_form_fk int8 NOT NULL,
	id_geolocation_fk int8 NULL,
	address_1 varchar(500) NULL,
	address_2 varchar(500) NULL,
	po_box varchar(10) NULL,
	gps_latitude varchar(40) NULL,
	gps_longitude varchar(40) NULL,
	CONSTRAINT cur_location_pk PRIMARY KEY (id),
	CONSTRAINT cur_location_fk FOREIGN KEY (id_cur_form_fk) REFERENCES beneficiary.cur_form(id),
	CONSTRAINT cur_location_fk_2 FOREIGN KEY (id_geolocation_fk) REFERENCES user_access.cat_geolocation(id)
);

DROP table if exists payment.arc_nvs_payment_list_unpivot cascade;
CREATE TABLE payment.arc_nvs_payment_list_unpivot (
	tfc_code varchar(1024) NULL,
	vca_usn varchar(1024) NULL,
	governorate_of_tfc varchar(1024) NULL,
	district_of_tfc varchar(1024) NULL,
	ozla_of_tfc varchar(1024) NULL,
	name_of_tfc varchar(1024) NULL,
	agency varchar(50) NULL,
	validation_code varchar NULL,
	payment_amount int4 NULL,
	validation_code_type text NULL
);

DROP table if exists user_access.gen_device_detail cascade;
CREATE TABLE user_access.gen_device_detail (
	id serial NOT NULL,
	created_at timestamp NULL,
	is_active bool NULL DEFAULT true,
	updated_at timestamp NULL,
	device_ip_address varchar(255) NULL,
	device_id varchar(255) NULL,
	manufacturer varchar(255) NULL,
	model varchar(255) NULL,
	os varchar(255) NULL,
	os_version varchar(255) NULL,
	created_by int8 NULL,
	updated_by int8 NULL,
	id_user_fk int8 NULL,
	CONSTRAINT device_detail_pkey PRIMARY KEY (id)
);

DROP table if exists beneficiary.gen_records_to_download cascade;
CREATE TABLE beneficiary.gen_records_to_download (
id serial NOT NULL,
record_json text NOT NULL,
reference_id int8 NULL,
reference_type varchar(255) NULL,
is_active varchar(5) NOT NULL,
status varchar(50) null,
synchronization_date timestamp null,
CONSTRAINT gen_records_to_download_pkey PRIMARY KEY (id)
);

DROP table if exists beneficiary.gen_device_downloaded_data cascade;
CREATE TABLE beneficiary.gen_device_downloaded_data (
id serial NOT NULL,
id_device_fk int8 NOT NULL,
id_records_to_download_fk int8 NOT NULL,
CONSTRAINT gen_device_downloaded_data_pkey PRIMARY KEY (id),
CONSTRAINT gen_device_downloaded_data_fk FOREIGN KEY (id_device_fk) REFERENCES user_access.gen_device_detail(id),
CONSTRAINT gen_device_downloaded_data_fk1 FOREIGN KEY (id_records_to_download_fk) REFERENCES beneficiary.gen_records_to_download(id)
);

