package org.yumnn.yct.beneficiaryservice.util.validate;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 26, 2021 11:19:13 PM
 * 
 */

@SpringBootTest(classes = {ValidateEnrollmentDetail.class, CommonValidationUtil.class, MessageSource.class})
public class ValidateEnrollmentDetailTest {
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private ValidateEnrollmentDetail validateEnrollmentDetail =null;
	
	@MockBean
	EnrollmentRepository enrollmentRepository=null;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("JUnit: validateEnrollmentDetails Basic Test")
	public void testValidateEnrollmentDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testValidateEnrollmentDetailsBasic Test Started");
		
		EnrollmentModel enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		Map<String, MultipartFile> filesMapHouseHoldMemberModel=ValidationTestFixture.createEnrollmentFileMap();
		when(enrollmentRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		assertDoesNotThrow(() ->
		validateEnrollmentDetail.validateEnrollmentDetails(filesMapHouseHoldMemberModel, enrollmentModel));
	
		logger.debug("JUnit: testValidateEnrollmentDetailsBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: validateEnrollmentDetails Invalid Param  Test")
	public void testValidateEnrollmentDetailsInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateEnrollmentDetailsInvalidParam Test Started");
		
		EnrollmentModel enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		Map<String, MultipartFile> filesMapHouseHoldMemberModel=ValidationTestFixture.createEnrollmentFileMap();
		
		enrollmentModel.setIsRefferdFromOtherTFC(null);
		when(enrollmentRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateEnrollmentDetail.validateEnrollmentDetails(filesMapHouseHoldMemberModel, enrollmentModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateEnrollmentDetailsInvalidParam Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: validateEnrollmentDetails CurrentForm Test")
	public void testValidateEnrollmentDetailsInvalidCurrentForm() throws Exception {
		
		logger.debug("JUnit: testValidateEnrollmentDetailsInvalidCurrentForm Test Started");
		
		EnrollmentModel enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		Map<String, MultipartFile> filesMapHouseHoldMemberModel=ValidationTestFixture.createEnrollmentFileMap();
		enrollmentModel.setProjectShortName(null);
		when(enrollmentRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateEnrollmentDetail.validateEnrollmentDetails(filesMapHouseHoldMemberModel, enrollmentModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		logger.debug("JUnit: testValidateEnrollmentDetailsInvalidCurrentForm Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: validateEnrollmentDetails Invalid HouseHoldMember Missing File Test")
	public void testValidateEnrollmentDetailsHouseHoldMemberMissingFile() throws Exception {
		
		logger.debug("JUnit: testValidateEnrollmentDetailsHouseHoldMemberMissingFile Test Started");
		
		EnrollmentModel enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		Map<String, MultipartFile> filesMapHouseHoldMemberModel=new HashMap<String, MultipartFile>();
		when(enrollmentRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateEnrollmentDetail.validateEnrollmentDetails(filesMapHouseHoldMemberModel, enrollmentModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateEnrollmentDetailsHouseHoldMemberMissingFile Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: validateEnrollmentDetails Invalid HouseHoldMember Test")
	public void testValidateEnrollmentDetailsHouseHoldMember() throws Exception {
		
		logger.debug("JUnit: testValidateEnrollmentDetailsHouseHoldMember Test Started");
		
		EnrollmentModel enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		Map<String, MultipartFile> filesMapHouseHoldMemberModel=ValidationTestFixture.createEnrollmentFileMap();
		
		enrollmentModel.setHouseholdMemberList(null);
		when(enrollmentRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateEnrollmentDetail.validateEnrollmentDetails(filesMapHouseHoldMemberModel, enrollmentModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateEnrollmentDetailsHouseHoldMember Test Completed");
		
	}
}
