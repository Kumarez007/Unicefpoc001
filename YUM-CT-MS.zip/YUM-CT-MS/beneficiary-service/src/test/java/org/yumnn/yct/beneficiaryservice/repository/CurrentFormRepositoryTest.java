package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.project.Project;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 14, 2021 11:25:53 PM
 */

@DataJpaTest
public class CurrentFormRepositoryTest {
	
	private static Logger logger = LoggerFactory.getLogger(CurrentFormRepositoryTest.class);
	
	@Autowired
	private CurrentFormRepository repo = null;
	
	private CurrentForm currentForm=null;
	
	@Test
	public void testFindByFormNumber() {
		logger.info("Inside testFindByFormNumber");
		CurrentForm result= repo.findByFormNumber("2");
		assertEquals("2",result.getFormNumber());
	}

	@Test
	public void testFindByFormNumberAsNull() {
		logger.info("Inside testFindByFormNumberAsNull");
		CurrentForm result= repo.findByFormNumber(null);
		assertNull(result);
	}
	
	@Test
	public void testFindByIncorrectFormNumber() {
		logger.info("Inside testFindByIncorrectFormNumber");
		CurrentForm result= repo.findByFormNumber("10");
		assertNull(result);
	}
	
	@Test
	public void testFindFormByVca() {
		logger.info("Inside testFindFormByVca");
		List<CurrentForm> result= repo.findFormByVca("300-101-100105");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testFindFormByVcaAsNull() {
		logger.info("Inside testFindFormByVcaAsNull");
		List<CurrentForm> result= repo.findFormByVca(null);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testFindFormByIncorrectVca() {
		logger.info("Inside testFindFormByIncorrectVca");
		List<CurrentForm> result= repo.findFormByVca("300-102-100249");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testFindBookletByVca() {
		logger.info("Inside testFindBookletByVca");
		Booklet result= repo.findBookletByVca("300-101-100105");
		assertNotNull(result);
	}
	
	@Test
	public void testFindBookletByVcaAsNull() {
		logger.info("Inside testFindBookletByVcaAsNull");
		Booklet result= repo.findBookletByVca(null);
		assertNull(result);
	}
	
	@Test
	public void testFindBookletByIncorrectVca() {
		logger.info("Inside testFindBookletByIncorrectVca");
		Booklet result= repo.findBookletByVca("300-102-100249");
		assertNull(result);
	}
	
	@Test
	public void testSaveCurrentForm() throws Exception {
		logger.info("Inside testSaveCurrentForm");
		
		setUpEntity();
	
		CurrentForm result= repo.save(currentForm);
		
		assertNotNull(result);
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		Booklet booklet=new Booklet();
		booklet.setId(1L);
		
		Project project=new Project();
		project.setId(1L);
		
		currentForm = new CurrentForm();
		currentForm.setId(100L);
		currentForm.setBooklet(booklet);
		currentForm.setProject(project);
		currentForm.setCreatedBy(user);
		currentForm.setCreatedAt(new Date());
	}

}
