package org.yumnn.yct.beneficiaryservice.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.service.SynchronizationService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 16, 2021 4:16:44 PM
 */

@WebMvcTest(value = SynchronizationController.class)
public class SynchronizationControllerTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	SynchronizationService synchronizationService;
	
	private Map<String, String> requestHeader=null;
	private HttpHeaders header=null;
	private Map<String, Object> mockResponse=null;
	
	private static final String BASE_URI = "/api/v1";
    private static final String SUCCESS_STATUS = "Success";
    private static final String SUCCESS_STATUS_CODE = "200";
    private static final String USERNAME="junit_tester";
    private SyncModel syncModel=null;
	
    @BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		header=new HttpHeaders();
		header.setAll(requestHeader);
		
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testGetPendingRecordsForSync() throws Exception {
    	
		logger.debug("JUnit : testGetPendingRecordsForSync");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		syncModel.setLastSyncId("1");
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put(ConstantsUtil.PENDING_RECORDS, "3");
		
		SuccessResponse testReponse= getTestResponse(mockResponse);
		
		when(synchronizationService.getPendingRecordsForSync(Mockito.any(Map.class),Mockito.any(SyncModel.class))).thenReturn(mockResponse);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/synchronizationControl/getPendingRecordsForSync")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(syncModel)))
				.andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertEquals(ValidationTestFixture.returnJson(successResponse.getData()), ValidationTestFixture.returnJson(testReponse.getData()));
		logger.debug("JUnit Test case - get user details completed");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testGetPendingRecordsForSyncWithInvalidHeader() throws Exception {
		logger.debug("JUnit Test case - testGetPendingRecordsForSyncWithInvalidHeader");
		
		syncModel=new SyncModel();
		
		mockResponse=new HashMap<String, Object>();
		
		when(synchronizationService.getPendingRecordsForSync(Mockito.any(Map.class),Mockito.any(SyncModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/synchronizationControl/getPendingRecordsForSync")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(syncModel)))
				.andExpect(status().isUnauthorized())
				.andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
		
		logger.debug("JUnit Test case - testGetPendingRecordsForSyncWithInvalidHeader completed");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testDownloadBeneficiarySyncData() throws Exception {
    	
		logger.debug("JUnit : testDownloadBeneficiarySyncData");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put("admissionList", getDataForSync());
		
		SuccessResponse testReponse= getTestResponse(mockResponse);
		
		when(synchronizationService.downloadBeneficiarySyncData(Mockito.any(Map.class),Mockito.any(SyncModel.class))).thenReturn(mockResponse);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/synchronizationControl/downloadBeneficiarySyncData")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(syncModel)))
				.andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertEquals(ValidationTestFixture.returnJson(successResponse.getData()), ValidationTestFixture.returnJson(testReponse.getData()));
		logger.debug("JUnit: testDownloadBeneficiarySyncData - completed");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testDownloadBeneficiarySyncDatawithInvalidHeader() throws Exception {
		logger.debug("JUnit Test testDownloadBeneficiarySyncDatawithInvalidHeader");
		
		syncModel=new SyncModel();
		
		mockResponse=new HashMap<String, Object>();
		
		when(synchronizationService.downloadBeneficiarySyncData(Mockito.any(Map.class),Mockito.any(SyncModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/synchronizationControl/downloadBeneficiarySyncData")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(syncModel)))
				.andExpect(status().isUnauthorized())
				.andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
		
		logger.debug("JUnit: testDownloadBeneficiarySyncDatawithInvalidHeader - completed");
	}
    
    private SuccessResponse getTestResponse(Map<String, Object> map) {
		SuccessResponse testReponse= new SuccessResponse();
	    testReponse.setData(map);
	    testReponse.setMessage(SUCCESS_STATUS);
	    testReponse.setStatus(Integer.valueOf(SUCCESS_STATUS_CODE));
	    
	    return testReponse;
	}
    
    List<Map<String, Object>> getDataForSync(){
    	List<Map<String, Object>> batchList=new ArrayList<>();
		Map<String, Object> map = new LinkedHashMap<>();
        
        map.put(ConstantsUtil.ADMISSION_ID, "1");
        map.put(ConstantsUtil.IS_AdMITTED, "No");
        map.put(ConstantsUtil.NON_ADMISSION_OTHER_REASONS, "");
        map.put(ConstantsUtil.ENROLLMENT_ID, "1");
        map.put(ConstantsUtil.ENROLLMENT_CODE, "1");
        map.put(ConstantsUtil.PROGRAM_ENTITY_SHORT_NAME, "TFC001");
        map.put(ConstantsUtil.NON_ADMISSION_REASON, "CHCATTFC");
        map.put(ConstantsUtil.CREATED_AT, "15-07-2021 04:42:50");
        map.put(ConstantsUtil.CREATED_BY, "1");
        map.put(ConstantsUtil.UPDATED_AT, "");
        map.put(ConstantsUtil.UPDATED_BY, "");
        map.put(ConstantsUtil.VALIDATION_CODE_DETAILS, getValidationCodeDetails());
        batchList.add(map);
        
        return batchList;
    	
    }
    
    private List<ValidationCodeModel> getValidationCodeDetails(){
		List<ValidationCodeModel> validationCodeDetailsList = new ArrayList<ValidationCodeModel>();
		ValidationCodeModel validationCodeDetails = new ValidationCodeModel();
		validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_ADMISSION);
		validationCodeDetails.setValidationCodeType("OTP");
		validationCodeDetails.setValidationCode("611001061");
		validationCodeDetails.setExpirydate("02-08-2021");
		
		validationCodeDetailsList.add(validationCodeDetails);
		
		return validationCodeDetailsList;
	}
    

}
