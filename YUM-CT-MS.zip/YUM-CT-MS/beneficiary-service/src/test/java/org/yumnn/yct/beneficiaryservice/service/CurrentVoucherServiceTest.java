package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.yumnn.yct.beneficiaryservice.entity.CurrentVoucher;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.CurrentVoucherModel;
import org.yumnn.yct.beneficiaryservice.repository.CurrentVoucherRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 22, 2021 6:00:03 PM
 */

@ExtendWith(MockitoExtension.class)
public class CurrentVoucherServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private CurrentVoucherService currentVoucherService = null;
	
	@Mock
	private CurrentVoucherRepository currentVoucherRepository =null;

	@Mock
	private EnrollmentRepository enrollmentRepository=null;
	
	private List<CurrentVoucherModel> expectedResponse=null;
	private List<CurrentVoucherModel> resultResponse=null;
	private User user=null;
	private CurrentVoucher currentVoucher=null;
	private CurrentVoucherModel currentVoucherModel=null;
	private Enrollment enrollment=null;
	
	@BeforeEach
	public void setup() throws IOException {
		
		user = new User();
		user.setId(1L);
		
		enrollment = new Enrollment();
		enrollment.setId(1L);
		
		currentVoucher= new CurrentVoucher();
		currentVoucher.setId(1L);
		currentVoucher.setEnrollment(enrollment);
		
	}
	
	@DisplayName("SaveCurrentVoucherDetails Test for Basic Operation")
	@Test
	public void testSaveCurrentVoucherDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testSaveCurrentVoucherDetailsBasic");
		
		currentVoucherModel= new CurrentVoucherModel();
		currentVoucherModel.setId("1");
		currentVoucherModel.setEnrollmentId("1");
		currentVoucherModel.setCreatedDate("15-07-2021 09:09:30");
		
		expectedResponse=new ArrayList<CurrentVoucherModel>();
		expectedResponse.add(currentVoucherModel);
		
		
		when(enrollmentRepository.findById(Mockito.anyLong()))
		.thenReturn(Optional.of(enrollment));
		
		when(currentVoucherRepository.save(Mockito.any(CurrentVoucher.class))).thenReturn(currentVoucher);
		
		//call service
		resultResponse=currentVoucherService.saveCurrentVoucherDetails(expectedResponse, user);
		
		assertNotNull(resultResponse);
		assertEquals(expectedResponse,resultResponse);
		
		logger.debug("JUnit: testSaveCurrentVoucherDetailsBasic - Completed");
		
	}
	
	@DisplayName("SaveCurrentVoucherDetails Test for Fail Process Operation")
	@Test
	public void testSaveCurrentVoucherDetailsFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveCurrentVoucherDetailsFailProcess");
		
		currentVoucherModel= new CurrentVoucherModel();
		currentVoucherModel.setId("1");
		currentVoucherModel.setEnrollmentId("1");
		currentVoucherModel.setCreatedDate("15-07-2021 09:09:30");
		
		expectedResponse=new ArrayList<CurrentVoucherModel>();
		expectedResponse.add(currentVoucherModel);
		
		
		when(enrollmentRepository.findById(Mockito.anyLong()))
		.thenReturn(Optional.of(enrollment));
		
		CurrentVoucher saveCurrentVoucher=new CurrentVoucher();
		when(currentVoucherRepository.save(saveCurrentVoucher)).thenReturn(currentVoucher);
		
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=currentVoucherService.saveCurrentVoucherDetails(expectedResponse, user);
        });
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testSaveCurrentVoucherDetailsFailProcess - Completed");
		
	}

}
