package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.common.entity.catalog.Booklet;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 14, 2021 6:53:38 PM
 */
@DataJpaTest
public class BookletRepositoryTest {

	private static Logger logger = LoggerFactory.getLogger(BookletRepositoryTest.class);
	
	@Autowired
	private BookletRepository repo = null;
	
	@Test
	public void testFindByShortName() {
		logger.info("Inside testFindByShortName");
		Booklet result= repo.findByShortName("300-102-100244");
		assertEquals("300-102-100244",result.getShortName());
	}
	
	@Test
	public void testFindByIncorrectShortName() {
		logger.info("Inside testFindByIncorrectShortName");
		Booklet result= repo.findByShortName("300-102-100249");
		assertNull(result);
	}
	
	@Test
	public void testFindByShortNameAsNull() {
		logger.info("Inside testFindByShortNameAsNull");
		Booklet result= repo.findByShortName(null);
		assertNull(result);
	}
	
}
