package org.yumnn.yct.beneficiaryservice.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 16, 2021 3:47:24 PM
 */

@WebMvcTest(value = EnrollController.class)
public class EnrollControllerTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	EnrollmentService enrollmentService;
	
	private Map<String, String> requestHeader=null;
	private HttpHeaders header=null;
	private Map<String, Object> mockResponse=null;
	
	private static final String BASE_URI = "/api/v1";
	private static final String SAMPLE_IMAGE ="junit_test_image.jpg";
    private static final String SUCCESS_STATUS = "Success";
    private static final String SUCCESS_STATUS_CODE = "200";
	
    @BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		header=new HttpHeaders();
		header.setAll(requestHeader);
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testEnrollBeneficiary() throws Exception {
		
		logger.debug("JUnit: testEnrollBeneficiary");
		
		when(enrollmentService.enrollBeneficiary(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(EnrollmentModel.class))).thenReturn(mockResponse);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/enrollcontrol/enrollBeneficiary")
				.file(ValidationTestFixture.getFile("caregiverFile1"))
				.file(ValidationTestFixture.getFile("nomineeFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestEnrollmentModel(requestBuilder);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isOk())
				   .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				   .andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);
		
		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertNotNull(successResponse.getData());
		assertEquals("1", successResponse.getData().get(ConstantsUtil.ENROLLMENT_CODE));
	
    	logger.debug("JUnit: testEnrollBeneficiary - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testEnrollBeneficiaryWithInvalidHeaderData() throws Exception {
		
		logger.debug("JUnit: testEnrollBeneficiaryWithInvalidHeaderData");

		when(enrollmentService.enrollBeneficiary(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(EnrollmentModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/enrollcontrol/enrollBeneficiary")
				.file(ValidationTestFixture.getFile("caregiverFile1"))
				.file(ValidationTestFixture.getFile("nomineeFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestEnrollmentModel(requestBuilder);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isUnauthorized())
				   .andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
	
    	logger.debug("Junit: testEnrollBeneficiaryWithInvalidHeaderData - Completed");
		
	}
	
	public RequestBuilder getRequestEnrollmentModel(MockMultipartHttpServletRequestBuilder requestBuilder) {
		
		requestBuilder.param("isRefferdFromOtherTFC","Yes");
		requestBuilder.param("tfcShortName","TFC001");
		requestBuilder.param("projectShortName","NVS");
		requestBuilder.param("otpReferenceNumber","999-999-999");
		requestBuilder.param("otpNutritionOfficerName","JUnit Tester");
		requestBuilder.param("otpNutritionOfficerRefrenceNumber","999-999-999");
		requestBuilder.param("otpNutritionOfficerPhoneNumber","701234567");
		requestBuilder.param("otpGeoAreaShortName","26-3-22-");
		requestBuilder.param("bookletShortName","1111-2222-3333-23");
		requestBuilder.param("placeOfAdmissionShortName","TFC001");
		requestBuilder.param("comments","JUnit Testing");
		requestBuilder.param("householdMemberList",ValidationTestFixture.returnJson(ValidationTestFixture.getHouseholdMemberList()));
		requestBuilder.param("isRequireInvestigation","No");
		requestBuilder.param("createdBy",requestHeader.get(ConstantsUtil.USER_ID_HEADER));
		
		return requestBuilder;
		
	}

}
