package org.yumnn.yct.beneficiaryservice.util.validate;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.MessageSource;
import org.yumnn.yct.beneficiaryservice.service.BeneficiaryApiCallService;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.model.administration.UserModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 27, 2021 1:07:52 AM
 */

@SpringBootTest(classes = {ValidateUserDetail.class, CommonValidationUtil.class, MessageSource.class})
public class ValidateUserDetailTest { 
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private ValidateUserDetail validateUserDetail =null;
	
	@MockBean
	private BeneficiaryApiCallService apiCallService=null;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("JUnit: ValidateAndGetUser Basic Test")
	public void testValidateAndGetUserBasic() throws Exception {
		
		logger.debug("JUnit: testValidateAndGetUserBasic Test Started");
		
		Map<String, String> requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		UserModel expectedResult= new UserModel();
		expectedResult .setId(1L);
		
		when(apiCallService.getUserDetails(requestHeader)).thenReturn(expectedResult);
		
		User actualResult=validateUserDetail.validateAndGetUser(requestHeader);
		
		assertEquals(expectedResult.getId(), actualResult.getId());
	
		logger.debug("JUnit: testValidateAndGetUserBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateAndGetUser Invalid Param Test")
	public void testValidateAndGetUserInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateAndGetUserInvalidParam Test Started");
		
		Map<String, String> requestHeader=new HashMap<String, String>();
		
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateUserDetail.validateAndGetUser(requestHeader);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateAndGetUserInvalidParam Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateAndGetUser Invalid User Test")
	public void testValidateAndGetUserInvalidUser() throws Exception {
		
		logger.debug("JUnit: testValidateAndGetUserInvalidUser Test Started");
		
		Map<String, String> requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		UserModel expectedResult= new UserModel();
		expectedResult .setId(2L);
		
		when(apiCallService.getUserDetails(requestHeader)).thenReturn(expectedResult);
		
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateUserDetail.validateAndGetUser(requestHeader);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateAndGetUserInvalidUser Test Completed");
		
	}
	
	

}
