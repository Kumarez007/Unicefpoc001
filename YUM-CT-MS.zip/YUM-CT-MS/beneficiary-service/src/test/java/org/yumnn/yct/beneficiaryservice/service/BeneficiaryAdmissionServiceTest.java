package org.yumnn.yct.beneficiaryservice.service;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.BookletByValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnableValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberRepository;
import org.yumnn.yct.beneficiaryservice.repository.ReasonOfNonAdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateAdmissionDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateEnrollmentDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.administration.UserModel;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.EnableValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.ReasonsNonAdmission;
import org.yumnn.yct.beneficiaryservice.entity.Validation;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:29:53 PM
 */

@ExtendWith(MockitoExtension.class)
public class BeneficiaryAdmissionServiceTest {

	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private BeneficiaryAdmissionService admissionService = null;
	
	@Mock
	private AdmissionRepository admissionRepository = null;
	
	@Mock
	private EnrollmentRepository enrollmentRepository =null;

	@Mock
	private ReasonOfNonAdmissionRepository reasonOfNonAdmissionRepository =null;

	@Mock
	private AttachmentRepository attachmentRepository =null;
	
	@Mock
	private EnableValidationCodeRepository enableValidationCodeRepository =null;

	@Mock
	private BookletByValidationCodeRepository bookletByValidationCodeRepository =null;

	@Mock
	private HouseholdMemberService householdMemberService =null;
	
	@Mock
	private CurrentFormRepository currentFormRepository =null;
	
	@Mock
	private ValidateEnrollmentDetail validateEnrollmentDetail =null;
	
	@Mock
	private ValidateAdmissionDetail validateAdmissionDetail =null;
	
	@Mock
	private ValidateUserDetail validateUserDetail =null;
	
	@Mock
	private  MessageSource messageSource =null;
	
	@Mock
	private HouseholdMemberRepository householdMemberRepository=null;

	@Mock
	private BeneficiaryApiCallService beneficiaryApiCallService=null;
	
	@Mock
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService=null;

	@Mock
	private EnrollmentService enrollmentService=null;
	
	@Mock
	ValidationRepository validationRepository=null;
	
	@Mock
	private ValidationService validationService=null;
	
	@Mock
	private SynchronizationService synchronizationService=null;
	
	private Map<String, String> requestHeader=null;
	private Map<String, Object> expectedResponse=null;
	private Map<String, Object> resultResponse=null;
	private Map<String, MultipartFile> filesMapAddAdmission = null;
	private Map<String, MultipartFile> filesMapAddAdmissionUpdateHHM = null;
	private  BeneficiaryAdmissionModel admissionModel = null;
	private UserModel userModel = null;
	private User user=null;
	private Enrollment enrollment=null;
	private ReasonsNonAdmission reasonsNonAdmission=null;
	private Admission admission=null;
	private BookletByValidationCode bookletByValidationCode=null;
	private EnableValidationCode enableValidationCode =null;
	private Attachment attachment =null;
	private List<Map<String, MultipartFile>> fileList=null;
	private Validation validation=null;
	
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		userModel = new UserModel();
		userModel.setId(1L);
		
		user = new User();
		user.setId(1L);
		
		enrollment = new Enrollment();
		enrollment.setId(1L);
		enrollment.setEnrollmentCode("1");
		
		reasonsNonAdmission = new ReasonsNonAdmission();
		reasonsNonAdmission.setId(1L);
		reasonsNonAdmission.setShortName("CHCATTFC");
		
		bookletByValidationCode= new  BookletByValidationCode();
		bookletByValidationCode.setId(1L);
		
		enableValidationCode = new EnableValidationCode();
		enableValidationCode.setId(1L);
		
		attachment = new Attachment();
		attachment.setId(1L);
		
		
		filesMapAddAdmission=ValidationTestFixture.createAdmissionFileMap();
		filesMapAddAdmissionUpdateHHM=createEnrollmentFileMap();
		
		admission=getAdmissionEntity();
		
		validation = new Validation();
		validation.setId(1L);
		validation.setAdmission(admission);
	}
	
	@DisplayName("AddBeneficiaryAdmission Test for Basic Operation")
	@Test
	public void testAddBeneficiaryAdmissionBasic() throws Exception {
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionBasic");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		expectedResponse.put(ConstantsUtil.ADMISSION_ID, 1L);
	
		admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		
		CycleByProjectModel cycleByProjectModel = new CycleByProjectModel();
		cycleByProjectModel.setCycleId(1L);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(enrollmentRepository.findByEnrollmentCode(admissionModel.getEnrollmentCode())).thenReturn(enrollment);
		
		when(reasonOfNonAdmissionRepository.findByShortName(admissionModel.getNonAdmissionReasonShortName())).thenReturn(reasonsNonAdmission);
		
		when(admissionRepository.save(Mockito.any(Admission.class))).thenReturn(admission);
		
		validationCodeMocks(admissionModel);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		when(beneficiaryApiCallService.getCycleByProjectName(Mockito.anyMap(),Mockito.anyString())).thenReturn(cycleByProjectModel);
		
		mocksForsaveLatestRecordJsonForAdmission();
		
		//call service
		resultResponse=admissionService.addBeneficiaryAdmission(requestHeader, filesMapAddAdmission, admissionModel);
		
		verify(validateAdmissionDetail,atLeastOnce()).validateAdmissionDetails(filesMapAddAdmission, admissionModel);
		verify(historicalBeneficiaryMilestoneService,atLeastOnce()).saveHistoricalBeneficiaryModel(Mockito.any(HistoricalBeneficiaryModel.class));
		assertEquals(expectedResponse.get(ConstantsUtil.ADMISSION_ID),resultResponse.get(ConstantsUtil.ADMISSION_ID));
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionBasic - Completed");
		
	}
	
	@DisplayName("AddBeneficiaryAdmission Test for FailProcessException Operation")
	@Test()
	public void testAddBeneficiaryAdmissionFailProcess() throws Exception {
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionFailProcess");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		expectedResponse.put(ConstantsUtil.ADMISSION_ID, 1L);
	
		admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(enrollmentRepository.findByEnrollmentCode(admissionModel.getEnrollmentCode())).thenReturn(enrollment);
		
		when(reasonOfNonAdmissionRepository.findByShortName(admissionModel.getNonAdmissionReasonShortName())).thenReturn(reasonsNonAdmission);
		
		Admission saveAdmission = new Admission();
		//pass admission object - throws fail process exception
		when(admissionRepository.save(saveAdmission)).thenReturn(admission);
		
		validationCodeMocks(admissionModel);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=admissionService.addBeneficiaryAdmission(requestHeader, filesMapAddAdmission, admissionModel);
        });
			
		verify(validateAdmissionDetail,atLeastOnce()).validateAdmissionDetails(filesMapAddAdmission, admissionModel);
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionFailProcess - Completed");
		
	}
	
	@DisplayName("AddBeneficiaryAdmission Test for Invalid Validation Code Operation")
	@Test()
	public void testAddBeneficiaryAdmissionInvalidCode() throws Exception {
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionInvalidCode");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		expectedResponse.put(ConstantsUtil.ADMISSION_ID, 1L);
	
		admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(enrollmentRepository.findByEnrollmentCode(admissionModel.getEnrollmentCode())).thenReturn(enrollment);
		
		when(reasonOfNonAdmissionRepository.findByShortName(admissionModel.getNonAdmissionReasonShortName())).thenReturn(null);
		
		//when(admissionRepository.save(Mockito.any(Admission.class))).thenReturn(admission);
		
//		when(bookletByValidationCodeRepository.findByValidationCodeAndIsActiveAndIsUsed(admissionModel.getOtpValidationCode(), YesNoEnum.YES, YesNoEnum.NO))
//		.thenReturn(null);
		

		//call service
		IllegalArgumentException ex= assertThrows(IllegalArgumentException.class, () -> {
			resultResponse=admissionService.addBeneficiaryAdmission(requestHeader, filesMapAddAdmission, admissionModel);
        });
			
		verify(validateAdmissionDetail,atLeastOnce()).validateAdmissionDetails(filesMapAddAdmission, admissionModel);
		
		assertEquals(IllegalArgumentException.class, ex.getClass());
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionInvalidCode - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@DisplayName("AddAdmissionUpdateHouseholdMember Test for Basic Operation")
	@Test
	public void testAddAdmissionUpdateHouseholdMemberBasic() throws Exception {
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMemberBasic");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		expectedResponse.put(ConstantsUtil.ADMISSION_ID, 1L);
	
		admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.TRUE);
		
		List<Map<String, MultipartFile>> fileList=new ArrayList<Map<String, MultipartFile>>();
		fileList.add(filesMapAddAdmission);
		fileList.add(filesMapAddAdmissionUpdateHHM);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(enrollmentRepository.findByEnrollmentCode(admissionModel.getEnrollmentCode())).thenReturn(enrollment);
		
		when(reasonOfNonAdmissionRepository.findByShortName(admissionModel.getNonAdmissionReasonShortName())).thenReturn(reasonsNonAdmission);
		
		when(admissionRepository.save(Mockito.any(Admission.class))).thenReturn(admission);
		
		CycleByProjectModel cycleByProjectModel = new CycleByProjectModel();
		cycleByProjectModel.setCycleId(1L);
		when(beneficiaryApiCallService.getCycleByProjectName(Mockito.anyMap(),Mockito.anyString())).thenReturn(cycleByProjectModel);
		
		mocksForsaveLatestRecordJsonForAdmission();
		
		validationCodeMocks(admissionModel);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		houseHoldMemeberMocks();
		//call service
		resultResponse=admissionService.addAdmissionUpdateHouseholdMember(requestHeader, fileList, admissionModel);
		
		verify(validateAdmissionDetail,atLeastOnce()).validateAdmissionDetails(filesMapAddAdmission, admissionModel);
		
		verify(validateEnrollmentDetail,atLeastOnce()).validateHouseholdDetails(Mockito.any(Map.class),Mockito.any(List.class));
		
		verify(householdMemberService,atLeastOnce()).updateHouseholdMemberDetails(Mockito.any(List.class), Mockito.any(Map.class),Mockito.any(Admission.class));
		
		assertEquals(expectedResponse.get(ConstantsUtil.ADMISSION_ID),resultResponse.get(ConstantsUtil.ADMISSION_ID));
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMemberBasic - Completed");
	}
	
	@DisplayName("AddAdmissionUpdateHouseholdMember Test for FailProcessException Operation")
	@Test
	public void testAddAdmissionUpdateHouseholdMemberFailProcess() throws Exception {
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMemberFailProcess");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		expectedResponse.put(ConstantsUtil.ADMISSION_ID, 1L);
	
		admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.TRUE);
		
		fileList=new ArrayList<Map<String, MultipartFile>>();
		fileList.add(filesMapAddAdmission);
		fileList.add(filesMapAddAdmissionUpdateHHM);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(enrollmentRepository.findByEnrollmentCode(admissionModel.getEnrollmentCode())).thenReturn(enrollment);
		
		when(reasonOfNonAdmissionRepository.findByShortName(admissionModel.getNonAdmissionReasonShortName())).thenReturn(reasonsNonAdmission);
		
		Admission saveAdmission = new Admission();
		
		//pass admission object - throws fail process exception
		when(admissionRepository.save(saveAdmission)).thenReturn(admission);
		
		validationCodeMocks(admissionModel);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		houseHoldMemeberMocks();
		
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=admissionService.addBeneficiaryAdmission(requestHeader, filesMapAddAdmission, admissionModel);
        });
			
		verify(validateAdmissionDetail,atLeastOnce()).validateAdmissionDetails(filesMapAddAdmission, admissionModel);
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMemberFailProcess - Completed");
	
	}
	
	private void validationCodeMocks(BeneficiaryAdmissionModel admissionModel) { 

		when(bookletByValidationCodeRepository.findByValidationCodeAndIsActiveAndIsUsed(admissionModel.getOtpValidationCode(), YesNoEnum.YES, YesNoEnum.NO))
		.thenReturn(bookletByValidationCode);
		
		when(bookletByValidationCodeRepository.findByValidationCodeAndIsActiveAndIsUsed(admissionModel.getTfcValidationCode(), YesNoEnum.YES, YesNoEnum.NO))
		.thenReturn(bookletByValidationCode);
		
		//use lenient to avoid STRICT_STUBS error for multiple call to same method or use thenReturn as many time as method is called
		//e.g.: when(enableValidationCodeRepository.save(Mockito.any(EnableValidationCode.class))).thenReturn(enableValidationCode).thenReturn(enableValidationCode);
		
		lenient().when(enableValidationCodeRepository.save(Mockito.any(EnableValidationCode.class))).thenReturn(enableValidationCode);
		
		lenient().when(bookletByValidationCodeRepository.save(Mockito.any(BookletByValidationCode.class))).thenReturn(bookletByValidationCode);
		
	}
	
	private void houseHoldMemeberMocks() throws Exception{
		
		CurrentForm cf=new CurrentForm();
		cf.setId(1L);
		Optional<CurrentForm> currentFormOpt= Optional.of(cf); 
		
		when(currentFormRepository.findById(1L)).thenReturn(currentFormOpt);
		
	}
	
	private Map<String, MultipartFile> createEnrollmentFileMap() throws IOException {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		filesMap.put(ConstantsUtil.CAREGIVER_FILE1, ValidationTestFixture.getFile(ConstantsUtil.CAREGIVER_FILE1));
    	filesMap.put(ConstantsUtil.NOMINEE_FILE1, ValidationTestFixture.getFile(ConstantsUtil.NOMINEE_FILE1));
		return filesMap;
	}
	
	private Admission getAdmissionEntity() {
		
		Date date= new Date();
		
		Project project = new Project();
		project.setId(1L);
		project.setShortName(ProjectNameEnum.NVS);
		
		CurrentForm currentForm= new CurrentForm();
		currentForm.setId(1L);
		currentForm.setProject(project);
		
		Booklet booklet= new Booklet();
		booklet.setId(1L);
    	
		Admission admission = new Admission();
		admission.setId(1L);
		admission.setCreatedBy(user);
		admission.setCreatedAt(date);
	
		enrollment.setCurrentForm(currentForm);
		enrollment.setBooklet(booklet);
		admission.setEnrollment(enrollment);
		admission.setIsAdmitted(YesNoEnum.NO);
		admission.setNonAdmissionReason(reasonsNonAdmission);
    	
    	return admission;
    }
    
    private void mocksForsaveLatestRecordJsonForAdmission(){
    	Optional<Enrollment> enrollmentOpt =  Optional.of(enrollment); 
		when(enrollmentRepository.findById(Mockito.anyLong())).thenReturn(enrollmentOpt);
		
		Map<String, Object> enrollmentMap=new HashMap<String, Object>();
		enrollmentMap.put(ConstantsUtil.ENROLLMENT_ID, enrollment.getId());
		when(enrollmentService.addEnrollmentDetailsToMap(Mockito.anyLong(),Mockito.any(Enrollment.class)))
		.thenReturn(enrollmentMap);
		
		when(validationRepository.getValidationByAdmission(admission.getId())).thenReturn(validation);
		
		Map<String, Object> validationMap=new HashMap<String, Object>();
		validationMap.put(ConstantsUtil.ENROLLMENT_ID, enrollment.getId());
		when(validationService.addValidationDetailsToMap(Mockito.anyLong(),Mockito.any(Validation.class)))
		.thenReturn(validationMap);
    }
}
