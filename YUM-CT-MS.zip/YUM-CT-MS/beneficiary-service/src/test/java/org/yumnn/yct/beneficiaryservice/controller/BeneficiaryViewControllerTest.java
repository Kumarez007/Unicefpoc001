package org.yumnn.yct.beneficiaryservice.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryTimelineModel;
import org.yumnn.yct.beneficiaryservice.model.ContactCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.HouseholdCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByServiceCardInfoModel;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;
import org.yumnn.yct.beneficiaryservice.service.HistoricalBeneficiaryMilestoneService;
import org.yumnn.yct.beneficiaryservice.service.HouseholdMemberService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 16, 2021 2:45:00 PM
 */

@WebMvcTest(value = BeneficiaryViewController.class)
public class BeneficiaryViewControllerTest {
	
private static Logger logger = LogManager.getLogger();
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	EnrollmentService enrollmentService;
	
	@MockBean
	HouseholdMemberService householdMemberService;
	
	@MockBean
	HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService;
	
	private Map<String, String> requestHeader=null;
	private HttpHeaders header=null;
	private Map<String, Object> mockResponse=null;
	private Map<String, String> requestBody=null;
	
	private static final String BASE_URI = "/api/v1";
    private static final String SUCCESS_STATUS = "Success";
    private static final String SUCCESS_STATUS_CODE = "200";
    
    @BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		header=new HttpHeaders();
		header.setAll(requestHeader);
	
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testSearchBeneficaryInfo() throws Exception {
    	
		logger.debug("JUnit: testSearchBeneficaryInfo");
		
		List<Map<String,String>> mapDataList=getMapDataList();
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put("searchBeneficiaryResponse", mapDataList);
		
		SuccessResponse testReponse= getTestResponse(mockResponse);
		
		when(enrollmentService.searchBeneficaryInfo(Mockito.any(Map.class))).thenReturn(mockResponse);
		
		requestBody=new HashMap<String, String>();
		requestBody.put(ConstantsUtil.SEARCH_TYPE_PARAM, ConstantsUtil.SEARCH_ALL);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/beneficiaryViewcontrol/searchBeneficaryInfo")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(requestBody)))
				.andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertEquals(ValidationTestFixture.returnJson(successResponse.getData()), ValidationTestFixture.returnJson(testReponse.getData()));
		logger.debug("JUnit: testSearchBeneficaryInfoTest - completed");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testSearchBeneficaryInfoWithInvalidHeader() throws Exception {
		logger.debug("JUnit: testSearchBeneficaryInfoWithInvalidHeader");
		
		List<Map<String,String>> mapDataList=getMapDataList();
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put("searchBeneficiaryResponse", mapDataList);
		
		when(enrollmentService.searchBeneficaryInfo(Mockito.any(Map.class))).thenReturn(mockResponse);
		
		requestBody=new HashMap<String, String>();
		requestBody.put(ConstantsUtil.SEARCH_TYPE_PARAM, ConstantsUtil.SEARCH_ALL);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/beneficiaryViewcontrol/searchBeneficaryInfo")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(requestBody)))
				.andExpect(status().isUnauthorized())
				.andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
		
		logger.debug("JUnit: testSearchBeneficaryInfoWithInvalidHeader - completed");
	}
    
   	@Test
   	public void testGetHouseholdCardInfo() throws Exception {
       	
   		logger.debug("JUnit: testGetHouseholdCardInfo");
   		
   		HouseholdCardInfoModel householdCardInfoModel = null;
   		
   		
   		List<HouseholdCardInfoModel> householdCardInfoList= new ArrayList<HouseholdCardInfoModel>();
   		householdCardInfoList.add(householdCardInfoModel);
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		expectedResponse.put(ConstantsUtil.HOUSEHOLD_CARD_INFO_LIST, householdCardInfoList);
   		expectedResponse.put(ConstantsUtil.PROJECT_NAME, "TEST");
   		expectedResponse.put(ConstantsUtil.UNIQUE_CODE, "123");
   		expectedResponse.put(ConstantsUtil.PRIMARY_MEMBER, "TEST CAREGIVER");
   		expectedResponse.put(ConstantsUtil.GEOLOCATION_ID_PARAM, 1L);
   		
   		SuccessResponse testReponse= getTestResponse(expectedResponse);
   		
   		when(enrollmentService.getHouseholdCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getHouseholdCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.param("projectShortName", "NVS")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		ObjectMapper mapper = new ObjectMapper();
   		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

   		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
   		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
   		assertEquals(ValidationTestFixture.returnJson(successResponse.getData().get(ConstantsUtil.HOUSEHOLD_CARD_INFO_LIST)), 
   				ValidationTestFixture.returnJson(testReponse.getData().get(ConstantsUtil.HOUSEHOLD_CARD_INFO_LIST)));
   		
   		logger.debug("JUnit: testGetHouseholdCardInfo - completed");
   	}
    
   	@Test
   	public void testGetHouseholdCardInfoWithInvalidHeader() throws Exception {
       	
   		logger.debug("JUnit: testGetHouseholdCardInfoWithInvalidHeader");
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		
   		when(enrollmentService.getHouseholdCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getHouseholdCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		assertEquals(401, result.getResponse().getStatus());
   		
   		logger.debug("JUnit: testGetHouseholdCardInfoWithInvalidHeader - completed");
   	}
    
    
    @Test
   	public void testGetPaymentByServiceCardInfo() throws Exception {
       	
   		logger.debug("JUnit: testGetPaymentByServiceCardInfo");
   		
   		PaymentByServiceCardInfoModel paymentByServiceCardInfoModel = null;
   		
   		
   		List<PaymentByServiceCardInfoModel> paymentByServiceCardInfoList= new ArrayList<PaymentByServiceCardInfoModel>();
   		paymentByServiceCardInfoList.add(paymentByServiceCardInfoModel);
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		expectedResponse.put(ConstantsUtil.PAYMENT_BY_SERVICE_CARD_INFO_LIST, paymentByServiceCardInfoList);
   		
   		SuccessResponse testReponse= getTestResponse(expectedResponse);
   		
   		when(enrollmentService.getPaymentByServiceCardInfo(Mockito.anyLong())).thenReturn(expectedResponse);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getPaymentByServiceCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		ObjectMapper mapper = new ObjectMapper();
   		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

   		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
   		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
   		assertEquals(ValidationTestFixture.returnJson(successResponse.getData().get(ConstantsUtil.PAYMENT_BY_SERVICE_CARD_INFO_LIST)), 
   				ValidationTestFixture.returnJson(testReponse.getData().get(ConstantsUtil.PAYMENT_BY_SERVICE_CARD_INFO_LIST)));
   		
   		logger.debug("JUnit: testGetPaymentByServiceCardInfo - completed");
   	}
    
   	@Test
   	public void testGetPaymentByServiceCardInfoWithInvalidHeader() throws Exception {
       	
   		logger.debug("JUnit: testGetPaymentByServiceCardInfoWithInvalidHeader");
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		
   		when(enrollmentService.getPaymentByServiceCardInfo(Mockito.anyLong())).thenReturn(expectedResponse);
   		
   		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getPaymentByServiceCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		assertEquals(401, result.getResponse().getStatus());
   		
   		logger.debug("JUnit: testGetPaymentByServiceCardInfoWithInvalidHeader - completed");
   	}
   	
   	@Test
   	public void testGetMemberCardInfo() throws Exception {
       	
   		logger.debug("JUnit: testGetMemberCardInfo");
   		
   		MemberCardInfoModel memberCardInfoModel = null;
   		
   		
   		List<MemberCardInfoModel> memberCardInfoModelList= new ArrayList<MemberCardInfoModel>();
   		memberCardInfoModelList.add(memberCardInfoModel);
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		expectedResponse.put(ConstantsUtil.MEMBER_CARD_INFO_LIST, memberCardInfoModelList);
   		
   		SuccessResponse testReponse= getTestResponse(expectedResponse);
   		
   		when(householdMemberService.getMemberCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getMemberCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.param("projectShortName", "NVS")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		ObjectMapper mapper = new ObjectMapper();
   		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

   		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
   		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
   		assertEquals(ValidationTestFixture.returnJson(successResponse.getData().get(ConstantsUtil.MEMBER_CARD_INFO_LIST)), 
   				ValidationTestFixture.returnJson(testReponse.getData().get(ConstantsUtil.MEMBER_CARD_INFO_LIST)));
   		
   		logger.debug("JUnit: testGetMemberCardInfo - completed");
   	}
    
   	@Test
   	public void testGetMemberCardInfoWithInvalidHeader() throws Exception {
       	
   		logger.debug("JUnit: testGetMemberCardInfoWithInvalidHeader");
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		
   		when(householdMemberService.getMemberCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getMemberCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		assertEquals(401, result.getResponse().getStatus());
   		
   		logger.debug("JUnit: testGetMemberCardInfoWithInvalidHeader - completed");
   	}
   	
   	@Test
   	public void testGetBeneficiaryTimelineData() throws Exception {
       	
   		logger.debug("JUnit: testGetBeneficiaryTimelineData");
   		
   		BeneficiaryTimelineModel beneficiaryTimelineModel = null;
   		
   		
   		List<BeneficiaryTimelineModel> beneficiaryTimelineModelList= new ArrayList<BeneficiaryTimelineModel>();
   		beneficiaryTimelineModelList.add(beneficiaryTimelineModel);
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		expectedResponse.put(ConstantsUtil.BENEFICIARY_TIMELINE_DATA, beneficiaryTimelineModelList);
   		
   		SuccessResponse testReponse= getTestResponse(expectedResponse);
   		
   		when(historicalBeneficiaryMilestoneService.getBeneficiaryTimelineData(Mockito.anyLong())).thenReturn(expectedResponse);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getBeneficiaryTimelineData")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		ObjectMapper mapper = new ObjectMapper();
   		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

   		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
   		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
   		assertEquals(ValidationTestFixture.returnJson(successResponse.getData().get(ConstantsUtil.BENEFICIARY_TIMELINE_DATA)), 
   				ValidationTestFixture.returnJson(testReponse.getData().get(ConstantsUtil.BENEFICIARY_TIMELINE_DATA)));
   		
   		logger.debug("JUnit: testGetBeneficiaryTimelineData - completed");
   	}
    
   	@Test
   	public void testGetBeneficiaryTimelineDataWithInvalidHeader() throws Exception {
       	
   		logger.debug("JUnit: testGetBeneficiaryTimelineDataWithInvalidHeader");
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		
   		when(historicalBeneficiaryMilestoneService.getBeneficiaryTimelineData(Mockito.anyLong())).thenReturn(expectedResponse);
   		
   		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getBeneficiaryTimelineData")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		assertEquals(401, result.getResponse().getStatus());
   		
   		logger.debug("JUnit: testGetBeneficiaryTimelineDataWithInvalidHeader - completed");
   	}
   	
   	@Test
   	public void testGetContactCardInfoInfo() throws Exception {
       	
   		logger.debug("JUnit: testGetContactCardInfoInfo");
   		
   		ContactCardInfoModel contactCardInfoModel = null;
   		
   		List<ContactCardInfoModel> contactCardInfoModelList= new ArrayList<ContactCardInfoModel>();
   		contactCardInfoModelList.add(contactCardInfoModel);
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		expectedResponse.put(ConstantsUtil.CONTACT_CARD_INFO_LIST, contactCardInfoModelList);
   		
   		SuccessResponse testReponse= getTestResponse(expectedResponse);
   		
   		when(householdMemberService.getContactCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getContactCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.param("uniqueCode", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		ObjectMapper mapper = new ObjectMapper();
   		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);

   		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
   		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
   		assertEquals(ValidationTestFixture.returnJson(successResponse.getData().get(ConstantsUtil.CONTACT_CARD_INFO_LIST)), 
   				ValidationTestFixture.returnJson(testReponse.getData().get(ConstantsUtil.CONTACT_CARD_INFO_LIST)));
   		
   		logger.debug("JUnit: testGetContactCardInfoInfo - completed");
   	}
    
   	@Test
   	public void testGetContactCardInfoInfoWithInvalidHeader() throws Exception {
       	
   		logger.debug("JUnit: testGetContactCardInfoInfoWithInvalidHeader");
   		
   		Map<String, Object> expectedResponse=new HashMap<String, Object>();
   		
   		when(householdMemberService.getContactCardInfo(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedResponse);
   		
   		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
   		
   		MvcResult result = mockMvc.perform(get(BASE_URI + "/beneficiaryViewcontrol/getContactCardInfo")
   				.headers(header)
				.param("curFormId", "1")
				.contentType(MediaType.APPLICATION_JSON))
		.andReturn();
   		
   		assertEquals(401, result.getResponse().getStatus());
   		
   		logger.debug("JUnit: testGetContactCardInfoInfoWithInvalidHeader - completed");
   	}
    
    private SuccessResponse getTestResponse(Map<String, Object> map) {
		SuccessResponse testReponse= new SuccessResponse();
	    testReponse.setData(map);
	    testReponse.setMessage(SUCCESS_STATUS);
	    testReponse.setStatus(Integer.valueOf(SUCCESS_STATUS_CODE));
	    
	    return testReponse;
	}
    
    private List<Map<String,String>> getMapDataList(){
    	Map<String,String> searchData=new HashMap<String, String>();
		searchData.put("beneficiaryId","1");
		searchData.put("admissionId","1");
		searchData.put("validationId","1");
		searchData.put("vcaNumber","300-102-100244");
		searchData.put("dateOfEnrollment","16-07-2021 10:11:12");
		searchData.put("fullName","JUnit User");
		List<Map<String,String>> mapDataList=new ArrayList<Map<String,String>>();
		mapDataList.add(searchData);
		return mapDataList;
    }

}
