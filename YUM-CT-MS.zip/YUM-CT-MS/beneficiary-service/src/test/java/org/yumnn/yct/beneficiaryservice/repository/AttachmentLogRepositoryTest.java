package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.AttachmentLog;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.SourceTypeEnum;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 11, 2021 3:52:27 PM
 */

@DataJpaTest
public class AttachmentLogRepositoryTest {
	
	private static Logger logger = LoggerFactory.getLogger(AttachmentLogRepositoryTest.class);
	
	@Autowired
	private AttachmentLogRepository repo = null;
	
	private AttachmentLog attachmentLog=null;
	
	@Test
	public void testSaveAttachmentLogBasic() throws Exception {
		logger.info("Inside testSaveAttachmentLog Basic");
		
		setUpEntity();
		
		AttachmentLog result= repo.save(attachmentLog);
		assertNotNull(result);
		logger.debug("save successful");
		
	}
	
	@Test
	public void testSaveAttachmentLogFail() throws Exception {
		logger.info("Inside testSaveAttachmentLog Not Null Contraint Violation");
		
		setUpEntity();
		
		attachmentLog.setCurrentForm(null);
		
		try {
			repo.save(attachmentLog);
		}
		catch(Exception e) {
			logger.debug("Error In Save");
			assertNotNull(e);
		}
		
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		CurrentForm currentForm= new CurrentForm();
		currentForm.setId(2L);
		
		attachmentLog = new AttachmentLog();
		attachmentLog.setId(100L);
		attachmentLog.setCreatedBy(user);
		attachmentLog.setCreatedAt(new Date());
		attachmentLog.setFile("dummy");
		attachmentLog.setFileSize(1L);
		attachmentLog.setFileMimeType("dummy");
		attachmentLog.setExtension(".txt");
		attachmentLog.setIsActive(YesNoEnum.YES);
		attachmentLog.setReferenceId(2L);
		attachmentLog.setReferenceType("admissionFile1");
		attachmentLog.setName("dummy");
		attachmentLog.setCurrentForm(currentForm);
		attachmentLog.setSourceId(1L);
		attachmentLog.setSourceType(SourceTypeEnum.ADMISSION);
	}

}
