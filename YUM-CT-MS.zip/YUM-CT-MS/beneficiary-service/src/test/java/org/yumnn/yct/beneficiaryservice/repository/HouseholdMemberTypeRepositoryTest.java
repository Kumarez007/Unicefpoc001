package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 1:58:45 AM
 */

@DataJpaTest
public class HouseholdMemberTypeRepositoryTest {

	private static Logger logger = LoggerFactory.getLogger(HouseholdMemberTypeRepositoryTest.class);
	
	@Autowired
	private HouseholdMemberTypeRepository repo = null;
	
	@Test
	public void testFindByShortName() {
		logger.info("Inside testFindByShortName");
		HouseholdMemberType result= repo.findByShortName("HMCG");
		assertEquals("HMCG",result.getShortName());
	}
	
	@Test
	public void testFindByIncorrectShortName() {
		logger.info("Inside testFindByIncorrectShortName");
		HouseholdMemberType result= repo.findByShortName("xyz");
		assertNull(result);
	}
	
	@Test
	public void testFindByShortNameAsNull() {
		logger.info("Inside testFindByShortNameAsNull");
		HouseholdMemberType result= repo.findByShortName(null);
		assertNull(result);
	}
}
