package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.RecordDownload;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.DeviceDownloadedDataRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.RecordDownloadRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateSyncDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.ConstantsUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:30:39 PM
 */

@ExtendWith(MockitoExtension.class)
public class SynchronizationServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private SynchronizationService synchronizationService = null;
	
	@Mock
	private ValidateUserDetail validateUserDetail;
	
	@Mock
	private ValidateSyncDetail validateSyncDetail;
	
	@Mock
	private RecordDownloadRepository recordDownloadRepository;
	
	@Mock
	private DeviceDownloadedDataRepository deviceDownloadedDataRepository;
	
	@Mock
	private BeneficiaryAdmissionService admissionService=null;
	
	@Mock
	private EnrollmentService enrollmentService=null;
	
	@Mock
	private EnrollmentRepository enrollmentRepository = null;
	
	@Mock
	private AdmissionRepository admissionRepository = null;
	
	@Mock
	private ValidationRepository validationRepository = null;
	
	@Mock
	private ValidationService validationService=null;
	
	private Map<String, String> requestHeader=null;
	private Map<String, Object> expectedResponse=null;
	private Map<String, Object> resultResponse=null;
	private SyncModel syncModel =null;
	private final String USERNAME="junit_tester";
	private User user=null;
	private List<Long> IdList=null;
	private Enrollment enrollment=null;
	private Admission admission=null;
	private Validation validation=null;
	private CurrentForm currentForm=null;
	
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		user = new User();
		user.setId(1L);
		
		IdList=new ArrayList<Long>();
		IdList.add(1L);
		
		currentForm=new CurrentForm();
		currentForm.setId(1L);
		
		enrollment = new Enrollment();
		enrollment.setId(1L);
		enrollment.setCurrentForm(currentForm);
		enrollment.setSyncDate(new Date());
		
		
		admission = new Admission();
		admission.setId(1L);
		admission.setSyncDate(new Date());
		
		validation = new Validation();
		validation.setId(1L);
		validation.setSyncDate(new Date());
		
	}
	
	@DisplayName("GetPendingRecordsForSync With Sync Id Test for Basic Operation")
	@Test
	public void testGetPendingRecordsForSyncWithSyncIdBasic() throws Exception {
		
		logger.debug("JUnit: testGetPendingRecordsForSyncWithSyncIdBasic");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		syncModel.setLastSyncId("1");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.PENDING_RECORDS,1L);
		
		//all mocks for the service methods
		when(recordDownloadRepository.getTotalBeneficiaryCountAfterId(Mockito.anyLong())).thenReturn(1L);
		
		//call service
		resultResponse=synchronizationService.getPendingRecordsForSync(requestHeader, syncModel);
		
		verify(validateSyncDetail,atLeastOnce()).validateForPendingRecords(syncModel);
		
		assertEquals(expectedResponse,resultResponse);
		
		logger.debug("JUnit: testGetPendingRecordsForSyncWithSyncIdBasic - Completed");
		
	}
	
	@DisplayName("GetPendingRecordsForSync Without Sync Id Test for Basic Operation")
	@Test
	public void testGetPendingRecordsForSyncWithoutSyncIdBasic() throws Exception {
		
		logger.debug("JUnit: testGetPendingRecordsForSyncWithoutSyncIdBasic");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		syncModel.setLastSyncId("");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.PENDING_RECORDS,1L);		
	
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(recordDownloadRepository.getTotalBeneficiaryCount()).thenReturn(1L);
		
		//call service
		resultResponse=synchronizationService.getPendingRecordsForSync(requestHeader, syncModel);
		
		verify(validateSyncDetail,atLeastOnce()).validateForPendingRecords(syncModel);
		
		assertEquals(expectedResponse,resultResponse);
		
		logger.debug("JUnit: testGetPendingRecordsForSyncWithoutSyncIdBasic - Completed");
		
	}
	
	@DisplayName("DownloadBeneficiarySyncData With Sync Id Test Operation")
	@Test
	public void testDownloadBeneficiaryWithSyncId() throws Exception {
		
		logger.debug("JUnit: testDownloadBeneficiaryWithSyncId");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		syncModel.setLastSyncId("1");
		syncModel.setDeviceId("test123");
		syncModel.setBatchSize("1");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.BENEFICIARY_LIST,getDownloadData());
		
		RecordDownload recordDownload= new RecordDownload();
		recordDownload.setId(1L);
		recordDownload.setRecordJson("{\"test\": 1}");
		List<RecordDownload> recordDownloadList= new ArrayList<RecordDownload>();
		recordDownloadList.add(recordDownload);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(recordDownloadRepository.getBeneficiaryRecordsAfterId(Mockito.anyLong(),Mockito.any(Pageable.class)))
		.thenReturn(recordDownloadList);
		
		//call service
		resultResponse=synchronizationService.downloadBeneficiarySyncData(requestHeader, syncModel);
		
		verify(validateSyncDetail,atLeastOnce()).validateForDownloadRecords(syncModel);
		
		assertEquals(expectedResponse.size(),resultResponse.size());
		assertEquals(expectedResponse.get(ConstantsUtil.RECORD_ID),resultResponse.get(ConstantsUtil.RECORD_ID));
		
		logger.debug("JUnit: testDownloadBeneficiaryWithSyncId - Completed");
		
	}
	
	@DisplayName("DownloadBeneficiarySyncData With No Sync Id Test Operation")
	@Test
	public void testDownloadBeneficiaryDataWithNoSyncId() throws Exception {
		
		logger.debug("JUnit: testDownloadBeneficiaryDataWithNoSyncId");
		
		syncModel=new SyncModel();
		syncModel.setUsername(USERNAME);
		syncModel.setLastSyncId("");
		syncModel.setDeviceId("test123");
		syncModel.setBatchSize("1");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.BENEFICIARY_LIST,getDownloadData());
		
		RecordDownload recordDownload= new RecordDownload();
		recordDownload.setId(1L);
		recordDownload.setRecordJson("{\"test\": 1}");
		List<RecordDownload> recordDownloadList= new ArrayList<RecordDownload>();
		recordDownloadList.add(recordDownload);
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(recordDownloadRepository.getBeneficiaryRecordsForFirstBatch(Mockito.any(Pageable.class)))
		.thenReturn(recordDownloadList);
		
		//call service
		resultResponse=synchronizationService.downloadBeneficiarySyncData(requestHeader, syncModel);
		
		verify(validateSyncDetail,atLeastOnce()).validateForDownloadRecords(syncModel);
		
		assertEquals(expectedResponse.size(),resultResponse.size());
		assertEquals(expectedResponse.get(ConstantsUtil.RECORD_ID),resultResponse.get(ConstantsUtil.RECORD_ID));
		
		
		logger.debug("JUnit: testDownloadBeneficiaryDataWithNoSyncId - Completed");
		
	}
	
	@DisplayName("Test Migrate Initial Record Json Basic Operation")
	@Test
	public void testMigrateInitialRecordJson() throws Exception {
		
		logger.debug("JUnit: testMigrateInitialRecordJson");
		
		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		
		Map<String, Object> enrollmentDataMap=new HashMap<String, Object>();
		Map<String, Object> admissionDataMap = new HashMap<String, Object>();
		Map<String, Object> validationDataMap = new HashMap<String, Object>();
		
		List<Enrollment> enrollmentList = new ArrayList<Enrollment>();
		enrollmentList.add(enrollment);
		
		when(enrollmentRepository.getEnrollmentList()).thenReturn(enrollmentList);
		enrollmentDataMap.put(ConstantsUtil.ENROLLMENT_ID, enrollment.getId());
		when(enrollmentService.addEnrollmentDetailsToMap(Mockito.anyLong(),Mockito.any(Enrollment.class))).thenReturn(enrollmentDataMap);
		
		when(admissionRepository.getAdmissionByEnrollment(Mockito.anyLong())).thenReturn(admission);
		admissionDataMap.put(ConstantsUtil.ADMISSION_ID, admission.getId());
		when(admissionService.addAdmissionDetailsToMap(Mockito.any(Admission.class))).thenReturn(admissionDataMap);
		
		when(validationRepository.getValidationByAdmission(Mockito.anyLong())).thenReturn(validation);
		validationDataMap.put(ConstantsUtil.VALIDATION_ID, validation.getId());
		when(validationService.addValidationDetailsToMap(Mockito.anyLong(),Mockito.any(Validation.class))).thenReturn(validationDataMap);
		
		beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);	
		beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);	
		
		List<RecordDownload> expectedRecordDownloadList=getExpectedDownloadJson(beneficiaryJsonMap);
		
		when(recordDownloadRepository.saveAll(Mockito.anyList())).thenReturn(expectedRecordDownloadList);
		
		//call service
		assertDoesNotThrow(() ->
		synchronizationService.migrateInitialRecordJson());
		
		logger.debug("JUnit: testMigrateInitialRecordJson - Completed");
		
	}
	
	@DisplayName("Test Migrate Initial Record Json Fail Operation")
	@Test
	public void testMigrateInitialRecordJsonFail() throws Exception {
		
		logger.debug("JUnit: testMigrateInitialRecordJsonFail");
		
		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		
		Map<String, Object> enrollmentDataMap=new HashMap<String, Object>();
		Map<String, Object> admissionDataMap = new HashMap<String, Object>();
		Map<String, Object> validationDataMap = new HashMap<String, Object>();
		
		List<Enrollment> enrollmentList = new ArrayList<Enrollment>();
		enrollmentList.add(enrollment);
		
		when(enrollmentRepository.getEnrollmentList()).thenReturn(enrollmentList);
		enrollmentDataMap.put(ConstantsUtil.ENROLLMENT_ID, enrollment.getId());
		when(enrollmentService.addEnrollmentDetailsToMap(Mockito.anyLong(),Mockito.any(Enrollment.class))).thenReturn(enrollmentDataMap);
		
		when(admissionRepository.getAdmissionByEnrollment(Mockito.anyLong())).thenReturn(admission);
		admissionDataMap.put(ConstantsUtil.ADMISSION_ID, admission.getId());
		when(admissionService.addAdmissionDetailsToMap(Mockito.any(Admission.class))).thenReturn(admissionDataMap);
		
		when(validationRepository.getValidationByAdmission(Mockito.anyLong())).thenReturn(validation);
		validationDataMap.put(ConstantsUtil.VALIDATION_ID, validation.getId());
		when(validationService.addValidationDetailsToMap(Mockito.anyLong(),Mockito.any(Validation.class))).thenReturn(validationDataMap);
		
		beneficiaryJsonMap.put(ConstantsUtil.ENROLLEMENT+"Data", enrollmentDataMap);
		beneficiaryJsonMap.put(ConstantsUtil.ADMISSION+"Data", admissionDataMap);	
		beneficiaryJsonMap.put(ConstantsUtil.VALIDATION+"Data", validationDataMap);	
		
		List<RecordDownload> expectedRecordDownloadList=getExpectedDownloadJson(beneficiaryJsonMap);
		
		when(recordDownloadRepository.saveAll(expectedRecordDownloadList)).thenReturn(expectedRecordDownloadList);
		
		//call service
		FailProcessException failProcessException= assertThrows(FailProcessException.class, () -> {
			synchronizationService.migrateInitialRecordJson();
        });
		
		assertEquals(FailProcessException.class,failProcessException.getClass());
		
		logger.debug("JUnit: testMigrateInitialRecordJsonFail - Completed");
		
	}
	
	@DisplayName("Test Save Latest Json Record For Download Basic Operation")
	@Test
	public void testSaveLatestJsonRecordForDownload() throws Exception {
		
		logger.debug("JUnit: testSaveLatestJsonRecordForDownload");
		
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setId(1L);
		
		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		beneficiaryJsonMap.put("TEST", "DATA");
		
		doNothing().when(recordDownloadRepository).updateBeneficiaryRecordIsActive(Mockito.any(YesNoEnum.class), Mockito.anyLong());
		
		when(recordDownloadRepository.save(Mockito.any(RecordDownload.class))).thenReturn(recordDownload);
		
		//call service
		assertDoesNotThrow(() ->
		synchronizationService.saveLatestJsonRecordForDownload(currentForm,new Date(),beneficiaryJsonMap));
		
		verify(recordDownloadRepository,atLeastOnce()).updateBeneficiaryRecordIsActive(Mockito.any(YesNoEnum.class), Mockito.anyLong());
		
		logger.debug("JUnit: testSaveLatestJsonRecordForDownload - Completed");
		
	}
	
	@DisplayName("Test Save Latest Json Record For Download Fail Operation")
	@Test
	public void testSaveLatestJsonRecordForDownloadFail() throws Exception {
		
		logger.debug("JUnit: testSaveLatestJsonRecordForDownloadFail");
		
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setId(1L);
		
		Map<String, Object> beneficiaryJsonMap = new HashMap<String, Object>();
		beneficiaryJsonMap.put("TEST", "DATA");
		
		doNothing().when(recordDownloadRepository).updateBeneficiaryRecordIsActive(Mockito.any(YesNoEnum.class), Mockito.anyLong());
		
		when(recordDownloadRepository.save(recordDownload)).thenReturn(recordDownload);
		
		//call service
		FailProcessException failProcessException= assertThrows(FailProcessException.class, () -> {
			synchronizationService.saveLatestJsonRecordForDownload(currentForm,new Date(),beneficiaryJsonMap);
        });
		
		verify(recordDownloadRepository,atLeastOnce()).updateBeneficiaryRecordIsActive(Mockito.any(YesNoEnum.class), Mockito.anyLong());
		assertEquals(FailProcessException.class,failProcessException.getClass());
		
		logger.debug("JUnit: testSaveLatestJsonRecordForDownloadFail - Completed");
		
	}
	
	private List<Map<String, Object>> getDownloadData() {
		List<Map<String, Object>> batchList=new ArrayList<Map<String,Object>>();
    	Map<String, Object> map=new HashMap<String, Object>();
    	map.put("test", "1");
    	map.put(ConstantsUtil.RECORD_ID,1L);
    	batchList.add(map);
    	return batchList;
    }
	
	private List<RecordDownload> getExpectedDownloadJson(Map<String, Object> beneficiaryJsonMap) throws JsonProcessingException{
		List<RecordDownload> recordDownloadList=new ArrayList<RecordDownload>();
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setReferenceId(enrollment.getCurrentForm().getId());
		recordDownload.setSyncDate(validation.getSyncDate());
		recordDownload.setIsActive(YesNoEnum.YES);
		recordDownload.setRecordJson(new ObjectMapper().writeValueAsString(beneficiaryJsonMap));
		recordDownload.setReferenceType(ConstantsUtil.BENEFICIARY_DATA);
		recordDownloadList.add(recordDownload);
		return recordDownloadList; 
	}
	
}
