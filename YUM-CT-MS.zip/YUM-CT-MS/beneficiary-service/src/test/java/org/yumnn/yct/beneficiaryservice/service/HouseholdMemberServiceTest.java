package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.ContactCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.beneficiaryservice.entity.AttachmentLog;
import org.yumnn.yct.beneficiaryservice.entity.HouseholdMemberLog;
import org.yumnn.yct.beneficiaryservice.entity.SearchForm;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentLogRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.beneficiaryservice.repository.DocumentsRepository;
import org.yumnn.yct.beneficiaryservice.repository.FlagRepository;
import org.yumnn.yct.beneficiaryservice.repository.GenderRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberLogRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberTypeRepository;
import org.yumnn.yct.beneficiaryservice.repository.SearchFormRepository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.catalog.Gender;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.entity.catalog.Relationship;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.repository.RelationshipRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:31:35 PM
 */

@ExtendWith(MockitoExtension.class)
public class HouseholdMemberServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private HouseholdMemberService householdMemberService = null;
	
	@Mock
	private HouseholdMemberRepository householdMemberRepository;
	
	@Mock 
	private GenderRepository genderRepository;
	
	@Mock 
	private DocumentsRepository documentsRepository;
	
	@Mock 
	private RelationshipRepository relationshipRepository;
	
	@Mock 
	private HouseholdMemberTypeRepository householdMemberTypeRepository;
	
	@Mock
	private AttachmentRepository attachmentRepository;
	
	@Mock
	private CurrentFormRepository currentFormRepository;
	
	@Mock
	CommonValidationUtil commonValidationUtil;
	
	@Mock
	private HouseholdMemberLogRepository householdMemberLogRepository;
	
	@Mock
	private AttachmentLogRepository attachmentLogRepository;
	
	@Mock
	SearchFormRepository searchFormRepository;
	
	@Mock
	MessageSource messageSource;
	@Mock
	private FlagService flagService;
	@Mock
	private FlagRepository flagRep;

	private Map<String, String> requestHeader=null;
	private List<HouseholdMemberModel> expectedResponse=null;
	private List<HouseholdMemberModel> resultResponse=null;
	private Map<String, MultipartFile> filesMapAddAdmissionUpdateHHM = null;
	private User user=null;
	private CurrentForm CurrentForm=null;
	private Gender gender=null;
	private Documents documents=null;
	private HouseholdMemberType householdMemberType=null;
	private Relationship relationship=null;
	private Attachment attachment =null;
	private Admission admission=null;
	
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		user = new User();
		user.setId(1L);
		
		CurrentForm=new CurrentForm();
		CurrentForm.setId(1L);
		
		gender=new Gender();
		gender.setId(1L);
		gender.setShortName("M");
		
		documents=new Documents();
		documents.setId(1L);
		documents.setShortName("PASS");
		
		relationship=new Relationship();
		relationship.setId(1L);
		relationship.setShortName("FAT");
		
		attachment = new Attachment();
		attachment.setId(1L);
		
		filesMapAddAdmissionUpdateHHM=createEnrollmentFileMap();
		
		admission=new Admission();
		admission.setId(1L);
		
		
	}
	
	@DisplayName("SaveHouseholdMemberDetails Test for Child Basic Operation")
	@Test
	public void testSaveHouseholdMemberDetailsChildBasic() throws Exception {
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsChildBasic");
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		expectedResponse=getHouseholdMemberList("HMC");

		when(genderRepository.findByShortName(Mockito.anyString())).thenReturn(gender);
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		when(householdMemberRepository.save(Mockito.any(HouseholdMember.class))).thenReturn(getHouseholdMemberEntity("HMC"));
		
		//call service
		resultResponse=householdMemberService.saveHouseholdMemberDetails(getHouseholdMemberList("HMC"), filesMapAddAdmissionUpdateHHM, user, null);
		
		assertNotNull(resultResponse);
		assertEquals(expectedResponse.get(0).getId(),resultResponse.get(0).getId());
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsChildBasic - Completed");
		
	}
	
	@DisplayName("SaveHouseholdMemberDetails Test for Child Fail Process Operation")
	@Test
	public void testSaveHouseholdMemberDetailsChildFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsChildFailProcess");
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		expectedResponse=getHouseholdMemberList("HMC");

		when(genderRepository.findByShortName(Mockito.anyString())).thenReturn(gender);
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		HouseholdMember saveHouseholdMember=new HouseholdMember();
		when(householdMemberRepository.save(saveHouseholdMember)).thenReturn(getHouseholdMemberEntity("HMC"));
		
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=householdMemberService.saveHouseholdMemberDetails(getHouseholdMemberList("HMC"), filesMapAddAdmissionUpdateHHM, user, null);
        });
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsChildFailProcess - Completed");
		
	}
	
	@DisplayName("SaveHouseholdMemberDetails Test for CareGiver Basic Operation")
	@Test
	public void testSaveHouseholdMemberDetailsCareGiverBasic() throws Exception {
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsCareGiverBasic");
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(2L);
		householdMemberType.setShortName("HMCG");

		expectedResponse=getHouseholdMemberList("HMCG");
		
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(relationshipRepository.findByShortName(Mockito.anyString())).thenReturn(relationship);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		when(householdMemberRepository.save(Mockito.any(HouseholdMember.class))).thenReturn(getHouseholdMemberEntity("HMCG"));
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		//call service
		resultResponse=householdMemberService.saveHouseholdMemberDetails(getHouseholdMemberList("HMCG"), filesMapAddAdmissionUpdateHHM, user, null);
		
		assertNotNull(resultResponse);
		assertEquals(expectedResponse.get(0).getId(),resultResponse.get(0).getId());
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsCareGiverBasic - Completed");
		
	}
	
	@DisplayName("SaveHouseholdMemberDetails Test for CareGiver Fail Process Operation")
	@Test
	public void testSaveHouseholdMemberDetailsCareGiverFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsCareGiverFailProcess");
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(2L);
		householdMemberType.setShortName("HMCG");

		expectedResponse=getHouseholdMemberList("HMCG");
		
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(relationshipRepository.findByShortName(Mockito.anyString())).thenReturn(relationship);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		HouseholdMember saveHouseholdMember=new HouseholdMember();
		when(householdMemberRepository.save(saveHouseholdMember)).thenReturn(getHouseholdMemberEntity("HMCG"));
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=householdMemberService.saveHouseholdMemberDetails(getHouseholdMemberList("HMCG"), filesMapAddAdmissionUpdateHHM, user, null);
        });
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testSaveHouseholdMemberDetailsCareGiverFailProcess - Completed");
		
	}
	
	@DisplayName("UpdateHouseholdMemberDetails Test for Basic Operation")
	@Test
	public void testUpdateHouseholdMemberDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testUpdateHouseholdMemberDetailsBasic");
		
		List<Attachment> attachmentList = new ArrayList<Attachment>();
		attachmentList.add(attachment);
		
		AttachmentLog attachmentLog=new AttachmentLog();
		attachmentLog.setId(1L);
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		when(genderRepository.findByShortName(Mockito.anyString())).thenReturn(gender);
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		HouseholdMember householdMember =getHouseholdMemberEntity("HMC");
		
		when(householdMemberRepository.findByCurrentFormAndHouseholdMemberType(householdMember.getCurrentForm(),householdMember.getHouseholdMemberType()))
		.thenReturn(householdMember);
		
		//when(attachmentRepository.getAttachmentByReferenceIdAndReferenceType(Mockito.anyLong(),Mockito.anyString())).thenReturn(attachmentList);
		
		when(householdMemberLogRepository.save(Mockito.any(HouseholdMemberLog.class))).thenReturn(getHouseholdMemberLogEntity("HMC"));
		//when(attachmentLogRepository.save(Mockito.any(AttachmentLog.class))).thenReturn(attachmentLog);
		
		householdMember =getHouseholdMemberEntity("HMC");
		householdMember.setCurrentForm(CurrentForm);
		when(householdMemberRepository.save(Mockito.any(HouseholdMember.class))).thenReturn(householdMember);
		
		SearchForm searchForm = new SearchForm();
		searchForm.setId(1L);
		when(searchFormRepository.getSearchFormByCurFormAndHouseHoldMemberType(Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(searchForm);
		
		List<HouseholdMemberModel> householdMemberModel=getHouseholdMemberList("HMC");
		householdMemberModel.get(0).setIsUpdated(YesNoEnum.YES.getValue());
		householdMemberModel.get(0).setCreatedDate("15-07-2021 09:09:30");
		//call service
		householdMemberService.updateHouseholdMemberDetails(householdMemberModel, filesMapAddAdmissionUpdateHHM, admission);
		
		logger.debug("JUnit: testUpdateHouseholdMemberDetailsBasic - Completed");
		
	}
	
	@DisplayName("UpdateHouseholdMemberDetailsFail Test for Basic Operation")
	@Test
	public void testUpdateHouseholdMemberDetailsFail() throws Exception {
		
		logger.debug("JUnit: testUpdateHouseholdMemberDetails Fail Process");
		
		List<Attachment> attachmentList = new ArrayList<Attachment>();
		attachmentList.add(attachment);
		
		AttachmentLog attachmentLog=new AttachmentLog();
		attachmentLog.setId(1L);
		
		householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		when(genderRepository.findByShortName(Mockito.anyString())).thenReturn(gender);
		when(documentsRepository.findByShortName(Mockito.anyString())).thenReturn(documents);
		when(householdMemberTypeRepository.findByShortName(Mockito.anyString())).thenReturn(householdMemberType);
		
		HouseholdMember householdMember =getHouseholdMemberEntity("HMC");
		
		when(householdMemberRepository.findByCurrentFormAndHouseholdMemberType(householdMember.getCurrentForm(),householdMember.getHouseholdMemberType()))
		.thenReturn(householdMember);
		
		//when(attachmentRepository.getAttachmentByReferenceIdAndReferenceType(Mockito.anyLong(),Mockito.anyString())).thenReturn(attachmentList);
		
		when(householdMemberLogRepository.save(Mockito.any(HouseholdMemberLog.class))).thenReturn(getHouseholdMemberLogEntity("HMC"));
		//when(attachmentLogRepository.save(Mockito.any(AttachmentLog.class))).thenReturn(attachmentLog);
		
		HouseholdMember saveHouseholdMember =new HouseholdMember();
		when(householdMemberRepository.save(saveHouseholdMember)).thenReturn(getHouseholdMemberEntity("HMC"));
		
		List<HouseholdMemberModel> householdMemberModel=getHouseholdMemberList("HMC");
		householdMemberModel.get(0).setIsUpdated(YesNoEnum.YES.getValue());
		householdMemberModel.get(0).setCreatedDate("15-07-2021 09:09:30");
		
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			householdMemberService.updateHouseholdMemberDetails(householdMemberModel, filesMapAddAdmissionUpdateHHM, admission);
        });
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testUpdateHouseholdMemberDetailsFail Process - Completed");
		
	}
	
	@DisplayName("Get Member Card Info Test for Basic Operation")
	@Test
	public void testGetMemberCardInfo() throws Exception {
		
		logger.debug("JUnit: testGetMemberCardInfo");
		
		MemberCardInfoModel memberCardInfoModel=null;
   		
   		List<MemberCardInfoModel> expectedMemberCardInfoModelList= new ArrayList<MemberCardInfoModel>();
   		expectedMemberCardInfoModelList.add(memberCardInfoModel);
		
		when(householdMemberRepository.getMemberCardInfo(Mockito.anyLong())).thenReturn(expectedMemberCardInfoModelList);
		
		Map<String, Object> resultResponse=householdMemberService.getMemberCardInfo(1L,"Test");

		assertNotNull(resultResponse);

		logger.debug("JUnit: testGetMemberCardInfo - Completed");
	}
	
	@DisplayName("Get Contact Card Info Test for Basic Operation")
	@Test
	public void testGetContactCardInfo() throws Exception {
		
		logger.debug("JUnit: testGetContactCardInfo");
		
		ContactCardInfoModel contactCardInfoModel=null;
   		
   		List<ContactCardInfoModel> expectedContactCardInfoModelList= new ArrayList<ContactCardInfoModel>();
   		expectedContactCardInfoModelList.add(contactCardInfoModel);
		
		when(householdMemberService.getBeneficiaryContacts(Mockito.anyLong(),Mockito.anyString())).thenReturn(expectedContactCardInfoModelList);
		
		Map<String, Object> resultResponse=householdMemberService.getContactCardInfo(1L,"Test");

		assertNotNull(resultResponse);

		logger.debug("JUnit: testGetContactCardInfo - Completed");
	}
	
	
	private Map<String, MultipartFile> createEnrollmentFileMap() throws IOException {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		filesMap.put(ConstantsUtil.CAREGIVER_FILE1, ValidationTestFixture.getFile(ConstantsUtil.CAREGIVER_FILE1));
    	filesMap.put(ConstantsUtil.NOMINEE_FILE1, ValidationTestFixture.getFile(ConstantsUtil.NOMINEE_FILE1));
		return filesMap;
	}
	
	private List<HouseholdMemberModel> getHouseholdMemberList(String type) {
		
		List<HouseholdMemberModel> HouseholdMemberList= new ArrayList<HouseholdMemberModel>();
		
		HouseholdMemberModel householdMemberModel=null;
		
		if(type.equals("HMCG")) {
			householdMemberModel=new HouseholdMemberModel();
			householdMemberModel.setId("2");
			householdMemberModel.setFullName("JUnit Caregiver");
			householdMemberModel.setPhoneNumber("701234567");
			householdMemberModel.setRelationshipShortName("FAT");
			householdMemberModel.setIsAssignedAsPaymentReceiver("Yes");
			householdMemberModel.setCatDocShortName("PASS");
			householdMemberModel.setDocumentReferenceNumber("123");
			householdMemberModel.setHouseholdMemberTypeShortName("HMCG");
			householdMemberModel.setCreatedDate("15-07-2021 09:09:30");
			HouseholdMemberList.add(householdMemberModel);
		}
		else {
			householdMemberModel=new HouseholdMemberModel();
			householdMemberModel.setId("1");
			householdMemberModel.setFullName("JUnit Child");
			householdMemberModel.setGenderShortName("M");
			householdMemberModel.setDateOfBirth("01-01-1992");
			householdMemberModel.setCatDocShortName("PASS");
			householdMemberModel.setDocumentReferenceNumber("123");
			householdMemberModel.setHouseholdMemberTypeShortName("HMC");
			householdMemberModel.setCreatedDate("15-07-2021 09:09:30");
			HouseholdMemberList.add(householdMemberModel);
		}
		
		return HouseholdMemberList;
	}
	
	private HouseholdMember getHouseholdMemberEntity(String type) throws ParseException {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
		
		HouseholdMember householdMember=null;
		
		if(type.equals("HMCG")) {
			householdMember=new HouseholdMember();
			householdMember.setId(2L);
			householdMember.setFirstName("JUnit");
			householdMember.setLastName("Caregiver");
			householdMember.setPhoneNumber("701234567");
			householdMember.setRelationship(relationship);
			householdMember.setIsAssignedAsPaymentReceiver(YesNoEnum.YES);
			householdMember.setDocument(documents);
			householdMember.setDocumentReferenceNumber("123");
			householdMember.setHouseholdMemberType(householdMemberType);
		}
		else {
			householdMember=new HouseholdMember();
			householdMember.setId(1L);
			householdMember.setFirstName("JUnit");
			householdMember.setLastName("Child");
			householdMember.setGender(gender);
			householdMember.setDateOfBirth(dateFormat.parse("01-01-1992"));
			householdMember.setDocument(documents);
			householdMember.setDocumentReferenceNumber("123");
			householdMember.setHouseholdMemberType(householdMemberType);
		}
		
		return householdMember;
	}
	
	private HouseholdMemberLog getHouseholdMemberLogEntity(String type) throws ParseException {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
		
		HouseholdMemberLog householdMemberLog=null;
		
		if(type.equals("HMCG")) {
			householdMemberLog=new HouseholdMemberLog();
			householdMemberLog.setId(2L);
			householdMemberLog.setFirstName("JUnit");
			householdMemberLog.setLastName("Caregiver");
			householdMemberLog.setPhoneNumber("701234567");
			householdMemberLog.setRelationship(relationship);
			householdMemberLog.setIsAssignedAsPaymentReceiver(YesNoEnum.YES);
			householdMemberLog.setDocument(documents);
			householdMemberLog.setDocumentReferenceNumber("123");
			householdMemberLog.setHouseholdMemberType(householdMemberType);
		}
		else {
			householdMemberLog=new HouseholdMemberLog();
			householdMemberLog.setId(1L);
			householdMemberLog.setFirstName("JUnit");
			householdMemberLog.setLastName("Child");
			householdMemberLog.setGender(gender);
			householdMemberLog.setDateOfBirth(dateFormat.parse("01-01-1992"));
			householdMemberLog.setDocument(documents);
			householdMemberLog.setDocumentReferenceNumber("123");
			householdMemberLog.setHouseholdMemberType(householdMemberType);
		}
		
		return householdMemberLog;
	}

}
