package org.yumnn.yct.beneficiaryservice.fixture;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.entity.HouseholdMemberLog;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.catalog.Gender;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.entity.catalog.Relationship;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SourceTypeEnum;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 26, 2021 2:44:12 PM
 */
public class ValidationTestFixture {
	
	private static Logger logger = LogManager.getLogger();
	
	public static final String API_ROUTE_GATEWAY = "api-route-gateway";
	
	private static final String SAMPLE_IMAGE ="junit_test_image.jpg";
	
	public static String returnJson(Object object) {
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
		  json = mapper.writeValueAsString(object);
		  //logger.debug("ResultingJSONstring = " + json);
		} catch (JsonProcessingException e) {
			logger.error("Error occurred while executing mapper.writeValueAsString()", e);
		}
		return json;
	}
	
	public static MockMultipartFile getFile(String param) throws IOException {
		
		Path resourceDirectory = Paths.get("src","test","resources");
		File file = new File(resourceDirectory+"/"+SAMPLE_IMAGE);
		
		FileInputStream fis = new FileInputStream(file);
		MockMultipartFile mmpf=new MockMultipartFile(param, file.getName(),MediaType.MULTIPART_FORM_DATA_VALUE , fis);
		fis.close();
		
		return mmpf;
	}
	
	public static EnrollmentModel getRequestEnrollmentModel() {
		
		EnrollmentModel enrollmentModel = new EnrollmentModel();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.CREATION_TIMESTAMP_FORMAT);
		
		enrollmentModel.setIsRefferdFromOtherTFC("Yes");
		enrollmentModel.setTfcShortName("TFC001");
		enrollmentModel.setProjectShortName("NVS");
		enrollmentModel.setOtpReferenceNumber("999-999-999");
		enrollmentModel.setOtpNutritionOfficerName("JUnit Tester");
		enrollmentModel.setOtpNutritionOfficerRefrenceNumber("999-999-999");
		enrollmentModel.setOtpNutritionOfficerPhoneNumber("701234567");
		enrollmentModel.setOtpGeoAreaShortName("18-13-");
		enrollmentModel.setBookletShortName("1111-2222-3333-23");
		enrollmentModel.setPlaceOfAdmissionShortName("TFC001");
		enrollmentModel.setComments("JUnit Testing");
		enrollmentModel.setHouseholdMemberList(returnJson(getHouseholdMemberList()));
		enrollmentModel.setIsRequireInvestigation("No");
		enrollmentModel.setCreatedBy("1");
		enrollmentModel.setCreatedDate(dateFormat.format(new Date()));
		enrollmentModel.setUniqueId("1");
    	
    	return enrollmentModel;
    }
	
	public static List<HouseholdMemberModel> getHouseholdMemberList() {
		
		List<HouseholdMemberModel> HouseholdMemberList= new ArrayList<HouseholdMemberModel>();
		
		HouseholdMemberModel householdMemberModel=new HouseholdMemberModel();
		
		householdMemberModel.setFullName("JUnit Child");
		householdMemberModel.setGenderShortName("M");
		householdMemberModel.setDateOfBirth("01-01-1992");
		householdMemberModel.setCatDocShortName("PASS");
		householdMemberModel.setDocumentReferenceNumber("123");
		householdMemberModel.setHouseholdMemberTypeShortName("HMC");
		HouseholdMemberList.add(householdMemberModel);
		
		householdMemberModel=new HouseholdMemberModel();
		householdMemberModel.setFullName("JUnit Caregiver");
		householdMemberModel.setPhoneNumber("701234567");
		householdMemberModel.setRelationshipShortName("FAT");
		householdMemberModel.setIsAssignedAsPaymentReceiver("Yes");
		householdMemberModel.setCatDocShortName("PASS");
		householdMemberModel.setDocumentReferenceNumber("123");
		householdMemberModel.setHouseholdMemberTypeShortName("HMCG");
		HouseholdMemberList.add(householdMemberModel);
		
		householdMemberModel=new HouseholdMemberModel();
		householdMemberModel.setFullName("JUnit Nominee");
		householdMemberModel.setPhoneNumber("701234567");
		householdMemberModel.setCatDocShortName("PASS");
		householdMemberModel.setDocumentReferenceNumber("123");
		householdMemberModel.setHouseholdMemberTypeShortName("HMN");
		HouseholdMemberList.add(householdMemberModel);
		return HouseholdMemberList;
	}
	
	public static BeneficiaryAdmissionModel getRequestAdmissionModel(Boolean isUpdateBeneficiary) {
    	
		BeneficiaryAdmissionModel admissionModel = new BeneficiaryAdmissionModel();
		
		admissionModel.setCreatedBy("1");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.CREATION_TIMESTAMP_FORMAT);
		admissionModel.setCreatedDate(dateFormat.format(new Date()));
		
		admissionModel.setEnrollmentCode("1");
    	
		SimpleDateFormat dateFormatExpiryDate = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
		admissionModel.setExpiryDate(dateFormatExpiryDate.format(new Date()));
    	
		admissionModel.setIsAdmitted(YesNoEnum.NO.getValue());
		
		admissionModel.setOtpValidationCode("411030165");
		admissionModel.setTfcValidationCode("411031511");
		admissionModel.setNonAdmissionReasonShortName("CHCATTFC");
		admissionModel.setIsValidationCodeUsed("No");
		admissionModel.setUniqueId("1");
    	
    	if(isUpdateBeneficiary) {
    		admissionModel.setHouseholdMemberList(returnJson(getHouseholdMemberList()));
    	}
    	
    	return admissionModel;
    }
	
	public static ValidationModel getRequestValidationModel() {
    	
		ValidationModel validationModel = new ValidationModel();
		
		validationModel.setAdmissionId("1");
		validationModel.setServiceTypeShortName("DISCG");
		validationModel.setDateFrom("28-07-2021");
		validationModel.setDateTo("30-07-2021");
		validationModel.setNumberOfDays("1");
		validationModel.setNumberOfPeriods("1");
		validationModel.setDoctorName("Dr Test");
		validationModel.setValidationCodeDetails(returnJson(getValidationCodeDetails()));
		validationModel.setCreatedBy("1");
		validationModel.setDocumentReferenceNo("12343");
		validationModel.setDocumentShortName("PASS");
		validationModel.setCreatedDate("15-07-2021 09:09:30");
		validationModel.setUniqueId("1");
		
		return validationModel;
    }
	
	public static List<ValidationCodeModel> getValidationCodeDetails(){
		 
		List<ValidationCodeModel> validationCodeDetailsList = new ArrayList<ValidationCodeModel>();
		
		ValidationCodeModel validationCodeDetails = new ValidationCodeModel();
		validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION);
		validationCodeDetails.setValidationCodeType("OTP");
		validationCodeDetails.setValidationCode("611001061");
		validationCodeDetails.setExpirydate("02-08-2021");
		validationCodeDetails.setIsActive(YesNoEnum.YES.getValue());
		validationCodeDetails.setIsUsed(YesNoEnum.NO.getValue());
		validationCodeDetails.setIsValidationCodeUsed(YesNoEnum.NO.getValue());
		validationCodeDetailsList.add(validationCodeDetails);
		
		validationCodeDetails = new ValidationCodeModel();
		validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION);
		validationCodeDetails.setValidationCodeType("PERDIEM");
		validationCodeDetails.setValidationCode("211003844");
		validationCodeDetails.setExpirydate("02-08-2021");
		validationCodeDetails.setIsActive(YesNoEnum.YES.getValue());
		validationCodeDetails.setIsUsed(YesNoEnum.NO.getValue());
		validationCodeDetails.setIsValidationCodeUsed(YesNoEnum.NO.getValue());
		validationCodeDetailsList.add(validationCodeDetails);
		
		return validationCodeDetailsList;
	}
	
	public static Map<String, MultipartFile> createAdmissionFileMap() throws IOException {
		
		Map<String, MultipartFile> filesMap = new HashMap<>();
		filesMap.put(ConstantsUtil.ADMISSION_FILE1, getFile(ConstantsUtil.ADMISSION_FILE1));
		filesMap.put(ConstantsUtil.REFERRAL_FILE1, getFile(ConstantsUtil.REFERRAL_FILE1));
			
		return filesMap;
	}
	
	public static Map<String, MultipartFile> createEnrollmentFileMap() throws IOException {
		Map<String, MultipartFile> filesMap = new HashMap<>();
		filesMap.put(ConstantsUtil.CAREGIVER_FILE1, ValidationTestFixture.getFile(ConstantsUtil.CAREGIVER_FILE1));
    	filesMap.put(ConstantsUtil.NOMINEE_FILE1, ValidationTestFixture.getFile(ConstantsUtil.NOMINEE_FILE1));
		return filesMap;
	}
	
	public static Map<String, MultipartFile> createValidationFileMap() throws IOException {
		
		Map<String, MultipartFile> filesMap = new HashMap<>();
		filesMap.put(ConstantsUtil.ID_DOCUMENT_FILE1, ValidationTestFixture.getFile(ConstantsUtil.ID_DOCUMENT_FILE1));
		filesMap.put(ConstantsUtil.TREATMENT_DOC_FILE1, ValidationTestFixture.getFile(ConstantsUtil.TREATMENT_DOC_FILE1));
		filesMap.put(ConstantsUtil.UPLOAD_VCA_FILE1, ValidationTestFixture.getFile(ConstantsUtil.UPLOAD_VCA_FILE1));
			
		return filesMap;
	}
	
	public static List<HouseholdMember> getHouseholdMemberEntityList() throws ParseException {
		
		List<HouseholdMember> HouseholdMemberList= new ArrayList<HouseholdMember>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
		
		Gender gender=new Gender();
		gender.setId(1L);
		gender.setShortName("M");
		
		Documents documents=new Documents();
		documents.setId(1L);
		documents.setShortName("PASS");
		
		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		Relationship relationship=new Relationship();
		relationship.setId(1L);
		relationship.setShortName("FAT");
		
		
		HouseholdMember householdMember=new HouseholdMember();
		
		householdMember.setId(1L);
		householdMember.setFirstName("JUnit");
		householdMember.setLastName("Child");
		householdMember.setGender(gender);
		householdMember.setDateOfBirth(dateFormat.parse("01-01-1992"));
		householdMember.setDocument(documents);
		householdMember.setDocumentReferenceNumber("123");
		householdMember.setHouseholdMemberType(householdMemberType);
		HouseholdMemberList.add(householdMember);
		
		householdMember=new HouseholdMember();
		householdMember.setId(2L);
		householdMember.setFirstName("JUnit");
		householdMember.setLastName("Caregiver");
		householdMember.setPhoneNumber("701234567");
		householdMember.setRelationship(relationship);
		householdMember.setIsAssignedAsPaymentReceiver(YesNoEnum.YES);
		householdMember.setDocument(documents);
		householdMember.setDocumentReferenceNumber("123");
		householdMemberType.setId(2L);
		householdMemberType.setShortName("HMG");
		householdMember.setHouseholdMemberType(householdMemberType);
		HouseholdMemberList.add(householdMember);
		
		householdMember=new HouseholdMember();
		householdMember.setId(3L);
		householdMember.setFirstName("JUnit");
		householdMember.setLastName("Nominee");
		householdMember.setPhoneNumber("701234567");
		householdMember.setDocument(documents);
		householdMember.setDocumentReferenceNumber("123");
		householdMemberType.setId(3L);
		householdMemberType.setShortName("HMN");
		householdMember.setHouseholdMemberType(householdMemberType);
		HouseholdMemberList.add(householdMember);
		
		return HouseholdMemberList;
	}
	
	
	public static List<HouseholdMemberLog> getHouseholdMemberLogEntityList() throws ParseException {
		
		List<HouseholdMemberLog> HouseholdMemberList= new ArrayList<HouseholdMemberLog>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
		
		Gender gender=new Gender();
		gender.setId(1L);
		gender.setShortName("M");
		
		Documents documents=new Documents();
		documents.setId(1L);
		documents.setShortName("PASS");
		
		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		householdMemberType.setShortName("HMC");
		
		Relationship relationship=new Relationship();
		relationship.setId(1L);
		relationship.setShortName("FAT");
		
		
		HouseholdMemberLog householdMemberLog=new HouseholdMemberLog();
		
		householdMemberLog.setId(1L);
		householdMemberLog.setFirstName("JUnit");
		householdMemberLog.setLastName("Child");
		householdMemberLog.setGender(gender);
		householdMemberLog.setDateOfBirth(dateFormat.parse("01-01-1992"));
		householdMemberLog.setDocument(documents);
		householdMemberLog.setDocumentReferenceNumber("123");
		householdMemberLog.setHouseholdMemberType(householdMemberType);
		householdMemberLog.setSourceId(1L);
		householdMemberLog.setSourceType(SourceTypeEnum.ADMISSION);
		HouseholdMemberList.add(householdMemberLog);
		
		householdMemberLog=new HouseholdMemberLog();
		householdMemberLog.setId(2L);
		householdMemberLog.setFirstName("JUnit");
		householdMemberLog.setLastName("Caregiver");
		householdMemberLog.setPhoneNumber("701234567");
		householdMemberLog.setRelationship(relationship);
		householdMemberLog.setIsAssignedAsPaymentReceiver(YesNoEnum.YES);
		householdMemberLog.setDocument(documents);
		householdMemberLog.setDocumentReferenceNumber("123");
		householdMemberType.setId(2L);
		householdMemberType.setShortName("HMG");
		householdMemberLog.setHouseholdMemberType(householdMemberType);
		householdMemberLog.setSourceId(1L);
		householdMemberLog.setSourceType(SourceTypeEnum.ADMISSION);
		HouseholdMemberList.add(householdMemberLog);
		
		householdMemberLog=new HouseholdMemberLog();
		householdMemberLog.setId(3L);
		householdMemberLog.setFirstName("JUnit");
		householdMemberLog.setLastName("Nominee");
		householdMemberLog.setPhoneNumber("701234567");
		householdMemberLog.setDocument(documents);
		householdMemberLog.setDocumentReferenceNumber("123");
		householdMemberType.setId(3L);
		householdMemberType.setShortName("HMN");
		householdMemberLog.setHouseholdMemberType(householdMemberType);
		householdMemberLog.setSourceId(1L);
		householdMemberLog.setSourceType(SourceTypeEnum.ADMISSION);
		HouseholdMemberList.add(householdMemberLog);
		
		return HouseholdMemberList;
	}

}
