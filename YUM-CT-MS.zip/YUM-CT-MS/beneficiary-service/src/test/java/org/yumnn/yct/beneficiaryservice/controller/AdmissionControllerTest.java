package org.yumnn.yct.beneficiaryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.service.BeneficiaryAdmissionService;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.junit.jupiter.api.Test;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 6:44:28 PM
 */

@WebMvcTest(value = AdmissionController.class)
public class AdmissionControllerTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	BeneficiaryAdmissionService beneficiaryAdmissionService;
	
	private Map<String, String> requestHeader=null;
	private HttpHeaders header=null;
	private Map<String, Object> mockResponse=null;
	
	private static final String BASE_URI = "/api/v1";
    private static final String SUCCESS_STATUS = "Success";
    private static final String SUCCESS_STATUS_CODE = "200";
	
    @BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		header=new HttpHeaders();
		header.setAll(requestHeader);
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
		mockResponse.put(ConstantsUtil.ADMISSION_ID, "1");
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAddBeneficiaryAdmissionWithData() throws Exception {
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionWithData");

		when(beneficiaryAdmissionService.addBeneficiaryAdmission(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(BeneficiaryAdmissionModel.class))).thenReturn(mockResponse);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/admissionControl/addBeneficiaryAdmission")
				.file(ValidationTestFixture.getFile("admissionFile1"))
				.file(ValidationTestFixture.getFile("referralFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestAdmissionModel(requestBuilder, Boolean.TRUE);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isOk())
				   .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				   .andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);
		
		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertNotNull(successResponse.getData());
		assertEquals("1", successResponse.getData().get(ConstantsUtil.ADMISSION_ID));
	
    	logger.debug("JUnit: testAddBeneficiaryAdmissionWithData - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAddBeneficiaryAdmissionWithInvalidHeaderData() throws Exception {
		
		logger.debug("JUnit: testAddBeneficiaryAdmissionWithInvalidHeaderData");

		when(beneficiaryAdmissionService.addBeneficiaryAdmission(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(BeneficiaryAdmissionModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/admissionControl/addBeneficiaryAdmission")
				.file(ValidationTestFixture.getFile("admissionFile1"))
				.file(ValidationTestFixture.getFile("referralFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestAdmissionModel(requestBuilder, Boolean.FALSE);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isUnauthorized())
				   .andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
	
    	logger.debug("Junit: testAddBeneficiaryAdmissionWithInvalidHeaderData - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAddAdmissionUpdateHouseholdMember() throws Exception {
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMember");
		
		when(beneficiaryAdmissionService.addAdmissionUpdateHouseholdMember(Mockito.any(Map.class),Mockito.any(List.class),Mockito.any(BeneficiaryAdmissionModel.class))).thenReturn(mockResponse);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/admissionControl/addAdmissionUpdateHouseholdMember")
				.file(ValidationTestFixture.getFile("admissionFile1"))
				.file(ValidationTestFixture.getFile("referralFile1"))
				.file(ValidationTestFixture.getFile("caregiverFile1"))
				.file(ValidationTestFixture.getFile("nomineeFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestAdmissionModel(requestBuilder, Boolean.FALSE);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isOk())
				   .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				   .andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);
		
		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertNotNull(successResponse.getData());
		assertEquals("1", successResponse.getData().get(ConstantsUtil.ADMISSION_ID));
	
    	logger.debug("JUnit: testAddAdmissionUpdateHouseholdMember - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAddAdmissionUpdateHouseholdMemberWithInvalidHeader() throws Exception {
		
		logger.debug("JUnit: testAddAdmissionUpdateHouseholdMemberWithInvalidHeader");

		when(beneficiaryAdmissionService.addAdmissionUpdateHouseholdMember(Mockito.any(Map.class),Mockito.any(List.class), Mockito.any(BeneficiaryAdmissionModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/admissionControl/addAdmissionUpdateHouseholdMember")
				.file(ValidationTestFixture.getFile("admissionFile1"))
				.file(ValidationTestFixture.getFile("referralFile1"))
				.file(ValidationTestFixture.getFile("caregiverFile1"))
				.file(ValidationTestFixture.getFile("nomineeFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestAdmissionModel(requestBuilder, Boolean.FALSE);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isUnauthorized())
				   .andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
	
    	logger.debug("Junit: testAddAdmissionUpdateHouseholdMemberWithInvalidHeader Completed");
		
	}
	
	private RequestBuilder getRequestAdmissionModel(MockMultipartHttpServletRequestBuilder requestBuilder, Boolean isUpdateBeneficiary) {
    	
    	requestBuilder.param("createdBy", requestHeader.get(ConstantsUtil.USER_ID_HEADER));
    	
    	requestBuilder.param("enrollmentCode", "1");
    	
    	SimpleDateFormat dateFormatExpiryDate = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
    	requestBuilder.param("expiryDate", dateFormatExpiryDate.format(new Date()));
    	
    	requestBuilder.param("isAdmitted", YesNoEnum.NO.getValue());
    	requestBuilder.param("otpValidationCode", "411030165");
    	requestBuilder.param("tfcValidationCode", "411031511");
    	requestBuilder.param("nonAdmissionReasonShortName","CHCATTFC");
    	
    	if(isUpdateBeneficiary) {
    		requestBuilder.param("householdMemberList", ValidationTestFixture.returnJson(ValidationTestFixture.getHouseholdMemberList()));
    	}
    	
    	return requestBuilder;
    }

}
