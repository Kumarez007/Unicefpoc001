package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.yumnn.yct.beneficiaryservice.repository.CurrentFormRepository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.CurrentFormModel;
import org.yumnn.yct.common.repository.ProjectRepository;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 22, 2021 5:29:47 PM
 */

@ExtendWith(MockitoExtension.class)
public class CurrentFormServiceTest {

	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private CurrentFormService currentFormService = null;
	
	@Mock
	private CurrentFormRepository currentFormRepository=null;
	
	@Mock
	private ProjectRepository projectRepository=null;
	
	private CurrentFormModel expectedResponse=null;
	private CurrentFormModel resultResponse=null;
	private User user=null;
	private CurrentForm currentForm=null;
	private Project project=null;
	
	@BeforeEach
	public void setup() throws IOException {
		user = new User();
		user.setId(1L);
		
		currentForm=new CurrentForm();
		currentForm.setId(1L);
		
		project=new Project();
		project.setId(1L);
		project.setShortName(ProjectNameEnum.NVS);
		
	}
	
	@DisplayName("testSaveCurrentFormBasic Test for Basic Operation")
	@Test
	public void testSaveCurrentFormBasic() throws Exception {
		
		logger.debug("JUnit: testSaveCurrentFormBasic");
		
		expectedResponse=new CurrentFormModel();
		expectedResponse.setId("1");
		expectedResponse.setProjectShortName("NVS");
		expectedResponse.setBookletId(1L);
		expectedResponse.setCreatedDate("15-07-2021 09:09:30");
		
		when(projectRepository.findByShortName(Mockito.any(ProjectNameEnum.class))).thenReturn(project);
		
		when(currentFormRepository.save(Mockito.any(CurrentForm.class))).thenReturn(currentForm);
		
		//call service
		resultResponse=currentFormService.saveCurrentForm(expectedResponse, user);
		
		assertNotNull(resultResponse);
		assertEquals(expectedResponse,resultResponse);
		
		logger.debug("JUnit: testSaveCurrentFormBasic - Completed");
		
	}
	
	@DisplayName("testSaveCurrentFormBasic Test for Fail Process Operation")
	@Test
	public void testSaveCurrentFormFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveCurrentFormFailProcess");
		
		expectedResponse=new CurrentFormModel();
		expectedResponse.setId("1");
		expectedResponse.setProjectShortName("NVS");
		expectedResponse.setBookletId(1L);
		expectedResponse.setCreatedDate("15-07-2021 09:09:30");
		
		when(projectRepository.findByShortName(Mockito.any(ProjectNameEnum.class))).thenReturn(project);
		
		CurrentForm saveCurrentForm= new CurrentForm();
		when(currentFormRepository.save(saveCurrentForm)).thenReturn(currentForm);
		
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=currentFormService.saveCurrentForm(expectedResponse, user);
        });
		
		assertEquals(FailProcessException.class, fPE.getClass());

		
		logger.debug("JUnit: testSaveCurrentFormFailProcess - Completed");
		
	}
	
}
