package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.common.entity.catalog.Gender;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 12:48:13 AM
 */

@DataJpaTest
public class GenderRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(GenderRepositoryTest.class);
	
	@Autowired
	private GenderRepository repo = null;

	@Test
	public void testFindByShortName() {
		logger.info("Inside testFindByShortName");
		Gender result= repo.findByShortName("M");
		assertEquals("M",result.getShortName());
	}
	
	@Test
	public void testFindByIncorrectShortName() {
		logger.info("Inside testFindByIncorrectShortName");
		Gender result= repo.findByShortName("X");
		assertNull(result);
	}
	
	@Test
	public void testFindByShortNameAsNull() {
		logger.info("Inside testFindByShortNameAsNull");
		Gender result= repo.findByShortName(null);
		assertNull(result);
	}

}
