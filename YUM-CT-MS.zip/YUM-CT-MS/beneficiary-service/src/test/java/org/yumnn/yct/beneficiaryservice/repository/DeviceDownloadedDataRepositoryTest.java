package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.DeviceDownloadedData;
import org.yumnn.yct.beneficiaryservice.entity.RecordDownload;
import org.yumnn.yct.common.entity.administration.DeviceDetail;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Oct 14, 2021 7:16:46 PM
 */

@DataJpaTest
public class DeviceDownloadedDataRepositoryTest {
	
	private static Logger logger = LoggerFactory.getLogger(DeviceDownloadedDataRepositoryTest.class);
	
	@Autowired
	private DeviceDownloadedDataRepository repo = null;
	
	private DeviceDownloadedData deviceDownloadedData=null;
	
	@Test
	public void testFindByDeviceDetail() {
		logger.info("Inside testFindByDeviceDetail");
		DeviceDetail deviceDetail=new DeviceDetail();
		deviceDetail.setId(1L);
		DeviceDownloadedData result= repo.findByDeviceDetail(deviceDetail);
		assertNotNull(result);
	}
	
	@Test
	public void testSaveDeviceDownloadedData() throws Exception {
		logger.info("Inside testSaveDeviceDownloadedData");
		
		setUpEntity();
	
		DeviceDownloadedData result= repo.save(deviceDownloadedData);
		
		assertNotNull(result);
	}
	
	private void setUpEntity() throws Exception {

		DeviceDetail deviceDetail=new DeviceDetail();
		deviceDetail.setId(1L);
		
		RecordDownload recordDownload=new RecordDownload();
		recordDownload.setId(1L);
		
		deviceDownloadedData = new DeviceDownloadedData();
		deviceDownloadedData.setId(2L);
		deviceDownloadedData.setDeviceDetail(deviceDetail);
		deviceDownloadedData.setRecordDownload(recordDownload);
	}
	
	
}
