package org.yumnn.yct.beneficiaryservice.util.validate;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 27, 2021 12:56:03 AM
 */

@SpringBootTest(classes = {ValidateSyncDetail.class, CommonValidationUtil.class, MessageSource.class})
public class ValidateSyncDetailTest {
	
private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private ValidateSyncDetail validateSyncDetail =null;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("JUnit: ValidateForPendingRecords Basic Test")
	public void testValidateForPendingRecordsBasic() throws Exception {
		
		logger.debug("JUnit: testValidateForPendingRecordsBasic Test Started");
		
		SyncModel syncModel=new SyncModel();
		syncModel.setUsername("xyz");
		
		assertDoesNotThrow(() ->
		validateSyncDetail.validateForPendingRecords(syncModel));
	
		logger.debug("JUnit: testValidateForPendingRecordsBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateForPendingRecords Invalid Param Test")
	public void testValidateForPendingRecordsInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateForPendingRecordsInvalidParam Test Started");
		
		SyncModel syncModel=new SyncModel();
		
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateSyncDetail.validateForPendingRecords(syncModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateForPendingRecordsInvalidParam Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateForDownloadRecords Basic Test")
	public void testValidateForDownloadRecordsBasic() throws Exception {
		
		logger.debug("JUnit: testValidateForDownloadRecordsBasic Test Started");
		
		SyncModel syncModel=new SyncModel();
		syncModel.setUsername("xyz");
		syncModel.setBatchSize("20");
		syncModel.setDeviceId("1");
		
		assertDoesNotThrow(() -> 
		validateSyncDetail.validateForDownloadRecords(syncModel));
	
		logger.debug("JUnit: testValidateForDownloadRecordsBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateForDownloadRecords Invalid Param Test")
	public void testValidateForDownloadRecordsInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateForDownloadRecordsInvalidParam Test Started");
		
		SyncModel syncModel=new SyncModel();
		
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateSyncDetail.validateForDownloadRecords(syncModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateForDownloadRecordsInvalidParam Test Completed");
		
	}

}
