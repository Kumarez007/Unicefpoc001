package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.EnableValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.ServiceType;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.entity.VcaMonitoringLog;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.model.VcaMonitoringDataModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.AttachmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.BookletByValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.DocumentsRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnableValidationCodeRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.ServiceTypeRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.repository.VcaMonitoringLogRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateValidationDetail;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:31:00 PM
 */

@ExtendWith(MockitoExtension.class)
public class ValidationServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private ValidationService validationService = null;
	
	@Mock
	private AdmissionRepository admissionRepository = null;
	
	@Mock
	private ServiceTypeRepository serviceTypeRepository = null;
	
	@Mock
	private AttachmentRepository attachmentRepository = null;
	
	@Mock
	private ValidationRepository validationRepository = null;
	
	@Mock
	private BookletByValidationCodeRepository bookletByValidationCodeRepository = null;
	
	@Mock
	private EnableValidationCodeRepository enableValidationCodeRepository = null;
	
	@Mock
	DocumentsRepository documentsRepository = null;
	
	@Mock
	private BookletByValidationCodeService bookletByValidationCodeService = null;
	
	@Mock
	private ValidateValidationDetail validateValidationDetail = null;
	
	@Mock
	private ValidateUserDetail validateUserDetail = null;
	
	@Mock
	private MessageSource messageSource = null;
	
	@Mock
	private BeneficiaryApiCallService beneficiaryApiCallService=null;
	
	@Mock
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService=null;
	
	@Mock
	private VcaMonitoringLogRepository vcaMonitoringLogRepository=null;
	
	@Mock
	private BeneficiaryAdmissionService admissionService=null;
	
	@Mock
	private EnrollmentService enrollmentService=null;
	
	@Mock
	private SynchronizationService synchronizationService=null;
	
	@Mock
	private EnrollmentRepository enrollmentRepository = null;
	
	private Map<String, String> requestHeader=null;
	private Map<String, Object> expectedResponse=null;
	private Map<String, Object> resultResponse=null;
	private Map<String, MultipartFile> filesMapValidation = null;
	private ValidationModel validationModel = null;
	private User user=null;
	private Admission admission=null;
	private Validation validation=null;
	private ServiceType serviceType =null;
	private Documents documents=null;
	private BookletByValidationCode bookletByValidationCode=null;
	private EnableValidationCode enableValidationCode =null;
	private Attachment attachment =null;
	private Enrollment enrollment=null;
	
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		user = new User();
		user.setId(1L);
		
		Project project = new Project();
		project.setId(1L);
		project.setShortName(ProjectNameEnum.NVS);
		
		CurrentForm currentForm= new CurrentForm();
		currentForm.setId(1L);
		currentForm.setProject(project);
		
		Booklet booklet= new Booklet();
		booklet.setId(1L);
		
		enrollment = new Enrollment();
		enrollment.setId(1L);
		enrollment.setCurrentForm(currentForm);
		enrollment.setBooklet(booklet);
		
		admission = new Admission();
		admission.setId(1L);
		admission.setEnrollment(enrollment);
		
		serviceType = new ServiceType();
		serviceType.setId(1L);
		serviceType.setShortName("DISCG");
		
		documents=new Documents();
		documents.setId(1L);
		documents.setShortName("PASS");
		
		bookletByValidationCode= new  BookletByValidationCode();
		bookletByValidationCode.setId(1L);
		
		enableValidationCode = new EnableValidationCode();
		enableValidationCode.setId(1L);
		
		attachment = new Attachment();
		attachment.setId(1L);
		
		filesMapValidation=ValidationTestFixture.createValidationFileMap();
		
		validation=getValidationEntity();	
	}
	
	@DisplayName("ValidateBeneficiary Test for Basic Operation")
	@Test
	public void testValidateBeneficiaryBasic() throws Exception {
		
		logger.debug("JUnit: testValidateBeneficiaryBasic");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.VALIDATION_ID,"1");
	
		validationModel=ValidationTestFixture.getRequestValidationModel();
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(admissionRepository.findById(1L)).thenReturn(Optional.of(admission));
		
		when(serviceTypeRepository.findByShortName(serviceType.getShortName())).thenReturn(serviceType);
		
		when(documentsRepository.findByShortName(documents.getShortName())).thenReturn(documents);
		
		when(validationRepository.save(Mockito.any(Validation.class))).thenReturn(validation);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		validationCodeMocks();		
		
		CycleByProjectModel cycleByProjectModel = new CycleByProjectModel();
			cycleByProjectModel.setCycleId(1L);
		when(beneficiaryApiCallService.getCycleByProjectName(Mockito.anyMap(),Mockito.anyString())).thenReturn(cycleByProjectModel);
		
		mocksForsaveLatestRecordJsonForValidation();
		
		//call service
		resultResponse=validationService.validateBeneficiary(requestHeader, filesMapValidation, validationModel);
		
		verify(validateValidationDetail,atLeastOnce()).validateValidationDetails(filesMapValidation, validationModel);
		
		verify(historicalBeneficiaryMilestoneService,atLeastOnce()).saveHistoricalBeneficiaryModel(Mockito.any(HistoricalBeneficiaryModel.class));
		
		assertEquals(expectedResponse.get(ConstantsUtil.VALIDATION_ID),resultResponse.get(ConstantsUtil.VALIDATION_ID));
		
		logger.debug("JUnit: testValidateBeneficiaryBasic - Completed");
		
	}
	
	@DisplayName("ValidateBeneficiary Test for FailProcessException Operation")
	@Test
	public void testValidateBeneficiaryFailProcess() throws Exception {
		
		logger.debug("JUnit: testValidateBeneficiaryFailProcess");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.VALIDATION_ID,"1");
	
		validationModel=ValidationTestFixture.getRequestValidationModel();
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(admissionRepository.findById(1L)).thenReturn(Optional.of(admission));
		
		when(serviceTypeRepository.findByShortName(serviceType.getShortName())).thenReturn(serviceType);
		
		when(documentsRepository.findByShortName(documents.getShortName())).thenReturn(documents);
		
		Validation saveValidation = new Validation();
		//pass admission object - throws fail process exception
		when(validationRepository.save(saveValidation)).thenReturn(validation);
		
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=validationService.validateBeneficiary(requestHeader, filesMapValidation, validationModel);
        });
			
		verify(validateValidationDetail,atLeastOnce()).validateValidationDetails(filesMapValidation, validationModel);
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testValidateBeneficiaryFailProcess - Completed");
		
	}
	
	@DisplayName("ValidateBeneficiary Test for Invalid Validation Code Operation")
	@Test
	public void testValidateBeneficiaryInvalidCode() throws Exception {
		
		logger.debug("JUnit: testValidateBeneficiaryInvalidCode");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.VALIDATION_ID,"1");
	
		validationModel=ValidationTestFixture.getRequestValidationModel();
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(admissionRepository.findById(1L)).thenReturn(Optional.of(admission));
		
		when(serviceTypeRepository.findByShortName(serviceType.getShortName())).thenReturn(serviceType);
		
		when(documentsRepository.findByShortName(documents.getShortName())).thenReturn(documents);
		
		when(validationRepository.save(Mockito.any(Validation.class))).thenReturn(validation);
		
		when(attachmentRepository.save(Mockito.any(Attachment.class))).thenReturn(attachment);
		
		when(bookletByValidationCodeRepository.findByValidationCodeAndIsActiveAndIsUsed(Mockito.anyString(), Mockito.any(YesNoEnum.class), Mockito.any(YesNoEnum.class)))
		.thenReturn(null);
		
		//call service
		IllegalArgumentException ex= assertThrows(IllegalArgumentException.class, () -> {
			resultResponse=validationService.validateBeneficiary(requestHeader, filesMapValidation, validationModel);
        });
			
		verify(validateValidationDetail,atLeastOnce()).validateValidationDetails(filesMapValidation, validationModel);
		
		assertEquals(IllegalArgumentException.class, ex.getClass());
		
		logger.debug("JUnit: testValidateBeneficiaryInvalidCode - Completed");
		
	}
	
	private Validation getValidationEntity() {
		
		Date date= new Date();
		
		Validation validation = new Validation();
		validation.setId(1L);
		validation.setCreatedBy(user);
		validation.setCreatedAt(date);
		validation.setServiceType(serviceType);
		validation.setDateFrom(date);
		validation.setDateTo(date);
		validation.setDateTo(date);
		validation.setNumberOfDays(1);
		validation.setNumberOfPeriods(1);
		validation.setAdmission(admission);
		validation.setDocReferenceNo("12343");
		validation.setDocuments(documents);
		
    	return validation;
    }
	
	private void validationCodeMocks() {

		//use lenient to avoid STRICT_STUBS error for multiple call to same method or use thenReturn as many time as method is called
		//e.g.: when(enableValidationCodeRepository.save(Mockito.any(EnableValidationCode.class))).thenReturn(enableValidationCode).thenReturn(enableValidationCode);
		
		lenient().when(bookletByValidationCodeRepository.findByValidationCodeAndIsActiveAndIsUsed(Mockito.anyString(), Mockito.any(YesNoEnum.class), Mockito.any(YesNoEnum.class)))
		.thenReturn(bookletByValidationCode);
	
		lenient().when(enableValidationCodeRepository.save(Mockito.any(EnableValidationCode.class))).thenReturn(enableValidationCode);
		
		lenient().when(bookletByValidationCodeRepository.save(Mockito.any(BookletByValidationCode.class))).thenReturn(bookletByValidationCode);
		
	}
	
	@DisplayName("testSaveVcaMonitoringLogBasic Test for Basic Operation")
	@Test
	public void testSaveVcaMonitoringLogBasic() throws Exception {
		
		logger.debug("JUnit: testSaveVcaMonitoringLogBasic");
		
		VcaMonitoringDataModel vcaMonitoringDataModel=new VcaMonitoringDataModel();
		vcaMonitoringDataModel.setFailedAttempt("1");
		vcaMonitoringDataModel.setViewedAttempt("2");
		vcaMonitoringDataModel.setCreatedBy("1");
		vcaMonitoringDataModel.setCreatedDate("27-08-2021 09:09:30");
		
		VcaMonitoringLog VcaMonitoringLog= new VcaMonitoringLog();
		VcaMonitoringLog.setId(1L);
		
		when(vcaMonitoringLogRepository.save(Mockito.any(VcaMonitoringLog.class))).thenReturn(VcaMonitoringLog);

		validationService.saveVcaMonitoringLog(vcaMonitoringDataModel);
		
		verify(vcaMonitoringLogRepository,atLeastOnce()).save(Mockito.any(VcaMonitoringLog.class));
		
		logger.debug("JUnit: testSaveVcaMonitoringLogBasic - Completed"); 
	}
	
	@DisplayName("testSaveVcaMonitoringLog Test for FailProcess Operation")
	@Test
	public void testSaveVcaMonitoringLogFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveVcaMonitoringLogFailProcess");
		
		VcaMonitoringDataModel vcaMonitoringDataModel=new VcaMonitoringDataModel();
		vcaMonitoringDataModel.setFailedAttempt("1");
		vcaMonitoringDataModel.setViewedAttempt("2");
		vcaMonitoringDataModel.setCreatedBy("1");
		vcaMonitoringDataModel.setCreatedDate("27-08-2021 09:09:30");
		
		VcaMonitoringLog VcaMonitoringLog= new VcaMonitoringLog();
		VcaMonitoringLog.setId(1L);
		
		when(vcaMonitoringLogRepository.save(VcaMonitoringLog)).thenReturn(VcaMonitoringLog);

		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			validationService.saveVcaMonitoringLog(vcaMonitoringDataModel);
	    });
			
		verify(vcaMonitoringLogRepository,atLeastOnce()).save(Mockito.any(VcaMonitoringLog.class));
		
		assertEquals(FailProcessException.class, fPE.getClass());
		
		logger.debug("JUnit: testSaveVcaMonitoringLogFailProcess - Completed");
	}
	
	
    private void mocksForsaveLatestRecordJsonForValidation(){
    	
		when(admissionRepository.getLatestAdmissionById(Mockito.anyLong())).thenReturn(admission);
		
		Map<String, Object> admissionMap=new HashMap<String, Object>();
		admissionMap.put(ConstantsUtil.ADMISSION_ID, admission.getId());
		when(admissionService.addAdmissionDetailsToMap(Mockito.any(Admission.class)))
		.thenReturn(admissionMap);
		
    	Optional<Enrollment> enrollmentOpt =  Optional.of(enrollment); 
		when(enrollmentRepository.findById(Mockito.anyLong())).thenReturn(enrollmentOpt);
		
		Map<String, Object> enrollmentMap=new HashMap<String, Object>();
		enrollmentMap.put(ConstantsUtil.ENROLLMENT_ID, enrollment.getId());
		when(enrollmentService.addEnrollmentDetailsToMap(Mockito.anyLong(),Mockito.any(Enrollment.class)))
		.thenReturn(enrollmentMap);
    }
}
