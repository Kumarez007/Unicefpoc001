package org.yumnn.yct.beneficiaryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeneficiaryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
