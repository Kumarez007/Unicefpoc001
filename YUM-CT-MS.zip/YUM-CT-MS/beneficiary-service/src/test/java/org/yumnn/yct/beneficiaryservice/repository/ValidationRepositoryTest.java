package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.ServiceType;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 2:09:52 AM
 */

@DataJpaTest
public class ValidationRepositoryTest {
	
	private static Logger logger = LoggerFactory.getLogger(ValidationRepositoryTest.class);
	
	@Autowired
	private ValidationRepository repo = null;
	
	private Validation validation=null;
	
	@Test
	public void testFindById() {
		logger.info("Inside testFindById()");
		Optional<Validation> result = repo.findById(2L);
		assertTrue(result.isPresent());
	}
	
	@Test
	public void testFindByWrongId() {
		logger.info("Inside testFindByWrongId()");
		Optional<Validation> result= repo.findById(10L);
		assertFalse(result.isPresent());
	}
	
	@Test
	public void testSaveValidation() throws Exception {
		logger.info("Inside testSaveValidation");
		
		setUpEntity();
	
		Validation result= repo.save(validation);
		
		assertNotNull(result);
	}
	
	@Test
	public void testFindByUniqueId() {
		logger.info("Inside testFindByUniqueId()");
		Validation result = repo.findByUniqueId("1");
		assertNotNull(result);
	}
	
	@Test
	public void testFindByUniqueIdNull() {
		logger.info("Inside testFindByUniqueIdNull()");
		Validation result = repo.findByUniqueId(null);
		assertNull(result);
	}
	
	private void setUpEntity() throws Exception {
		
		User user = new User();
		user.setId(1L);
		
		Admission admission = new Admission();
		admission.setId(2L);
		
		ServiceType serviceType = new ServiceType();
		serviceType.setId(1L);
		
		Documents documents=new Documents();
		documents.setId(1L);
		
		validation = new Validation();
		validation.setId(100L);
		validation.setCreatedBy(user);
		validation.setCreatedAt(new Date());
		validation.setServiceType(serviceType);
		validation.setDateFrom(new Date());
		validation.setDateTo(new Date());
		validation.setNumberOfDays(1);
		validation.setNumberOfPeriods(1);
		validation.setAdmission(admission);
		validation.setDocReferenceNo("12343");
		validation.setDocuments(documents);
	}

}
