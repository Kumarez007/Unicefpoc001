package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.HouseholdMemberLog;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.catalog.Gender;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.SourceTypeEnum;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 11, 2021 3:52:49 PM
 */

@DataJpaTest
public class HouseholdMemberLogRepositoryTest {

private static Logger logger = LoggerFactory.getLogger(HouseholdMemberLogRepositoryTest.class);
	
	@Autowired
	private HouseholdMemberLogRepository repo = null;
	
	private HouseholdMemberLog householdMemberLog=null;
	
	@Test
	public void testSaveHouseholdMemberLogBasic() throws Exception {
		logger.info("Inside testSaveHouseholdMemberLog Basic");
		
		setUpEntity();
		
		HouseholdMemberLog result= repo.save(householdMemberLog);
		assertNotNull(result);
		logger.debug("save successful");
		
	}
	
	@Test
	public void testSaveHouseholdMemberLogFail() throws Exception {
		logger.info("Inside testSaveHouseholdMemberLog Not Null Contraint Violation");
		
		setUpEntity();
		
		householdMemberLog.setCurrentForm(null);
		
		try {
			repo.save(householdMemberLog);
		}
		catch(Exception e) {
			logger.debug("Error In Save");
			assertNotNull(e);
		}
		
	}
	
	private void setUpEntity() throws Exception {
		

		User user = new User();
		user.setId(1L);

		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		
		Gender gender=new Gender();
		gender.setId(1L);
		
		Documents documents=new Documents();
		documents.setId(1L);
		
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		
		householdMemberLog = new HouseholdMemberLog();
		householdMemberLog.setId(100L);
		householdMemberLog.setFirstName("JUnit");
		householdMemberLog.setLastName("Child");
		householdMemberLog.setGender(gender);
		householdMemberLog.setDateOfBirth(new Date());
		householdMemberLog.setDocument(documents);
		householdMemberLog.setDocumentReferenceNumber("123");
		householdMemberLog.setHouseholdMemberType(householdMemberType);
		householdMemberLog.setCurrentForm(currentForm);
		householdMemberLog.setIsAssignedAsPaymentReceiver(YesNoEnum.NO);
		householdMemberLog.setCreatedBy(user);
		householdMemberLog.setCreatedAt(new Date());
		householdMemberLog.setIsPrimary(YesNoEnum.NO);
		householdMemberLog.setSourceId(1L);
		householdMemberLog.setSourceType(SourceTypeEnum.ADMISSION);
	}
	
}
