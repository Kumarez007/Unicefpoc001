package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.common.model.administration.UserModel;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:32:25 PM
 */

@ExtendWith(MockitoExtension.class)
public class BeneficiaryApiCallServiceTest { 
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private BeneficiaryApiCallService beneficiaryApiCallService = null;
	
	@Mock
	private RestTemplate rt =null;
	
	private Map<String, String> requestHeader=null;
	private Map<String, Object> responseMap=null;
	private UserModel userModel = null;
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		userModel = new UserModel();
		userModel.setId(1L);
	}
	
	@DisplayName("GetUserDetails Test for Basic Operation")
	@Test
	public void testGetUserDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testGetUserDetailsBasic");
		
		responseMap = new HashMap<String, Object>();
		responseMap.put(ConstantsUtil.USER_OBJ, userModel);
		SuccessResponse sucRes=new SuccessResponse();
		sucRes.setData(responseMap);
		
		ResponseEntity<SuccessResponse> resEntity= new ResponseEntity<SuccessResponse>(sucRes,HttpStatus.OK);
		
		String serviceUri="http://localhost:9090".concat(ConstantsUtil.API_GATEWAY_BASE_PATH+ConstantsUtil.USER_DETAILS_API_ENDPOINT);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(requestHeader);
		HttpEntity<SuccessResponse> requestEntity = new HttpEntity<>(null, headers);
		
		when(rt.exchange(serviceUri,HttpMethod.GET,requestEntity,SuccessResponse.class)).thenReturn(resEntity);
		
	
		//call service
		UserModel resultResponse=beneficiaryApiCallService.getUserDetails(requestHeader);
		
		assertEquals(userModel.getId(),resultResponse.getId());
		
		logger.debug("JUnit: testGetUserDetailsBasic - Completed");
		
	}
	
	@DisplayName("Get Device Detail Id Test for Basic Operation")
	@Test
	public void testGetDeviceDetailIdBasic() throws Exception {
		
		logger.debug("JUnit: testGetDeviceDetailIdBasic");
		
		Long expectedDeviceId=1L;
		
		responseMap = new HashMap<String, Object>();
		responseMap.put(ConstantsUtil.DEVICE_ID, expectedDeviceId);
		SuccessResponse sucRes=new SuccessResponse();
		sucRes.setData(responseMap);
		
		ResponseEntity<SuccessResponse> resEntity= new ResponseEntity<SuccessResponse>(sucRes,HttpStatus.OK);
		
		String serviceUri="http://localhost:9090".concat(ConstantsUtil.API_GATEWAY_BASE_PATH+ConstantsUtil.DEVICE_DETAILS_API_ENDPOINT);
		serviceUri=serviceUri.concat("?deviceId="+ 1);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAll(requestHeader);
		HttpEntity<SuccessResponse> requestEntity = new HttpEntity<>(null, headers);
		
		when(rt.exchange(serviceUri,HttpMethod.GET,requestEntity,SuccessResponse.class)).thenReturn(resEntity);
		
	
		//call service
		Long resultDeviceDetailId=beneficiaryApiCallService.getDeviceDetailId(requestHeader,"1");
		
		assertEquals(expectedDeviceId,resultDeviceDetailId);
		
		logger.debug("JUnit: testGetDeviceDetailIdBasic - Completed");
		
	}
	

}
