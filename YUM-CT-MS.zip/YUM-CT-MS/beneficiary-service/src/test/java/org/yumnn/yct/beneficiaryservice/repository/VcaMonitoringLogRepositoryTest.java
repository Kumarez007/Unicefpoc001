package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.VcaMonitoringLog;
import org.yumnn.yct.common.entity.administration.User;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 30, 2021 2:11:46 PM
 */

@DataJpaTest
public class VcaMonitoringLogRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(VcaMonitoringLogRepositoryTest.class);
	
	@Autowired
	private VcaMonitoringLogRepository repo = null;
	
	private VcaMonitoringLog vcaMonitoringLog=null;
	
	@Test
	public void testVcaMonitoringLogBasic() throws Exception {
		logger.info("Inside testVcaMonitoringLogBasic Basic");
		
		setUpEntity();
		
		VcaMonitoringLog result= repo.save(vcaMonitoringLog);
		assertNotNull(result);
		logger.debug("save successful");
		
	}
	
	@Test
	public void testVcaMonitoringLogFail() throws Exception {
		logger.info("Inside testVcaMonitoringLogFail Not Null Contraint Violation");
		
		setUpEntity();
		
		vcaMonitoringLog.setFailedAttempt(null);
		
		try {
			repo.save(vcaMonitoringLog);
		}
		catch(Exception e) {
			logger.debug("Error In Save");
			assertNotNull(e);
		}
		
	}
	
	private void setUpEntity() throws Exception {
		

		User user = new User();
		user.setId(1L);
		
		vcaMonitoringLog = new VcaMonitoringLog();
		vcaMonitoringLog.setId(100L);
		vcaMonitoringLog.setFailedAttempt(1L);
		vcaMonitoringLog.setViewedAttempt(1L);
		vcaMonitoringLog.setCreatedBy(user);
		vcaMonitoringLog.setCreatedAt(new Date());

	}

}
