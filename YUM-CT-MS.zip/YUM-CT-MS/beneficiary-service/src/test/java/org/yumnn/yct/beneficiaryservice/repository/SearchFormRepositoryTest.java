package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.SearchForm;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 12, 2021 1:05:03 PM
 */

@DataJpaTest
public class SearchFormRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(SearchFormRepositoryTest.class);
	
	@Autowired
	private SearchFormRepository repo = null;
	
	private SearchForm searchForm=null;
	
	
	@Test
	public void testSearchFormByCurFormAndHouseHoldMemberType() {
		logger.info("Inside testSearchFormByCurFormAndHouseHoldMemberType");
		SearchForm result= repo.getSearchFormByCurFormAndHouseHoldMemberType(2L,1L);
		assertNotNull(result);
	}
	

	@Test
	public void testSearchFormByCurFormAndInvalidHouseHoldMemberType() {
		logger.info("Inside testSearchFormByCurFormAndInvalidHouseHoldMemberType");
		SearchForm result= repo.getSearchFormByCurFormAndHouseHoldMemberType(2L,10L);
		assertNull(result);
	}

}
