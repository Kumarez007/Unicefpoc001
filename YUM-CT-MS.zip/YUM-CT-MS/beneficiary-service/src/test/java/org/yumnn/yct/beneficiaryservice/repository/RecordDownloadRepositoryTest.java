package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.yumnn.yct.beneficiaryservice.entity.RecordDownload;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Oct 14, 2021 7:16:06 PM
 */

@DataJpaTest
public class RecordDownloadRepositoryTest {
	
	private static Logger logger = LoggerFactory.getLogger(RecordDownloadRepositoryTest.class);
	
	@Autowired
	private RecordDownloadRepository repo = null;
	
	private RecordDownload recordDownload=null;
	
	@Test
	public void testGetTotalBeneficiaryCount() {
		logger.info("Inside testGetTotalBeneficiaryCount");
		Long result= repo.getTotalBeneficiaryCount();
		assertTrue(result>0);
	}
	
	@Test
	public void testGetTotalBeneficiaryCountAfterId() {
		logger.info("Inside testGetTotalBeneficiaryCountAfterId");
		Long result= repo.getTotalBeneficiaryCountAfterId(1L);
		assertEquals("1",result.toString());
	}
	
	@Test
	public void testGetBeneficiaryRecordsForFirstBatch() {
		logger.info("Inside testGetBeneficiaryRecordsForFirstBatch");
		Pageable pageable=  PageRequest.of(0, 1); 
		List<RecordDownload> result= repo.getBeneficiaryRecordsForFirstBatch(pageable);
		assertTrue(result.size()>0);
	}
	
	@Test
	public void testGetBeneficiaryRecordsAfterId() {
		logger.info("Inside testGetBeneficiaryRecordsAfterId");
		Pageable pageable=  PageRequest.of(0, 1); 
		List<RecordDownload> result= repo.getBeneficiaryRecordsAfterId(1L,pageable);
		assertTrue(result.size()>0);
	}
	
	@Test
	public void testSaveRecordDownload() throws Exception {
		logger.info("Inside testSaveRecordDownload");
		
		setUpEntity();
	
		RecordDownload result= repo.save(recordDownload);
		
		assertNotNull(result);
	}
	
	@Test
	public void testUpdateBeneficiaryRecordIsActive() throws Exception {
		logger.info("Inside testUpdateBeneficiaryRecordIsActive");
		
		assertDoesNotThrow(() ->
			repo.updateBeneficiaryRecordIsActive(YesNoEnum.YES,2L));
		
	}
	
	private void setUpEntity() throws Exception {

		recordDownload = new RecordDownload();
		recordDownload.setId(3L);
		recordDownload.setIsActive(YesNoEnum.YES);
		recordDownload.setReferenceId(1L);
		recordDownload.setReferenceType("TEST");
		recordDownload.setRecordJson("{\"param\":\"value\"}");
		recordDownload.setSyncDate(new Date());
	}


}
