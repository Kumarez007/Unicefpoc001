package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.beneficiaryservice.model.EnrollmentModel;
import org.yumnn.yct.beneficiaryservice.model.HouseholdCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByServiceCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.SearchModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.beneficiaryservice.repository.BookletRepository;
import org.yumnn.yct.beneficiaryservice.repository.EnrollmentRepository;
import org.yumnn.yct.beneficiaryservice.repository.HouseholdMemberRepository;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateEnrollmentDetail;
import org.yumnn.yct.beneficiaryservice.util.validate.ValidateUserDetail;
import org.yumnn.yct.common.entity.administration.ProgramEntity;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.entity.project.model.CycleByProjectModel;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.CurrentFormModel;
import org.yumnn.yct.common.model.HouseholdMemberModel;
import org.yumnn.yct.common.repository.GeographicalAreaRepository;
import org.yumnn.yct.common.repository.ProgramEntityRepository;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 19, 2021 2:30:14 PM
 */

@ExtendWith(MockitoExtension.class)
public class EnrollmentServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private EnrollmentService enrollmentService = null;
	
	@Mock
	private EnrollmentRepository enrollmentRepository = null;

	@Mock
	private HouseholdMemberService householdMemberService = null;

	@Mock
	private CurrentFormService currentFormService = null;

	@Mock
	private ValidateEnrollmentDetail validateEnrollmentDetail = null;

	@Mock
	private ValidateUserDetail validateUserDetail = null;
	
	@Mock
	private ProgramEntityRepository programEntityRepository = null;
	
	@Mock
	private GeographicalAreaRepository geographicalAreaRepository = null;
	
	@Mock
	private BookletRepository bookletRepository =null;
	
	@Mock
	private HouseholdMemberRepository householdMemberRepository = null;
	
	@Mock
	CommonValidationUtil commonValidationUtil=null;
	
	@Mock
	private BeneficiaryApiCallService beneficiaryApiCallService=null;
	
	@Mock
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService=null;	
	
	@Mock
	private BeneficiaryAdmissionService admissionService=null;
	
	@Mock
	ValidationRepository validationRepository=null;
	
	@Mock
	private ValidationService validationService=null;
	
	@Mock
	private SynchronizationService synchronizationService=null;
	
	@Mock
	private AdmissionRepository admissionRepository = null;
	
	private Map<String, String> requestHeader=null;
	private Map<String, Object> expectedResponse=null;
	private Map<String, Object> resultResponse=null;
	private Map<String, MultipartFile> filesMapAddAdmissionUpdateHHM = null;
	private  EnrollmentModel enrollmentModel = null;
	private User user=null;
	private Enrollment enrollment=null;
	private CurrentFormModel currentFormModel=null;
	private ProgramEntity programEntity=null;
	private Geolocation geolocation=null;
	private Booklet booklet=null;
	private Admission admission=null;
	private Validation validation=null;
	
	@BeforeEach
	public void setup() throws IOException {
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		
		user = new User();
		user.setId(1L);
		
		programEntity=new ProgramEntity();
		programEntity.setId(1L);
		programEntity.setShortName("TFC001");
		
		geolocation=new Geolocation();
		geolocation.setId(1L);
		geolocation.setShortName("18-13-");
		
		booklet=new Booklet();
		booklet.setId(1L);
		booklet.setIsActive(YesNoEnum.YES);
		booklet.setShortName("1111-2222-3333-23");
		
		filesMapAddAdmissionUpdateHHM=ValidationTestFixture.createEnrollmentFileMap();
		
		enrollment=getEnrollmentEntity();
		
		admission=new Admission();
		admission.setId(1L);
		admission.setEnrollment(enrollment);
		
		validation = new Validation();
		validation.setId(1L);
		validation.setAdmission(admission);
		
	} 
	
	@SuppressWarnings("unchecked")
	@DisplayName("EnrollBeneficiary Test for Basic Operation")
	@Test
	public void testEnrollBeneficiaryBasic() throws Exception {
		
		logger.debug("JUnit: testEnrollBeneficiaryBasic");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
	
		enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		currentFormModel=getCurrentFormModel();
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(currentFormService.saveCurrentForm(Mockito.any(CurrentFormModel.class),Mockito.any(User.class))).thenReturn(currentFormModel);
		
		List<HouseholdMemberModel> householdMemberModel=ValidationTestFixture.getHouseholdMemberList();
		when(householdMemberService.saveHouseholdMemberDetails(Mockito.any(List.class), Mockito.any(Map.class),Mockito.any(User.class), null)).thenReturn(householdMemberModel);
		
		when(programEntityRepository.findByShortName(enrollmentModel.getTfcShortName())).thenReturn(programEntity);
		when(geographicalAreaRepository.findByShortName(enrollmentModel.getOtpGeoAreaShortName())).thenReturn(Optional.of(geolocation));
		when(bookletRepository.findByShortName(enrollmentModel.getBookletShortName())).thenReturn(booklet);
		
		when(enrollmentRepository.save(Mockito.any(Enrollment.class))).thenReturn(enrollment);
		
		CycleByProjectModel cycleByProjectModel = new CycleByProjectModel();
		cycleByProjectModel.setCycleId(1L);
		when(beneficiaryApiCallService.getCycleByProjectName(Mockito.anyMap(),Mockito.anyString())).thenReturn(cycleByProjectModel);

		mocksForsaveLatestRecordJsonForEnrollment();
		
		//call service
		resultResponse=enrollmentService.enrollBeneficiary(requestHeader, filesMapAddAdmissionUpdateHHM, enrollmentModel);
		
		verify(validateEnrollmentDetail,atLeastOnce()).validateEnrollmentDetails(filesMapAddAdmissionUpdateHHM, enrollmentModel);
		verify(historicalBeneficiaryMilestoneService,atLeastOnce()).saveHistoricalBeneficiaryModel(Mockito.any(HistoricalBeneficiaryModel.class));
		assertEquals(expectedResponse.get(ConstantsUtil.ENROLLMENT_CODE),resultResponse.get(ConstantsUtil.ENROLLMENT_CODE));
		
		logger.debug("JUnit: testEnrollBeneficiaryBasic - Completed");
		
	}
	
	@SuppressWarnings("unchecked")
	@DisplayName("EnrollBeneficiary Test for FailProcessException Operation")
	@Test
	public void testEnrollBeneficiaryFailProcess() throws Exception {
		
		logger.debug("JUnit: testEnrollBeneficiaryFailProcess");
		
		expectedResponse=new HashMap<String, Object>();
		expectedResponse.put(ConstantsUtil.ENROLLMENT_CODE, "1");
	
		enrollmentModel=ValidationTestFixture.getRequestEnrollmentModel();
		currentFormModel=getCurrentFormModel();
		
		//all mocks for the service methods
		when(validateUserDetail.validateAndGetUser(requestHeader)).thenReturn(user);
		
		when(currentFormService.saveCurrentForm(Mockito.any(CurrentFormModel.class),Mockito.any(User.class))).thenReturn(currentFormModel);
		
		List<HouseholdMemberModel> householdMemberModel=ValidationTestFixture.getHouseholdMemberList();
		when(householdMemberService.saveHouseholdMemberDetails(Mockito.any(List.class), Mockito.any(Map.class),Mockito.any(User.class), null)).thenReturn(householdMemberModel);
		
		when(programEntityRepository.findByShortName(enrollmentModel.getTfcShortName())).thenReturn(programEntity);
		when(geographicalAreaRepository.findByShortName(enrollmentModel.getOtpGeoAreaShortName())).thenReturn(Optional.of(geolocation));
		when(bookletRepository.findByShortName(enrollmentModel.getBookletShortName())).thenReturn(booklet);
		
		Enrollment saveEnrollment =new Enrollment();
		when(enrollmentRepository.save(saveEnrollment)).thenReturn(enrollment);

		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			resultResponse=enrollmentService.enrollBeneficiary(requestHeader, filesMapAddAdmissionUpdateHHM, enrollmentModel);
        });
			
		verify(validateEnrollmentDetail,atLeastOnce()).validateEnrollmentDetails(filesMapAddAdmissionUpdateHHM, enrollmentModel);
		
		assertEquals(FailProcessException.class, fPE.getClass());
				
		logger.debug("JUnit: testEnrollBeneficiaryFailProcess - Completed");
		
	}
	
	@DisplayName("SearchBeneficaryInfo Test for Basic Operation")
	@Test
	public void testSearchBeneficaryInfoBasic() throws Exception {
		
		logger.debug("JUnit: testSearchBeneficaryInfoBasic");
		
		List<Map<String,String>> mapDataList=new ArrayList<Map<String,String>>();
		
		Map<String, Object> mockResponse=new HashMap<String, Object>();
		mockResponse.put("searchBeneficiaryResponse", mapDataList);
		
		Map<String, String> requestBody=new HashMap<String, String>();
		requestBody.put(ConstantsUtil.SEARCH_TYPE_PARAM, ConstantsUtil.SEARCH_ALL);
		
		List<SearchModel> searchModelList=new ArrayList<SearchModel>();
		
		when(enrollmentRepository.getAllEnrollmentData()).thenReturn(searchModelList);
		
		Map<String, Object> resultResponse=enrollmentService.searchBeneficaryInfo(requestBody);
		
		verify(commonValidationUtil,atLeastOnce()).validateIsNull("Search Request Params",requestBody);
		assertNotNull(resultResponse);

		logger.debug("JUnit: testSearchBeneficaryInfoBasic - Completed");
	}
	
	@DisplayName("Get Household Card Info Test for Basic Operation")
	@Test
	public void testGetHouseholdCardInfoBasic() throws Exception {
		
		logger.debug("JUnit: testGetHouseholdCardInfoBasic");
		
   		HouseholdCardInfoModel householdCardInfoModel=null;
   		
   		List<HouseholdCardInfoModel> expectedHouseholdCardInfoList= new ArrayList<HouseholdCardInfoModel>();
   		expectedHouseholdCardInfoList.add(householdCardInfoModel);
		
   		Mockito.lenient().when(enrollmentRepository.getHouseholdCardInfo(Mockito.anyLong())).thenReturn(expectedHouseholdCardInfoList);
		
		Enrollment enrollment = getEnrollmentEntity();
		Mockito.lenient().when(enrollmentRepository.findByEnrollmentCode(Mockito.anyString())).thenReturn(enrollment);
		
		when(enrollmentRepository.getPrimaryMemberName(Mockito.anyLong())).thenReturn("TEST CAREGIVER");
		
		when(enrollmentRepository.getBeneficiaryGeoLocation(Mockito.anyLong())).thenReturn(1L);
		
		Map<String, Object> resultResponse=enrollmentService.getHouseholdCardInfo(1L,"Test");

		assertNotNull(resultResponse);

		logger.debug("JUnit: testGetHouseholdCardInfoBasic - Completed");
	}
	
	@DisplayName("Get Payment By Service Card Info Test for Basic Operation")
	@Test
	public void testGetPaymentByServiceCardInfo() throws Exception {
		
		logger.debug("JUnit: testGetPaymentByServiceCardInfo");
		
		PaymentByServiceCardInfoModel paymentByServiceCardInfoModel=null;
   		
   		List<PaymentByServiceCardInfoModel> expectedPaymentByServiceCardInfoList= new ArrayList<PaymentByServiceCardInfoModel>();
   		expectedPaymentByServiceCardInfoList.add(paymentByServiceCardInfoModel);
		
		when(enrollmentRepository.getPaymentByServiceCardInfo(Mockito.anyLong())).thenReturn(expectedPaymentByServiceCardInfoList);
		
		Map<String, Object> resultResponse=enrollmentService.getPaymentByServiceCardInfo(1L);

		assertNotNull(resultResponse);

		logger.debug("JUnit: testGetPaymentByServiceCardInfo - Completed");
	}
	
	private Enrollment getEnrollmentEntity() {
		
		Date date= new Date();
		
		Enrollment enrollment = new Enrollment();
		enrollment.setId(1L);
		enrollment.setCreatedBy(user);
		enrollment.setCreatedAt(date);
		enrollment.setEnrollmentCode("1");
		enrollment.setIsRefferdFromOtherTFC(YesNoEnum.YES);
		enrollment.setOtpReferenceNumber("999-999-999");
		enrollment.setOtpNutritionOfficerName("JUnit Tester");
		enrollment.setOtpNutritionOfficerPhoneNumber("701234567");
		enrollment.setOtpNutritionOfficerRefrenceNumber("999-999-999");
		
		enrollment.setPlaceOfAdmission(programEntity);
		enrollment.setIsRequireInvestigation(YesNoEnum.NO);
		enrollment.setProgramEntity(programEntity);
		enrollment.setGeoLocationOTP(geolocation);
		
		Project project = new Project();
		project.setId(1L);
		project.setShortName(ProjectNameEnum.NVS);
		
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(1L);
		currentForm.setBooklet(booklet);
		currentForm.setProject(project);
		
		enrollment.setCurrentForm(currentForm);
		enrollment.setBooklet(booklet);
		enrollment.setComments("JUnit Testing");
    	
    	return enrollment;
    }
	
	private CurrentFormModel getCurrentFormModel(){
		CurrentFormModel currentFormModel=new CurrentFormModel();
		currentFormModel.setProjectShortName(enrollmentModel.getProjectShortName());
		currentFormModel.setCreatedBy(enrollmentModel.getCreatedBy());
		currentFormModel.setCreatedDate(enrollmentModel.getCreatedDate());
		return currentFormModel;
	}
	
	
	 
	
    private void mocksForsaveLatestRecordJsonForEnrollment(){
    	
		when(admissionRepository.getAdmissionByEnrollment(Mockito.anyLong())).thenReturn(admission);
		
		Map<String, Object> admissionMap=new HashMap<String, Object>();
		admissionMap.put(ConstantsUtil.ADMISSION_ID, admission.getId());
		when(admissionService.addAdmissionDetailsToMap(Mockito.any(Admission.class)))
		.thenReturn(admissionMap);
		
		when(validationRepository.getValidationByAdmission(admission.getId())).thenReturn(validation);
		
		Map<String, Object> validationMap=new HashMap<String, Object>();
		validationMap.put(ConstantsUtil.VALIDATION_ID, validation.getId());
		when(validationService.addValidationDetailsToMap(Mockito.anyLong(),Mockito.any(Validation.class)))
		.thenReturn(validationMap);
    }
}
