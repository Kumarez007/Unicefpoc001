package org.yumnn.yct.beneficiaryservice.util.validate;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryAdmissionModel;
import org.yumnn.yct.beneficiaryservice.repository.AdmissionRepository;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;
import org.yumnn.yct.beneficiaryservice.service.EnrollmentService;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 26, 2021 5:25:40 PM
 * 
 */

@SpringBootTest(classes = {ValidateAdmissionDetail.class, CommonValidationUtil.class, MessageSource.class})
public class ValidateAdmissionDetailTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private ValidateAdmissionDetail validateAdmissionDetail =null;
	
	@MockBean
	EnrollmentService enrollmentService=null;
	
	@MockBean
	AdmissionRepository admissionRepository=null;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("JUnit: ValidateAdmissionDetails Basic Test")
	public void testValidateAdmissionDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testValidateAdmissionDetailsBasic Test Started");
		
		BeneficiaryAdmissionModel admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		Map<String, MultipartFile> filesMapAddAdmission=ValidationTestFixture.createAdmissionFileMap();
		when(admissionRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		assertDoesNotThrow(() ->
		validateAdmissionDetail.validateAdmissionDetails(filesMapAddAdmission, admissionModel));
	
		logger.debug("JUnit: testValidateAdmissionDetailsBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateAdmissionDetails Invalid Param Test")
	public void testValidateAdmissionDetailsInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateAdmissionDetailsInvalidParam Test Started");
		
		BeneficiaryAdmissionModel admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		Map<String, MultipartFile> filesMapAddAdmission=ValidationTestFixture.createAdmissionFileMap();
		
		admissionModel.setIsAdmitted(null);
		when(admissionRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateAdmissionDetail.validateAdmissionDetails(filesMapAddAdmission, admissionModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateAdmissionDetailsInvalidParam Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateAdmissionDetails Proof Of Referral File Test")
	public void testValidateAdmissionDetailsProofOfReferralFileBasic() throws Exception {
		
		logger.debug("JUnit: testValidateAdmissionDetailsProofOfReferralFileBasic Test Started");
		
		BeneficiaryAdmissionModel admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		Map<String, MultipartFile> filesMapAddAdmission=ValidationTestFixture.createAdmissionFileMap();
		
		Enrollment enrollment=new Enrollment();
		enrollment.setId(1L);
		enrollment.setIsRefferdFromOtherTFC(YesNoEnum.YES);
		
		when(enrollmentService.getEnrollmentByCode(admissionModel.getEnrollmentCode()))
				.thenReturn(enrollment);
		when(admissionRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		assertDoesNotThrow(() ->
		validateAdmissionDetail.validateAdmissionDetails(filesMapAddAdmission, admissionModel));
		
		logger.debug("JUnit: testValidateAdmissionDetailsProofOfReferralFileBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateAdmissionDetails Proof Of Referral File Missing Test")
	public void testValidateAdmissionDetailsProofOfReferralFileMissing() throws Exception {
		
		logger.debug("JUnit: testValidateAdmissionDetailsProofOfReferralFileMissing Test Started");
		
		BeneficiaryAdmissionModel admissionModel=ValidationTestFixture.getRequestAdmissionModel(Boolean.FALSE);
		Map<String, MultipartFile> filesMapAddAdmissionEmpty=new HashMap<String, MultipartFile>();
		
		Enrollment enrollment=new Enrollment();
		enrollment.setId(1L);
		enrollment.setIsRefferdFromOtherTFC(YesNoEnum.YES);
		
		when(enrollmentService.getEnrollmentByCode(admissionModel.getEnrollmentCode()))
				.thenReturn(enrollment);
		when(admissionRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateAdmissionDetail.validateAdmissionDetails(filesMapAddAdmissionEmpty, admissionModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		
		logger.debug("JUnit: testValidateAdmissionDetailsProofOfReferralFileMissing Test Completed");
		
	}

}
