package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.common.entity.catalog.Documents;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 14, 2021 11:52:18 PM
 */

@DataJpaTest
public class DocumentsRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(DocumentsRepositoryTest.class);
	
	@Autowired
	private DocumentsRepository repo = null;

	@Test
	public void testFindByShortName() {
		logger.info("Inside testFindByShortName");
		Documents result= repo.findByShortName("PASS");
		assertEquals("PASS",result.getShortName());
	}
	
	@Test
	public void testFindByIncorrectShortName() {
		logger.info("Inside testFindByIncorrectShortName");
		Documents result= repo.findByShortName("VOT");
		assertNull(result);
	}
	
	@Test
	public void testFindByShortNameAsNull() {
		logger.info("Inside testFindByShortNameAsNull");
		Documents result= repo.findByShortName(null);
		assertNull(result);
	}
	
	
}
