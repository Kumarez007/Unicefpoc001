package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.entity.EnableValidationCode;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.project.Project;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 14, 2021 11:56:36 PM
 */

@DataJpaTest
public class EnableValidationCodeRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(EnableValidationCodeRepositoryTest.class);
	
	@Autowired
	private EnableValidationCodeRepository repo = null;
	
	private EnableValidationCode enableValidationCode=null;
	
	@Test
	public void testFindByReferenceIdAndReferenceType() {
		logger.info("Inside testFindByValidationCodeAndIsActive");
		List<EnableValidationCode> result= repo.findByReferenceIdAndReferenceType(2L, "Admission");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testFindByReferenceIncorrectIdAndReferenceType() {
		logger.info("Inside testFindByReferenceIncorrectIdAndReferenceType");
		List<EnableValidationCode> result= repo.findByReferenceIdAndReferenceType(10L, "Admission");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testFindByReferenceIdAndIncorrectReferenceType() {
		logger.info("Inside testFindByReferenceIncorrectIdAndReferenceType");
		List<EnableValidationCode> result= repo.findByReferenceIdAndReferenceType(2L, "xyz");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testSaveEnableValidationCode() throws Exception {
		logger.info("Inside testSaveEnableValidationCode");
		
		setUpEntity();
	
		EnableValidationCode result= repo.save(enableValidationCode);
		
		assertNotNull(result);
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		BookletByValidationCode bookletByValidationCode=new BookletByValidationCode();
		bookletByValidationCode.setId(1L);
		
		enableValidationCode = new EnableValidationCode();
		enableValidationCode.setId(100L);
		enableValidationCode.setReferenceId(2L);
		enableValidationCode.setReferenceType("Admission");
		enableValidationCode.setCreatedBy(user);
		enableValidationCode.setCreatedAt(new Date());
		enableValidationCode.setSetupBookletByValidationCode(bookletByValidationCode);
		enableValidationCode.setExpiryDate(new Date());
		enableValidationCode.setValidationType("Test");
	}
	
	

}
