package org.yumnn.yct.beneficiaryservice.util.validate;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.repository.ValidationRepository;
import org.yumnn.yct.common.validation.util.CommonValidationUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 27, 2021 1:42:11 AM
 */

@SpringBootTest(classes = {ValidateValidationDetail.class, CommonValidationUtil.class, MessageSource.class})
public class ValidateValidationDetailTest {
	
private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private ValidateValidationDetail validateValidationDetail =null;
	
	@MockBean 
	private ValidationRepository validationRepository=null;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	@DisplayName("JUnit: ValidateValidationDetails Basic Test")
	public void testValidateValidationDetailsBasic() throws Exception {
		
		logger.debug("JUnit: testValidateValidationDetailsBasic Test Started");
		
		ValidationModel validationModel=ValidationTestFixture.getRequestValidationModel();
		Map<String, MultipartFile> filesMapValidation=ValidationTestFixture.createValidationFileMap();
		
		when(validationRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		assertDoesNotThrow(() ->
		validateValidationDetail.validateValidationDetails(filesMapValidation, validationModel));
	
		logger.debug("JUnit: testValidateValidationDetailsBasic Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateValidationDetails Invalid Param Test")
	public void testValidateValidationDetailsInvalidParam() throws Exception {
		
		logger.debug("JUnit: testValidateValidationDetailsInvalidParam Test Started");
		
		ValidationModel validationModel=ValidationTestFixture.getRequestValidationModel();
		Map<String, MultipartFile> filesMapValidation=ValidationTestFixture.createValidationFileMap();
		
		validationModel.setServiceTypeShortName(null);
		when(validationRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateValidationDetail.validateValidationDetails(filesMapValidation, validationModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		logger.debug("JUnit: testValidateValidationDetailsInvalidParam Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateValidationDetails Empty Validation Code Test")
	public void testValidateValidationDetailsEmptyValidationCode() throws Exception {
		
		logger.debug("JUnit: testValidateValidationDetailsEmptyValidationCode Test Started");
		
		ValidationModel validationModel=ValidationTestFixture.getRequestValidationModel();
		Map<String, MultipartFile> filesMapValidation=ValidationTestFixture.createValidationFileMap();
		
		validationModel.setValidationCodeDetails(null);
		when(validationRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateValidationDetail.validateValidationDetails(filesMapValidation, validationModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		logger.debug("JUnit: testValidateValidationDetailsEmptyValidationCode Test Completed");
		
	}
	
	@Test
	@DisplayName("JUnit: ValidateValidationDetails Missing Validation File Code Test")
	public void testValidateValidationDetailsMissingValidationFile() throws Exception {
		
		logger.debug("JUnit: testValidateValidationDetailsMissingValidationFile Test Started");
		
		ValidationModel validationModel=ValidationTestFixture.getRequestValidationModel();
		Map<String, MultipartFile> filesMapValidation=new HashMap<String, MultipartFile>();
		when(validationRepository.findByUniqueId(Mockito.anyString())).thenReturn(null);
		IllegalArgumentException iAE= assertThrows(IllegalArgumentException.class, () -> {
			validateValidationDetail.validateValidationDetails(filesMapValidation, validationModel);
        });
		
		assertEquals(IllegalArgumentException.class,iAE.getClass());
		logger.debug("JUnit: testValidateValidationDetailsMissingValidationFile Test Completed");
		
	}

}
