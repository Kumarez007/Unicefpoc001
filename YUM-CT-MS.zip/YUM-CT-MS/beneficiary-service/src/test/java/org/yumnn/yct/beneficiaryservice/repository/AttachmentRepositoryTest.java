package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.Attachment;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

import junit.framework.AssertionFailedError;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 13, 2021 1:43:06 PM
 */
@DataJpaTest
public class AttachmentRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(AttachmentRepositoryTest.class);
	
	@Autowired
	private AttachmentRepository repo = null;
	
	private Attachment attachment=null;
	
	@Test
	public void testFindByReferenceIdAndReferenceTypeAndIsActive() {
		logger.info("Inside testFindByReferenceIdAndReferenceTypeAndIsActive");
		Attachment result= repo.findByReferenceIdAndReferenceTypeAndIsActive(2L,"admissionFile1",YesNoEnum.YES);
		assertNotNull(result);
	}
	
	@Test
	public void testFindByReferenceIdNullAndReferenceTypeAndIsActive() {
		logger.info("Inside testFindByReferenceIdNullAndReferenceTypeAndIsActive");
		Attachment result= repo.findByReferenceIdAndReferenceTypeAndIsActive(null,"admissionFile1",YesNoEnum.YES);
		assertNull(result);
	}
	
	@Test
	public void testFindByReferenceIdAndReferenceTypeAndIsNotActive() {
		logger.info("Inside testFindByReferenceIdAndReferenceTypeAndIsNotActive");
		Attachment result= repo.findByReferenceIdAndReferenceTypeAndIsActive(2L,"admissionFile1",YesNoEnum.NO);
		assertNull(result);
	}
	
	@Test
	public void testFindByReferenceIdAndInvalidReferenceTypeAndIsActive() {
		logger.info("Inside testFindByReferenceIdAndInvalidReferenceTypeAndIsActive");
		Attachment result= repo.findByReferenceIdAndReferenceTypeAndIsActive(2L,"admissionFile1111",YesNoEnum.YES);
		assertNull(result);
	}
	
	@Test
	public void testSaveAttachmentBasic() throws Exception {
		logger.info("Inside testSaveAttachment Basic");
		
		setUpEntity();
		
		Attachment result= repo.save(attachment);
		assertNotNull(result);
		logger.debug("save successful");
	}
	
	@Test
	public void testSaveAttachmentFail() throws Exception {
		logger.info("Inside testSaveAttachment Not Null Contraint Violation");
		
		setUpEntity();
		attachment.setFile(null);
		try {
			repo.save(attachment);
		}
		catch(Exception e) {
			assertNotNull(e);
			logger.debug("Error in save");
		}
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		attachment = new Attachment();
		attachment.setId(100L);
		attachment.setCreatedBy(user);
		attachment.setCreatedAt(new Date());
		attachment.setFile("dummy");
		attachment.setFileSize(1L);
		attachment.setFileMimeType("dummy");
		attachment.setExtension(".txt");
		attachment.setIsActive(YesNoEnum.YES);
		attachment.setReferenceId(2L);
		attachment.setReferenceType("admissionFile1");
		attachment.setName("dummy");
	}
	
	@Test
	public void testGetAttachmentByReferenceIdAndReferenceType() {
		logger.info("Inside testgetAttachmentByReferenceIdAndReferenceType");
		List<Attachment> result= repo.getAttachmentByReferenceIdAndReferenceType(2L,"admissionFile");
		assertNotNull(result);
	}
	
	@Test
	public void testGetAttachmentByReferenceIdAndInvalidReferenceType() {
		logger.info("Inside testgetAttachmentByReferenceIdAndInvalidReferenceType");
		List<Attachment> result= repo.getAttachmentByReferenceIdAndReferenceType(2L,"admissionFile1111");
		assertTrue(result.size()<1);
	}
	
}