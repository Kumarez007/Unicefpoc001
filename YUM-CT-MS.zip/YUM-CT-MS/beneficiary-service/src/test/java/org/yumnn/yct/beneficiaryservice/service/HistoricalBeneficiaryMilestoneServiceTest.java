package org.yumnn.yct.beneficiaryservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.yumnn.yct.beneficiaryservice.entity.history.HistoricalBeneficiaryMilestone;
import org.yumnn.yct.beneficiaryservice.enumeration.milestoneEnum.MilestoneTypeEnum;
import org.yumnn.yct.beneficiaryservice.model.BeneficiaryTimelineModel;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.repository.HistoricalBeneficiaryMilestoneRepository;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.model.historical.HistoricalBeneficiaryModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Aug 16, 2021 6:50:50 PM
 */

@ExtendWith(MockitoExtension.class)
public class HistoricalBeneficiaryMilestoneServiceTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@InjectMocks
	private HistoricalBeneficiaryMilestoneService historicalBeneficiaryMilestoneService = null;
	
	@Mock
	private HistoricalBeneficiaryMilestoneRepository historicalBeneficiaryMilestoneRepository=null;

	
	@DisplayName("testSaveHistoricalBeneficiaryModel Test for Basic Operation")
	@Test
	public void testSaveHistoricalBeneficiaryModelBasic() throws Exception {
		
		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelBasic");
		
		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setCurrentFormId(1L);
		historicalBeneficiaryModel.setBookletId(1L);
		historicalBeneficiaryModel.setMilestoneReferenceId(1L);
		historicalBeneficiaryModel.setCycleId(1L);
		
		historicalBeneficiaryModel.setMilestoneType(MilestoneTypeEnum.ENROLLMENT.toString());	
		
		HistoricalBeneficiaryMilestone historicalBeneficiaryMilestone = new HistoricalBeneficiaryMilestone();
		historicalBeneficiaryMilestone.setId(1L);
			
		when(historicalBeneficiaryMilestoneRepository.save(Mockito.any(HistoricalBeneficiaryMilestone.class))).thenReturn(historicalBeneficiaryMilestone);
			
		//call service
		historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);

		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelBasic - Completed");
		
	}
	
	@DisplayName("testSaveHistoricalBeneficiaryModel Test for Fail Process Operation")
	@Test
	public void testSaveHistoricalBeneficiaryModelFailProcess() throws Exception {
		
		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelFailProcess");
		
		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setCurrentFormId(1L);
		historicalBeneficiaryModel.setBookletId(1L);
		historicalBeneficiaryModel.setMilestoneReferenceId(1L);
		historicalBeneficiaryModel.setCycleId(1L);
		
		historicalBeneficiaryModel.setMilestoneType(MilestoneTypeEnum.ENROLLMENT.toString());	
		
		HistoricalBeneficiaryMilestone historicalBeneficiaryMilestone = new HistoricalBeneficiaryMilestone();
			
		when(historicalBeneficiaryMilestoneRepository.save(historicalBeneficiaryMilestone)).thenReturn(historicalBeneficiaryMilestone);
			
		//call service
		FailProcessException fPE= assertThrows(FailProcessException.class, () -> {
			historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);
        });
			
		assertEquals(FailProcessException.class, fPE.getClass());
			
		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelFailProcess - Completed");
		
	}
	
	@DisplayName("testSaveHistoricalBeneficiaryModel Test for Invalid Param Operation")
	@Test
	public void testSaveHistoricalBeneficiaryModelInvalidParam() throws Exception {
		
		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelInvalidParam");
		
		HistoricalBeneficiaryModel historicalBeneficiaryModel = new HistoricalBeneficiaryModel();
		historicalBeneficiaryModel.setMilestoneType("TEST_MILESTONE");
		
		//call service
		IllegalArgumentException illegalArgumentException= assertThrows(IllegalArgumentException.class, () -> {
			historicalBeneficiaryMilestoneService.saveHistoricalBeneficiaryModel(historicalBeneficiaryModel);
        });
			
		assertEquals(IllegalArgumentException.class, illegalArgumentException.getClass());
			
		logger.debug("JUnit: testSaveHistoricalBeneficiaryModelInvalidParam - Completed");
		
	}
	
	@DisplayName("Get Beneficiary Timeline Test for Basic Operation")
	@Test
	public void testGetBeneficiaryTimelineData() throws Exception {
		
		logger.debug("JUnit: testGetBeneficiaryTimelineData");
		
		BeneficiaryTimelineModel beneficiaryTimelineModel=null;
   		
   		List<BeneficiaryTimelineModel> expectedBeneficiaryTimelineModelList= new ArrayList<BeneficiaryTimelineModel>();
   		expectedBeneficiaryTimelineModelList.add(beneficiaryTimelineModel);
		
		when(historicalBeneficiaryMilestoneRepository.getBeneficiaryTimelineData(Mockito.anyLong())).thenReturn(expectedBeneficiaryTimelineModelList);
		
		Map<String, Object> resultResponse=historicalBeneficiaryMilestoneService.getBeneficiaryTimelineData(1L);

		assertNotNull(resultResponse);

		logger.debug("JUnit: testGetBeneficiaryTimelineData - Completed");
	}
}
