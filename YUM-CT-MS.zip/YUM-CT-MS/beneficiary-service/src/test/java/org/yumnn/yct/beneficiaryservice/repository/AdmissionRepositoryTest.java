package org.yumnn.yct.beneficiaryservice.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.Admission;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.entity.ReasonsNonAdmission;
import org.yumnn.yct.beneficiaryservice.entity.Validation;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 13, 2021 1:19:58 PM
 */
@DataJpaTest
public class AdmissionRepositoryTest {
	private static Logger logger = LoggerFactory.getLogger(AdmissionRepositoryTest.class);
	
	@Autowired
	private AdmissionRepository repo = null;
	
	private Admission admission=null;
	
	@Test
	public void testFindById() {
		logger.info("Inside testFindById()");
		Optional<Admission> result = repo.findById(2L);
		assertTrue(result.isPresent());
	}
	
	@Test
	public void testFindByWrongId() {
		logger.info("Inside testFindByWrongId()");
		Optional<Admission> result= repo.findById(10L);
		assertFalse(result.isPresent());
	}
	
	@Test
	public void testSaveAdmission() throws Exception {
		logger.info("Inside testSaveAdmission");
		
		setUpEntity();
	
		Admission result= repo.save(admission);
		assertNotNull(result);
	}
	
	@Test
	public void testFindByUniqueId() {
		logger.info("Inside testFindByUniqueId()");
		Admission result = repo.findByUniqueId("1");
		assertNotNull(result);
	}
	
	@Test
	public void testFindByUniqueIdNull() {
		logger.info("Inside testFindByUniqueIdNull()");
		Admission result = repo.findByUniqueId(null);
		assertNull(result);
	}
	
	private void setUpEntity() throws Exception {
		
		User user = new User();
		user.setId(1L);
		
		Enrollment enrollment = new Enrollment();
		enrollment.setId(2L);
		
		ReasonsNonAdmission reasonsNonAdmission = new ReasonsNonAdmission();
		reasonsNonAdmission.setId(1L);

		admission = new Admission();
		admission.setId(100L);
		admission.setCreatedBy(user);
		admission.setCreatedAt(new Date());
		admission.setEnrollment(enrollment);
		admission.setIsAdmitted(YesNoEnum.NO);
		admission.setNonAdmissionReason(reasonsNonAdmission);
	}

}
