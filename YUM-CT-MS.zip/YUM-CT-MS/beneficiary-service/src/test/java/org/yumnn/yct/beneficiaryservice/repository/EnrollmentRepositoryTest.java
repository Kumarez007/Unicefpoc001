package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.Enrollment;
import org.yumnn.yct.beneficiaryservice.model.HouseholdCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByServiceCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.SearchModel;
import org.yumnn.yct.common.entity.administration.ProgramEntity;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.DateFormatterUtil;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 12:05:33 AM
 */

@DataJpaTest
public class EnrollmentRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(EnrollmentRepositoryTest.class);
	
	@Autowired
	private EnrollmentRepository repo = null;
	
	private Enrollment enrollment=null;
	
	@Test
	public void testFindById() {
		logger.info("Inside testFindById()");
		Optional<Enrollment> result = repo.findById(2L);
		assertTrue(result.isPresent());
	}
	
	@Test
	public void testFindByWrongId() {
		logger.info("Inside testFindByWrongId()");
		Optional<Enrollment> result= repo.findById(10L);
		assertFalse(result.isPresent());
	}
	
	@Test
	public void testFindByEnrollmentCode() {
		logger.info("Inside testFindByEnrollmentCode");
		Enrollment result= repo.findByEnrollmentCode("2");
		assertNotNull(result);
	}
	
	@Test
	public void testFindByIncorrectEnrollmentCode() {
		logger.info("Inside testFindByIncorrectEnrollmentCode");
		Enrollment result= repo.findByEnrollmentCode("10");
		assertNull(result);
	}
	
	@Test
	public void testGetEnrollmentDataByBookletAndVCA() {
		logger.info("Inside testGetEnrollmentDataByBookletAndVCA");
		List<SearchModel> result= repo.getEnrollmentDataByBookletAndVCA("300-101-100105");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByWrongBookletAndVCA() {
		logger.info("Inside testGetEnrollmentDataByWrongBookletAndVCA");
		List<SearchModel> result= repo.getEnrollmentDataByBookletAndVCA("300-101-100105111");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetAllEnrollmentData() {
		logger.info("Inside testGetAllEnrollmentData");
		List<SearchModel> result= repo.getAllEnrollmentData();
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByNameAndGeolocation() {
		logger.info("Inside testGetEnrollmentDataByNameAndGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByNameAndGeolocation("John1","Test",1L);
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByNameAndInvalidGeolocation() {
		logger.info("Inside testGetEnrollmentDataByNameAndInvalidGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByNameAndGeolocation("John1","Test",10L);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByInvalidNameAndGeolocation() {
		logger.info("Inside testGetEnrollmentDataByInvalidNameAndGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByNameAndGeolocation("xyzzzz","pqr",1L);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByFirstNameAndGeolocation() {
		logger.info("Inside testGetEnrollmentDataByFirstNameAndGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByFirstNameAndGeolocation("John1",1L);
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void getEnrollmentDataByFirstNameAndInvalidGeolocation() {
		logger.info("Inside getEnrollmentDataByFirstNameAndInvalidGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByFirstNameAndGeolocation("John1",10L);
		assertTrue(result.isEmpty()); 
	}
	
	@Test
	public void testGetEnrollmentDataByInvalidFirstNameAndGeolocation() {
		logger.info("Inside testGetEnrollmentDataByInvalidFirstNameAndGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByFirstNameAndGeolocation("xyzzzz",1L);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByName() {
		logger.info("Inside testGetEnrollmentDataByName");
		List<SearchModel> result= repo.getEnrollmentDataByName("John1","Test");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void getEnrollmentDataByInvalidName() {
		logger.info("Inside getEnrollmentDataByInvalidName");
		List<SearchModel> result= repo.getEnrollmentDataByName("Test1","Tesssst");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByFirstName() {
		logger.info("Inside testGetEnrollmentDataByFirstName");
		List<SearchModel> result= repo.getEnrollmentDataByFirstName("John1");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByWrongFirstName() {
		logger.info("Inside testGetEnrollmentDataByWrongFirstName");
		List<SearchModel> result= repo.getEnrollmentDataByFirstName("Williams11111");
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByGeolocation() {
		logger.info("Inside testGetEnrollmentDataByGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByGeolocation(1L);
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetEnrollmentDataByWrongGeolocation() {
		logger.info("Inside testGetEnrollmentDataByWrongGeolocation");
		List<SearchModel> result= repo.getEnrollmentDataByGeolocation(10L);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testSaveEnrollment() throws Exception {
		logger.info("Inside testSaveEnrollment");
		
		setUpEntity();
	
		Enrollment result= repo.save(enrollment);
		
		assertNotNull(result);
	}
	
	@Test
	public void testGetHouseholdCardInfo() {
		logger.info("Inside testGetHouseholdCardInfo");
		List<HouseholdCardInfoModel> result= repo.getHouseholdCardInfo(2L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetHouseholdCardInfoByIncorrectCurForm() {
		logger.info("Inside testGetHouseholdCardInfoByIncorrectCurForm");
		List<HouseholdCardInfoModel> result= repo.getHouseholdCardInfo(20L);
		assertTrue(result.size()==0);
	}
	
	@Test
	public void testGetPrimaryMemberName() {
		logger.info("Inside testGetPrimaryMemberName");
		String result= repo.getPrimaryMemberName(2L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetPrimaryMemberNameByIncorrectCurForm() {
		logger.info("Inside testGetPrimaryMemberNameByIncorrectCurForm");
		String result= repo.getPrimaryMemberName(20L);
		assertNull(result);
	}
	
	@Test
	public void testGetBeneficiaryGeoLocation() {
		logger.info("Inside testGetBeneficiaryGeoLocation");
		Long result= repo.getBeneficiaryGeoLocation(2L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetBeneficiaryGeoLocationByIncorrectCurForm() {
		logger.info("Inside testGetBeneficiaryGeoLocationByIncorrectCurForm");
		Long result= repo.getBeneficiaryGeoLocation(20L);
		assertNull(result);
	}
	
	@Test
	public void testGetPaymentByServiceCardInfo() {
		logger.info("Inside testGetPaymentByServiceCardInfo");
		List<PaymentByServiceCardInfoModel> result= repo.getPaymentByServiceCardInfo(2L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetPaymentByServiceCardInfoByIncorrectCurForm() {
		logger.info("Inside testGetPaymentByServiceCardInfoByIncorrectCurForm");
		List<PaymentByServiceCardInfoModel> result= repo.getPaymentByServiceCardInfo(20L);
		assertTrue(result.size()==0);
	}
	
	@Test
	public void testFindByUniqueId() {
		logger.info("Inside testFindByUniqueId()");
		Enrollment result = repo.findByUniqueId("1");
		assertNotNull(result);
	}
	
	@Test
	public void testFindByUniqueIdNull() {
		logger.info("Inside testFindByUniqueIdNull()");
		Enrollment result = repo.findByUniqueId(null);
		assertNull(result);
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		Booklet booklet=new Booklet();
		booklet.setId(1L);
		
		ProgramEntity programEntity=new ProgramEntity();
		programEntity.setId(1L);
		
		Geolocation geolocation=new Geolocation();
		geolocation.setId(1L);
		
		enrollment = new Enrollment();
		enrollment.setId(100L);
		enrollment.setCreatedBy(user);
		enrollment.setCreatedAt(new Date());
		enrollment.setEnrollmentCode("1");
		enrollment.setIsRefferdFromOtherTFC(YesNoEnum.YES);
		enrollment.setOtpReferenceNumber("999-999-999");
		enrollment.setOtpNutritionOfficerName("JUnit Tester");
		enrollment.setOtpNutritionOfficerPhoneNumber("701234567");
		enrollment.setOtpNutritionOfficerRefrenceNumber("999-999-999");
		
		enrollment.setPlaceOfAdmission(programEntity);
		enrollment.setIsRequireInvestigation(YesNoEnum.NO);
		enrollment.setProgramEntity(programEntity);
		enrollment.setGeoLocationOTP(geolocation);
		
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		enrollment.setCurrentForm(currentForm);
		enrollment.setBooklet(booklet);
		enrollment.setComments("JUnit Testing");
	}
	
}
