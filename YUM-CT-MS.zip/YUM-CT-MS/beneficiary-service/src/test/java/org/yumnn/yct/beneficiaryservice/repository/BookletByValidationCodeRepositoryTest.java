package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.entity.BookletByValidationCode;
import org.yumnn.yct.beneficiaryservice.enumeration.ValidationCodeTypeEnum;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.exception.FailProcessException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 13, 2021 1:59:34 PM
 */
@DataJpaTest
public class BookletByValidationCodeRepositoryTest {
private static Logger logger = LoggerFactory.getLogger(BookletByValidationCodeRepositoryTest.class);
	
	@Autowired
	private BookletByValidationCodeRepository repo = null;
	
	private BookletByValidationCode bookletByValidationCode=null;
	
	@Test
	public void testFindByValidationCodeAndIsActive() {
		logger.info("Inside testFindByValidationCodeAndIsActive");
		BookletByValidationCode result= repo.findByValidationCodeAndIsActive("211035972", YesNoEnum.YES);
		assertEquals("211035972",result.getValidationCode());
	}
	
	@Test
	public void testFindByValidationCodeAndIsNotActive() {
		logger.info("Inside testFindByValidationCodeAndIsNotActive");
		BookletByValidationCode result= repo.findByValidationCodeAndIsActive("211035972", YesNoEnum.NO);
		assertNull(result);
	}
	
	@Test
	public void testFindByValidationCodeAndIsActiveAndIsUsed() {
		logger.info("Inside testFindByValidationCodeAndIsActiveAndIsUsed");
		BookletByValidationCode result= repo.findByValidationCodeAndIsActiveAndIsUsed("211035972", YesNoEnum.YES,YesNoEnum.NO);
		assertEquals("211035972",result.getValidationCode());
	}
	
	@Test
	public void testFindByValidationCodeAndIsActiveAndIsNotUsed() {
		logger.info("Inside testFindByValidationCodeAndIsActiveAndIsNotUsed");
		BookletByValidationCode result= repo.findByValidationCodeAndIsActiveAndIsUsed("211035972", YesNoEnum.YES,YesNoEnum.YES);
		assertNull(result);
	}
	
	@Test
	public void testFindByVca() {
		logger.info("Inside testFindByVca");
		List<BookletByValidationCode> result= repo.findByVca("300-101-100105");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testFindByVcaNull() {
		logger.info("Inside testFindByVca");
		List<BookletByValidationCode> result= repo.findByVca(null);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testUpadteRedeemedValue() throws FailProcessException {
		logger.info("Inside testUpadteRedeemedValue");
		try{
			repo.upadteRedeemedValue(YesNoEnum.YES, 5L);
			Optional<BookletByValidationCode> resultOpt = repo.findById(5L);
			BookletByValidationCode result=resultOpt.orElse(null);
			assertEquals("YES",result.getIsRedeemed().getValue().toUpperCase());
		}
		catch(FailProcessException e) {
			logger.info("Exception in testUpadteRedeemedValue");
		}
	}
	
	@Test
	public void testUpadteRedeemedValueByCode() throws FailProcessException {
		logger.info("Inside testUpadteRedeemedValue");
		try{
			repo.upadteRedeemedValueByCode(YesNoEnum.YES, "611034595");
			BookletByValidationCode result = repo.findByValidationCodeAndIsActive("611034595", YesNoEnum.YES);
			assertEquals("YES",result.getIsRedeemed().getValue().toUpperCase());
		}
		catch(FailProcessException e) {
			logger.info("Exception in testUpadteRedeemedValue");
		}
	}
	
	@Test
	public void testUpadteRedeemedValueByInvalidCode() throws FailProcessException {
		logger.info("Inside testUpadteRedeemedValueByInvalidCode");
		try{
			repo.upadteRedeemedValueByCode(YesNoEnum.YES, "61103459500");
			BookletByValidationCode result = repo.findByValidationCodeAndIsActive("61103459500", YesNoEnum.YES);
			assertNull(result);
		}
		catch(FailProcessException e) {
			logger.info("Exception in testUpadteRedeemedValueByInvalidCode");
		}
	}
	
	@Test
	public void testSaveBookletByValidationCode() throws Exception {
		logger.info("Inside testSaveBookletByValidationCode");
		
		setUpEntity();
	
		BookletByValidationCode result= repo.save(bookletByValidationCode);
		
		assertNotNull(result);
	}
	
	private void setUpEntity() throws Exception {
	
		User user = new User();
		user.setId(1L);
		
		Booklet booklet=new Booklet();
		booklet.setId(1L);
		
		bookletByValidationCode = new BookletByValidationCode();
		bookletByValidationCode.setId(100L);
		bookletByValidationCode.setBooklet(booklet);
		bookletByValidationCode.setIsActive(YesNoEnum.YES);
		bookletByValidationCode.setIsUsed(YesNoEnum.NO);
		bookletByValidationCode.setValidationCode("111-1234-0000");
		bookletByValidationCode.setValidationCodeType(ValidationCodeTypeEnum.OTP);
		bookletByValidationCode.setIsPrinted(YesNoEnum.NO);
		bookletByValidationCode.setIsRedeemed(YesNoEnum.NO);
		bookletByValidationCode.setOrderItem(1);
	}
	
}
