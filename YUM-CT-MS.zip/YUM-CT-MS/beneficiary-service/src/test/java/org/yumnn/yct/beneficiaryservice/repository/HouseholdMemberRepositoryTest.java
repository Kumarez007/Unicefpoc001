package org.yumnn.yct.beneficiaryservice.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.yumnn.yct.beneficiaryservice.model.MemberCardInfoModel;
import org.yumnn.yct.beneficiaryservice.model.PaymentByServiceCardInfoModel;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.catalog.Gender;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.SourceTypeEnum;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 15, 2021 1:02:14 AM
 */

@DataJpaTest
public class HouseholdMemberRepositoryTest {
	
private static Logger logger = LoggerFactory.getLogger(HouseholdMemberRepositoryTest.class);
	
	@Autowired
	private HouseholdMemberRepository repo = null;
	
	private HouseholdMember householdMember=null;
	
	@Test
	public void testFindByMemberCode() {
		logger.info("Inside testFindByMemberCode");
		HouseholdMember result= repo.findByMemberCode("1");
		assertNotNull(result);
	}
	
	@Test
	public void testFindByIncorrectMemberCode() {
		logger.info("Inside testFindByIncorrectMemberCode");
		HouseholdMember result= repo.findByMemberCode("10");
		assertNull(result);
	}
	
	@Test
	public void testGetHouseholdMemberId() {
		logger.info("Inside testGetHouseholdMemberId");
		Long result= repo.getHouseholdMemberId(2L,1L);
		assertNotNull(result);
	}
	

	@Test
	public void testGetHouseholdMemberIdByIncorrectType() {
		logger.info("Inside testGetHouseholdMemberIdByIncorrectType");
		Long result= repo.getHouseholdMemberId(2L,10L);
		assertNull(result);
	}
	
	@Test
	public void testGetHouseholdMemberIdByIncorrectCurFormId() {
		logger.info("Inside testGetHouseholdMemberIdByIncorrectCurFormId");
		Long result= repo.getHouseholdMemberId(20L,1L);
		assertNull(result);
	}
	
	@Test
	public void testFindByCurrentForm() {
		logger.info("Inside testFindByCurrentForm");
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		List<HouseholdMember> result= repo.findByCurrentForm(currentForm);
		assertFalse(result.isEmpty());
	}
	

	@Test
	public void testFindByInvalidCurrentForm() {
		logger.info("Inside testFindByInvalidCurrentForm");
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(20L);
		List<HouseholdMember> result= repo.findByCurrentForm(currentForm);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testFindByCurrentFormAsNull() {
		logger.info("Inside testFindByCurrentFormAsNull");
		List<HouseholdMember> result= repo.findByCurrentForm(null);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testSaveHouseholdMemberBasic() throws Exception {
		logger.info("Inside testSaveHouseholdMemberBasic");
		
		setUpEntity();
	
		HouseholdMember result= repo.save(householdMember);
		
		assertNotNull(result);
	}
	
	@Test
	public void testSaveHouseholdMemberFail() throws Exception {
		logger.info("Inside testSaveHouseholdMember Not Null Contraint Violation");
		
		setUpEntity();
		
		householdMember.setCurrentForm(null);
		try {
			repo.save(householdMember);
		}
		catch(Exception e) {
			assertNotNull(e);
			logger.debug("Error in save");
		}
	}
	
	@Test
	public void testFindByCurrentFormAndHouseholdMemberType() {
		logger.info("Inside testFindByCurrentFormAndHouseholdMemberType");
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		
		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(2L);
		
		HouseholdMember result= repo.findByCurrentFormAndHouseholdMemberType(currentForm,householdMemberType);
		assertNotNull(result);
	}
	

	@Test
	public void testFindByCurrentFormAndInvalidHouseholdMemberType() {
		logger.info("Inside testFindByCurrentFormAndInvalidHouseholdMemberType");
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		
		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(20L);
		
		HouseholdMember result= repo.findByCurrentFormAndHouseholdMemberType(currentForm,householdMemberType);
		assertNull(result);
	}
	
	@Test
	public void testGetEnrollmentHouseholdDetailsBasic() {
		logger.info("Inside testGetEnrollmentHouseholdDetailsBasic");
		
		List<HouseholdMember> result= repo.getEnrollmentHouseholdDetails(2L,"");
		assertFalse(result.isEmpty());
	}
	
	@Test
	public void testGetAdmissionHouseholdDetailsForNull() {
		logger.info("Inside testGetAdmissionHouseholdDetailsForNull");
		
		List<HouseholdMember> result= repo.getAdmissionHouseholdDetails(2L,1L,"");
		assertTrue(result.size()<1);
	}
	
	@Test
	public void testUpdateHouseholdSourceForError() {
		logger.info("Inside testUpdateHouseholdSourceForError");
		
		try {
			CurrentForm currentForm=new CurrentForm();
			currentForm.setId(2L);
			repo.updateHouseholdSource(2L,SourceTypeEnum.ADMISSION,currentForm);
		}
		catch(Exception e) {
			assertNotNull(e);
			logger.debug("Error in save");
		}
		
	}
	
	@Test
	public void testGetMemberCardInfo() {
		logger.info("Inside testGetMemberCardInfo");
		List<MemberCardInfoModel> result= repo.getMemberCardInfo(2L);
		assertNotNull(result);
	}
	
	@Test
	public void testGetMemberCardInfoByIncorrectCurForm() {
		logger.info("Inside testGetMemberCardInfoByIncorrectCurForm");
		List<MemberCardInfoModel> result= repo.getMemberCardInfo(20L);
		assertTrue(result.size()==0);
	}
	
	private void setUpEntity() throws Exception {
		

		User user = new User();
		user.setId(1L);

		HouseholdMemberType householdMemberType=new HouseholdMemberType();
		householdMemberType.setId(1L);
		
		Gender gender=new Gender();
		gender.setId(1L);
		
		Documents documents=new Documents();
		documents.setId(1L);
		
		CurrentForm currentForm=new CurrentForm();
		currentForm.setId(2L);
		
		householdMember = new HouseholdMember();
		householdMember.setId(100L);
		householdMember.setFirstName("JUnit");
		householdMember.setLastName("Child");
		householdMember.setGender(gender);
		householdMember.setDateOfBirth(new Date());
		householdMember.setDocument(documents);
		householdMember.setDocumentReferenceNumber("123");
		householdMember.setHouseholdMemberType(householdMemberType);
		householdMember.setCurrentForm(currentForm);
		householdMember.setIsAssignedAsPaymentReceiver(YesNoEnum.NO);
		householdMember.setCreatedBy(user);
		householdMember.setCreatedAt(new Date());
		householdMember.setIsPrimary(YesNoEnum.NO);
	}
	

}
