package org.yumnn.yct.beneficiaryservice.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.yumnn.yct.beneficiaryservice.fixture.ValidationTestFixture;
import org.yumnn.yct.beneficiaryservice.model.SyncModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationCodeModel;
import org.yumnn.yct.beneficiaryservice.model.ValidationModel;
import org.yumnn.yct.beneficiaryservice.model.VcaMonitoringDataModel;
import org.yumnn.yct.beneficiaryservice.service.ValidationService;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SuccessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 16, 2021 6:46:10 PM
 */

@WebMvcTest(value = ValidationController.class)
public class ValidationControllerTest {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	ValidationService validationService;
	
	private Map<String, String> requestHeader=null;
	private HttpHeaders header=null;
	private Map<String, Object> mockResponse=null;
	
	private static final String BASE_URI = "/api/v1";
    private static final String SUCCESS_STATUS = "Success";
    private static final String SUCCESS_STATUS_CODE = "200";
    SimpleDateFormat dateFormat = null;
    SimpleDateFormat dateFormatExpiryDate = null;
	
    @BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		requestHeader=new HashMap<String, String>();
		requestHeader.put(ConstantsUtil.LANGUAGE, "1");
		requestHeader.put(ConstantsUtil.APP_VERSION, "v1");
		requestHeader.put(ConstantsUtil.USER_ID_HEADER, "1");
		requestHeader.put(ConstantsUtil.SESSION_TOKEN_HEADER, "abc123456xyz");
		requestHeader.put(ValidationTestFixture.API_ROUTE_GATEWAY, "common-gateway");
		
		header=new HttpHeaders();
		header.setAll(requestHeader);
		
		mockResponse=new HashMap<String, Object>();
		mockResponse.put(ConstantsUtil.VALIDATION_ID, "1");
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testValidateBeneficiary() throws Exception {
		
		logger.debug("JUnit: testValidateBeneficiary");
		
		when(validationService.validateBeneficiary(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(ValidationModel.class))).thenReturn(mockResponse);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/validationControl/validateBeneficiary")
				.file(ValidationTestFixture.getFile("idDocumentFile1"))
				.file(ValidationTestFixture.getFile("treatmentDocFile1"))
				.file(ValidationTestFixture.getFile("uploadVcaFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestValidationModel(requestBuilder);
		
		MvcResult result = mockMvc.perform(request)
				   .andExpect(status().isOk())
				   .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				   .andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);
		
		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
		assertNotNull(successResponse.getData());
		assertEquals("1", successResponse.getData().get(ConstantsUtil.VALIDATION_ID));
	
    	logger.debug("JUnit: testValidateBeneficiary - Completed");
		
	}
    
    @SuppressWarnings("unchecked")
	@Test
	public void testValidateBeneficiaryWithInvalidHeader() throws Exception {
		
		logger.debug("JUnit: testValidateBeneficiaryWithInvalidHeader");
		
		when(validationService.validateBeneficiary(Mockito.any(Map.class),Mockito.any(Map.class), Mockito.any(ValidationModel.class))).thenReturn(mockResponse);
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		RequestBuilder request = MockMvcRequestBuilders.multipart(BASE_URI + "/validationControl/validateBeneficiary")
				.file(ValidationTestFixture.getFile("idDocumentFile1"))
				.file(ValidationTestFixture.getFile("treatmentDocFile1"))
				.file(ValidationTestFixture.getFile("uploadVcaFile1"))
				.headers(header);
		
		MockMultipartHttpServletRequestBuilder requestBuilder=(MockMultipartHttpServletRequestBuilder) request;
		request = getRequestValidationModel(requestBuilder);
		
		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isUnauthorized())
				   .andReturn();
		
		
		assertEquals(401, result.getResponse().getStatus());
	
    	logger.debug("JUnit: testValidateBeneficiaryWithInvalidHeader - Completed");
		
	}
	
	private RequestBuilder getRequestValidationModel(MockMultipartHttpServletRequestBuilder requestBuilder) {

		requestBuilder.param("admissionId", "1");
		requestBuilder.param("serviceTypeShortName", "DISCG");
		requestBuilder.param("dateFrom", "28-07-2021");
		requestBuilder.param("dateTo", "30-07-2021");
		requestBuilder.param("numberOfDays", "2");
		requestBuilder.param("numberOfPeriods", "1");
		requestBuilder.param("doctorName", "Dr Test");
		requestBuilder.param("validationCodeDetails", ValidationTestFixture.returnJson(getValidationCodeDetails()));
		requestBuilder.param("createdBy", requestHeader.get(ConstantsUtil.USER_ID_HEADER));
    	requestBuilder.param("documentShortName", "PASS");
    	requestBuilder.param("documentReferenceNo", "12343");
   
		return requestBuilder;
		
	}
	
	 private List<ValidationCodeModel> getValidationCodeDetails(){
		 
		List<ValidationCodeModel> validationCodeDetailsList = new ArrayList<ValidationCodeModel>();
		
		ValidationCodeModel validationCodeDetails = new ValidationCodeModel();
		validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION);
		validationCodeDetails.setValidationCodeType("OTP");
		validationCodeDetails.setValidationCode("611001061");
		validationCodeDetails.setExpirydate("02-08-2021");
		validationCodeDetailsList.add(validationCodeDetails);
		
		validationCodeDetails = new ValidationCodeModel();
		validationCodeDetails.setReferenceType(ConstantsUtil.REFERENCE_TYPE_VALIDATION);
		validationCodeDetails.setValidationCodeType("PERDIEM");
		validationCodeDetails.setValidationCode("211003844");
		validationCodeDetails.setExpirydate("02-08-2021");
		validationCodeDetailsList.add(validationCodeDetails);
		
		return validationCodeDetailsList;
	}
	 
	@Test
	public void testAddVcaMonitoringLog() throws Exception {
		
		logger.debug("JUnit: testAddVcaMonitoringLog");
		
		VcaMonitoringDataModel vcaMonitoringDataModel=new VcaMonitoringDataModel();
		vcaMonitoringDataModel.setFailedAttempt("1");
		vcaMonitoringDataModel.setViewedAttempt("2");
		vcaMonitoringDataModel.setCreatedBy("1");
		vcaMonitoringDataModel.setCreatedDate("27-08-2021 09:09:30");
		
		doNothing().when(validationService).saveVcaMonitoringLog(Mockito.any(VcaMonitoringDataModel.class));
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/validationControl/addVcaMonitoringLog")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(vcaMonitoringDataModel)))
				.andReturn();
		
		ObjectMapper mapper = new ObjectMapper();
		SuccessResponse successResponse = mapper.readValue(result.getResponse().getContentAsString(), SuccessResponse.class);
		
		verify(validationService,atLeastOnce()).saveVcaMonitoringLog(Mockito.any(VcaMonitoringDataModel.class));
		
		assertEquals(SUCCESS_STATUS, successResponse.getMessage());
		assertEquals(SUCCESS_STATUS_CODE, successResponse.getStatus().toString());
	
    	logger.debug("JUnit: testAddVcaMonitoringLog - Completed");
		
	}
    
	@Test
	public void testAddVcaMonitoringLogWithInvalidHeader() throws Exception {
		
		logger.debug("JUnit: testAddVcaMonitoringLogWithInvalidHeader");
		
		VcaMonitoringDataModel vcaMonitoringDataModel=new VcaMonitoringDataModel();
		
		header.remove(ConstantsUtil.SESSION_TOKEN_HEADER);
		
		doNothing().when(validationService).saveVcaMonitoringLog(Mockito.any(VcaMonitoringDataModel.class));
		
		MvcResult result = mockMvc.perform(post(BASE_URI + "/validationControl/addVcaMonitoringLog")
				.headers(header)
				.contentType(MediaType.APPLICATION_JSON)
				.content(ValidationTestFixture.returnJson(vcaMonitoringDataModel)))
				.andReturn();
		
		assertEquals(401, result.getResponse().getStatus());
	
    	logger.debug("JUnit: testAddVcaMonitoringLogWithInvalidHeader - Completed");
		
	}

}
