package org.yumnn.yct.common.enumeration.uploadInfo;

import org.yumnn.yct.common.exception.FailProcessException;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ClientDeviceTypeEnum.java
 * @class_description
 * @create_date Oct 12, 2017
 * @last_Update Oct 12, 2017
 */
public enum ClientDeviceTypeEnum {
	
	payment_site(3), offline_desktop(2), offline_server(1), mobile(0),external_server(4) , payment_agency_unpaid(5), payment_site_code(6);

	private Integer value;

	private ClientDeviceTypeEnum(Integer value) {
		this.value = value;
	}

	public Integer getValue() {
		return value;
	}

	public static ClientDeviceTypeEnum getByValue(Integer value) throws FailProcessException {
		for (ClientDeviceTypeEnum clientDeviceTypeEnum : ClientDeviceTypeEnum.values()) {
			if (clientDeviceTypeEnum.getValue().equals(value)) {
				return clientDeviceTypeEnum;
			}
		}
		throw new FailProcessException();
	}

}
