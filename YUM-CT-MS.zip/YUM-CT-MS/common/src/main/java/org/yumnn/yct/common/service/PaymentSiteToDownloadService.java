package org.yumnn.yct.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.common.entity.uploadInfo.PaymentSiteToDownload;
import org.yumnn.yct.common.repository.IPaymentSiteToDownloadRepository;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {PaymentSiteToDownloadService.java
 * @create_date May 27, 2021
 * @last_Update May 27, 2021
 */
@Service
public class PaymentSiteToDownloadService {
	@Autowired
	private IPaymentSiteToDownloadRepository iPaymentSiteToDownloadRepository;

	/**
	 * 
	 * @param recordToDownload
	 * @return
	 */
	public PaymentSiteToDownload save(PaymentSiteToDownload recordToDownload) {
		return iPaymentSiteToDownloadRepository.save(recordToDownload);

	}
}
