package org.yumnn.yct.common.enumeration.uploadInfo;

public enum MilestoneTypeEnum {
	
	VERIFICATION("تحقق", "Verification", "VERIFICATION"),
	BENEFICIARY_INFO("معلومات المستفيد", "Beneficiary Information", "BENEFICIARY_INFO"),
	UPL_PAYMENT_INFO("معلومات الدفعة", "Payment Information", "UPL_PAYMENT_INFO"),
	PAYMENT_INFO("معلومات الدفعة", "Payment Information", "PAYMENT_INFO"), GRIEVANCE("شكوى", "Grievance", "GRIEVANCE"),
	ARC_GRIEVANCE("شكوى", "Grievance", "ARC_GRIEVANCE"), ATTENDANCE("الحضور", "Attendance", "ATTENDANCE"),
	FAILED_VERIFICATION("لم يجتاز التحقق", "Failed Verification", "FAILED_VERIFICATION"),
	CM_RECORD("إدارة الحالة", "Case Management", "CM_RECORD"),
	HOUSE_PAYMENT_CONFIRMED("طلب وصول منزلي", "Home Outreach Request", "HOUSE_PAYMENT_CONFIRMED"),
	NON_VERIFICATION("غير متحقق منه", "Non verification", "NON_VERIFICATION"), CVI("CVI", "CVI", "CVI"),
	NON_CVI("Non CVI", "Non CVI", "NON_CVI");

	String labelAr;
	String labelEn;
	String displayName;
	String shortName;

	MilestoneTypeEnum(String labelAr, String labelEn, String shortName) {
		this.labelAr = labelAr;
		this.labelEn = labelEn;
		this.shortName = shortName;
	}

	public String getLabelAr() {
		return labelAr;
	}

	public String getShortName() {
		return this.shortName;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public Object getObject() {
		return this;
	}

	/**
	 * @return the labelEn
	 */
	public String getLabelEn() {
		return labelEn;
	}

	/**
	 * @param labelEn the labelEn to set
	 */
	public void setLabelEn(String labelEn) {
		this.labelEn = labelEn;
	}

	/**
	 * @param labelAr the labelAr to set
	 */
	public void setLabelAr(String labelAr) {
		this.labelAr = labelAr;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
}
