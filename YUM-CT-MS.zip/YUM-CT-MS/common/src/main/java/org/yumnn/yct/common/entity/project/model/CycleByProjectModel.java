package org.yumnn.yct.common.entity.project.model;

import java.util.Date;

/** 
*
* @author Nitin Joshi
* @department PMU - ICT
* @owner UNICEF
* @class_name GeolocationModel.java
* @class_description
* @create_date Sep 09, 2020
* @last_Update Sep 09, 2020
*/

public class CycleByProjectModel {
	
	private Long	id;
	
	private Long	cycleId;
	
	private Long	projectId;
	
	private Date creationDate;
	
	private Date endingDate;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the cycleId
	 */
	public Long getCycleId() {
		return cycleId;
	}

	/**
	 * @param cycleId the cycleId to set
	 */
	public void setCycleId(Long cycleId) {
		this.cycleId = cycleId;
	}

	/**
	 * @return the projectId
	 */
	public Long getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}
	
	

}
