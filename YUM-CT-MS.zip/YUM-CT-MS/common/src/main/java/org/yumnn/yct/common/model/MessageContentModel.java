package org.yumnn.yct.common.model;

import javax.persistence.Column;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {MessageContentModel.java
 * @create_date May 26, 2021
 * @last_Update May 26, 2021
 */
public class MessageContentModel {

	private String textAr;

	private String textEn;
	
	private Long messageContentId;

	@Column(name = "label")
	private String label;

	@Column(name = "code")
	private String code;

	public String getTextAr() {
		return textAr;
	}

	public void setTextAr(String textAr) {
		this.textAr = textAr;
	}

	public String getTextEn() {
		return textEn;
	}

	public void setTextEn(String textEn) {
		this.textEn = textEn;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the messageContentId
	 */
	public Long getMessageContentId() {
		return messageContentId;
	}

	/**
	 * @param messageContentId the messageContentId to set
	 */
	public void setMessageContentId(Long messageContentId) {
		this.messageContentId = messageContentId;
	}
	
}
