package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class ValidationCodeGenerator {


  /**
   * @param serialNumber
   * @return
   */
  public String validationCodeGenerator(String serialNumber) {
    String validationCode = "";
    return validationCode;
  }
}

