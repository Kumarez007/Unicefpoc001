package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

@Entity
@Table(name = "cat_not_verifiable_reason")
@NamedQueries({
		@NamedQuery(name = "NotVerifiableReason.findAllByOrderItem", query = "SELECT r from NotVerifiableReason r order by r.orderItem asc")
})
public class NotVerifiableReason extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	
	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		NotVerifiableReason other = (NotVerifiableReason) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
