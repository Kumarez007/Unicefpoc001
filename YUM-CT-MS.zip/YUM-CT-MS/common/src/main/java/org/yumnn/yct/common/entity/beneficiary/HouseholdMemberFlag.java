/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.beneficiary;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Flag;
import org.yumnn.yct.common.entity.cycle.Cycle;


@Entity
@Table(name = "cur_household_member_flag")
@NamedQueries({ @NamedQuery(name = "HouseholdMemberFlag.getByForm",
		query = "SELECT t FROM HouseholdMemberFlag t WHERE t.currentHouseholdMember.currentForm = :currentForm order by cycle.id desc, t.currentHouseholdMember.firstName asc"),

	@NamedQuery(name = "HouseholdMemberFlag.getFlagsByFormIdActiveCycle",
	query = "SELECT t FROM HouseholdMemberFlag t WHERE t.currentHouseholdMember.currentForm = :currentForm and t.cycle = :cycle"),
	
	@NamedQuery(name= "HouseholdMemberFlag.retrieveByFlagTypeAndHouseHoldMemeberId" , 
	 			 query = "SELECT t FROM HouseholdMemberFlag t WHERE t.currentHouseholdMember.id = :householdMemberId and flag.flagType = :flagType ")
})
public class HouseholdMemberFlag extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_household_member_fk", referencedColumnName = "ID")
	private HouseholdMember currentHouseholdMember;

	@ManyToOne
	@JoinColumn(name = "id_cycle_fk", referencedColumnName="ID")
	private Cycle cycle;
	
	@ManyToOne
	@JoinColumn(name = "id_flag_fk", referencedColumnName="ID")
	private Flag flag;	
	
	@Column(name= "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	/**
	 * @return the currentHouseholdMember
	 */
	public HouseholdMember getCurrentHouseholdMember() {
		return currentHouseholdMember;
	}

	/**
	 * @param currentHouseholdMember the currentHouseholdMember to set
	 */
	public void setCurrentHouseholdMember(HouseholdMember currentHouseholdMember) {
		this.currentHouseholdMember = currentHouseholdMember;
	}

	/**
	 * @return the cycle
	 */
	public Cycle getCycle() {
		return cycle;
	}

	/**
	 * @param cycle the cycle to set
	 */
	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	/**
	 * @return the flag
	 */
	public Flag getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(Flag flag) {
		this.flag = flag;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
