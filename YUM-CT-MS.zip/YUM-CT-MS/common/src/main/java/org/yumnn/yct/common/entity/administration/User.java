/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "user_access.adm_user")
@NamedQueries({
		@NamedQuery(name = "User.findByUsernameAndStatus", query = "SELECT u from User u where u.username = :username and u.isActive = :isActive"),
		@NamedQuery(name = "User.findByUsernameWithoutStatus", query = "SELECT u from User u where u.username = :username "),
		@NamedQuery(name = "User.findActiveUserByUsernameAndPassword", query = "SELECT u from User u where u.username = :username and u.password = :password and u.isActive = :isActive"),
		@NamedQuery(name = "User.findAllActive", query = "SELECT u from User u where u.isActive = :isActive"),
		@NamedQuery(name = "User.findAll", query = "SELECT u from User u"),
		@NamedQuery(name = "User.findMaxId", query = "SELECT max(u.id) from User u"),
		@NamedQuery(name = "User.findByUsernames", query = "SELECT u from User u where u.username in ( :usernames ) ")
		
		
})
public class User extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "user_name", unique = true)
	private String username;

	@Column(name = "user_password")
	private String password;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "session_token")
	private String sessionToken;

	@Column(name = "failed_attempts_for_login")
	private Integer loginAttempt;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_access.adm_user_by_role", joinColumns = { @JoinColumn(name = "id_user_fk") }, inverseJoinColumns = {
			@JoinColumn(name = "id_role_fk") })
	private List<Role> roleList = new ArrayList<Role>();
	
	@ManyToOne
	@JoinColumn(name = "id_geolocation_fk")
	private Geolocation userGeographicalArea;

	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "id_program_entity_fk")
	private ProgramEntity programEntity;

	@Column(name = "phone_number")
	private String phoneNumber;

	@Column(name = "unique_user_signature")
	private String uniqueUserSignature;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;
	
	@Column(name = "user_email", length = 60, columnDefinition = "character varying (60)")
	private String email;


	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the sessionToken
	 */
	public String getSessionToken() {
		return sessionToken;
	}

	/**
	 * @param sessionToken the sessionToken to set
	 */
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	/**
	 * @return the loginAttempt
	 */
	public Integer getLoginAttempt() {
		return loginAttempt;
	}

	/**
	 * @param loginAttempt the loginAttempt to set
	 */
	public void setLoginAttempt(Integer loginAttempt) {
		this.loginAttempt = loginAttempt;
	}

	/**
	 * @return the roleList
	 */
	public List<Role> getRoleList() {
		return roleList;
	}

	/**
	 * @param roleList the roleList to set
	 */
	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}

	/**
	 * @return the userGeographicalAreaId
	 */
	public Geolocation getUserGeographicalArea() {
		return userGeographicalArea;
	}

	/**
	 * @param userGeographicalAreaId the userGeographicalAreaId to set
	 */
	public void setUserGeographicalArea(Geolocation userGeographicalArea) {
		this.userGeographicalArea = userGeographicalArea;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the uniqueUserSignature
	 */
	public String getUniqueUserSignature() {
		return uniqueUserSignature;
	}

	/**
	 * @param uniqueUserSignature the uniqueUserSignature to set
	 */
	public void setUniqueUserSignature(String uniqueUserSignature) {
		this.uniqueUserSignature = uniqueUserSignature;
	}

	public ProgramEntity getCatalogProgramEntity() {
		return programEntity;
	}

	public void setCatalogProgramEntity(ProgramEntity programEntity) {
		this.programEntity = programEntity;
	}

	public ProgramEntity getProgramEntity() {
		return programEntity;
	}

	public void setProgramEntity(ProgramEntity programEntity) {
		this.programEntity = programEntity;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
