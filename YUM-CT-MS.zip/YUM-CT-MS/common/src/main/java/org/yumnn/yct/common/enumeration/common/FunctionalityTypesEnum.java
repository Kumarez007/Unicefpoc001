package org.yumnn.yct.common.enumeration.common;

public enum FunctionalityTypesEnum {

    MANAGE_BENEFICERIES("Manage Beneficeries", "Manage Beneficeries"),
    ADD_BENEFICIARY("Add Beneficiary", "Add Beneficiary"),
    EDIT_BENEFICIARY("Edit Beneficiary", "Edit Beneficiary"),
    VIEW_BENEFICIARY("View Beneficiary", "View Beneficiary"),
    MANAGE_USERS("Manage Users", "Manage Users"),
    MANAGE_ROLES("Manage Roles", "Manage Roles"),
    MANAGE_POSSIBLE_DUPLICATES("Manage Possible Duplicates", "Manage Possible Duplicates"),
    ADMIN("Administrator", "ADMIN"),
    MANAGE_GRIEVANCE("Manage Grievance", "Manage Grievance"),
    SUBMIT_GRIEVANCE("Submit grievance", "Submit grievance"),
    FOLLOW_UP_ON_GRIEVANCE("Follow up on grievance", "Follow up on grievance"),
    APPROVE_GRIEVANCE_CLOSURE("Approve grievance closure", "Approve grievance closure"),
    INBOX("Inbox", "Inbox"), CM_INBOX("CM Inbox", "CM Inbox"), VIEW_CM_CASES("View CM Cases", "View CM Cases");

    private String value;
    private String arValue;

    FunctionalityTypesEnum(String functionalityName, String arfunctionalityName) {
        this.value = functionalityName;
        this.arValue = arfunctionalityName;
    }

    public String getValue() {
        return value;
    }

    public String getArValue() {
        return this.value + " - " + this.arValue;
    }

}
