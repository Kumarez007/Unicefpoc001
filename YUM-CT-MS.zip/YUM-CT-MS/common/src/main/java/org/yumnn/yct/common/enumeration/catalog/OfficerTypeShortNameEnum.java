/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License; Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing; software
 * distributed under the License is distributed on an "AS IS" BASIS; WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND; either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.enumeration.catalog;

import java.util.ArrayList;
import java.util.List;

public enum OfficerTypeShortNameEnum {

	facilitation_officer, bsgr_officer, tmp_officer, call_officer,
	grievance_redressal_officer;

	// old version
	public static List<OfficerTypeShortNameEnum> getListForOldVersion() {
		List<OfficerTypeShortNameEnum> list = new ArrayList<OfficerTypeShortNameEnum>();

		list.add(facilitation_officer);
		list.add(bsgr_officer);
		list.add(tmp_officer);
		list.add(call_officer);
		return list;
	}

	//// new version
	public static List<OfficerTypeShortNameEnum> getListForNewVersion() {
		List<OfficerTypeShortNameEnum> list = new ArrayList<OfficerTypeShortNameEnum>();
		list.add(call_officer);
		list.add(grievance_redressal_officer);
		return list;

	}

}
