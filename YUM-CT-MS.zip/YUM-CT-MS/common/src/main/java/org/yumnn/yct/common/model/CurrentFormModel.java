package org.yumnn.yct.common.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CurrentFormModel {

	private String id;
	private String projectShortName;
	private String createdBy;
	private String createdDate;
	private Long bookletId;
	
	@JsonIgnore
	private Date enrollDate;
	private Long projectId;

	@Override
	public String toString() {
		return "CurrentFormModel [id=" + id + ", projectShortName=" + projectShortName + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", bookletId=" + bookletId + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectShortName() {
		return projectShortName;
	}

	public void setProjectShortName(String projectShortName) {
		this.projectShortName = projectShortName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the bookletId
	 */
	public Long getBookletId() {
		return bookletId;
	}

	/**
	 * @param bookletId the bookletId to set
	 */
	public void setBookletId(Long bookletId) {
		this.bookletId = bookletId;
	}

	/**
	 * @return the projectId
	 */
	public Long getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the enrollDate
	 */
	public Date getEnrollDate() {
		return enrollDate;
	}

	/**
	 * @param enrollDate the enrollDate to set
	 */
	public void setEnrollDate(Date enrollDate) {
		this.enrollDate = enrollDate;
	}
	
	
}
