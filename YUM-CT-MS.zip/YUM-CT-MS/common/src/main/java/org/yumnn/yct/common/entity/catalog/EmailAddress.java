/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name EmailAddress.java
 * @create_date Apr 23, 2019
 * @last_Update Apr 23, 2019
 */
@Entity
@Table(name = "adm_email_address")
@NamedQueries({
	@NamedQuery(name = "EmailAddress.getByUser", query = "SELECT e from EmailAddress e where e.user= :user")})
public class EmailAddress extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "email")
	private String email ;
	
	@ManyToOne
	@JoinColumn(name = "id_user_fk")
	private User user;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

}
