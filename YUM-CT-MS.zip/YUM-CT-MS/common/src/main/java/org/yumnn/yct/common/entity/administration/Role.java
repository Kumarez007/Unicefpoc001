/*
 * Copyright 2014 Ayala Consulting Corporation.
 *
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 *
 * http://www.ayalaconsulting.us
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "user_access.adm_role")
@NamedQueries({
        @NamedQuery(name = "Role.findAllActive", query = "SELECT r from Role r where r.isActive = :isActive order by r.id"),
        @NamedQuery(name = "Role.findAllRoles", query = "SELECT r from Role r order by r.id"),
        @NamedQuery(name = "Role.findRolesWithTheSameNameExcludingCurrent", query = "SELECT r from Role r where LOWER(r.roleName) = LOWER(:roleName) AND r.id <> :roleId "),
        @NamedQuery(name = "Role.findRolesWithTheSameName", query = "SELECT r from Role r where LOWER(r.roleName) = LOWER(:roleName)  ")})
public class Role extends BaseEntity implements Serializable {
    private static final long serialVersionUID = -6739919052158515878L;

    /**
     * The Strings fields are defined the column type with columnDefinition =
     * "character varying (x)".
     */

    @Column(name = "role_name", length = 64, columnDefinition = "character varying (64)")
    private String roleName;

    @Column(name = "is_active", length = 5, columnDefinition = "character varying (5)")
    @Enumerated(EnumType.STRING)
    private YesNoEnum isActive = YesNoEnum.NO;

    @OneToMany(mappedBy = "role")
    @JsonIgnore
    private List<UserByRole> userByRoles;


    @JsonIgnore
    @OneToMany(mappedBy = "role", fetch = FetchType.EAGER)
    private List<RoleByProject> roleByProject;


    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "id_updated_by", referencedColumnName = "ID")
    private User updatedBy;

    @Column(name = "is_privileged")
    @Enumerated(EnumType.STRING)
    private YesNoEnum isPrivileged = YesNoEnum.NO;

    @Transient
    private String selectedRolesInString;
    
    public Role() {

    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the roleName
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * @param roleName the roleName to set
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * @return the isActive
     */
    public YesNoEnum getIsActive() {
        return isActive;
    }

    /**
     * @param isActive the isActive to set
     */
    public void setIsActive(YesNoEnum isActive) {
        this.isActive = isActive;
    }

    /**
     * @return the userByRoles
     */
    public List<UserByRole> getUserByRoles() {
        return userByRoles;
    }

    /**
     * @param userByRoles the userByRoles to set
     */
    public void setUserByRoles(List<UserByRole> userByRoles) {
        this.userByRoles = userByRoles;
    }

    /**
     * @return the isPrivileged
     */
    public YesNoEnum getIsPrivileged() {
        return isPrivileged;
    }

    /**
     * @param isPrivileged the isPrivileged to set
     */
    public void setIsPrivileged(YesNoEnum isPrivileged) {
        this.isPrivileged = isPrivileged;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Role other = (Role) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
    /**
     * @return the updatedBy
     */
    public User getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(User updatedBy) {
        this.updatedBy = updatedBy;
    }


    public String getSelectedRolesInString() {
        return selectedRolesInString;
    }

    public void setSelectedRolesInString(String selectedRolesInString) {
        this.selectedRolesInString = selectedRolesInString;
    }

	/**
	 * @return the roleByProject
	 */
	public List<RoleByProject> getRoleByProject() {
		return roleByProject;
	}

	/**
	 * @param roleByProject the roleByProject to set
	 */
	public void setRoleByProject(List<RoleByProject> roleByProject) {
		this.roleByProject = roleByProject;
	}

    
}
