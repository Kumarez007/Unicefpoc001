package org.yumnn.yct.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Service;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Service
public class DateComparisonUtil {
  /**
   * The function compares the two dates and returns the boolean result
   * 
   * @param dateCurrentString
   * @param dateOfDeliveryString
   * @return boolean
   * @throws Exception
   */
  public Boolean dateComparisionUtil(String dateCurrentString, String dateOfDeliveryString)
      throws Exception {
    Date dateCurrent;
    Date dateOfDelivery;
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    dateCurrent = format.parse(dateCurrentString);
    dateOfDelivery = format.parse(dateOfDeliveryString);
    int difference = dateCurrent.compareTo(dateOfDelivery);
    if (difference > 0) {
      return false;
    } else {
      return true;
    }
  }
}
