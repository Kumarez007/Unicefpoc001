package org.yumnn.yct.common.enumeration.messages;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name ReminderMessageParameterTypeEnum.java
 * @create_date Nov 29, 2021
 * @last_Update Nov 29, 2021
 */
public enum ReminderMessageParameterTypeEnum {

	REMINDER_RELATED, RECIPIENT_EMAIL, COMMON

}
