package org.yumnn.yct.common.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.yumnn.yct.common.entity.catalog.GeolocationType;

public class CustomizedGeolocationTypeRepositoryImpl implements CustomizedGeolocationTypeRepository{
	@PersistenceContext
	protected EntityManager em;
	
	/**
	 * WQ
	 * @param geolocationType
	 * @return
	 */
	public GeolocationType findByParent(GeolocationType geolocationType) {
		try {
			String jpql = "SELECT g FROM GeolocationType g WHERE g.geolocationTypeParent = :geolocationType";
			Query query = em.createQuery(jpql);
			query.setParameter("geolocationType", geolocationType);
			return (GeolocationType) query.getSingleResult();
		}catch(Exception e) {
			em.getTransaction().rollback(); 
		}
		return null;
	}

	/**
	 * WQ
	 * @return
	 */
	public GeolocationType retrieveMaxGeolocationTypeByOrderItem() {
		try {
		String jpql = "SELECT g FROM GeolocationType g WHERE g.orderItem = (SELECT max(g.orderItem) FROM GeolocationType g)";
		Query query = em.createQuery(jpql);
		return (GeolocationType) query.getSingleResult();
		}catch(Exception e) {
			em.getTransaction().rollback(); 
		}
		return null;
	}
	/**
	 * WQ
	 * @return
	 */
	public Long retrieveCountGeolocationType() {
		try {
			CriteriaBuilder builder = em.getCriteriaBuilder();
			CriteriaQuery<Long> query = builder.createQuery(Long.class);
			query.select(builder.count(query.from(GeolocationType.class)));
			return em.createQuery(query).getSingleResult();
		}catch(Exception e) {
			em.getTransaction().rollback(); 
		}
		return null;
	}
	/**
	 * WQ
	 * @param numberOfLevels
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<GeolocationType> findByNumberOfLevel(Integer numberOfLevels){
		try {
			Query query = em.createNamedQuery("GeolocationType.findAllOrderdByOrderItemAsc");
			query.setFirstResult(0);
			query.setMaxResults(numberOfLevels);
			return query.getResultList();
		}catch(Exception e) {
			em.getTransaction().rollback(); 
		}
		return null;
	}
	/**
	 * WQ
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<GeolocationType> findAllOrderedByOrderItem(){
		try {
			Query query = em.createNamedQuery("GeolocationType.findAllOrderdByOrderItemAsc");
			return query.getResultList();
		}catch(Exception e) {
			em.getTransaction().rollback(); 
		}
		return null;
	}
}
