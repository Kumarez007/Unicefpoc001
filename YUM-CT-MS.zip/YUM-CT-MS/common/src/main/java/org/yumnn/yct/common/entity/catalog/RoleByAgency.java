/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.administration.Role;
import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Reem Issa
 * @department PMU.
 * @owner UNICEF.
 * @class_name RoleByAgency.java
 * @class_description
 * @create_date May 08, 2019
 * @last_Update May 08, 2019
 */
@Entity
@Table(name = "adm_role_by_agency")
@NamedQueries({
	@NamedQuery(name = "RoleByAgency.findByRole", query = "SELECT r from RoleByAgency r where r.role = :role ")
	})
public class RoleByAgency  extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	

	@ManyToOne
	@JoinColumn(name = "id_role_fk", referencedColumnName = "ID")
	private Role role;
	

	@ManyToOne
	@JoinColumn(name = "id_agency_fk", referencedColumnName = "ID")
	private Agency agency;


	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}


	/**
	 * @param role the role to set
	 */
	public void setRole(Role role) {
		this.role = role;
	}


	/**
	 * @return the agency
	 */
	public Agency getAgency() {
		return agency;
	}


	/**
	 * @param agency the agency to set
	 */
	public void setAgency(Agency agency) {
		this.agency = agency;
	}
}
