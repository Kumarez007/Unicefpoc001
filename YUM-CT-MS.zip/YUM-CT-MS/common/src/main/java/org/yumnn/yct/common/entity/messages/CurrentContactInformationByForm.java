package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.enumeration.messages.PhoneSourceEnum;
import org.yumnn.yct.common.enumeration.messages.PhoneTypeEnum;
import org.yumnn.yct.common.enumeration.messages.PresentedPhoneNumberEnum;

/**
 * 
 * @author Christian Alvarez
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name CurrentInfoContactInformation.java
 * @class_description represents the table of contact_information from the
 *                    current information scheme
 * @create_date Feb 22, 2019
 * @last_Update Feb 22, 2019
 */
@Entity
@Table(name = "messages.cur_contact_information_by_form")
public class CurrentContactInformationByForm extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Column(name = "phone_number")
	private String cellPhone;

	@Column(name = "email_address")
	private String emailAddress;

	@ManyToOne
	@JoinColumn(name = "id_cur_form_fk", referencedColumnName = "ID")
	private CurrentForm currentForm;

	@Column(name = "owned_by")
	@Enumerated(EnumType.STRING)
	private PresentedPhoneNumberEnum ownedBy;

	@Column(name = "owned_by_person_name")
	private String ownedByPersonName;

	@Column(name = "phone_source")
	@Enumerated(EnumType.STRING)
	private PhoneSourceEnum phoneSource;

	@Column(name = "phone_type")
	@Enumerated(EnumType.STRING)
	private PhoneTypeEnum phoneType;

	public CurrentContactInformationByForm() {

	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}

	public PresentedPhoneNumberEnum getOwnedBy() {
		return ownedBy;
	}

	public void setOwnedBy(PresentedPhoneNumberEnum ownedBy) {
		this.ownedBy = ownedBy;
	}

	public String getOwnedByPersonName() {
		return ownedByPersonName;
	}

	public void setOwnedByPersonName(String ownedByPersonName) {
		this.ownedByPersonName = ownedByPersonName;
	}

	public PhoneSourceEnum getPhoneSource() {
		return phoneSource;
	}

	public void setPhoneSource(PhoneSourceEnum phoneSource) {
		this.phoneSource = phoneSource;
	}

	public PhoneTypeEnum getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(PhoneTypeEnum phoneType) {
		this.phoneType = phoneType;
	}

}