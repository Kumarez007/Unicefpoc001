package org.yumnn.yct.common.entity.base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.yumnn.yct.common.util.entityobject.ParentEntityObject;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt May 11, 2021 10:10:04 PM
 */
@Entity
public class DropDownModel extends ParentEntityObject {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	private Long id;
	
	@Column(name = "en_name")
	private String enName;
	
	@Column(name = "ar_name")
	private String arName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getArName() {
		return arName;
	}

	public void setArName(String arName) {
		this.arName = arName;
	}
	
	
	
}
