/*
 * Copyright 2016 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.entity.catalog.GeolocationType;
import org.yumnn.yct.common.util.GeolocationUtils;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name IGeolocationRepository.java
 * @class_description
 * @create_date Jun 2, 2020
 * @last_Update Jun 2, 2020
 */
@Repository
public interface IGeolocationRepository extends JpaRepository<Geolocation, Long> , CustomizedGeolocationRepository{

	public List<Geolocation> findRootGeolocations();

	public List<Geolocation> findAllByGeolocationParent(Geolocation geolocationParent);

	public List<Geolocation> findAllByGeolocationParentByName(Geolocation geolocationParent);

	public List<Geolocation> findAllRelatedToGeolocationType(GeolocationType geolocationType);

//	@Query(value = "select c4.en_name as governorate, c3.en_name as district, c2.en_name as ozla, c1.en_name as villageLocality from user_access.cat_geolocation c1 " +
//			"inner join user_access.cat_geolocation c2 on " +
//			"c1.id_geolocation_parent_fk=c2.id inner join user_access.cat_geolocation c3 on " +
//			"c2.id_geolocation_parent_fk=c3.id inner join user_access.cat_geolocation c4 on " +
//			"c3.id_geolocation_parent_fk=c4.id where c1.id = :id", nativeQuery = true)
//	public GeolocationUtils findGeolocationById(@Param("id") Long id);

	@Query(value = "select c4.en_name as governorate, c4.ar_name as arGovernorate, c3.en_name as district, c3.ar_name as arDistrict, c2.en_name as ozla, c2.ar_name as arOzla, c1.en_name as villageLocality, c1.ar_name as arVillageLocality from user_access.cat_geolocation c1 " +
			"inner join user_access.cat_geolocation c2 on " +
			"c1.id_geolocation_parent_fk=c2.id inner join user_access.cat_geolocation c3 on " +
			"c2.id_geolocation_parent_fk=c3.id inner join user_access.cat_geolocation c4 on " +
			"c3.id_geolocation_parent_fk=c4.id where c1.id = :id", nativeQuery = true)
	public GeolocationUtils findGeolocationByThree(@Param("id") Long id);

	@Query(value = "select c2.en_name as governorate, c2.ar_name as arGovernorate, c3.en_name as district, c3.ar_name as arDistrict, c4.en_name as ozla, c4.ar_name as arOzla from user_access.cat_geolocation c4 " +
			"inner join user_access.cat_geolocation c3 on c4.id_geolocation_parent_fk=c3.id " +
			"inner join user_access.cat_geolocation c2 on c3.id_geolocation_parent_fk=c2.id where c4.id = :id", nativeQuery = true)
	public GeolocationUtils findGeolocationByTwo(@Param("id") Long id);

	@Query(value = "select c3.en_name as governorate, c3.ar_name as arGovernorate, c4.en_name as district, c4.ar_name as arDistrict from user_access.cat_geolocation c4 " +
			"inner join user_access.cat_geolocation c3 on c4.id_geolocation_parent_fk=c3.id where c4.id = :id ", nativeQuery = true)
	public GeolocationUtils findGeolocationByOne(@Param("id") Long id);


}
