package org.yumnn.yct.common.model;

import org.yumnn.yct.common.enumeration.cycle.ProjectClassificationEnum;

//FIXME move to common //Fixed
public class Project {
    
	protected Long id;
    private String name;
    private String shortName;
    private Project parentProject;
    private String pmuShortName;
    private ProjectClassificationEnum projectClassification;
    private String arName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public Project getParentProject() {
		return parentProject;
	}
	public void setParentProject(Project parentProject) {
		this.parentProject = parentProject;
	}
	/**
	 * @return the pmuShortName
	 */
	public String getPmuShortName() {
		return pmuShortName;
	}
	/**
	 * @param pmuShortName the pmuShortName to set
	 */
	public void setPmuShortName(String pmuShortName) {
		this.pmuShortName = pmuShortName;
	}
	/**
	 * @return the projectClassification
	 */
	public ProjectClassificationEnum getProjectClassification() {
		return projectClassification;
	}
	/**
	 * @param projectClassification the projectClassification to set
	 */
	public void setProjectClassification(ProjectClassificationEnum projectClassification) {
		this.projectClassification = projectClassification;
	}
	/**
	 * @return the arName
	 */
	public String getArName() {
		return arName;
	}
	/**
	 * @param arName the arName to set
	 */
	public void setArName(String arName) {
		this.arName = arName;
	}
	
	
}