package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user_access.adm_role_by_project_by_functionality")
@NamedQueries({
		@NamedQuery(
			name = "RoleByProjectByFunctionality.findAllRegisteredFunctionalitiesByRole",
			query = "SELECT t.functionality FROM RoleByProjectByFunctionality t WHERE t.roleByProject.role = :role"),
		@NamedQuery(
			name = "RoleByProjectByFunctionality.deleteAllByRole",
			query = "DELETE FROM RoleByProjectByFunctionality t WHERE t.roleByProject.role = :role")})
public class RoleByProjectByFunctionality extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_role_by_project_fk", referencedColumnName = "ID")
	private RoleByProject roleByProject;

	@ManyToOne
	@JoinColumn(name = "id_functionality_fk", referencedColumnName = "ID")
	private Functionality functionality;
	
	@Transient
    private String name;

	/**
	 * @return the roleByProject
	 */
	public RoleByProject getRoleByProject() {
		return roleByProject;
	}

	/**
	 * @param roleByProject the roleByProject to set
	 */
	public void setRoleByProject(RoleByProject roleByProject) {
		this.roleByProject = roleByProject;
	}

	/**
	 * @return the functionality
	 */
	public Functionality getFunctionality() {
		return functionality;
	}

	/**
	 * @param functionality the functionality to set
	 */
	public void setFunctionality(Functionality functionality) {
		this.functionality = functionality;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	
}
