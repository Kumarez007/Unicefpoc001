package org.yumnn.yct.common.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public interface GeolocationUtils {

    public String getGovernorate();

    public String getDistrict();

    public String getOzla();

    public String getVillageLocality();

    public String getArGovernorate();

    public String getArDistrict();

    public String getArOzla();

    public String getArVillageLocality();


}
