package org.yumnn.yct.common.model.message;

import java.util.Date;
import java.util.Map;

import org.yumnn.yct.common.enumeration.administration.LanguageEnum;
import org.yumnn.yct.common.enumeration.messages.MessageContentCodeEnum;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {RapidProMessageRequestModel.java
 * @create_date May 6, 2021
 * @last_Update May 6, 2021
 */
public class MessageRequestModel {

	protected String messageContentCode;
	protected Map<String , String> parameterByValueMap;
	protected LanguageEnum messageLanguage;
	private Long projectId;

	public String getMessageContentCode() {
		return messageContentCode;
	}

	public void setMessageContentCode(String messageContentCode) {
		this.messageContentCode = messageContentCode;
	}

	public Map<String, String> getParameterByValueMap() {
		return parameterByValueMap;
	}

	public void setParameterByValueMap(Map<String, String> parameterByValueMap) {
		this.parameterByValueMap = parameterByValueMap;
	}

	public LanguageEnum getMessageLanguage() {
		return messageLanguage;
	}

	public void setMessageLanguage(LanguageEnum messageLanguage) {
		this.messageLanguage = messageLanguage;
	}

	/**
	 * @return the projectId
	 */
	public Long getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
}
