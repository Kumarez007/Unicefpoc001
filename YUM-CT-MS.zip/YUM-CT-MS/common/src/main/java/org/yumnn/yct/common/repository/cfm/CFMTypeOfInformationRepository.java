package org.yumnn.yct.common.repository.cfm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.cfm.CFMTypeOfInformation;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name CFMTypeOfInformationRepository.java
 * @create_date Jul 25, 2022
 * @last_Update Jul 25, 2022
 */
@Repository
public interface CFMTypeOfInformationRepository extends JpaRepository<CFMTypeOfInformation, Long> {

}
