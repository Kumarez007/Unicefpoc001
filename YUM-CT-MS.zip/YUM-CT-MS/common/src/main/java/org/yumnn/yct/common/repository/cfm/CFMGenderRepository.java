package org.yumnn.yct.common.repository.cfm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.cfm.CFMGender;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name CFMGenderRepository.java
 * @create_date Jul 27, 2022
 * @last_Update Jul 27, 2022
 */
@Repository
public interface CFMGenderRepository extends JpaRepository<CFMGender, Long> {

}
