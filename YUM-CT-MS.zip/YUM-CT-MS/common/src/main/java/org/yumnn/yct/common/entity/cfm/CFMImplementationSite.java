package org.yumnn.yct.common.entity.cfm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;

import java.io.Serializable;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name CFMImplementationSite.java
 * @create_date Aug 4, 2022
 * @last_Update Aug 4, 2022
 */
@Entity
@Table(name = "cat_cfm_implementation_site", schema = "user_access")
public class CFMImplementationSite extends BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name = "ar_name")
	private String adjustedName;

	@Column(name = "en_name")
	private String enName;
	@Column(name = "new_code")
	private String newCode;

	@Column(name="site_type")
	private String siteType;


	public String getAdjustedName() {
		return adjustedName;
	}

	public void setAdjustedName(String adjustedName) {
		this.adjustedName = adjustedName;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getNewCode() {
		return newCode;
	}

	public void setNewCode(String newCode) {
		this.newCode = newCode;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

}
