package org.yumnn.yct.common.model.payment;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name NotPaidBeneficiaryModel.java
 * @class_description 
 * @create_date Sep 20, 2021
 * @last_Update Sep 20, 2021
 */
public class NotPaidBeneficiaryModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	private Long paymentAgencyId;

	@NotNull
	private String uniqueCode;
	
	private String reason;
	
	private List<String> validationCodesList;

	public NotPaidBeneficiaryModel() {
	}

	public Long getPaymentAgencyId() {
		return paymentAgencyId;
	}

	public String getUniqueCode() {
		return uniqueCode;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @param paymentAgencyId the paymentAgencyId to set
	 */
	public void setPaymentAgencyId(Long paymentAgencyId) {
		this.paymentAgencyId = paymentAgencyId;
	}

	/**
	 * @param uniqueCode the uniqueCode to set
	 */
	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}

	/**
	 * @return the validationCodesList
	 */
	public List<String> getValidationCodesList() {
		return validationCodesList;
	}

	/**
	 * @param validationCodesList the validationCodesList to set
	 */
	public void setValidationCodesList(List<String> validationCodesList) {
		this.validationCodesList = validationCodesList;
	}

}
