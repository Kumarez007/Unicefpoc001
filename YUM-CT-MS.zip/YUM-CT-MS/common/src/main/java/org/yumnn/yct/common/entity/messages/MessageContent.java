/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.messages.MessageTypeEnum;
/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name MessageContent.java
 * @create_date Apr 03, 2019
 * @last_Update Apr 03, 2019
 */
@Entity
@Table(name = "messages.msg_message_content")
@NamedQueries({
	@NamedQuery(name = "MessageContent.findAllOrderByLabel", query = "SELECT r from MessageContent r order by r.label"),
	@NamedQuery(name = "MessageContent.findByMessageCategoryId", query = "SELECT r from MessageContent r where r.messageCategory.id = :messageCategoryId"),
})

public class MessageContent  extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "text_ar")
	private String textAr;
	
	@Column(name = "text_en")
	private String textEn;

	@Column(name = "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;
	
	@Column(name = "label")
	private String label;
	
	@Column(name = "code")
	private String code;

	@ManyToOne
	@JoinColumn(name = "id_message_category_fk")
	private MessageCategory messageCategory;
	
	@Column(name = "message_type")
	@Enumerated(EnumType.STRING)
	private MessageTypeEnum messageType;
	
	
	
	/**
	 * @return the textAr
	 */
	public String getTextAr() {
		return textAr;
	}

	/**
	 * @param textAr the textAr to set
	 */
	public void setTextAr(String textAr) {
		this.textAr = textAr;
	}

	/**
	 * @return the textEn
	 */
	public String getTextEn() {
		return textEn;
	}

	/**
	 * @param textEn the textEn to set
	 */
	public void setTextEn(String textEn) {
		this.textEn = textEn;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the messageCategory
	 */
	public MessageCategory getMessageCategory() {
		return messageCategory;
	}

	/**
	 * @param messageCategory the messageCategory to set
	 */
	public void setMessageCategory(MessageCategory messageCategory) {
		this.messageCategory = messageCategory;
	}

	/**
	 * @return the messageType
	 */
	public MessageTypeEnum getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(MessageTypeEnum messageType) {
		this.messageType = messageType;
	}
}
