package org.yumnn.yct.common.enumeration.messages;

public enum MessageContentCodeEnum {
	

	GRIEVANCE_CONFIRMATION_MESSAGE("gr_message") , 
	APPROVE_PAYMENT_SITE_MESSAGE("ps_approve_msg"),
	DECLINE_PAYMENT_SITE_MESSAGE("ps_decline_msg"),
	RECEIVE_PAYMENT_SITE_MESSAGE("ps_receieve_msg"),
	RECOMMEND_PAYMENT_SITE_MESSAGE("ps_recommend_msg"),
	ENDORSE_PAYMENT_SITE_MESSAGE("ps_end_approve_msg"),
	ENDORSE_APPROVE_PAYMENT_SITE_MESSAGE("ps_end_approve_msg"),
	ENDORSE_DECLINE_PAYMENT_SITE_MESSAGE("ps_end_decline_msg"),
	SEND_ISSUE_LOG_TO_BANK_FOR_FEEDBACK_MESSAGE("ps_send_to_bank_msg"),
	GRIEVANCE_FOLLOWUP_ACTION_MESSAGE("gr_followup_action"),
	CFM_GRIEVANCE_FOLLOWUP_ACTION_MESSAGE("cfm_gr_followup_action"),
	GRIEVANCE_CLOSE_ACTION_MESSAGE_FIRST("gr_close_action_1"),
	GRIEVANCE_CLOSE_ACTION_MESSAGE_SECOND("gr_close_action_2"),
	GRIEVANCE_CREATED_ACTION_MESSAGE("GRIEVANCES_CREATED"),
	GRIEVANCES_CREATED_GI_CATEGORY("GRIEVANCES_CREATED_GI_CATEGORY"),
	GRIEVANCES_CREATED_GBV_CATEGORY("GRIEVANCES_CREATED_GBV_CATEGORY"),
	GRIEVANCES_CREATED_SEA_CATEGORY("GRIEVANCES_CREATED_SEA_CATEGORY"),
	GRIEVANCE_CASE_UNDER_INVESTEGATION_MESSAGE("gr_case_under_investigation"),
	
	GRIEVANCE_CASE_REVIEW_ADD_INFO_MESSAGE("gr_case_review_add_info"),
	
	GRIEVANCE_CASE_REVIEW_RECOMMENDATION_MESSAGE("gr_case_review_recommendation"),
	GRIEVANCE_CASE_REVIEW_APPROVAL_MESSAGE("gr_case_review_approval"),
	
	GRIEVANCE_CASE_INVESTEGATION_COMPLETED_MESSAGE("gr_case_investigation_completed"),
	GRIEVANCE_CASE_INVESTEGATION_ENDORSED_MESSAGE("gr_case_investigation_endorsed"),
	
	GRIEVANCE_CASE_REVIEW_DOCUMENT_MESSAGE("gr_case_review_document"),
	GRIEVANCE_CASE_DOCUMENT_ENDORSED_MESSAGE("gr_case_review_document_endorsed"),
	
	GRIEVANCE_CASE_PROVID_CLARIFICATION_MESSAGE("gr_case_provide_clarification"),
	GRIEVANCE_CASE_REDRESSAL_COMPLETED_MESSAGE("gr_case_redressal_completed"),
	OTP_CODE_MESSAGE("otp_code_message"),
	GRIEVANCE_REDRESSAL_ENDORSMENT_MESSAGE("gr_case_redressal_endorsement"),
	GRIEVANCE_REDRESSAL_APPROVAL_MESSAGE("gr_case_redressal_approval"),
	GRIEVANCE_CLOSURE_MESSAGE("gr_closure_action"),
	
	GRIEVANCE_CASE_REVIEW_DOCUMENT_CLEARANCE_MESSAGE("gr_case_review_document_clearance"),
	GRIEVANCE_ADDITIONAL_REVIEW_DOCUMENT("gr_case_additional_review_document"),
	GRIEVANCE_ADDITIONAL_REVIEW_DOCUMENT_ENDOR("gr_case_addit_review_endorsement"),
	GRIEVANCE_FINAL_REDRESSAL("gr_case_final_redressal"),
	GRIEVANCE_REGISTER_COMPLAINT("gr_case_cfm_register_complaint"),
	GRIEVANCE_REGISTER_INQUIRY("gr_case_cfm_register_inquiry"),
	GRIEVANCE_REGISTER_FEEDBACK("gr_case_cfm_register_feedback"),
	GRIEVANCE_COMPLAINT_RESOLVED("gr_case_cfm_complaint_resolved")
	;


	private String value;

	MessageContentCodeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
