/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

/**
 * @author Reem Issa
 * @department PMU.
 * @owner UNICEF.
 * @class_name EnrollmentType.java
 * @class_description
 * @create_date Mar 04, 2019
 * @last_Update Mar 04, 2019
 */
@Entity
@Table(name = "cat_enrollment_type")
@NamedQueries({
	@NamedQuery(name = "EnrollmentType.findByShortName", query = "SELECT r from EnrollmentType r WHERE r.shortName = :shortName") 
	})
public class EnrollmentType extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		EnrollmentType other = (EnrollmentType) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}


}
