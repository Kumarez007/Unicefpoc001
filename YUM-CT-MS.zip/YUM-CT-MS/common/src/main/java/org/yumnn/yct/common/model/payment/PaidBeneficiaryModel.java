package org.yumnn.yct.common.model.payment;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.yumnn.yct.common.enumeration.payment.RegionEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.util.Constants;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {PaidBeneficiaryModel.java
 * @create_date May 19, 2021
 * @last_Update May 19, 2021
 */
public class PaidBeneficiaryModel {

	private static final long serialVersionUID = 1L;

	@NotNull
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_FORMAT_yyyyMMdd, timezone = Constants.SERVER_TIME_ZONE)
	private Date date;
	@NotNull
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT_HH_mm_ss, timezone = Constants.SERVER_TIME_ZONE)
	private String transactionStartingTime ;
	@NotNull
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT_HH_mm_ss, timezone = Constants.SERVER_TIME_ZONE)
	private String transactionEndingTime;
	@NotNull
	@NotBlank
	private String paymentSiteCode;
	@NotNull
	private String idReferenceNumber;
	@NotNull
	private String telephoneNumber;
	@NotNull
	private Long paymentAgencyId;
	@NotNull
	@NotBlank
	@NotEmpty
	private String cashierName;
	@NotNull
	private String uniqueCode;
	@NotNull
	private String idType;
	
	private String memberCode;
	@NotNull
	private String beneficiaryName;
	
	@NotNull
	private RegionEnum regionPaid;
	
	@NotNull
	private Double paidAmount;

	@NotNull
	private List<String> validationCodesList;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getPaymentSiteCode() {
		return paymentSiteCode;
	}

	public void setPaymentSiteCode(String paymentSiteCode) {
		this.paymentSiteCode = paymentSiteCode;
	}

	public String getTransactionStartingTime() {
		return transactionStartingTime;
	}

	public void setTransactionStartingTime(String transactionStartingTime) {
		this.transactionStartingTime = transactionStartingTime;
	}

	public String getTransactionEndingTime() {
		return transactionEndingTime;
	}

	public void setTransactionEndingTime(String transactionEndingTime) {
		this.transactionEndingTime = transactionEndingTime;
	}

	public String getIdReferenceNumber() {
		return idReferenceNumber;
	}

	public void setIdReferenceNumber(String idReferenceNumber) {
		this.idReferenceNumber = idReferenceNumber;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public Long getPaymentAgencyId() {
		return paymentAgencyId;
	}

	public void setPaymentAgencyId(Long paymentAgencyId) {
		this.paymentAgencyId = paymentAgencyId;
	}

	public String getCashierName() {
		return cashierName;
	}

	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}

	public String getUniqueCode() {
		return uniqueCode;
	}

	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public List<String> getValidationCodesList() {
		return validationCodesList;
	}

	public void setValidationCodesList(List<String> validationCodesList) {
		this.validationCodesList = validationCodesList;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	/**
	 * @return the regionPaid
	 */
	public RegionEnum getRegionPaid() {
		return regionPaid;
	}

	/**
	 * @param regionPaid the regionPaid to set
	 */
	public void setRegionPaid(RegionEnum regionPaid) {
		this.regionPaid = regionPaid;
	}

	/**
	 * @return the paidAmount
	 */
	public Double getPaidAmount() {
		return paidAmount;
	}

	/**
	 * @param paidAmount the paidAmount to set
	 */
	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}
}
