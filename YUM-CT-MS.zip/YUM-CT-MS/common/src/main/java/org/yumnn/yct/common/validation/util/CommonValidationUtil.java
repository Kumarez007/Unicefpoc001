package org.yumnn.yct.common.validation.util;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.CustomException;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 1, 2021 4:36:25 PM
 */
@Component
public class CommonValidationUtil {
	
	private static Logger logger = LogManager.getLogger();
	
	@Autowired
	private MessageSource messageSource;
	
	private String message=null;
	
	public void validateIsNullOrEmpty(String field, String value) {
		
		if (value==null || value.isEmpty() || "null".equalsIgnoreCase(value.trim())) {
			logger.debug("Validation For: "+field);
			message=messageSource.getMessage("validate.param",null, "Validation Failed", LocaleContextHolder.getLocale()).concat(": ")
					.concat(field);
			throw new IllegalArgumentException(message);	
		}
	}
	
	public void validateIsNull(String field, Object value) {
		
		if (value==null) {
			logger.debug("Validation For: "+field);
			message=messageSource.getMessage("validate.param", null, "Validation Failed", LocaleContextHolder.getLocale()).concat(": ")
					.concat(field);
			throw new IllegalArgumentException(message);	
		}
	}
	
	public void validatePhoneNumber(String field, String value) {
		
		validateIsNullOrEmpty(field,value);

		String regexLandLine = "^0[1-7][0-9]{6}$";
        String regex = "^[7][0-9]{8}$";
	        
        if (value != null && (value.trim().length() < 8 || value.trim().length() > 9
            || (value.trim().length() == 8 && !value.matches(regexLandLine))
            || (value.trim().length() == 9 && !value.matches(regex)))) {
        	logger.debug("Validation For: "+field);
        	message=messageSource.getMessage("validate.phonenumber", null, "Validation Failed", LocaleContextHolder.getLocale());
			throw new IllegalArgumentException(message);
        }
	}
	
	public void validateIsoDate(String field, String value) {
		
		validateIsNullOrEmpty(field,value);
		
		String iso_date_regex =
	            "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[13-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$";
        if (!value.matches(iso_date_regex)) {
        	logger.debug("Validation For: "+field);
        	message=messageSource.getMessage("validate.isoDate", null, "Validation Failed", LocaleContextHolder.getLocale());
        	throw new IllegalArgumentException(message);
        }
	}
	
	public void validateMultipartFile(String field, MultipartFile file1, MultipartFile file2) throws NoSuchMessageException, IOException {
		
		message=messageSource.getMessage("validate.param", null, "Validation Failed", LocaleContextHolder.getLocale()).concat(": ")
				.concat(field);
		
		if (file1==null && file2==null) {
			logger.debug("Validation For: "+field);
			throw new IllegalArgumentException(message);
	    }
			
		
		if ((file1!=null && file1.getBytes() != null && file1.getBytes().length == 0) && (file2==null)) {
			logger.debug("Validation For: "+field);
			throw new IllegalArgumentException(message);
		}
		
		if ((file1==null) && (file2!=null && file2.getBytes() != null && file2.getBytes().length == 0)) {
			logger.debug("Validation For: "+field);
			throw new IllegalArgumentException(message);
		}
	}
	
	public void validateUserId(String headerUser, String dbUser) {
		
		if (headerUser!=null && dbUser!=null && !headerUser.equals(dbUser)) {
			logger.debug("======= validateUserId ========");
			throw new IllegalArgumentException("User Validation Failed");
		}
	}
	
	public void validateUserName(String headerUsername, String dbUsername) {
		
		if (!headerUsername.equals(dbUsername)) {
			logger.debug("======= validateUserName ========");
			message=messageSource.getMessage("validate.userNotExist", null, "Validation Failed", LocaleContextHolder.getLocale());
			throw new IllegalArgumentException(message);
		}
	}
	
	public void validateSixDigitPassword(String password) {
		if (password != null && password.length() > 0 && password.length() < 6) {
			logger.debug("======= validateSixDigitPassword ========");
			message=messageSource.getMessage("validate.password", null, "Validation Failed", LocaleContextHolder.getLocale());
			throw new IllegalArgumentException(message);
        }
		
	}
	
	public void validateIsUserActive(YesNoEnum isActive) throws CustomException {
		if (isActive != null && !YesNoEnum.YES.equals(isActive)) {
			logger.debug("======= validateIsUserActive ========");
			message=messageSource.getMessage("validate.userDeactivated", null, "Validation Failed", LocaleContextHolder.getLocale());
			throw new CustomException(message);
		}
		
	}
	
	public void validatePasswordMismatch(String password, String confirmPassword) throws CustomException {
		
		if (password != null  && confirmPassword != null && !password.equals(confirmPassword)) {
			logger.debug("======= validatePasswordMismatch ========");
			message=messageSource.getMessage("validate.passwordMismatch", null, "Validation Failed", LocaleContextHolder.getLocale());
			throw new CustomException(message);
		}
		
	}
	
	public void checkDuplicateRequest(String field, Object value) {
		
		if (value!=null) {
			logger.debug("checkDuplicateRequest Validation For: "+field);
			message=messageSource.getMessage("validate.request", null, "Duplicate Request. Record Already Exists!", LocaleContextHolder.getLocale());
			throw new IllegalArgumentException(message);	
		}
	}
}
