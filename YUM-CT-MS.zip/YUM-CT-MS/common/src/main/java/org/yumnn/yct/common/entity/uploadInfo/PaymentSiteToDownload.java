package org.yumnn.yct.common.entity.uploadInfo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.uploadInfo.UploadedRecordProcessStatusEnum;

@Entity
@Table(name = "payment.gen_payment_site_to_download")
@NamedQueries({
		@NamedQuery(name = "PaymentSiteToDownload.retrievePendingRecord", query = "SELECT t FROM PaymentSiteToDownload t WHERE t.status = :status order by t.id"),
		@NamedQuery(name = "PaymentSiteToDownload.retrievePendingRecordByCode", query = "SELECT t FROM PaymentSiteToDownload t WHERE t.paymentSiteCode = :paymentSiteCode and t.status = :status order by t.id") })
public class PaymentSiteToDownload extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "id_user_fk", referencedColumnName = "ID")
	private User user;

	@Column(name = "record_json")
	private String recordJson;

	@Column(name = "payment_site_code")
	private String paymentSiteCode;

	@Column(name = "creation_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date creationDate;

	@Column(name = "ending_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date endingDate;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private UploadedRecordProcessStatusEnum status;

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the recordJson
	 */
	public String getRecordJson() {
		return recordJson;
	}

	/**
	 * @param recordJson the recordJson to set
	 */
	public void setRecordJson(String recordJson) {
		this.recordJson = recordJson;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the status
	 */
	public UploadedRecordProcessStatusEnum getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(UploadedRecordProcessStatusEnum status) {
		this.status = status;
	}

	/**
	 * @return the paymentSiteCode
	 */
	public String getPaymentSiteCode() {
		return paymentSiteCode;
	}

	/**
	 * @param paymentSiteCode the paymentSiteCode to set
	 */
	public void setPaymentSiteCode(String paymentSiteCode) {
		this.paymentSiteCode = paymentSiteCode;
	}
}
