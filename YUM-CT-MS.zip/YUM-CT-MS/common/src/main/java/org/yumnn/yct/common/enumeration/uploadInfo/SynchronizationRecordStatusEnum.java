package org.yumnn.yct.common.enumeration.uploadInfo;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ClientDeviceTypeEnum.java
 * @class_description
 * @create_date Oct 12, 2017
 * @last_Update Oct 12, 2017
 */
public enum SynchronizationRecordStatusEnum {
	PENDING, SENT, CONFIRMED, ERROR, RECEIVED;
}
