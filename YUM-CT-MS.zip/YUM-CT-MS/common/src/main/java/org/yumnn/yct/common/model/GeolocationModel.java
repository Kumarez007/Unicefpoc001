package org.yumnn.yct.common.model;

/** 
*
* @author Nitin Joshi
* @department PMU - ICT
* @owner UNICEF
* @class_name GeolocationModel.java
* @class_description
* @create_date Sep 09, 2020
* @last_Update Sep 09, 2020
*/

public class GeolocationModel {
	
	private Long	governorateId;
	
	private Long	districtId;
	
	private Long	ozlaId;
	
	private Long	villageId;
	
	private String	governNameEn;
	
	private String	governNameAr;
	
	private String	districtNameEn;
	
	private String	districtNameAr;
	
	private String	ozlaNameEn;
	
	private String	ozlaNameAr;
	
	private String	cityName;
	
	private String	cityNameEn;
	
	private String	cityNameAr;
	
	private Long typeOrder;
	
	
	
	public String getGovernNameEn() {
		return governNameEn;
	}
	public void setGovernNameEn(String governNameEn) {
		this.governNameEn = governNameEn;
	}
	public String getGovernNameAr() {
		return governNameAr;
	}
	public void setGovernNameAr(String governNameAr) {
		this.governNameAr = governNameAr;
	}
	public String getDistrictNameEn() {
		return districtNameEn;
	}
	public void setDistrictNameEn(String districtNameEn) {
		this.districtNameEn = districtNameEn;
	}
	public String getDistrictNameAr() {
		return districtNameAr;
	}
	public void setDistrictNameAr(String districtNameAr) {
		this.districtNameAr = districtNameAr;
	}
	public String getOzlaNameEn() {
		return ozlaNameEn;
	}
	public void setOzlaNameEn(String ozlaNameEn) {
		this.ozlaNameEn = ozlaNameEn;
	}
	public String getOzlaNameAr() {
		return ozlaNameAr;
	}
	public void setOzlaNameAr(String ozlaNameAr) {
		this.ozlaNameAr = ozlaNameAr;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public Long getGovernorateId() {
		return governorateId;
	}
	public void setGovernorateId(Long governorateId) {
		this.governorateId = governorateId;
	}
	public Long getDistrictId() {
		return districtId;
	}
	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}
	public Long getOzlaId() {
		return ozlaId;
	}
	public void setOzlaId(Long ozlaId) {
		this.ozlaId = ozlaId;
	}
	public Long getVillageId() {
		return villageId;
	}
	public void setVillageId(Long villageId) {
		this.villageId = villageId;
	}
	public String getCityNameEn() {
		return cityNameEn;
	}
	public void setCityNameEn(String cityNameEn) {
		this.cityNameEn = cityNameEn;
	}
	public String getCityNameAr() {
		return cityNameAr;
	}
	public void setCityNameAr(String cityNameAr) {
		this.cityNameAr = cityNameAr;
	}
	/**
	 * @return the typeOrder
	 */
	public Long getTypeOrder() {
		return typeOrder;
	}
	/**
	 * @param typeOrder the typeOrder to set
	 */
	public void setTypeOrder(Long typeOrder) {
		this.typeOrder = typeOrder;
	}

}
