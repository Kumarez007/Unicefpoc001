package org.yumnn.yct.common.enumeration.cycle;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name AmountByCyclePaymentStatusEnum.java
 * @class_description enum that contains the payment statusfor amount by cycle
 * @create_date Jul 10, 2017
 * @last_Update Jul 10, 2017
 */
public enum AmountByCyclePaymentStatusEnum {

	EXITED,I,ARREARS,REGULAR;

}
