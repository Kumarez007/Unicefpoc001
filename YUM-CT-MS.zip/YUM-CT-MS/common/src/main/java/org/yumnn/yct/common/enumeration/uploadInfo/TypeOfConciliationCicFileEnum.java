package org.yumnn.yct.common.enumeration.uploadInfo;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name TypeOfConciliationCicFileEnum.java
 * @class_description types of conciliation files
 * @create_date Sep 11, 2017
 * @last_Update Sep 11, 2017
 */
public enum TypeOfConciliationCicFileEnum {

	VERSION_ONE("without old_ben_id"), VERSION_TWO("with old_ben_id, birth_certificate");
	
	private String description;

	private TypeOfConciliationCicFileEnum(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}
