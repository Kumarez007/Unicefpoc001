package org.yumnn.yct.common.util;

import org.json.JSONObject;
import org.yumnn.yct.common.enumeration.project.ProjectPmuShortNameEnum;

public class RequestJsonObject {

	private String projectName;

	private JSONObject recordJson;

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the recordJson
	 */
	public JSONObject getRecordJson() {
		return recordJson;
	}

	/**
	 * @param recordJson the recordJson to set
	 */
	public void setRecordJson(JSONObject recordJson) {
		this.recordJson = recordJson;
	}

}
