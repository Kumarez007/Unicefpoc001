package org.yumnn.yct.common.enumeration.administration;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name FunctionalitiesFunctionalityTypesEnum.java
 * @class_description enum for functionality types
 * @create_date Mar 31, 2017
 * @last_Update Mar 31, 2017
 */
public enum FunctionalitiesFunctionalityTypesEnum {

    MENU, LINK, HIDDEN, ELEMENT;
}
