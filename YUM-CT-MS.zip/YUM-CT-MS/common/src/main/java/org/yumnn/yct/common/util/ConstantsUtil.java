package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public final class ConstantsUtil {


	
	
	public static final String CAREGIVER_FILE1 = "caregiverFile1";
	public static final String NOMINEE_FILE1 = "nomineeFile1";
	public static final String CAREGIVER_FILE2 = "caregiverFile2";
	public static final String NOMINEE_FILE2 = "nomineeFile2";

	public static final String YES_VAL = "YES";
	public static final String HOUSEHOLD_MEMBER_TYPE_CHILD = "HMC";
	public static final String HOUSEHOLD_MEMBER_TYPE_CAREGIVER = "HMCG";
	public static final String HOUSEHOLD_MEMBER_TYPE_NOMINEE = "HMN";

	public static final String ATTACHMENT_REFERENCE_TYPE_CAREGIVER = "HMCG_DOC";
	public static final String ATTACHMENT_REFERENCE_TYPE_NOMINEE = "HMN_DOC";
	public static final String ATTACHMENT_REFERENCE_TYPE_CHILD = "HMC_DOC";


	public static final String WEB_SERVICE_BASEPATH = "/ws/api/";
	public static final String WEB_SERVICE_VERSION = "v1";
	public static final String API_VERSION = "v1";
	public static final String LOGOUT_PATH = "/yct/api/v1/authcontrol/logout";
	public static final String _SYSTEM_USER = "system";
	//Added by rupal patoliya 29-08-2022
	public static final String GRIEVANCE_OBJECT_CF_CODE = "grievanceObjectCFCode";


	// Response message
	public static final String BAD_REQUEST = "Can't process request, please try again!";
	public static final String DATA_GET_SUCCESS = "Data get request successfully processed!";
	public static final String SERVER_ERROR = "Oops, Something went wrong!";
	public static final String DO_NOT_HAVE_PERMISSTION_TO_PERFORM_OPERATION =
			"Sorry, you don't have permission to do this operation!";
	public static final String INVALID_USER = "Please enter Username or Password";
	public static final String INVALID_USERNAME = "Username does not exist";
	public static final String INVALID_USERPASSWORD =
			"Please verify entered password. Upon three failed attempts, your account will be inaccessible";
	public static final String DEACTIVED_ACCOUNT =
			"User has been deactivated, please contact your administration";
	public static final String SERVER_EXCEPTION = "Something went wrong";
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String SUCCESS_MESSAGE_TRUE = "TRUE";
	public static final String SUCCESS_MESSAGE_FALSE = "FALSE";
	public static final String INVALID_TOKEN_MESSAGE =
			" Either user have deactivated or unable to validate the session. Please contact Administrator";
	public static final String ERROR_MESSAGE = "Error";
	public static final String GENERAL_ERROR_MESSAGE = "General exception occured";
	public static final String DATA_NOT_FOUND = "Data not available";
	public static final Boolean IS_VALIDATED_TRUE = true;
	public static final String IS_VALIDATED = "isValidated";
	public static final Boolean IS_VALIDATED_FALSE = false;

	// Status codes
	public static final Integer STATUS_CODE_SUCCESS = 200;
	public static final Integer STATUS_CODE_UNPROCESSABLE_ENTITY = 422;
	public static final Integer STATUS_CODE_SERVER_ERROR = 500;
	public static final Integer STATUS_CODE_DATA_UNCHANGED = 601;
	public static final Integer STATUS_CODE_INACTIVE = 603;
	public static final Integer STATUS_CODE_DATA_NOT_AVAILABLE = 604;
	public static final Integer STATUS_CODE_BAD_REQUEST = 400;
	public static final Integer STATUS_CODE_UNAUTHORIZED = 401;
	public static final Integer STATUS_CODE_NOT_FOUND = 404;
	public static final Integer STATUS_CODE_TIME_OUT = 408;
	public static final Integer STATUS_CODE_PASSWORD_CHANGED = 605;
	public static final Integer STATUS_CODE_CONFLICT = 409;

	// Requestheader
	public static final String SESSION_TOKEN_HEADER = "sessiontoken";
	public static final String USER_ID_HEADER = "userid";
	public static final String USER_UNIQUE_CODE = "uniqueusersignature";
	public static final String DEVICE_MODEL = "devicemodel";
	public static final String DEVICE_ID = "deviceid";
	public static final String OS = "os";
	public static final String APP_VERSION = "appversion";
	public static final String OS_VERSION = "osversion";
	public static final String DEVICE_IP_ADDRESS = "host";
	public static final String DEVICE_MANUFACTURER = "devicemanufacturer";
	public static final String LANGUAGE = "language";
	public static final String BEARER_TOKEN = "bearertoken";
	public static final String BEARER_AUTHENTICATION_PREFIX = "Bearer";
	public static final String AUTHENTICATION_HEADER = "Authorization";
	public static final String CLIENT_ID = "clientid";
	public static final Integer TOTAL_PREGNANCY_WEEK = 40;

	// Requestbody
	public static final String SESSION_TOKEN = "sessionToken";
	public static final String USER_DETAIL = "userDetail";
	public static final String USER_ID = "userId";
	public static final String JWT_PREFIX = "org.yumnn.yct.useraccessservice-";
	public static final String GEOLOCATION_LIST = "geographicalAreas";
	public static final String GEOLOCATION_VERSION = "geographicalAreaVersion";
	public static final String HEALTH_FACILITY_LIST = "healthFacilities";
	public static final String HEALTH_FACILITY_VERSION = "healthFacilityVersion";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String PHONE_NUMBER = "phoneNumber";
	public static final String VOUCHER_SERIAL_NUMBER_BODY = "voucherSerialNumber";
	public static final String VOUCHER_SERIAL_NUMBER = "serialNumber";
	public static final String DATE_OF_DELIVERY = "dateOfDelivery";
	public static final String VOUCHER_EXPIRY_DATE = "voucherExpiryDate";
	public static final String VALIDATION_CODE = "validationCode";
	public static final String DOCTOR_NAME = "doctorName";
	public static final String COMPLICATIONS_ID = "complicationsId";
	public static final String SERVICE_TYPE = "serviceType";
	public static final String ID_REFERENCE = "idReference";
	public static final String UNIQUE_USER_SIGNATURE = "uniqueUserSignature";
	public static final String ROLE = "role";
	public static final String BENEFICIARY_NAME_AS_ON_THE_DISCHARGE_CARD =
			"beneficiaryNameAsOnTheDischargeCard";
	public static final Long COMPLICATION_ABORTION_ID = 1L;
	public static final String SERVICE_TYPE_BODY = "servicetype";
	public static final String CREATED_AT = "createdAt";
	public static final String MIDWIFE_NAME = "midwifeName";
	public static final String MIDWIFE_COMMENTS = "midwifeComments";
	public static final String PLACE_OF_REFERRAL_ID = "placeOfReferralId";
	public static final Integer VOUCHER_SERIAL_NUMBER_1 = 1;
	public static final Integer VOUCHER_SERIAL_NUMBER_2 = 2;
	public static final Integer VOUCHER_SERIAL_NUMBER_3 = 3;
	public static final Integer VOUCHER_SERIAL_NUMBER_4 = 4;
	public static final Integer REASON_OF_ISSUE_BOOKLET_NEW_PREGNANCY = 1;
	public static final Integer REASON_OF_ISSUE_BOOKLET_ALL_USED = 2;
	public static final Integer REASON_OF_ISSUE_BOOKLET_REPLACEMENT = 3;
	public static final String WEB_SERVICE_NAME = "webservicename";
	public static final String ENROLLMENT_CODE = "enrollmentCode";
	public static final String REASON_OF_ISSUE_BOOKLET_IS_ALL_HAVE_USED = "All have been used";
	public static final String REASON_OF_ISSUE_BOOKLET_REQUEST_REPLACEMENT_OF_VOUCHER =
			"Request replacement of a voucher";
	public static final String BENEFICIARY_ID = "beneficiaryId";
	public static final String BENEFICIARY_ID_REQUEST_BODY_MAP = "beneficiaryid";
	public static final String ID_TYPE_ID = "idTypeId";
	public static final String UPLOAD_DISCHARGE_CARD_FILES1 = "uploadDischargeCardFiles1";
	public static final String UPLOAD_DISCHARGE_CARD_FILES2 = "uploadDischargeCardFiles2";
	public static final String BENEFICIARYFILES1 = "beneficiaryFiles1";
	public static final String BENEFICIARYFILES2 = "beneficiaryFiles2";
	public static final String NOMINEE1_FILE1 = "nominee1File1";
	public static final String NOMINEE1_FILE2 = "nominee1File2";
	public static final String NOMINEE2_FILE1 = "nominee2File1";
	public static final String NOMINEE2_FILE2 = "nominee2File2";
	public static final String GEOGRAPHICAl_AREA_ID = "geographicalAreaId";
	public static final String GOVERNRATE_ID = "governorateId";
	public static final String DISTRICT_ID = "districtId";
	public static final String OZLA_ID = "ozlaId";
	public static final String VILLAGE_ID = "villageId";
	public static final String GEOGRAPHICAL_AREA_TYPE = "geographicalAreaType";
	public static final String IS_ACTIVE = "isActive";
	public static final String GEOGRAPHICAL_AREA = "geographicalArea";
	public static final String FULL_NAME = "fullName";
	public static final String RECORD_UNIQUE_CODE = "recordUniqueCode";
	public static final String DEACTIVATED_USER = "deactivatedUser";
	public static final String BENEFICIARY_NAME = "beneficiaryName";
	public static final String IDTYPE_EN = "idTypeEn";
	public static final String IDTYPE_AR = "idTypeAr";
	public static final String GOVERNORATE_ID = "governorateId";
	public static final String BOOKLET_NUMBER = "bookletNumber";
	public static final String NOMINEE_CODE_LIST = "nomineeCodeList";
	public static final String VOUCHER_DETAILS = "vouchersDetail";
	public static final String TOTAL_VALIDATED_SERVICE = "totalValidatedService";
	public static final String PENDING_RECORDS = "pendingRecords";
	public static final String BENEFICIARY_ID_LIST = "beneficiaryIDList";
	public static final String LAST_SYNC_TIMESTAMP = "lastSyncTimeStamp";

	// Language
	public static final String ENGLISH = "1";
	public static final String ARABIC = "2";
	public static final String LOCALE_EN = "en";
	public static final String LOCALE_AR = "ar";

	// Project Number
	public static final String PROJECT_ID = "6";
	// Initial Enrollment code
	public static final String ENROLLMENT_NUMBER_START_WITH = "10001";
	public static final String ZERO = "0";
	public static final String TRUE_FLAG = "true";
	public static final String FALSE_FLAG = "false";

	// Validation
	public static final String RULE = "rule";
	public static final String FIELD_NAME = "fieldName";
	public static final String FIELD_VALUE = "fieldValue";
	public static final String DB_VALUE = "dbValue";
	public static final String VALIDATION = "validation";
	public static final String API_MESSAGE = "message";

	// Maximum number of voucher beneficiary can have
	public static final String TOTAL_VOUCHER_PER_BENEFICIARY = "4";

	// HVS deviceId registered in the GRM
	public static final Integer REGISTERED_DEVICE_ID_GRM = 3341;

	// To identify nominee
	public static final String NOMINEE1 = "_N1";
	public static final String NOMINEE2 = "_N2";

	public static final String ENROLLEMENT = "enrollment";
	public static final String ENROLL_BENEFICIARY = "ENROLL_BENEFICIARY";
	public static final String CMA = "CMA";

	public static final String ENROLLEMENT_INBOX = "enrollmentInbox";
	public static final String CMA_INBOX = "CMAInbox";

	public static final String PENDING = "pending";
	public static final String UPLOAD_UPDATED_CMA_INFO = "UPLOAD_UPDATED_CMA_INFO";
	public static final String UPLOAD_UPDATED_INFO = "Upload Update info";
	public static final String UPDATE_INFORMATION = "UPDATE_INFORMATION";
	public static final String COMMENT = "comment";
	public static final String CASE_CODE = "caseCode";

	public static final Integer COMBINATION_KEYS = 7;

	public static final String ATTACHMENT_NAME = "attachmentName";
	public static final String ATTACHMENT_EXT = "attachmentExtension";
	public static final String UNIQUE_BENEFICIARY_CODE = "uniqueBeneficiaryCode";
	public static final String ID = "id";

	public static final String PERIODIC_VISIT_UPDATEBENEFICIARY = "UPDATE_BENEFICIARY";
	public static final String PERIODIC_VISIT_ISSUEBOOKLET = "ISSUE_BOOKLET";
	public static final String PERIODIC_VISIT_PERIODICCHECKUP = "PERIODIC_CHECKUP";
	public static final String VALIDATION_SERVICE = "validationService";
	public static final String PAYMENT_SITE = "Payment Site";
	public static final String TRANSACTION_DATE = "Transatcion Date";
	public static final String TRANSACTION_TIME = "transaction time";
	public static final String ID_TYPE = "id type";
	public static final String MEMBER_CODE = "member code";

	public static final String GOVERNORATE = "governorate";
	public static final String DISTRICT = "district";
	public static final String TWO_SIMILAR_NAME_FLAG = "twoSimilarNameFlag";
	public static final String IDTYPE = "idType";
	public static final String LAST_MENSTRUATION_PERIOD = "lastMenstruationPeriod";
	public static final String HAS_DELIVERED = "hasDelivered";
	public static final String SIZE_OF_FAMILY = "sizeOfFamily";
	public static final String SEX_OF_NEW_BORN = "sexOfNewBorn";
	public static final String PLACE_OF_REFERAL = "placeOfReferal";

	public static final Long PREGNANCY_WEEK_NUMBER = 36L;
	public final static int ELIGIBILITY_MAX_DAYS_NUMBER = 60;

	public static final String DATE_FORMAT_yyyyMMdd = "yyyy-MM-dd";
	public static final String DATE_FORMAT_yyyyMMddHHmmss = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_FORMAT_yyyyMMddHHmmss_WITH_SLASH = "yyyy/MM/dd HH:mm:ss";
	public static final String DATE_FORMAT_YYYYMMDD_WITH_SLASH = "yyyy/MM/dd";

	public static final String TIMESTAMP_FORMAT = "dd/MMM/yyyy HH:mm";
	public static final String DATE_FORMAT_FOR_REPORTS = "yyyyMMddHH'h'mm'm'";
	public static final String DATE_FORMAT_WITH_MONTH_NAME = "yyyyMMMdd-HH'h'mm'm'";
	public static final String DATE_FORMAT_FOR_REPORTS_WITH_MILISICOND =
			"yyyyMMddHH'h'mm'm'ss's'SSS'ms'";
	public static final String DATE_FORMAT_FOR_CUTOFF_WITH_MILISECONDS = "yyyyMMddHHmmssSSS";
	public static final String DATE_FORMAT_HIDDEN_INPUT = "E MMM dd HH:mm:ss Z yyyy";

	public static final String TIME_FORMAT_hh_mm = "hh:mm";
	public static final String TIME_FORMAT_HH_mm = "HH:mm";

	public static final String DATE_FORMAT_MMddyyyy = "MM/dd/yyyy";
	public static final String DATE_FORMAT_DDMMYYYY_WITH_SLASH = "dd/MM/yyyy";
	public static final String DATE_FORMAT_MMMddyyyy = "MMM-dd-yyyy";
	public static final String DATE_FORMAT_MMddyyyy_hhmm = "MM/dd/yyyy hh:mm";
	public static final String DATE_FORMAT_ddMMyyyy_hhmm = "dd/MM/yyyy hh:mm";
	public static final String DATE_FORMAT_MMddyyyy_hhmmss = "MM/dd/yyyy HH:mm:ss";
	public static final String DATE_FORMAT_FOR_WATERMARK = "dd/mm/yyyy";

	public static final String DATE_FORMAT = "dd/MMM/yyyy";
	public static final String DATE_FORMAT_ONLY_NUMBERS = "dd/MM/yyyy";
	public static final String DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW = "dd-MM-yyyy";
	public static final String DATE_FORMAT_ONLY_FOR_VIEW = "dd-MMM-yyyy";

	public static final String DATE_FORMAT_ONLY_FOR_VIEWS = "dd-MMMM-yyyy";
	public static final String DATE_FORMAT_ONLY_FOR_VIEW_DATETIME = "dd-MMM-yyyy HH:mm:ss";

	public static final String ISO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	public static final String EMPTY = "";
	public static final String APOSTROPHE = "'";
	public static final String DASH = "-";
	public static final String HTTP_POST_REQUEST = "POST";
	public static final String COMMA_CHAR = ",";


	public static final String GRIEVANCE_CASE_CODE_PARAMETER = "P_GRIEVANCE_CASE_CODE";


	/*********************** NEW YCT CONSTANTS FROM HERE 15-Apr-2021 ********************/
	public static final String ADMISSION_FILE1 = "admissionFile1";
	public static final String ADMISSION_FILE2 = "admissionFile2";
	public static final String REFERRAL_FILE1 = "referralFile1";
	public static final String REFERRAL_FILE2 = "referralFile2";
	public static final String UPDATED_AT= "updatedAt";
	public static final String ADMISSION_ID= "admissionId";
	public static final String ADMISSION = "admission";  
	public static final String INVALID_PARAM_VALUE = "Invalid Or Missing Request Param Value";
	public static final String SYNC_TYPE_PARAM = "syncType";
	public static final String IS_AdMITTED = "isAdmitted";
	public static final String NON_ADMISSION_OTHER_REASONS = "nonAdmissionOtherReasons";
	public static final String OPTIONAl_VALIDATAION_CODE = "otpValidationCode";
	public static final String ENROLLMENT_ID = "enrollmentId";
	public static final String PROGRAM_ENTITY_SHORT_NAME = "programEntityShortName";
	public static final String NON_ADMISSION_REASON = "nonAdmissionReason";
	public static final String TFC_VALIDATION_CODE = "tfcValidationCode";
	public static final String CREATED_BY = "createdBy";
	public static final String UPDATED_BY = "updatedBy";
	public static final String OTP_EXPIRY_DATE = "otpExpiryDate";
	public static final String TFC_EXPIRY_DATE = "tfcExpiryDate";
	public static final String HISTORICAL_PAYMENT_LIST_RESULT = "historicalPaymentList";
	public static final String PAYMENT_CALCULATION_RESULT = "payamentCalculation";  
	public static final String HISTORICAL_PAYMENT_OBJECT = "historicalPaymentObject";
	
  public static final String SEARCH_GRIEVANCE_RESULT = "searchGrievanceResult";
  public static final String SEARCH_CASE_INBOX_RESULT = "searchSearchInboxResult";
  public static final String SUBMIT_GRIEVANCE_UTIL_OBJECT = "submitGrievanceUtilObject";

  
  public static final String GET_GEOLOCATION_DETAILS_BY_CODE_API_ENDPOINT = "/commonApiControl/getGeolocationInfoByCode";
 	public static final String ID_DOCUMENT_FILE1 = "idDocumentFile1";
	public static final String ID_DOCUMENT_FILE2 = "idDocumentFile2";
	public static final String TREATMENT_DOC_FILE1 = "treatmentDocFile1";
	public static final String TREATMENT_DOC_FILE2 = "treatmentDocFile2";
	public static final String UPLOAD_VCA_FILE1 = "uploadVcaFile1";
	public static final String UPLOAD_VCA_FILE2 = "uploadVcaFile2";

	public static final String REFERENCE_TYPE_VALIDATION = "validateService";
	public static final String REFERENCE_TYPE_VALIDATION_TREATMENT = "ValidateService-Treatment";
	public static final String REFERENCE_TYPE_VALIDATION_TREATMENT_AND_DISCHARGE = "ValidateService-TreatmentAndDischarge";
	public static final String REFERENCE_TYPE_VALIDATION_DISCHARGE  = "ValidateService-Discharge";
	public static final String REFERENCE_TYPE_VALIDATION_DISCHARGE_PLUS  = "ValidateService-Discharge_Plus";

	public static final String REFERENCE_TYPE_VALIDATION_OF_DISCHARGE  = "ValidateService-DischargeofTFC";
	public static final String REFERENCE_TYPE_ADMISSION = "Admission";
	public static final String REFERENCE_TYPE_NON_ADMISSION = "NonAdmission";
	public static final String REFERENCE_TYPE_REFERTOANOTHERTFC = "	ReferToAnotherTFC";
	public static final String VALIDATION_ID = "validationId";


	public static final String IS_REFERRED_FROM_OTHER_TFC = "is_referred_from_other_tfc";
	public static final String TFC_GEOLOCATION = "tfc_geolocation";
	public static final String OTP_GEOLOCATION = "otp_geolocation";
	public static final String OTP_REFERENCE_NUMBER = "otp_Reference_Number";
	public static final String OTP_NUTRITION_OFFICER_NAME = "otp_nut_officer_name";
	public static final String OTP_NUTRITION_OFFICER_REFERENCE_NUMBER = "otp_nut_officer_ref_number";
	public static final String OTP_NUTRITION_OFFICER_PHONE_NUMBER = "otp_nut_officer_phone_number";
	public static final String CURRENT_FORM = "currentForm";
	public static final String BOOKLET = "booklet";
	public static final String PLACE_OF_ADMISSION = "place_of_admission_location";

	public static final String ALLOW_SEND_EMAILS_FOR_PAYMENT_SITES_ENDPOINT = "/messagesCommonControl/allowSendEMailsForReceivePaymentSite";
	public static final String FIND_MESSAGE_CONTENT_BY_CODE_ENDPOINT = "/messagesControl/findMessageContentByCode";
	public static final String FIND_USER_EMAILS_BY_MESSAGEE_CONTENT_ENDPOINT = "/messagesControl/findUserEmailsByMessageContent";
	public static final String FIND_USER_BY_ROLE_BY_ROLE_NAME_ENDPOINT = "/commonApiControl/findUserByRoleByRoleName/";
	
	
	public static final String FIND_CLIENT_DEVICE_BY_DEVICE_CODE = "/commonApiControl/getClientDeviceByCode";

	
	public static final String BOL_IS_SEND_PAYMENT_SITE_EMAILS_ALLOWED = "isSendPaymentSiteEmailsAllowed";
	public static final String MESSAGE_CONTENT_OBJ = "messageContentObject";
	public static final String USER_EMAILS_OBJ = "userEMailsObject";
	public static final String USER_BY_ROLE_LIST_OBJECT = "userByRoleListObject";
	public static final String PAYMENT_SITE_OBJECT = "paymentSiteObject";
	public static final String ISSUE_LOG_SUB_CATEGORY_OBJECT = "issueLogSubCategoryList";


	public static final String DATE_FROM = "dateFrom";
	public static final String DATE_TO = "dateTo";
	public static final String NUMBER_OF_DAYS = "numberOfDays";
	public static final String NUMBER_OF_PERIODS = "numberOfPeriods";
	public static final String VALIDATION_CODE_DETAILS = "validationCodeDetails";
	
	public static final String GRIEVANCE_FOLLOWUP_ACTION_RESULT = "grievanceFollowupActionResult";
	public static final String  GRIEVANCE_TYPES_FOLLOWUP_BY_CATEGORY = "grievanceTypesByCategoryResult";
	public static final String  GRIEVANCE_ACTION_BY_ID_RESULT= "grievanceActionByIdResult";
	public static final String  GRIEVANCE_ATTACHMENTS_BY_ID_RESULT= "grievanceAttachmentsByIdResult";
	public static final String  GET_GRIEVANCE_ID_BY_CASE_CODE_RESULT= "getGrievanceIdByCaseCodeResult";
	public static final String  GET_GRIEVANCE_CATEGORY_BY_ID_RESULT= "getGrievanceCategoryByIdResult";
	public static final String  GET_GRIEVANCE_BY_ID_RESULT= "getGrievanceByIdResult";
	public static final String  GET_GRIEVANCE_DESTINATION_BY_ID= "getGrievanceDestinationByIdResult";
	public static final String  GET_GRIEVANCE_Attachment_BY_ID_RESULT= "getGrievanceAttachmentByIdResult";


	public static final String  CLOSE_GRIEVANCE_COMMENT_BY_GRIEVANCE_ID_RESULT= "closeGrievanceCommentByGrievanceIdResult";

	public static final String  CFM_GRIEVANCE_COMPLAINT_CLOSURE_COMMENT_BY_GRIEVANCE_ID_RESULT= "cfmGrievanceComplaintClosureCommentByGrievanceIdResult";

	public static final String VALIDATION_TYPE_OTP = "OTP";
	public static final String VALIDATION_TYPE_TFC = "TFC";
	public static final String VALIDATION_TYPE_PERDIEM = "PERDIEM";
	public static final String NO = "NO";
	public static final String P_GRIEVANCE_CASE_CODE = "P_GRIEVANCE_CASE_CODE";
	public static final String P_PROJECT_NAME = "P_PROJECT_NAME";
	public static final String P_GRIEVANCE_CREATED_DATE = "P_GRIEVANCE_CREATED_DATE";

	//Messages
	public static final String RAPID_PRO_MESSAGE_ID = "rapidProMessageId";
	public static final String GRIEVANCE_CODE = "grievanceCode";
	public static final String CF_CODE = "cfCode";

	
	public static final String GEOLOCATION_OBJECT = "geolocationObject";
	public static final String CYCLE_OBJECT = "cycleObject";
	public static final String PROJECT_OBJECT = "projectObject";

	public static final String ROOT_GEOLOCATIONS = "rootGeolocation";
	public static final String GEOLOCATIONS_BY_PARENTS = "geolocationsByParents";
	public static final String CYCLE_BY_PROJECT_OBJECT = "cycleByProjectObject";
	public static final String DOCUMENT_MODEL_OBJECT = "documentModelObject";
	public static final String FLAG_MODEL_LIST_OBJECT = "flagModelListObject";
	public static final String TYPE_MODEL_LIST_OBJECT = "typeModelListObject";
	public static final String ACTION_MODEL_LIST_OBJECT = "actionModelListObject";
	public static final String CALL_ATTEMPT_ACTION_MODEL_LIST_OBJECT = "callAttemptActionModelListObject";
	public static final String KEY_LIST_OBJECT = "keyListObject";
	public static final String IS_BNF_LIST_UPLOADED = "isUploaded";
	public static final String QUARTER_LIST_OBJECT = "quarterListObject";
	
	public static final String CLIENT_DEVICE_MODEL_OBJECT = "clientDeviceModelObject";

	
	public static final String BENEFICIARY_GRIEVANCE_RESULT = "beneficiaryGrievanceResult";
	public static final String USER_OBJ = "userObj";
	public static final String HISTORICAL_BENEFICIARY_MODEL = "historicalBeneficiaryModel";

	public static final String GRIEVANCE_COMPLAINT_CLOSURE_OBJECT = "grievanceComplaintClosureObject";

	public static final String API_GATEWAY_BASE_PATH = "/yct/api/v1";
	public static final String USER_DETAILS_API_ENDPOINT = "/authcontrol/fetchUserDetail";
	public static final String SYSTEM_USER_API_ENDPOINT = "/authcontrol/getSystemUser";
	public static final String USER_LOGIN_API_ENDPOINT = "/authcontrol/login";
	

	public static final String PROJECT_PARAMETER_API_ENDPOINT = "/authcontrol/fetchUserDetail";


	public static final String ADD_HISTORICAL_BENEFICIARY_MILESTONE_API_ENDPOINT = "/commonBeneficiaryApiControl/addHistoricalBeneficiaryMilestone";

	public static final String ADD_HISTORICAL_BENEFICIARY_MILESTONE_LIST_API_ENDPOINT = "/commonBeneficiaryApiControl/addHistoricalBeneficiaryMilestoneList";
	public static final String SSL_PROTOCOL = "https://";
	public static final String GET_GEOLOCATION_DETAILS_API_ENDPOINT = "/commonApiControl/getGeolocationInfo";
	public static final String CREATE_RAPIDPRO_MESSAGE_API_ENDPOINT = "/messagesControl/createRapidproMessage";
	public static final String CREATE_MESSAGE_QUEUE_API_ENDPOINT = "/emailsControl/createMessageQueue";
	public static final String GET_GEOLOCATION_DETAILS = "/commonApiControl/getGeolocationInfo";
	public static final String GET_CYCLE_BY_PROJECT_DETAILS = "/commonApiControl/getCycleByProjectInfo";
	public static final String GET_CYCLE_BY_PROJECT_ENDPOINT = "/commonApiControl/cycleByProject/";
	public static final String GET_CYCLE_BY_PROJECT_BY_PROJECT_ID_ENDPOINT = "/commonApiControl/getCycleByProjectByProjectId/";

	public static final String GET_PROJECT_CYCLES_ENDPOINT = "/commonApiControl/cycle/";
	public static final String GET_FEATURE_INFO_ENDPOINT = "/commonApiControl/featureInformation/";
	public static final String GET_ACTIVE_CYCLE_BY_PROJECT_ENDPOINT = "/commonApiControl/activeCycle/";
	public static final String GET_PROJECT_BY_ID_ENDPOINT = "/commonApiControl/getProjectInfoById/";

	
	public static final String SEARCH_BY_VCA_NUMBER = "searchByVCANumber";
	public static final String SEARCH_ALL = "searchAll";
	public static final String SEARCH_BY_NAME_AND_GEOLOCATION = "searchByNameAndGeolocation";
	public static final String SEARCH_BY_NAME = "searchByName";
	public static final String SEARCH_BY_GEOLOCATION = "searchByGeolocation";
	public static final String SPACE_DELIMETER = " ";
	public static final String PROJECT_PARAMETER_VALUE = "projectParameterValue";
	public static final String ACTIVE_CYCLE_VALUE = "activeCycleValue";
	public static final String MESSAGE_QUEUE_MODEL_OBJECT = "messageQueueModelObject";
	public static final String PAID_BENEFICIARY_OBJECT = "paidBeneficiaryModel";
	public static final String FEATURE_INFO_VALUE = "featureInfoValue";
	

	public static final String GET_ACTIVE_CYCLE_ENDPOINT = "/cycleControl/getActiveCycle";

	public static final String CURRENT_FORM_OBJ = "currentFormObject";
	public static final String CURRENT_FORM_MODEL_OBJ = "currentFormModelObject";

	public static final String VALIDATION_CODE_LIST = "validationCodeList";

	public static final String SERVICE_TYPE_LIST = "serviceTypeList";

	public static final String DOCUMENT_OBJECT = "documentObject";

	public static final String HOUSEHOLD_MEMBER_OBJECT = "householdMemberObject";
	public static final String HOUSEHOLD_MEMBER__MODEL_OBJECT = "householdMemberModelObject";
	public static final String HOUSEHOLD_MEMBER__MODEL_LIST_OBJECT = "householdMemberModelListObject";

	public static final String GRIEVANCE_CATEGORY_MODEL_LIST = "grievanceCategoryModelList";
	public static final String GRIEVANCE_TYPE_MODEL_LIST = "grievanceTypeModelList";
	public static final String REQUEST_GRIEVANCE_CANCELATION_MODEL = "requestCancelGrievanceModel";
	public static final String EXTERNAL_GRIEVANCE_MODEL = "externalGrievanceModel";
	
	public static final String ADDITIONAL_FIELD_BY_GRIEVANCE_TYPE_LIST_MODEL = "additionalFieldByGrievanceTypeListModel";
	public static final String ADDITIONAL_FIELD_VALUE_BY_GRIEVANCE_MODEL_LIST = "additionalFieldValueByGrievanceModelList";

	

	
	
	public static final String GET_PROJECT_PARAMETER_VALUE_ENDPOINT = "/commonApiControl/getProjectParameteValuerByName";
	public static final String GET_DOCUMENT_BY_SHORT_NAME_ENDPOINT = "/commonBeneficiaryApiControl/getDocumentByShortName";
	public static final String GET_HOUSEHOLD_MEMBER_BY_CODE_ENDPOINT = "/commonBeneficiaryApiControl/findHouseholdMemberByCode";

	public static final String GET_CURRENT_FORM_BY_FORM_NUMBER_ENDPOINT = "/commonBeneficiaryApiControl/findFormByFormNumber";
	public static final String GET_CURRENT_FORM_BY_VCA_NUMBER_ENDPOINT = "/commonBeneficiaryApiControl/findFormByVca";
	public static final String GET_VALIDATION_CODE_BY_VCA_NUMBER_ENDPOINT = "/validationControl/getValidationCodeByVca";
	public static final String REDEEM_VALIDATION_CODE_ENDPOINT = "/validationControl/redeemValidationCodeList";
	
	public static final String CALCULATE_CYCLE_AMOUNT_ENDPOINT = "/historicalPayment/cycleAmount";
	public static final String HISTORICAL_PAYMENT_INFO_ENDPOINT = "/historicalPayment/historicalPaymentInfoList";
	public static final String HISTORICAL_PAYMENT_ACTIVE_CYCLE_INFO_ENDPOINT = "/historicalPayment/historicalPaymentInfoActiveCycle";
		
	public enum CommonEntityList {
		GEOLOCATION("cat_geolocation"), 
		PROGRAM("cat_program_entity"), 
		GEOLOCATIONTYPE("cat_geolocation_type"), 
		GRIEVANCECATEGORY("cat_grievance_category"),
		GRIEVANCEAGAINST("cat_grievance_against"),
	  	OWNERSHIPTYPE("cat_ownership_type"),
		INQUIRY_CATEGORY("cat_inquiry_category"),
		INQUIRY_TYPE("cat_inquiry_type"),
		PROJECT("adm_project"),
		GRIEVANCEACTION("cat_grievance_action"),
		GRIEVANCEACTIONSENDBACKTOOWNER("cat_grievance_action_send_back_to_owner"),
		AGENCY("cat_agency"),
		ISSUE_TYPE("cat_issue_type"),
		CFM_PROGRAMME("adm_cfm_programme"),
		CFM_TYPE_OF_INFORMATION("adm_cfm_type_of_information"),
		CFM_PROJECT_INTERVENTION("adm_cfm_project"),
		CFM_GENDER("cat_cfm_gender"),
		CFM_PRIORITY("cat_cfm_priority"),
		CFM_COMPLAINANT_MEDIUM("cat_cfm_complainant_medium"),
		CFM_INFORMATION_CHANNEL("cat_cfm_information_channel"),
		CFM_PREFERRED_COMMUNICATION_CHANNEL("cat_cfm_preferred_communication_channel"),
		CFM_PRIORITY_TIMEFRAME("cat_cfm_priority_timeframe"),
		CFM_GRIVANCE_STATUS("adm_cfm_grievance_status"),
		CFM_IMPLEMENTATION_PARTNER("adm_cfm_implementation_partner"),
		CFM_GRIEVANCE_CATEGORY("cat_cfm_grievance_category"),
		CFM_IMPLEMENTATION_SITE("cat_cfm_implementation_site"),
		CATEGORY("adm_grievance_category_by_role"),
		CFM_GRIEVANCE_ACTION("cat_cfm_grievance_action"),
		GRIEVANCECHANNEL("adm_channel"),
		GRIEVANCYCLE("adm_cycle");







		final String commonEntityName;

		CommonEntityList(String commonEntity) {
			commonEntityName = commonEntity;
		}

		public String getCommonEntityName() {
			return commonEntityName;
		}


	}
  
  public static final String GEOLOCATION_DROPDOWN_API_ENDPOINT = "/beneficiaryViewcontrol/geoLocationDropDowns";
  
  public static final String ENTIY_NAME_PARAM = "entityName";
  public static final String PARENT_ID_PARAM = "parentId";
  public static final String SHORT_NAME_PARAM = "typeShortName";
  public static final String NUMBER_OF_LEVELS_PARAM = "numberOfLevels";
  public static final String FUNCTION_NAME_PARAM = "functionName";
  public static final String SEARCH_TYPE_PARAM = "searchType";
  public static final String PROJECT_ID_PARAM = "projectId";
  public static final String ROLE_ID_PARAM= "roleId";
  public static final String GEOLOCATION_ID_PARAM = "geolocationId";
  public static final String PROJECT_SHORT_NAME_PARAM = "projectShortName";

  public static final String ENROLLMENT_ID_LIST = "enrollmentIDList";
  public static final String VALIDATION_ID_LIST = "validationIDList";
  public static final String ADMISSION_ID_LIST = "admissionIDList";
  
  public static final String CAREGIVER_FILE = "caregiverFile";
  public static final String NOMINEE_FILE = "nomineeFile";
  
  public static final String TFC_SHORT_NAME = "tfcShortName";
  public static final String GEO_LOCATION_AREA = "geoLocationArea";
  
  public static final String HOUSEHOLD_MEMBER_LIST = "householdMemberList";
  public static final String DOC_SHORT_NAME = "documentShortName";
  public static final String DOC_SHORT_REF = "documentReferenceNo";
  public static final String PLACE_OF_ADMSN_SHORT_NAME = "placeOfAdmissionShortName";
  public static final String IS_REQUIRED_INVESTIGATION = "isRequireInvestigation";

  public static final String LANGUAGE_EN = "1";
  public static final String LANGUAGE_AR = "2";
  public static final String INQUIRY_CAT_ID_PARAM = "inquiryCatId";
  public static final String INQUIRY_TYPE_ID_PARAM = "inquiryTypeId";  
  public static final String SWAGGER_ENDPOINT = "/swagger";
  
  public static final String CREATION_TIMESTAMP_FORMAT = "dd-MM-yyyy HH:mm:ss";
  
  public static final String USER_DETAILS_BY_SHORT_NAME_API_ENDPOINT = "/authcontrol/fetchUserDetailByShortName"; 
  public static final String BENEFICIARY_LIST_REVIEW_RESPONSE_OBJ = "beneficiaryListReviewResponseObject";
  
  public static final String BENEFICIARY_LIST_REVIEW_TO_UPDATE_RESPONSE_OBJ = "beneficiaryListReviewToUpdateResponseObject";

  public static final String COMMON_GET_CYCLE_BY_PROJECT_URL = "/commonApiControl/getCycleByProjectInfo";
  
  //Issue log
  public static final String ISSUE_LOG_ISSUES_LIST = "issuesList";
  public static final String USER_ROLE_LIST_OBJ = "userRoleListObj";


  
  public static final String BENEFICIARY_CARD_TAB_LIST = "beneficiaryCardsTabList";

  public static final String FACILITY_CARD_TAB_LIST = "facilityCardsTabList";
  public static final String PROJECT_SHORT_NAME = "projectShortName";
  public static final String PROJECT_REVIEW_SCHEME = "projectReviewScheme";
  public static final String HOUSEHOLD_CARD_INFO_LIST = "householdCardInfoList";
  public static final String FACILITY_CARD_INFO_LIST = "facilityCardInfoList";
  public static final String PROJECT_NAME = "projectName";
  public static final String UNIQUE_CODE = "uniqueCode";
  public static final String PRIMARY_MEMBER = "primaryMemberName";
  public static final String PAYMENT_BY_SERVICE_CARD_INFO_LIST = "paymentByServiceCrdInfoList";
  public static final String PAYMENT_BY_CYCLE_CARD_INFO_LIST = "paymentByCycleCrdInfoList";
  public static final String GRIEVANCES_CARD_INFO_LIST = "grievancesCrdInfoList";
  public static final String INQUIRIES_CARD_INFO_LIST = "inquiriesCrdInfoList";
  public static final String INQUIRIES_LIST = "inquiriesList";
  public static final String MEMBER_CARD_INFO_LIST = "memberCardInfoList";
  public static final String BENEFICIARY_DATA = "BENEFICIARY DATA";
  public static final String BENEFICIARY_LIST = "beneficiaryList";
  public static final String RECORD_ID = "recordId";
  public static final String LAST_RECORD_DOWNLOAD_ID = "lastDownloadRecordId";
  public static final String DEVICE_DETAILS_API_ENDPOINT = "/authcontrol/fetchDeviceDetail";
  public static final String RECORD_UNIQUE_ID = "uniqueId";
  public static final String RECORD_DELIMETER = "|";  
  public static final String BENEFICIARY_TIMELINE_DATA = "beneficiaryTimelineData";
  public static final String ISSUE_LOG_FILE1 = "issueLogFile1";
  public static final String ISSUE_LOG_ID = "issuesLogId";
  public static final String ISSUE_LOG_PAYMENT_SITE_LIST = "paymentSiteListForIssueLog";
  public static final String PAYMENT_SITE_DATA = "paymentSiteData";
  public static final String CONTACT_CARD_INFO_LIST = "contactCardInfoList";
  public static final String ISSUE_LOG_FILE2 = "issueLogFile2";
  
  
  public static final String YUMN_EMAIL_NAME = "Yumn MIS";

  public static final String PAYMENT_LIST_SUMMARY_BY_CRITERIA_OBJECT = "paymentListSummaryByCriteriaObject";

  //CFM
  public static final String CFM_RESULTLIST = "cfmResultList";

  //EXPRESS PAYMENT
  public static final String EXPRESS_PAYMENT_REVIEW_RESPONSE_OBJ = "expressPaymentReviewResponseObject";
  
  public static final String EXPRESS_PAYMENT_UPLOAD_IN_PROGRESS = "Uploading in Progress";
  public static final String EXPRESS_PAYMENT_UPLOAD_SUCCESS = "Upload Success";
  public static final String EXPRESS_PAYMENT_UPLOAD_ERROR = "Upload Error";

}
