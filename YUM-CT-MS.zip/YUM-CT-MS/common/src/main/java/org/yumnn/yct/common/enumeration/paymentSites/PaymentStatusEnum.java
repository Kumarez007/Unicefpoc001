package org.yumnn.yct.common.enumeration.paymentSites;

import org.yumnn.yct.common.entity.base.Displayable;

public enum PaymentStatusEnum implements Displayable {
	
	PAID("PAID","مدفوع"), NOT_PAID("NOT PAID","غير مدفوع");
	String enStatus;
	String arStatus;

	PaymentStatusEnum(String enStatus, String arStatus) {
		this.enStatus = enStatus;
		this.arStatus = arStatus;
	}

	@Override
	public String getDisplayName() {
		return enStatus + " - " + arStatus;
	}

	@Override
	public Object getObject() {
		return this;
	}
	
	public String getValue(){
		return this.arStatus;
	}


}
