package org.yumnn.yct.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Geolocation;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Repository
public interface GeographicalAreaRepository extends JpaRepository<Geolocation, Long> {

  List<Geolocation> findByIsActive(String flag);

  @Override
  Optional<Geolocation> findById(Long id);

  Optional<Geolocation> findByShortName(String shortName);
}
