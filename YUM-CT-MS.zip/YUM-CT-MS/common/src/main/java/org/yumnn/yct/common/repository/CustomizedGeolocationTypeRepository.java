package org.yumnn.yct.common.repository;

import java.util.List;

import org.yumnn.yct.common.entity.catalog.GeolocationType;

/**
 * 
 * @author wkaraleh
 *
 */
public interface CustomizedGeolocationTypeRepository {
	/**
	 * WQ
	 * @param geolocationType
	 * @return
	 */
	GeolocationType findByParent(GeolocationType geolocationType) ;

	/**
	 * WQ
	 * @return
	 */
	GeolocationType retrieveMaxGeolocationTypeByOrderItem();
	/**
	 * WQ
	 * @return
	 */
	Long retrieveCountGeolocationType();
	/**
	 * WQ
	 * @param numberOfLevels
	 * @return
	 */
	List<GeolocationType> findByNumberOfLevel(Integer numberOfLevels);
	/**
	 * WQ
	 * @return
	 */
	List<GeolocationType> findAllOrderedByOrderItem();
}
