package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;


/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name MessageParameterByReminder.java
 * @create_date Nov 30, 2021
 * @last_Update Nov 30, 2021
 */
@Entity
@Table(name = "messages.stp_message_parameter_by_reminder")
@NamedQueries({
		@NamedQuery(name = "MessageParameterByReminder.retrieveByReminder", query = "SELECT t.reminderMessageParameter FROM MessageParameterByReminder t WHERE t.reminder = :reminder order by t.parameteOrderInQuery") })
public class MessageParameterByReminder extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_reminder_fk", referencedColumnName = "ID")
	private Reminder reminder;

	@ManyToOne
	@JoinColumn(name = "id_reminder_message_parameter_fk", referencedColumnName = "ID")
	private ReminderMessageParameter reminderMessageParameter;

	@Column(name = "parameter_order_in_query")
	private Integer parameteOrderInQuery;

	/**
	 * @return the reminder
	 */
	public Reminder getReminder() {
		return reminder;
	}

	/**
	 * @param reminder the reminder to set
	 */
	public void setReminder(Reminder reminder) {
		this.reminder = reminder;
	}

	/**
	 * @return the reminderMessageParameter
	 */
	public ReminderMessageParameter getReminderMessageParameter() {
		return reminderMessageParameter;
	}

	/**
	 * @param reminderMessageParameter the reminderMessageParameter to set
	 */
	public void setReminderMessageParameter(ReminderMessageParameter reminderMessageParameter) {
		this.reminderMessageParameter = reminderMessageParameter;
	}

	/**
	 * @return the parameteOrderInQuery
	 */
	public Integer getParameteOrderInQuery() {
		return parameteOrderInQuery;
	}

	/**
	 * @param parameteOrderInQuery the parameteOrderInQuery to set
	 */
	public void setParameteOrderInQuery(Integer parameteOrderInQuery) {
		this.parameteOrderInQuery = parameteOrderInQuery;
	}
}
