/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.administration.FeatureShortNameEnum;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.model.administration.FeatureInformationModel;

/**
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FeatureInformation.java
 * @class_description
 * @create_date Feb 23, 2020
 * @last_Update Feb 23, 2020
 */
@Entity
@Table(name = "user_access.adm_feature_information")
public class FeatureInformation extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "short_name")
	@Enumerated(EnumType.STRING)
	private FeatureShortNameEnum shortName;

	@Column(name = "description")
	private String description;

	@Column(name = "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	@Column(name = "action_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date actionDate;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;

	/**
	 * @return the shortName
	 */
	public FeatureShortNameEnum getShortName() {
		return shortName;
	}

	/**
	 * @param shortName
	 *            the shortName to set
	 */
	public void setShortName(FeatureShortNameEnum shortName) {
		this.shortName = shortName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the actionDate
	 */
	public Date getActionDate() {
		return actionDate;
	}

	/**
	 * @param actionDate
	 *            the actionDate to set
	 */
	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive
	 *            the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
	/**
	 * 
	 * @author WQ
	 * @date Aug 5, 2021
	 * @description_method 
	 * @return
	 */
	public FeatureInformationModel getConvertedFeatureInformation() {
		FeatureInformationModel featureInformationModel = new FeatureInformationModel();
		featureInformationModel.setId(this.id);
		featureInformationModel.setIsActive(this.isActive);
		featureInformationModel.setActionDate(this.actionDate);
		featureInformationModel.setShortName(this.shortName);
		featureInformationModel.setDescription(this.description);
		featureInformationModel.setCreationDate(this.creationDate);
		return featureInformationModel;
	}
}
