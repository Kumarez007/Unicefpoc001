/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;
import org.yumnn.yct.common.enumeration.flag.FlagForHouseholdOrIndividualEnum;
import org.yumnn.yct.common.enumeration.flag.FlagTypeEnum;
import org.yumnn.yct.common.model.administration.FlagModel;
import org.yumnn.yct.common.util.Utilities;

/**
 * @author Ala'a Darwish
 * @department PMU.
 * @owner UNICEF.
 * @class_name Flag.java
 * @class_description
 * @create_date May 08, 2019
 * @last_Update May 08, 2019
 */
@Entity
@Table(name = "beneficiary.cat_flag")
public class Flag extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	@Column(name = "flag_type")
	@Enumerated(EnumType.STRING)
	private FlagTypeEnum flagType;
 
	@Column(name = "flag_for")
	@Enumerated(EnumType.STRING)
	private FlagForHouseholdOrIndividualEnum flagFor;

	@Column(name = "flag_description")
	private String flagDescription;

	@Column(name = "flag_description_ar")
	private String flagDescriptionAr;

	@ManyToOne
	@JoinColumn(name = "id_cycle_by_project_fk", referencedColumnName = "ID")
	private CycleByProject cycleByProject;

	@ManyToOne
	@JoinColumn(name = "id_flag_parent_fk", referencedColumnName = "ID")
	private Flag parentFlag;

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	public FlagTypeEnum getFlagType() {
		return flagType;
	}

	public void setFlagType(FlagTypeEnum flagType) {
		this.flagType = flagType;
	}

	public String getFlagDescription() {
		return flagDescription;
	}

	public void setFlagDescription(String flagDescription) {
		this.flagDescription = flagDescription;
	}


	/**
	 * @return the cycleByProject
	 */
	public CycleByProject getCycleByProject() {
		return cycleByProject;
	}

	/**
	 * @param cycleByProject the cycleByProject to set
	 */
	public void setCycleByProject(CycleByProject cycleByProject) {
		this.cycleByProject = cycleByProject;
	}

	public Flag getParentFlag() {
		return parentFlag;
	}

	public void setParentFlag(Flag parentFlag) {
		this.parentFlag = parentFlag;
	}

	public FlagForHouseholdOrIndividualEnum getFlagFor() {
		return flagFor;
	}

	public void setFlagFor(FlagForHouseholdOrIndividualEnum flagFor) {
		this.flagFor = flagFor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		Flag other = (Flag) obj;
		if (id == null) {
			if (other.id != null) return false;
		} else if (!id.equals(other.id)) return false;
		return true;
	}

	public String getFlagDescriptionAr() {
		return flagDescriptionAr;
	}

	public void setFlagDescriptionAr(String flagDescriptionAr) {
		this.flagDescriptionAr = flagDescriptionAr;
	}

	public FlagModel getFlagModel() {
		FlagModel flagModel = new FlagModel();
		flagModel.setCycleByProjectId(cycleByProject.getId());
		flagModel.setFlagDescription(flagDescription);
		flagModel.setFlagDescriptionAr(flagDescriptionAr);
		flagModel.setFlagFor(flagFor);
		flagModel.setFlagType(flagType);
		flagModel.setId(id);
		flagModel.setNameAr(getArabicName());
		flagModel.setNameEn(getEnglishName());
		flagModel.setShortname(getShortName());
		flagModel.setParentFlagId(Utilities.isNULL(parentFlag) ? null :parentFlag.getId());
		return flagModel;
	}
}
