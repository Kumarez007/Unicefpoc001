package org.yumnn.yct.common.util;

import org.yumnn.yct.common.entity.messages.RapidProMessagesToProcess;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name RapidproMessageToProcessWithStatusDescriptionUtil.java
 * @create_date Oct 27, 2021
 * @last_Update Oct 27, 2021
 */
public class RapidproMessageToProcessWithStatusDescriptionUtil {

	private RapidProMessagesToProcess rapidProMessagesToProcess;
	private String statusDescription;


	/**
	 * 
	 * Constructor
	 */
	public RapidproMessageToProcessWithStatusDescriptionUtil(
			RapidProMessagesToProcess rapidProMessagesToProcess, String statusDescription) {
		super();
		this.rapidProMessagesToProcess = rapidProMessagesToProcess;
		this.statusDescription = statusDescription;
	}
	
	/**
	 * @return the rapidProMessagesToProcess
	 */
	public RapidProMessagesToProcess getRapidProMessagesToProcess() {
		return rapidProMessagesToProcess;
	}

	/**
	 * @param rapidProMessagesToProcess the rapidProMessagesToProcess to set
	 */
	public void setRapidProMessagesToProcess(RapidProMessagesToProcess rapidProMessagesToProcess) {
		this.rapidProMessagesToProcess = rapidProMessagesToProcess;
	}

	/**
	 * @return the statusDescription
	 */
	public String getStatusDescription() {
		return statusDescription;
	}

	/**
	 * @param statusDescription the statusDescription to set
	 */
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

}
