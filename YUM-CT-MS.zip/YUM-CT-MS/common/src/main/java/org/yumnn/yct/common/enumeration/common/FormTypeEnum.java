package org.yumnn.yct.common.enumeration.common;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name FormTypeEnum.java
 * @create_date Nov 7, 2021
 * @last_Update Nov 7, 2021
 */
public enum FormTypeEnum {

	BENEFICIARY, PROGRAM_ENTITY,TEACHER,TRAINER,SCHOOL

}
