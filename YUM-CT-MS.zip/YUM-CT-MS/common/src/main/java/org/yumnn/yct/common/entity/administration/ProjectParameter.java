/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ProjectParameter.java
 * @class_description represents a catalog table from database which contains
 *                    ProjectParameter
 * @create_date Oct 13, 2016
 * @last_Update Oct 13, 2016
 */
@Entity
@Table(name = "user_access.cat_project_parameter")
public class ProjectParameter extends BaseEntity implements Serializable {
	private static final long serialVersionUID = -6739919052158515878L;

	@Size(max = 50)
	@Column(name = "name", length = 50, columnDefinition = "character varying (50)")
	private String name;

	@Size(max = 1024)
	@Column(name = "value", length = 1024, columnDefinition = "character varying (1024)")
	private String value;

	public ProjectParameter() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Double getValueAsDouble() {
		try {
			return Double.parseDouble(value);
		} catch (Exception e) {
			return 0.0;
		}
	}

}
