package org.yumnn.yct.common.enumeration.catalog;

import java.util.ArrayList;
import java.util.List;


/**
 	* @author Jorge Villafuerte
 	* @department IT Department - Ecuador
 	* @owner Ayala Consulting Corporation.
 	* @class_name NotVerifiedReasonCatalogShortNameEnum.java
 	* @class_description shortName for NotVerifiedReasonCatalog
 	* @create_date Sep 25, 2017
 	* @last_Update Sep 25, 2017
 	*/
public enum NotVerifiedReasonCatalogShortNameEnum {

	passbook_damage, id_damage, falsified_doc;
	
	
	public static List<NotVerifiedReasonCatalogShortNameEnum> getCatalogOrderForMobileApplication(){
		List<NotVerifiedReasonCatalogShortNameEnum> list = new ArrayList<>();
		list.add(passbook_damage);
		list.add(id_damage);
		list.add(falsified_doc);
		return list;
	}
	
}
