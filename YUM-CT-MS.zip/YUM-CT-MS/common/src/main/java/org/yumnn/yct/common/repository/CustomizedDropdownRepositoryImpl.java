package org.yumnn.yct.common.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.yumnn.yct.common.entity.base.DropDownModel;
import org.yumnn.yct.common.exception.TheresNoEntityException;
import org.yumnn.yct.common.query.util.DropdownNativeQueries;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 6, 2021 1:17:15 PM
 */
@SuppressWarnings("unchecked")
public class CustomizedDropdownRepositoryImpl implements CustomizedDropdownRepository {
	@PersistenceContext
	protected EntityManager em;

	@Override
	public List<DropDownModel> getProgramEntityDropdownByIdAsc(String id, Boolean onlyTFCRequired, String projectId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getProgramEntityDropdownByIdAsc(id,onlyTFCRequired,projectId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getProgramEntityDropdownByIdAsc(String id, Boolean onlyTFCRequired, String projectId, String path) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getProgramEntityDropdownByIdAsc(id,onlyTFCRequired,projectId,path),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}


	@Override
	public List<DropDownModel> getProjectDropdownByShortNameAsc(String shortName) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getProjectDropdownByShortNameAsc(shortName),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getOwnershipDropdownByAsc() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getOwnershipDropdownByAsc(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getGrievanceAgainstDropdownAsc() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceAgainstDropdownAsc(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getGrievanceCategoryDropdownAsc(String projectId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceCategoryDropdownAsc(projectId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	
	
	
	
	@Override
	public List<DropDownModel> getGrievanceCategoryByRoleDropdownAsc(String roleId) {
		Query 	query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceCategoryByRoleDropdownAsc(roleId),
					DropDownModel.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}


	@Override
	public List<DropDownModel> getGrievanceCategoryDropdownAsc() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceCategoryDropdownAsc(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	@Override
	public List<DropDownModel> getGrievanceChannelDropdownAsc() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceChannelDropdownAsc(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	
	
	@Override
	public List<DropDownModel> getGrievanceCycleDropdownAsc(String projectId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceCycleDropdownAsc(projectId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	
	@Override
	public List<DropDownModel> getGovernorateDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGovernorateDropDown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getGeoDropDownByParentId(String id) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGeoDropDownByParentId(id),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getInquiryCatDropdown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getInquiryCatDropdown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getInquiryCatDropdownById(String inquiryCatId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getInquiryCatDropdownById(inquiryCatId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getInquiryTypeDropdownByCategory(String inquiryCatId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getInquiryTypeDropdownByCategory(inquiryCatId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getInquiryTypeDropdownById(String inquiryTypeId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getInquiryTypeDropdownById(inquiryTypeId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getProjectDropdown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getProjectDropdown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getProjectDropdownById(String projectId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getProjectDropdownById(projectId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getGrievanceActionDropdown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceActionDropdown(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	
	@Override
	public List<DropDownModel> getGrievanceActionDropdownTable() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceActionDropdownTable(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}
	
	@Override
	public List<DropDownModel> getGrievanceActionDropdownSendBackToOwner() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceActionDropdownSendBackToOwner(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getAgenciesDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getAgencyDropdown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getActiveIssueTypesDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getActiveIssueTypesDropDown(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMProgrammeDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMProgrammeDropDown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMTypeOfInformationDropDown(Long roleId) {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMTypeOfInformationDropDown(roleId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMProjectDropDownByProgrammeId(Long programmeId, Boolean mainProjectsOnly) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMProjectDropDownByProgrammeId(programmeId, mainProjectsOnly),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMGendersDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMTGendersDropDown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMPriorityDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMPriorityDropDown(), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMPComplainantMediumDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMPComplainantMediumDropDown(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMPInformationChannelDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMPInformationChannelDropDown(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMPPreferedCommunicationChannelDropDown() {
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getCFMPPreferedCommunicationChannelDropDown(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMPriorityTimeframelDropDownByPriorityId(Long priorityId) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMPriorityTimeframelDropDownByPriorityId(priorityId), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMGrievanceStatusByTypeOfInformationIdDropDown(Long typeOfInfoId , String displayOnCFMForm) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMGrievanceStatusByTypeOfInfoIdDropDown(typeOfInfoId , displayOnCFMForm), DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMImplementationPartnersByProgrammeIdDropDown(Long programmeId) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMImplementationPartnersByProgrammeIdDropDown(programmeId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMGrievanceCategoryByTypeOfInfoIdDropDown(Long typeOfInformationId,String isActive) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMGrievanceCategoryByTypeOfInfoIdDropDown(typeOfInformationId,isActive),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMImplementationSitesByGeolocationIdDropDown(Long geolocationId) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMImplementationSitesByGeolocationIdDropDown(geolocationId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMSubProjectsByMainProjectId(Long projectId) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMSubProjectsByMainProjectId(projectId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMGrievanceCategoryByTypeOfInfoIdAndRoleIdDropDown(Long typeOfInformationId,
			Long roleId) {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMGrievanceCategoryByTypeOfInfoIdAndRoleIdDropDown(typeOfInformationId , roleId),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getCFMGrievanceActions() {
		Query query = this.em.createNativeQuery(
				DropdownNativeQueries.getCFMGrievanceActions(),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	
	@Override
	public List<DropDownModel> getGrievanceCategoryByProjectDropdownAsc(String roleId, String projectId) {
		Query 	query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceCategoryByProjectDropdownAsc(roleId,projectId),
					DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	@Override
	public List<DropDownModel> getGrievanceChannelByRoleDropdownAsc(String roleId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DropDownModel> getGrievanceChannelByProjectDropdownAsc(String roleId, String projectId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DropDownModel> getGrievanceActionDropdownByLoggedInRole(Long id) {
		// TODO Auto-generated method stub
		Query query = this.em.createNativeQuery(DropdownNativeQueries.getGrievanceActionDropdownByRoleId(id),
				DropDownModel.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	
	}


}
