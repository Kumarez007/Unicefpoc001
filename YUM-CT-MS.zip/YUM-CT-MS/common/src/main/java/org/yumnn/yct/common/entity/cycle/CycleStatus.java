/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.cycle;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.cycle.CycleStatusEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 	* @author Alaa Darwish
 	* @department PMU - ICT
 	* @owner UNICEF
 	* @class_name CycleStatus.java
 	* @class_description 
 	* @create_date Feb 17, 2019
 	* @last_Update Feb 17, 2019
 	*/

@Entity
@Table(name = "adm_cycle_status")
@NamedQueries({
		@NamedQuery(name = "CycleStatus.findCurrentStatusByCycle", query = "SELECT t FROM CycleStatus t WHERE t.cycle = :cycle AND t.endingDate IS NULL ") })
public class CycleStatus extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_cycle_fk", referencedColumnName = "ID")
	private Cycle cycle;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private CycleStatusEnum cycleStatus;

	@Column(name = "creation_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date creationDate;

	@Column(name = "ending_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date endingDate;

	@Column(name = "status_description")
	private String statusDescription;

	public CycleStatus() {
	}

	public CycleStatus(Cycle cycle, CycleStatusEnum cycleStatus, Date creationDate) {
		super();
		this.cycle = cycle;
		this.cycleStatus = cycleStatus;
		this.creationDate = creationDate;
	}

	public CycleStatus(Cycle cycle, CycleStatusEnum cycleStatus, Date creationDate, String statusDescription) {
		super();
		this.cycle = cycle;
		this.cycleStatus = cycleStatus;
		this.creationDate = creationDate;
		this.statusDescription = statusDescription;
	}

	public Cycle getCycle() {
		return cycle;
	}

	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	public CycleStatusEnum getCycleStatus() {
		return cycleStatus;
	}

	public void setCycleStatus(CycleStatusEnum cycleStatus) {
		this.cycleStatus = cycleStatus;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getEndingDate() {
		return endingDate;
	}

	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

}