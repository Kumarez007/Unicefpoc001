/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License; Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing; software
 * distributed under the License is distributed on an "AS IS" BASIS; WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND; either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.enumeration.catalog;

import java.util.ArrayList;
import java.util.List;

public enum ProblemsExperiencedShortNameEnum {
	lack_of_access_due_to_security,
	insufficient_bsgr_personnel,
	uncontrolled_and_unorganized_flow_of_beneficiaries,
	beneficiaries_being_given_incorrect_messages,
	beneficiaries_not_knowing_what_to_bring_with_them_or_what_to_do,
	absence_of_all_the_required_documents_in_their_possession,
	long_line_wait,
	insufficient_quantity_of_authorization_forms_at_the_section,
	no_facilitation_officers_at_the_section,
	large_amount_of_non_beneficiaries_inside_the_bsgr_section,
	inability_of_disabled_people_accessing_the_section,
	confusion_as_to_which_table_to_approach,
	slow_internet_access,
	no_internet_access,
	bsgr_protocols_are_not_being_followed,
	beneficiary_expressing_dissatisfaction,
	problems_with_bsgr_offline_application,
	problems_with_bsgr_online_application,

	not_agree_to_cooperate,
	not_interested_in_the_project,
	high_level_of_conflict,
	no_confidence_in_the_donor,

	lack_of_agreement_for_cooperation,
	chaos_due_to_uncontrolled_and_unorganized_flow_of_people,
	lack_of_coordination_among_stakeholders_unicef_and_other_service,
	insufficent_messaging_and_information_materials,
	no_messaging_and_information_materials,
	insufficient_facilitation_personnel,
	local_actors_not_interested_in_the_project,
	local_actors_have_no_confidence_in_the_donor,
	communication_problems,
	lack_of_consensus_amongst_local_actors,
	locality_village_not_organized_properly,
	remote_area,

	inomplete_names,
	order_of_names,
	short_name,

	not_verified_benef_going_payment_site,
	insufficient_number_cashiers,
	not_enough_benef_to_pay,
	lack_enough_cash,
	prob_accessing_pay_site_software,
	benef_not_knowing_proj_rules,
	
	
	cannot_attend_chronical_illness,
	cannot_attend_disability,
	cannot_attend_senior_citizen,
	cannot_attend_risk_pregnacy,
	cannot_attend_other_factors,
	
	beneficiary_identity_theft_verified_yes,
	beneficiary_identity_theft_verified_no



	;

	// BSGR
	public static List<ProblemsExperiencedShortNameEnum> getListForBSGRDailyProgress() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();

		list.add(lack_of_access_due_to_security);
		list.add(insufficient_bsgr_personnel);
		list.add(benef_not_knowing_proj_rules);
		list.add(insufficient_quantity_of_authorization_forms_at_the_section);
		list.add(problems_with_bsgr_offline_application);
		list.add(problems_with_bsgr_online_application);
		list.add(beneficiaries_being_given_incorrect_messages);
		list.add(beneficiary_expressing_dissatisfaction);
		return list;
	}

	// FACILITATION
	public static List<ProblemsExperiencedShortNameEnum> getListForFacilitationDailyProgressSectionInLocalActors() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();
		list.add(not_agree_to_cooperate);
		list.add(not_interested_in_the_project);
		list.add(lack_of_access_due_to_security);
		list.add(high_level_of_conflict);
		return list;

	}

	public static List<ProblemsExperiencedShortNameEnum> getListForFacilitationDailyProgressSectionVillageLocality() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();

		list.add(lack_of_agreement_for_cooperation);
		list.add(local_actors_not_interested_in_the_project);
		list.add(communication_problems);
		list.add(lack_of_access_due_to_security);
		list.add(insufficent_messaging_and_information_materials);
		list.add(beneficiary_expressing_dissatisfaction);

		return list;

	}

	public static List<ProblemsExperiencedShortNameEnum> getListForFacilitationDailyProgressSectionVillageLocalityReasonNotAccesible() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();
		list.add(lack_of_access_due_to_security);
		list.add(high_level_of_conflict);
		list.add(remote_area);
		return list;
	}

	// PAYMENT SITE
	public static List<ProblemsExperiencedShortNameEnum> getListForPaymentSiteDailyProgress() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();
		list.add(lack_of_access_due_to_security);
		list.add(not_verified_benef_going_payment_site);
		list.add(insufficient_number_cashiers);
		list.add(not_enough_benef_to_pay);
		list.add(lack_enough_cash);
		list.add(prob_accessing_pay_site_software);
		list.add(benef_not_knowing_proj_rules);
		list.add(beneficiary_expressing_dissatisfaction);
		return list;
	}
	
	// GRIEVANCE - ISSUES IN NAMES
	public static List<ProblemsExperiencedShortNameEnum> getListForBSGRGrievanceIssuesInNames() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();
		list.add(order_of_names);
		list.add(inomplete_names);
		list.add(short_name);
		return list;
	}
	
	// GRIEVANCE - BENEFICIARY CANNOT ATTEND
	public static List<ProblemsExperiencedShortNameEnum> getListForBSGRGrievanceReasonCannotAttend() {
		List<ProblemsExperiencedShortNameEnum> list = new ArrayList<ProblemsExperiencedShortNameEnum>();
		list.add(cannot_attend_chronical_illness);
		list.add(cannot_attend_disability);
		list.add(cannot_attend_senior_citizen);
		list.add(cannot_attend_risk_pregnacy);
		list.add(cannot_attend_other_factors);
		return list;
	}

}
