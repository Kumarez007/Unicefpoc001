package org.yumnn.yct.common.entity.project;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.cycle.ProjectClassificationEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "user_access.adm_project")
@NamedQueries({
        @NamedQuery(name = "Project.findByShortName", query = "SELECT r from Project r where r.shortName = :shortName  ") ,
        @NamedQuery(name = "Project.findChild", query = "SELECT r from Project r where r.parentProject = :parentProject  ") ,
        @NamedQuery(name = "Project.getMainProjects", query = "SELECT r from Project r where r.parentProject is null  ") })
public class Project extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "name")
    private String name;

    @Column(name = "short_name")
    @Enumerated(EnumType.STRING)
    private ProjectNameEnum shortName;

    @ManyToOne
    @JoinColumn(name = "id_parent_project_fk")
    @JsonBackReference
    private Project parentProject;
    
    @Column(name = "pmu_short_name")
    private String pmuShortName;
    
    @Column(name = "project_classification")
    @Enumerated(EnumType.STRING)
    private ProjectClassificationEnum projectClassification;

    @Column(name = "ar_name")
    private String arName;
    
    @Column(name = "en_name")
    private String enName;

    @Column(name = "facility_project")
    private String facilityProject;


    public Project() {

    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Project other = (Project) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the shortName
     */
    public ProjectNameEnum getShortName() {
        return shortName;
    }

    /**
     * @param shortName the shortName to set
     */
    public void setShortName(ProjectNameEnum shortName) {
        this.shortName = shortName;
    }

    /**
     * @return the parentProjectName
     */
    public Project getParentProject() {
        return parentProject;
    }

    /**
     * @param parentProjectName the parentProjectName to set
     */
    public void setParentProject(Project parentProjectName) {
        this.parentProject = parentProjectName;
    }

	/**
	 * @return the arName
	 */
	public String getArName() {
		return arName;
	}

	/**
	 * @param arName the arName to set
	 */
	public void setArName(String arName) {
		this.arName = arName;
	}

	/**
	 * @return the enName
	 */
	public String getEnName() {
		return enName;
	}

	/**
	 * @param enName the enName to set
	 */
	public void setEnName(String enName) {
		this.enName = enName;
	}

    public String getFacilityProject() {
        return facilityProject;
    }

    public void setFacilityProject(String facilityProject) {
        this.facilityProject = facilityProject;
    }
}