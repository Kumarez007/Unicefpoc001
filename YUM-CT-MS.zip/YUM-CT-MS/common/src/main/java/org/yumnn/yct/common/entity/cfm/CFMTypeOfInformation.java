package org.yumnn.yct.common.entity.cfm;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name CFMTypeOfInformation.java
 * @create_date Jul 25, 2022
 * @last_Update Jul 25, 2022
 */
@Entity
@Table(name = "user_access.adm_cfm_type_of_information")
public class CFMTypeOfInformation extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "name")
	private String name;

	@Column(name = "short_name")
	private String shortName;

	@Column(name = "ar_name")
	private String arName;

	@Column(name = "en_name")
	private String enName;

	public CFMTypeOfInformation() {

	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the shortName
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * @param shortName the shortName to set
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	/**
	 * @return the arName
	 */
	public String getArName() {
		return arName;
	}

	/**
	 * @param arName the arName to set
	 */
	public void setArName(String arName) {
		this.arName = arName;
	}

	/**
	 * @return the enName
	 */
	public String getEnName() {
		return enName;
	}

	/**
	 * @param enName the enName to set
	 */
	public void setEnName(String enName) {
		this.enName = enName;
	}

}
