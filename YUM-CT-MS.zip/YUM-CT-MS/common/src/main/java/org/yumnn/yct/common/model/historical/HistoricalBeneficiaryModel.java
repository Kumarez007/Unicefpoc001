package org.yumnn.yct.common.model.historical;

import java.util.Date;
import java.util.List;

import org.yumnn.yct.common.model.administration.CycleModel;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name HistoricalBeneficiaryModel.java
 * @class_description 
 * @create_date May 13, 2021
 * @last_Update May 13, 2021
 */
public class HistoricalBeneficiaryModel{


	private Long currentFormId;

	private Long cycleId;

	private Long milestoneReferenceId;

	private String milestoneType;
	
	private Long bookletId;
	
	private List<CycleModel> cycleList;
	
	private Date createdDate;

	private Long cycleByProjectId;

	/**
	 * @return the currentFormId
	 */
	public Long getCurrentFormId() {
		return currentFormId;
	}

	/**
	 * @param currentFormId the currentFormId to set
	 */
	public void setCurrentFormId(Long currentFormId) {
		this.currentFormId = currentFormId;
	}

	/**
	 * @return the cycleId
	 */
	public Long getCycleId() {
		return cycleId;
	}

	/**
	 * @param cycleId the cycleId to set
	 */
	public void setCycleId(Long cycleId) {
		this.cycleId = cycleId;
	}

	/**
	 * @return the milestoneReferenceId
	 */
	public Long getMilestoneReferenceId() {
		return milestoneReferenceId;
	}

	/**
	 * @param milestoneReferenceId the milestoneReferenceId to set
	 */
	public void setMilestoneReferenceId(Long milestoneReferenceId) {
		this.milestoneReferenceId = milestoneReferenceId;
	}

	/**
	 * @return the milestoneType
	 */
	public String getMilestoneType() {
		return milestoneType;
	}

	/**
	 * @param milestoneType the milestoneType to set
	 */
	public void setMilestoneType(String milestoneType) {
		this.milestoneType = milestoneType;
	}

	/**
	 * @return the bookletId
	 */
	public Long getBookletId() {
		return bookletId;
	}

	/**
	 * @param bookletId the bookletId to set
	 */
	public void setBookletId(Long bookletId) {
		this.bookletId = bookletId;
	}

	/**
	 * @return the cycleList
	 */
	public List<CycleModel> getCycleList() {
		return cycleList;
	}

	/**
	 * @param cycleList the cycleList to set
	 */
	public void setCycleList(List<CycleModel> cycleList) {
		this.cycleList = cycleList;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Long getCycleByProjectId() {
		return cycleByProjectId;
	}

	public void setCycleByProjectId(Long cycleByProjectId) {
		this.cycleByProjectId = cycleByProjectId;
	}
}
