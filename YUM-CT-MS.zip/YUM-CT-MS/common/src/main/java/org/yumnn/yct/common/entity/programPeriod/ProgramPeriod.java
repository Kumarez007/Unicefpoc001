package org.yumnn.yct.common.entity.programPeriod;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.util.Utilities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

@Entity
@Table(name= "user_access.cat_program_period")
public class ProgramPeriod extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name= "name")
	private String name;
	
	@Column(name= "short_name")
	private String shortName;
	
	@Column(name= "order_item")
	private Integer orderItem;
	
	@Column(name= "en_name")
	private String englishName;
	
	@Column(name="ar_name")
	private String arabicName;
	
	@Column(name= "period_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date periodDate;
	
	@Column(name="period_amount")
	private Double periodAmount;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public Integer getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Integer orderItem) {
		this.orderItem = orderItem;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public Date getPeriodDate() {
		return periodDate;
	}

	public void setPeriodDate(Date periodDate) {
		this.periodDate = periodDate;
	}

	public Double getPeriodAmount() {
		return periodAmount;
	}

	public void setPeriodAmount(Double periodAmount) {
		this.periodAmount = periodAmount;
	}
	public String getMonthAndYearProgramPeriod() {
		if (!Utilities.isNULL(periodDate)) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(periodDate);
			return cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH) + "-"
					+ cal.getDisplayName(Calendar.MONTH, Calendar.LONG, new Locale("ar", "SY")) + ", "
					+ cal.getWeekYear();
		}
		return "";
	}
}
