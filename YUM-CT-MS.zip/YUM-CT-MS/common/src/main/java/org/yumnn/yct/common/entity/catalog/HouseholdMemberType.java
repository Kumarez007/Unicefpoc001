package org.yumnn.yct.common.entity.catalog;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

@Entity
@Table(name = "beneficiary.cat_household_member_type")
public class HouseholdMemberType extends CatalogParentEntity {

	private static final long serialVersionUID = 1L;

}
