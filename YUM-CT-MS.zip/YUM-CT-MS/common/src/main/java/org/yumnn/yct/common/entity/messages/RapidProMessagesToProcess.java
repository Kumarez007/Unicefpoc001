/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;
import org.yumnn.yct.common.enumeration.uploadInfo.UploadedRecordProcessStatusEnum;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name RapidProMessagesToProcess.java
 * @class_description
 * @create_date Jun 17, 2019
 * @last_Update Jun 17, 2019
 */
@Entity
@Table(name = "messages.gen_rapidpro_messages_to_process")
public class RapidProMessagesToProcess extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "creation_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date creationDate;
	
	@Column(name = "update_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date updateDate;

	@Column(name = "record_unique_code")
	private String recordUniqueCode;
	
	@Column(name = "text_to_send")
	private String textToSend;
	
	@Column(name = "mobile_number")
	private String mobileNumber;

	@ManyToOne
	@JoinColumn(name = "id_message_content_fk", referencedColumnName = "ID")
	private MessageContent messageContent;
	
	@ManyToOne
	@JoinColumn(name = "id_cycle_by_project_fk", referencedColumnName = "ID")
	private CycleByProject cycleByProject;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private UploadedRecordProcessStatusEnum status;

	@Column(name = "error_description")
	private String errorDescription;

	@Column(name = "scheduled_sending_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date scheduledSendingDate;

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the recordUniqueCode
	 */
	public String getRecordUniqueCode() {
		return recordUniqueCode;
	}

	/**
	 * @param recordUniqueCode
	 *            the recordUniqueCode to set
	 */
	public void setRecordUniqueCode(String recordUniqueCode) {
		this.recordUniqueCode = recordUniqueCode;
	}

	/**
	 * @return the cycleByProject
	 */
	public CycleByProject getCycleByProject() {
		return cycleByProject;
	}

	/**
	 * @param cycleByProject the cycleByProject to set
	 */
	public void setCycleByProject(CycleByProject cycleByProject) {
		this.cycleByProject = cycleByProject;
	}

	/**
	 * @return the status
	 */
	public UploadedRecordProcessStatusEnum getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(UploadedRecordProcessStatusEnum status) {
		this.status = status;
	}

	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}

	/**
	 * @param errorDescription
	 *            the errorDescription to set
	 */
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	/**
	 * @return the textToSend
	 */
	public String getTextToSend() {
		return textToSend;
	}

	/**
	 * @param textToSend the textToSend to set
	 */
	public void setTextToSend(String textToSend) {
		this.textToSend = textToSend;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the messageContent
	 */
	public MessageContent getMessageContent() {
		return messageContent;
	}

	/**
	 * @param messageContent the messageContent to set
	 */
	public void setMessageContent(MessageContent messageContent) {
		this.messageContent = messageContent;
	}

	public Date getScheduledSendingDate() {
		return scheduledSendingDate;
	}

	public void setScheduledSendingDate(Date scheduledSendingDate) {
		this.scheduledSendingDate = scheduledSendingDate;
	}
}