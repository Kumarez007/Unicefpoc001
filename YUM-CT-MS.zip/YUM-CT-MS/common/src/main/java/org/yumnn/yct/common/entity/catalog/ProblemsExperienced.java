package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ReasonToBeClosed.java
 * @class_description catalogs for daily progress registry
 * @create_date Aug 21, 2017
 * @last_Update Aug 21, 2017
 */
@Entity
@Table(name = "cat_problems_experienced")
@NamedQueries({
		@NamedQuery(name = "ProblemsExperienced.findAllForByShortName", query = "SELECT r from ProblemsExperienced r WHERE r.shortName IN (:list) order by r.orderItem asc")

})
public class ProblemsExperienced extends CatalogParentEntity implements Serializable, Catalog {
	private static final long serialVersionUID = 1L;

	public ProblemsExperienced() {
		super();
	}

	public ProblemsExperienced(Long id) {
		super();
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProblemsExperienced other = (ProblemsExperienced) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	

}