package org.yumnn.yct.common.model.administration;

import java.util.Date;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.enumeration.cycle.CycleStyleClassEnum;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name CycleModel.java
 * @class_description 
 * @create_date Aug 4, 2021
 * @last_Update Aug 4, 2021
 */
public class CycleModel {
	
	private Long id;
	
    private Long programPeriodId;

    private String cycleName;

    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

    @Temporal(TemporalType.TIMESTAMP)
    private Date endingDate;

    @Enumerated(EnumType.STRING)
    private CycleStyleClassEnum cycleStyleClass;

    private Integer cycleNumber;
    
    private String cycleDisplayName;

	/**
	 * @return the programPeriodId
	 */
	public Long getProgramPeriodId() {
		return programPeriodId;
	}

	/**
	 * @param programPeriodId the programPeriodId to set
	 */
	public void setProgramPeriodId(Long programPeriodId) {
		this.programPeriodId = programPeriodId;
	}

	/**
	 * @return the cycleName
	 */
	public String getCycleName() {
		return cycleName;
	}

	/**
	 * @param cycleName the cycleName to set
	 */
	public void setCycleName(String cycleName) {
		this.cycleName = cycleName;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the cycleStyleClass
	 */
	public CycleStyleClassEnum getCycleStyleClass() {
		return cycleStyleClass;
	}

	/**
	 * @param cycleStyleClass the cycleStyleClass to set
	 */
	public void setCycleStyleClass(CycleStyleClassEnum cycleStyleClass) {
		this.cycleStyleClass = cycleStyleClass;
	}

	/**
	 * @return the cycleNumber
	 */
	public Integer getCycleNumber() {
		return cycleNumber;
	}

	/**
	 * @param cycleNumber the cycleNumber to set
	 */
	public void setCycleNumber(Integer cycleNumber) {
		this.cycleNumber = cycleNumber;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	
    public String getCycleDisplayName() {
		return cycleDisplayName;
	}

	public void setCycleDisplayName(String cycleDisplayName) {
		this.cycleDisplayName = cycleDisplayName;
	}

}
