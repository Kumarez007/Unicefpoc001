package org.yumnn.yct.common.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.exception.TheresNoEntityException;
import org.yumnn.yct.common.query.util.GlobalNativeQueries;
import org.yumnn.yct.common.util.GeolocationUtil;

public class CustomizedGeolocationRepositoryImpl implements CustomizedGeolocationRepository {

	@PersistenceContext
	protected EntityManager em;

	/**
	 * 
	 * @author WQ
	 * @date Jun 02, 2020
	 * @description_method
	 * @return
	 */
	public List<Geolocation> findAllChildrenByGeolocation(Geolocation geolocation) {
		try {
			Query query = em.createNamedQuery("Geolocation.findAllByGeolocationParent");
			query.setParameter("geolocationParent", geolocation);
			return query.getResultList();
		} catch (Exception e) {
			em.getTransaction().rollback();
		} finally {
			em.close();
		}
		return new ArrayList<>();
	}

	/**
	 * 
	 * @author WQ
	 * @date Jun 02, 2020
	 * @description_method
	 * @return
	 */
	public List<Integer> findRecursiveGeolocation(Geolocation geolocation) {
		Query query = this.em
				.createNativeQuery(GlobalNativeQueries.getQueryForFindRecursiveGeolocation(geolocation.getId()));
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	/**
	 * 
	 * @author WQ
	 * @date Jun 02, 2020
	 * @description_method
	 * @return
	 */
	public Long getGeolocationChildrenCount(Geolocation geolocation) {
		try {
			Query query = em.createNamedQuery("Geolocation.findCountByGeolocationParent");
			query.setParameter("geolocationParent", geolocation);
			return (Long) query.getSingleResult();
		} catch (Exception e) {
			em.getTransaction().rollback();
		} finally {
			em.close();
		}
		return null;
	}

	/**
	 * WQ
	 */
	public GeolocationUtil geolocationDetails(Long geolocationId) {
		Query query = this.em.createNativeQuery(GlobalNativeQueries.geolocationDetails(geolocationId),
				GeolocationUtil.class);
		try {
			return (GeolocationUtil) query.getSingleResult();
		} catch (NoResultException e) {
			em.getTransaction().rollback();
			throw new TheresNoEntityException(e);
		} finally {
			em.close();
		}
	}

	/**
	 * 
	 * @param geolocationCode
	 * @return
	 */
	public GeolocationUtil getGeolocationDetailsByCode(String code) {
		try {
			Query query = this.em.createNativeQuery(GlobalNativeQueries.geolocationDetails(code),
					GeolocationUtil.class);
			return (GeolocationUtil) query.getSingleResult();
		}catch(NoResultException e) {
			return null;
		}
		catch (Exception e) {
			em.getTransaction().rollback();
		} finally {
			em.close();
		}
		return null;
	}

	public List<Geolocation> retrieveByParents(Long[] parents) {
		try {
			Query query = em.createNamedQuery("Geolocation.retrieveByParents");
			query.setParameter("parents", Arrays.asList(parents));
				
			return query.getResultList();

		} catch (Exception e) {
			em.getTransaction().rollback();
		} finally {
			em.close();
		}
		return new ArrayList<>();
	}

}
