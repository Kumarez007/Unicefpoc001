/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.model.administration;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import org.yumnn.yct.common.enumeration.flag.FlagForHouseholdOrIndividualEnum;
import org.yumnn.yct.common.enumeration.flag.FlagTypeEnum;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FlagModel.java
 * @class_description 
 * @create_date Aug 4, 2021
 * @last_Update Aug 4, 2021
 */
public class FlagModel  {

	private Long id;
	@Enumerated(EnumType.STRING)
	private FlagTypeEnum flagType;

	@Enumerated(EnumType.STRING)
	private FlagForHouseholdOrIndividualEnum flagFor;

	private String flagDescription;

	private String flagDescriptionAr;

	private String nameAr;
	
	private String nameEn;
	
	private String shortname;

	
	private Long cycleByProjectId;

	
	private Long parentFlagId;


	/**
	 * @return the flagType
	 */
	public FlagTypeEnum getFlagType() {
		return flagType;
	}


	/**
	 * @param flagType the flagType to set
	 */
	public void setFlagType(FlagTypeEnum flagType) {
		this.flagType = flagType;
	}


	/**
	 * @return the flagFor
	 */
	public FlagForHouseholdOrIndividualEnum getFlagFor() {
		return flagFor;
	}


	/**
	 * @param flagFor the flagFor to set
	 */
	public void setFlagFor(FlagForHouseholdOrIndividualEnum flagFor) {
		this.flagFor = flagFor;
	}


	/**
	 * @return the flagDescription
	 */
	public String getFlagDescription() {
		return flagDescription;
	}


	/**
	 * @param flagDescription the flagDescription to set
	 */
	public void setFlagDescription(String flagDescription) {
		this.flagDescription = flagDescription;
	}


	/**
	 * @return the flagDescriptionAr
	 */
	public String getFlagDescriptionAr() {
		return flagDescriptionAr;
	}


	/**
	 * @param flagDescriptionAr the flagDescriptionAr to set
	 */
	public void setFlagDescriptionAr(String flagDescriptionAr) {
		this.flagDescriptionAr = flagDescriptionAr;
	}


	/**
	 * @return the nameAr
	 */
	public String getNameAr() {
		return nameAr;
	}


	/**
	 * @param nameAr the nameAr to set
	 */
	public void setNameAr(String nameAr) {
		this.nameAr = nameAr;
	}


	


	/**
	 * @return the cycleByProjectId
	 */
	public Long getCycleByProjectId() {
		return cycleByProjectId;
	}


	/**
	 * @param cycleByProjectId the cycleByProjectId to set
	 */
	public void setCycleByProjectId(Long cycleByProjectId) {
		this.cycleByProjectId = cycleByProjectId;
	}


	/**
	 * @return the parentFlagId
	 */
	public Long getParentFlagId() {
		return parentFlagId;
	}


	/**
	 * @param parentFlagId the parentFlagId to set
	 */
	public void setParentFlagId(Long parentFlagId) {
		this.parentFlagId = parentFlagId;
	}
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return the nameEn
	 */
	public String getNameEn() {
		return nameEn;
	}


	/**
	 * @param nameEn the nameEn to set
	 */
	public void setNameEn(String nameEn) {
		this.nameEn = nameEn;
	}


	/**
	 * @return the shortname
	 */
	public String getShortname() {
		return shortname;
	}


	/**
	 * @param shortname the shortname to set
	 */
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}

	
}
