package org.yumnn.yct.common.enumeration.messages;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name ReminderMessageParameterEnum.java
 * @create_date Nov 29, 2021
 * @last_Update Nov 29, 2021
 */
public enum ReminderMessageParameterEnum {

	P_USER_EMAIL, P_GRIEVANCE_CODE, P_GRIEVANCE_CREATION_DATE, P_MESSAGE_REFERENCE_ID, P_MESSAGE_REFERENCE_ID_TYPE

}
