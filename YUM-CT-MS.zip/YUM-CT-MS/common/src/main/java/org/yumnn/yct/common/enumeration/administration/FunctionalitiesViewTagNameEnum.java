package org.yumnn.yct.common.enumeration.administration;


/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name FunctionalitiesViewTagNameEnum.java
 * @class_description enum with view tag names
 * @create_date Mar 29, 2017
 * @last_Update Mar 29, 2017
 */
public enum FunctionalitiesViewTagNameEnum {

    adminSubMenu, initSetSubMenu, progSubSetSubMenu, hhPayAndCompSubMenu, reportsSubMenu, dailyProgressDashboardMapMenu, minimalSyncInfoSubMenu, gisProgressInformationMenu,

    admUsersMenuItem, admOnlineUsersMenuItem, admCentersMenuItem, admCatalogsMenuItem, admRolesMenuItem, admPaymentAgencyMenuItem, admUserCategorizationMenuItem, admAssignDashboardToUsersMenuItem, admAssignGrievanceCategoryToRoleMenuItem, admEnableDisableFunctionalitiesMenuItem, admurveyMenuItem,

    hhMemberBiometricsMenuItem, paymentListMenuItem, viewPaymentsMenuItem, complianceListMenuItem, compMemberComplianceMenuItem, mngPayAndCompSubMenu, cycleSubMenu, termDefinitionMenuItem, closeComplianceMenuItem, indicatorsSubMenu, productionIndicatorsMenuItem, hhMemberDetailsMenuItem, exportReportsMenuItem, lnkAndRefSubMenu, admSocialWorkerMenuItem, progSetProcessDefManagementMenuItem, progSetCriteriaDefAndRoutingMenuItem, progSetReportSettingMenuItem, progSetTarFeaturesMenuItem, progSetPaymentConfigMenuItem, progSetDefineFormulasMenuItem, progSetDeactivatesFormsMenuItem, socialWorkerWorkspaceMenuItem, householdAssignmentMenuItem, settingCreateDefFlowMenuItem, settingCreateDefFormMenuItem,

    hhMngMenuItem_viewHouseholdCard, hhMngMenuItem_cct_program, hhMngMenuItem_disasters_program, hhMngMenuItem_st_kitts_program, hhMngMenuItem_bsgr_not_verified, hhMngMenuItem_bsgr_fraud_beneficiary, hhMngMenuItem_bsgr_fraud_for_name_beneficiary, hhMngMenuItem_bsgr_exit_program, hhMngMenuItem_bsgr_pmt_confirmation, hhMngMenuItem_bsgr_verifiable, hhMngMenuItem_bsgr_dupl_auth_form,

    generateCicFileMenuItem, generateManualPaymentFileMenuItem, generatePaymentFileMenuItem, generateCicStatusFileMenuItem, generateCommunityVerificationFileMenuItem, genFilesSubMenu, cycleManagementMenuItem, conciliateFilesSubMenu, conciliateCicFileMenuItem, conciliateCicFileVersionTwoMenuItem, conciliateCicFileBasicVersionOneMenuItem, conciliateCicFileBasicVersionTwoMenuItem,
    // bsgr
    searchBeneficiaryListSubMenu, registerBeneficiaryMenuItem, registerBeneficiaryMenuItem_viewBenInfo, registerBeneficiaryMenuItem_updateBenInfo, registerBeneficiaryMenuItem_viewUpdatedBenInfo, registerBeneficiaryMenuItem_registerFraud, registerBeneficiaryMenuItem_registerFraudForName, searchBeneficiaryForGrievanceMenuItem_newGrievanceExternal, registerBeneficiaryMenuItem_authorizationForm, admManageNumberConciliationMenuItem,

    grievanceManagementSubMenu, searchBeneficiaryForGrievanceMenuItem, searchBeneficiaryForGrievanceMenuItem_viewBenInfo, searchGrievancesMenuItem_bsgr_fraud_beneficiary, searchGrievancesMenuItem_bsgr_fraud_for_name_beneficiary, searchGrievancesMenuItem_bsgr_fraud_for_non_beneficiary, searchGrievancesMenuItem_edit_bsgr_fraud_beneficiary, searchGrievancesMenuItem_edit_bsgr_fraud_for_name_beneficiary, searchGrievancesMenuItem_edit_bsgr_fraud_for_non_beneficiary, searchGrievancesMenuItem_viewHouseholdInformation, searchRegisteredCallsMenuItem, searchCaseManagementCodeMenuItem,

    searchClosedGrievancesMenuItem, searchClosedGrievancesMenuItem_viewNormalGrievance, searchClosedGrievancesMenuItem_viewForNameGrievance, searchClosedGrievancesMenuItem_viewNonBeneficiary,

    generateGrievanceAndSubGrievanceFilesMenuItem,

    // sub-grievance
    searchSubGrievanceInvestigationMenuItem, searchSubGrievanceInvestigationMenuItem_viewHouseholdInformation, searchSubGrievanceInvestigationMenuItem_subGrievanceInvestigationForBeneficiaryEditForm, searchSubGrievanceInvestigationMenuItem_subGrievanceInvestigationForNonBeneficiaryEditForm, loadActionsFromCSVFileForSubGrievanceMenuItem,

    // exited beneficiary
    exitedBenefMenuItem,
    // download and upload payment file
    downloadUploadPayFileSubMenu, managePaymentFileForPaymentAgencyMenuItem, manageDailyPaymentFileForPaymentAgencyMenuItem,

    // daily progress
    dailyProgressSubMenu, managePaymentSiteDailyProgressMenuItem, manageBSGRDailyProgressMenuItem, manageFacilitationDailyProgressMenuItem, managePaidBeneficiaryMenuItem, manageVerifiedBeneficiaryMenuItem, manageVerifiedBeneficiaryByDistrictMenuItem, manageVillageCoveredFacilitationPerGovernorateMenuItem,
    // accumulated progress
    accumulatedProgressSubMenu,
    // reports
    generalReportsMenuItem,

    // maps
    bsgrDailyProgressDashboardMapMenuItem, facilitationDailyProgressDashboardMapMenuItem, paySiteDailyProgressDashboardMapMenuItem,

    bsgrDailyProgressDashboardMapMenuItem_map, facilitationDailyProgressDashboardMapMenuItem_map, paySiteDailyProgressDashboardMapMenuItem_map, districtDailyProgressDashboardMapMenuItem_map,

    bsgrDailyProgressDashboardMapMenuItem_viewForm, facilitationDailyProgressDashboardMapMenuItem_viewForm, paySiteDailyProgressDashboardMapMenuItem_viewForm,

    // Minimal Sync
    minimalSyncInfoMenuItem, minimalUploadCviFileMenuItem,

    // Daily Reports
    dailyReportsSubMenu, pmuDailyReportsMenuItem, searchDailyReportsMenuItem, searchDailyReportsMenuItem_viewForm,

    // GIS DASHBOARD
    gisProgressInformationMenu_dailyReportMap, gisProgressInformationMenu_beneficiariesProgressMap, gisProgressInformationMenu_dailyReportForm,
    // Inbox
    caseManagersForm,
    // case managers
    caseManagersMenu, caseManagersMenuItem, closeOpenCase,

    // cvi
    cviSubMenu, searchCVIMenuItem, searchCVIMenuItem_verifiable, searchCVIMenuItem_notVerifiable, searchCVIMenuItem_housePayment, searchCVIMenuItem_viewHHInfo, searchCVIMenuItem_verifiableReceipt,
    // backup
    backupSubMenu, backupMenuItem, restoreBackupMenuItem,
    // sync
    syncSubMenu, syncMenuItem, generateSyncDataMenuItem,
    // restore
    restoreSubMenu, restoreMenuItem,
    // online sync
    onlineSyncSubMenu, onlineSyncUploadMenuItem, onlineSyncDownloadMenuItem,
    // verification
    verificationSubMenu, searchVerificationMenuItem, searchVerificationMenuItem_verified, searchVerificationMenuItem_notVerified, searchVerificationMenuItem_viewHHInfo, searchVerificationMenuItem_viewVerified, searchVerificationMenuItem_authorizationForm, searchVerificationMenuItem_duplicateAuthorizationForm, searchVerificationMenuItem_duplicateUpdateInfo, searchVerificationMenuItem_duplicateAuthorizationFormUpdateInfo,
    // grievances
    grievancesSubMenu, searchGrievancesMenuItem_viewBenInfo,
    searchGrievancesMenuItem_viewBenInfo_newGrievanceBeneficiary, searchGrievancesMenuItem_newGrievanceNonBeneficiary, searchGrievancesMenuItem,


    // daily report
    dailyReportSubMenu, dailyReportMenuItem, dailyReportGRMenuItem, dailyReportVerificationMenuItem,
    // issue log
    mobileAppSubMenu, issueLogSubMenu, issueLogSearchMenu, issueLogProvideFeedbackMenu, issueLogCloseIssueMenu, addViewIssueLog,
    // household search(benefeciciary info)
    beneficiaryInfoSubMenu, searchBeneficiaryMenuItem, searchBeneficiaryMenuItem_viewBenfeciaryMilestones, searchBeneficiaryForGrievancesMenuItem,
    // Rapid pro
    rapidProSubMenu, viewMessagesFormMenu, sendMessagesFormMenu, viewBroadcastsMenu, recommendGrievanceToCloseForm,
    // Search Inquiries
    searchInquiriesMenuItem, viewHouseholdCard, viewBeneficiaryInfoForGrievances,

    manageCyclesMenuItem,

    requestGrievanceCancellationForm,
    // Inbox
    inboxSubMenu, inboxMenuItem, caseApprovalMenuItem, searchGrievancesToApproveMenuItem,
    searchGrievancesToCloseMenuItem, searchCasesForQAMenuItem, searchCasesForEndorsementMenuItem,
    searchCasesForClosureMenuItem, viewGrievanceCancellationForm, viewGrievanceClosureForm,
    registerFraudBeneficiaryInfo, registerFraudForExternalBeneficiaryInfo,

    searchViewCMCasesMenuItem,

    // Online Payment Plan
    beneficiaryListPaymentInformationElement,

    //issueEditorElement
    issueEditorElement, issueLogSendToBankColumnElement, issueLogfeedbackColumnElement, issueLogFeedbackSendToBankColumnElement, issueLogFeedbackfeedbackColumnElement,
    onlinePaymentPlanSubMenu, managePaymentPlanMenuItem, vieweOnlinePaymentPlan, revieweOnlinePaymentPlan, endorseOnlinePaymentPlan,

    grievancesFollowupMenuItem, paymentSitesManagementMenuItem, issueLogFormMenu, issueLogFormMenuHidden,
    closeGrievanceMenuItem, dashboardSubMenu, viewDashboardMenu, surveySubMenu, searchSurveyMenu,
    closeGrievanceCashPlusOnly, closeGrievanceAllCategories, followUpCashPlusOnly, followUpAllCategories, suspectedFraudForm, viewSuspectedFraudCaseMenu,
    suspectedFraudFormHidden, cancelGrievanceMenuItem , cfmSubMenu , submitCFMMenuItem , registerNewCF;

    @Override
    public String toString() {
        return this.name();
    }
}
