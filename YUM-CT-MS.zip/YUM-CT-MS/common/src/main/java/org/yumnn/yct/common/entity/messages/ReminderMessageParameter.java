package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.messages.ReminderMessageParameterEnum;
import org.yumnn.yct.common.enumeration.messages.ReminderMessageParameterTypeEnum;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name ReminderMessageParameter.java
 * @create_date Nov 29, 2021
 * @last_Update Nov 29, 2021
 */
@Entity
@Table(name = "messages.stp_reminder_message_parameter")
public class ReminderMessageParameter extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "name")
	private String name;

	@Column(name = "short_name")
	@Enumerated(EnumType.STRING)
	private ReminderMessageParameterEnum shortName;
	
	@Column(name = "column_name")
	private String columnName;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "creation_date")
	private Date creationDate;
	
	@Column(name = "type")
	@Enumerated(EnumType.STRING)
	private ReminderMessageParameterTypeEnum type;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the shortName
	 */
	public ReminderMessageParameterEnum getShortName() {
		return shortName;
	}

	/**
	 * @param shortName the shortName to set
	 */
	public void setShortName(ReminderMessageParameterEnum shortName) {
		this.shortName = shortName;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * @param columnName the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the type
	 */
	public ReminderMessageParameterTypeEnum getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(ReminderMessageParameterTypeEnum type) {
		this.type = type;
	}

}
