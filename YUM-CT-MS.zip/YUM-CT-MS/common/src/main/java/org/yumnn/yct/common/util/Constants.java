/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.util;

/**
 * @author Oswaldo Tutillo, Frank Munoz
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name Constants.java
 * @class_description manage all constants for web layer (Controllers).
 * @create_date Mar 19, 2014
 * @last_Update Sep 4, 2014
 */
public class Constants {

	public static final String _NEW_LINE = "\\n";
	public static final String EMPTY = "";
	public static final String SPACE = " ";
	public static final String COMMA_CHAR = ",";
	public static final String EQUALS_CHAR = "=";
	public static final String COLON = ":";
	public static final String DATE_FORMAT_MMddyyyy = "MM/dd/yyyy";
	public static final String DATE_FORMAT_DDMMYYYY_WITH_SLASH = "dd/MM/yyyy";
	public static final String DATE_FORMAT_MMMddyyyy = "MMM-dd-yyyy";
	public static final String DATE_FORMAT_MMddyyyy_hhmm = "MM/dd/yyyy hh:mm";
	public static final String DATE_FORMAT_ddMMyyyy_hhmm = "dd/MM/yyyy hh:mm";
	public static final String DATE_FORMAT_MMddyyyy_hhmmss = "MM/dd/yyyy HH:mm:ss";
	public static final String DATE_FORMAT_FOR_WATERMARK = "dd/mm/yyyy";
	public static final String DATE_FORMAT = "dd/MMM/yyyy";
	public static final String DATE_FORMAT_ONLY_NUMBERS = "dd/MM/yyyy";
	public static final String DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW = "dd-MM-yyyy";
	public static final String TIME_FORMAT_hh_mm = "hh:mm";
	public static final String TIME_FORMAT_HH_mm = "HH:mm";
	public static final String TIME_FORMAT_HH_mm_ss = "HH:mm:ss";
	public static final String DOUBLE_FORMAT = "#0.00";
	public static final String TIMESTAMP_FORMAT = "dd/MMM/yyyy HH:mm";
	public static final String DATE_FORMAT_FOR_REPORTS = "yyyyMMddHH'h'mm'm'";
	public static final String DATE_FORMAT_WITH_MONTH_NAME = "yyyyMMMdd-HH'h'mm'm'";
	public static final String DATE_FORMAT_FOR_REPORTS_WITH_MILISICOND = "yyyyMMddHH'h'mm'm'ss's'SSS'ms'";
	public static final String DATE_FORMAT_FOR_CUTOFF_WITH_MILISECONDS = "yyyyMMddHHmmssSSS";
	public static final String DATE_FORMAT_HIDDEN_INPUT = "E MMM dd HH:mm:ss Z yyyy";
	public static final String MIN_DATE = "01/jan/1895";
	public static final String MIN_YEAR = "1900";
	public static final String OPEN_BRACE = "[";
	public static final String CLOSE_BRACE = "]";
	public static final String QUOTE = "\"";
	public static final String BACK_SLASH = "\\";
	public static final String DATE_FORMAT_yyyyMMdd = "yyyy-MM-dd";
	public static final String DATE_FORMAT_yyyyMMddHHmmss = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_FORMAT_yyyyMMddHHmmss_WITH_SLASH = "yyyy/MM/dd HH:mm:ss";
	public static final String DATE_FORMAT_YYYYMMDD_WITH_SLASH = "yyyy/MM/dd";
	public static final String UNDERSCORE = "_";
	public static final String JSON_FULL_DATE_SEPARATOR = "T";
	public static final String IS_INTEGER_REGEX_PATTERN = ".*\\D+.*";
	public static final String IN_PARENTHESES_REGEX_PATTERN = "\\(([^)]+)\\)";
	public static final String BR = "<br>";
	public static final String _BR_HTML = "&lt;br /&gt;";
	public static final String DASH = "-";
	public static final String SLASH = "/";
	public static final String _X = "X";
	public static final String _DOT = "\\.";
	public static final String APOSTROPHE = "'";
	public static final String _ASC = "ASC";
	public static final String _DESC = "DESC";
	public static final String _DOT_WO_SCAPE_CHARACTER = ".";
	public static final Integer MINUS_ONE = -1;
	public static final String DOWNLOAD_COOKIE = "primefaces.download";
	public static final String REDIRECT_PAGE = "?faces-redirect=true";
	public static final String _FIELDS = "FIELDS";
	public static final String _PARAMETER_WILDCARD = "PARAMETERS_WILDCARD";
	public static final String _JDBC_PAGINATION_LIMITS = " LIMIT VAR_LIMIT OFFSET VAR_OFFSET";
	public static final String _VAR_LIMIT_JDBC_PAGINATION_LIMITS = "VAR_LIMIT";
	public static final String _VAR_LIMIT_QUERY = "LIMIT_RECORDS";
	public static final String _VAR_LIMIT_QUERY_COMMAND = "LIMIT";
	public static final String _VAR_OFFSET_JDBC_PAGINATION_LIMITS = "VAR_OFFSET";
	public static final String _WEB_CONTEXT = "WEB_CONTEXT";
	public static final String _INVALID_ID_NUMBER = "-1";
	public static final String _TEMPORAL_IMAGE_NAME = "ïmageTmp";
	public static final String _WHERE_CONDITION = "where";
	public static final String _AND_CONDITION = "and";
	public static final String _SYSTEM_USER = "system";
	public static final String _TAB = "\t";
	public static final String _CHAR_TO_REPLACE_IN_HIERARCHY_GEOLOCATION_AS_ARRAY = "[{}\"]";
	public static final String _LIMIT_RECORDS_FOR_DATATABLE = "50";
	public static final String _LIMIT_RECORDS_FOR_QUERY = "50";
	public static final Long _LIMIT_COUNTER_SEARCH_HOUSEHOLD_MANAGEMENT = 50l;
	public static final String ALL_GEOLOCATION_SELECTED = "ALL_GEOLOCATION_SELECTED";
	public static final String PRIMEFACES_STYLE_CLASS_ERROR = "ui-state-error";
	public static final String PRIMEFACES_STYLE_CLASS_ERROR_WITHOUT_BORDER = "ui-state-error-without-border";
	public static final String PATH_MAP_MARKER_IMAGE = "resources/images/marker/";
	public static final String YEMEN_CENTER_POINT_FOR_MAP = "15.407000, 47.560194";
	public static final String SERVER_TIME_ZONE = "Asia/Amman";
	//public static final String SERVER_TIME_ZONE = "America/Guayaquil"; // DEVELOPMENT
	public static final Integer MAX_FILE_SIZE_SUPPORTED_IN_BYTES = 52428800;

	// FILES EXTENSION
	public static final String CSV_SUFFIX = "-CSV";

	// FLOW CONSTANTS
	public static final String PREFIX_ACCOUNT_NUMBER = "ACC-";
	public static final String PREFIX_FORM_NUMBER = "HH-";
	public static final String INITIAL_FLOW_PREFIX = "init_flow";
	public static final String INITIAL_PROCESS_PREFIX = "init_process";
	public static final String PREFIX_FLOW_INSTANCE_NUMBER = "FLOW_INST_";

	// DYNAMIC FORM
	public static final String _PRIMEFACES_CALENDAR_COMPONENT_YEAR_RANGE = "c-100:c+1";
	public static final String _PRIMEFACES_WILDCARD_THIS = "@this";
	public static final String _PRIMEFACES_WILDCARD_FORM = "@form";
	public static final String _SELECT = "Select";
	public static final String _LOADING_DIALOG_HIDE = "PF('loadingDialogWidget').hide();";
	public static final String _LOADING_DIALOG_SHOW = "PF('loadingDialogWidget').show();";
	public static final String _IS_ROSTER_DATA_ENTRY_VISIBLE = "isRosterDataEntryVisible";
	public static final String _SHOW_DATA_ENTRY_METHOD = "showDataEntry()";
	public static final String _SAVE_ENTERED_INFORMATION_METHOD = "saveEnteredInformation()";
	public static final String _CANCEL_ENTERED_INFORMATION_METHOD = "cancelEnteredInformation()";
	// DYNAMIC FORM - COMPONENT ID
	public static final String _SUFFIX_OLD_DATA_ID = "OldData";
	public static final String _SUFFIX_OLD_DATA_FOR_ROSTER_COMPONENT_ID = "OldDataForRosterComponent";
	public static final String _PANEL_ROSTER_DATA_ENTRY_ID = "panelRosterDataEntryId";
	public static final String _PANEL_DATA_TABLE_ROSTER_ID = "panelDataTableRosterId";
	public static final String _PANEL_GROUP_BUTTONS_DATA_ENTRY_ID = "panelGroupButtonsDataEntryId";
	public static final String _MAIN_ROSTER_PANEL_ID = "mainRosterPanelId";
	public static final String _CONTAINER_PANEL_FOR_MAIN_ROSTER_PANEL_ID = "containerPanelMainRosterPanelId";
	public static final String _SAVED_INFORMATION_DIALOG_PANEL_ID = "savedInformationDialogPanelId";
	public static final String _DYNAMIC_FORM_COMPONENT_ID = "dynamicFormComponentId";
	public static final String _DYNAMIC_FORM_ID = "mainForm";
	public static final String _DYNAMIC_HIDDEN_ROSTER_ELEMENT_ID = "hiddenRosterId";
	public static final String _DYNAMIC_ROSTER_DETAILS_ID = "rosterDetailsPanelId";
	public static final String _DYNAMIC_SAVE_BUTTON_ID = "saveFormButtonId";
	public static final String _PANEL_GROUP_PAYMENT_RECEIVER_ID = "panelGroupPaymentReceiverId";
	public static final String _SELECT_ONE_MENU_PAYMENT_RECEIVER_CONTAINER_PANEL_ID = "selectOneMenuPaymentReceiverContainerPanelId";
	// DYNAMIC FORM - COMPONENT ATTRIBUTES
	public static final String _CHECK_BOX_DATA_TABLE_COMPONENT_CATALOG_HEADER = "checkboxComponentCatalogHeader";
	public static final String _CHECK_BOX_DATA_TABLE_COMPONENT_VALUE_HEADER = "checkboxComponentValueHeader";
	public static final String _CHECK_BOX_DATA_TABLE_COMPONENT_BEFORE_VALUE_HEADER = "checkboxComponentBeforeValueHeader";
	public static final String _CHECK_BOX_DATA_TABLE_COMPONENT_AFTER_VALUE_HEADER = "checkboxComponentAfterValueHeader";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_CATALOG_ATTRIBUTE = "catalog.id";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_DISPLAY_NAME_ATTRIBUTE = "catalog.displayName";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_OBJECT_CATALOG_ATTRIBUTE = "catalog.object";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_INPUT_OBJECT_ATTRIBUTE = "inputObject";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_INPUT_TWO_OBJECT_ATTRIBUTE = "inputTwoObject";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_IS_SELECTED_ATTRIBUTE = "isSelected";
	public static final String _CHECKBOX_DATA_TABLE_WITH_INPUT_COMPONENT_CATALOG_ID_ATTRIBUTE = "catalogId";
	public static final String _SELECT_ONE_MENU_WITH_CONTROLLER_DATASOURCE_ITEM_VALUE_ENROLLMENT = "viewTemporalCode";
	public static final String _SELECT_ONE_MENU_WITH_CONTROLLER_DATASOURCE_ITEM_LABEL_ENROLLMENT = "enrollmentHouseholdMember.enrollmentHouseholdMemberFullName";
	public static final String _CATALOG_OBJECT_INTERFACE = "object";
	public static final String _CATALOG_OBJECT_DISPLAY_NAME_INTERFACE = "displayName";
	public static final String SOURCE_SUFFIX = "Source";
	public static final String _CLIENT_GEOLOCATION_INPUT_LATITUDE = "clientGeolocationComponentLatitude";
	public static final String _CLIENT_GEOLOCATION_INPUT_LONGITUDE = "clientGeolocationComponentLongitude";
	public static final String _CLIENT_GEOLOCATION_WRAPPER_LATITUDE = "latitude";
	public static final String _CLIENT_GEOLOCATION_WRAPPER_LONGITUDE = "longitude";
	public static final String PHOTO_FILE_NAME_PREFIX = "Name";
	public static final String _DYNAMIC_FORM_COMPONENT_VIEW_MEMBER_DETAILS_BUTTON_MESSAGE_PROPERTIES = "dynamicFormComponentViewMemberDetailsButtonLabel";
	public static final String _CURRENT_INFO_MEMBER_CODE_ATTRIBUTE = "currentInfoHouseholdMember.memberCode";
	public static final String _HIDDEN_VALUE_FOR_MEMBER_INFO_IN_ROSTER = "hiddenValueForMemberInfoInRoster";
	// DYNAMIC FORM - CSS
	public static final String _CSS_CLASS_FOR_DYNAMIC_FORM = "dynamicFormStyleClass";
	public static final String _CSS_CLASS_FOR_ROSTER_DATA_TABLE_IN_DYNAMIC_FORM = "rosterDataTableClass";
	public static final String _CSS_DYNAMIC_PANEL_GRID_COLUMN_CLASSES = "dynamic_panel_grid_column_classes";
	public static final String _CSS_TEXT_ALING_RIGHT_CLASS = "text_aling_right";
	public static final String _CSS_DYNAMIC_PANEL_GRID_WITHOUT_PADDING = "p_panel_without_padding";
	public static final String _CSS_ROSTER_DETAIL_PANEL_GRID = "roster_detail_panel_grid";
	public static final String _CSS_NOT_INCLUDED_CLASS = "notIncluded";
	public static final String _HIDDEN_VALUE_FOR_MEMBER_INFO_IN_ROSTER_STYLE_CLASS = "hiddenValueForMemberInfoInRosterStyleClass";
	// DYNAMIC FORM - UTIL OBJECT
	public static final String _CURRENT_INFO_UTIL_CLASS = "currentInfoUtil";
	public static final String _CURRENT_INFO_UTIL_CLASS_FOR_HISTORIC_DATA = "currentInfoUtilOld";
	// DYNAMIC FORM - URL PAGES KEY
	public static final String _UPDATE_PAGE_URL_FOR_VIEW_HISTORY_SUFFIX = "viewChangesHistory.jsf";
	public static final String _UPDATE_PAGE_URL_FOR_UPDATE_FORM_SUFFIX = "form.jsf";
	public static final String _UPDATE_PAGE_URL_FOR_UPDATE_NON_DYNAMIC_FORM_SUFFIX = "nonDynamicForm.jsf";
	public static final String _UPDATE_PAGE_URL_FOR_COMPARE_FORMS_SUFFIX = "compareHistoricData.jsf";

	public static final String SEPARATOR_HIDDENS = "SEPARATOR_HIDDENS";
	public static final String SEPARATOR_ATTRIBUTE_WILDCARD = "SEPARATOR_ATTRIBUTES";
	public static final String SEPARATOR_KEY_VALUE_WILDCARD = "SEPARATOR_KEY_VALUE";
	public static final String STYLE_CLASS_FOR_DIFFERENCES = "has_difference_style";

	public static final String _FORM_ID_KEY = "FORM_ID";
	public static final String _PROCESS_INSTANCE_ID = "PROCESS_INSTANCE_ID";
	public static final String _CURINF_AMOUNT_BY_CYCLE_ID = "CURINF_AMOUNT_BY_CYCLE_ID";
	public static final String _CSS_WILDCARD_STYLE_CLASS = "_wildcard_style_class_";
	public static final String _FILTER_VALUE_KEY = "FILTER_VALUE";
	public static final String _DEFINED_FLOW_ID_KEY = "DEFINED_FLOW_ID";
	public static final String _COMPLIANCE_NAME_KEY = "COMPLIANCE_NAME";
	public static final String _COMPLIANCE_ID_KEY = "COMPLIANCE_ID";
	public static final String _TERM_DEFINITION_KEY = "TERM_DEFINITION_ID";
	public static final String _CATALOG_TABLE_ID_KEY = " c.id";
	public static final String _GEOLOCATION_ID_KEY = "GEOLOCATION_ID";
	public static final String _STYLE_CLASS_COMPONENT_SUFFIX = "_style_class";

	public static final String _LABEL_STYLE_CLASS = "label_style_class";
	public static final String _INPUT_TEXT_STYLE_CLASS = "input_text_style_class";
	public static final String _INPUT_TEXT_AREA_STYLE_CLASS = "input_text_area_style_class";
	public static final String _SELECT_ONE_MENU_STYLE_CLASS = "select_one_menu_style_class";
	public static final String _NESTED_SELECT_ONE_MENU_WITH_UPDATE_ACTION_STYLE_CLASS = "nested_select_one_menu_with_update_action_style_class";
	public static final String _SELECT_MANY_CHECKBOX_STYLE_CLASS = "select_many_checkbox_style_class";
	public static final String _RADIO_BUTTON_STYLE_CLASS = "radio_button_style_class";
	public static final String _GEOLOCATION_COMPONENT_STYLE_CLASS = "geolocation_component_style_class";
	public static final String _CALENDAR_STYLE_CLASS = "calendar_style_class";
	public static final String _TIME_STYLE_CLASS = "time_style_class";
	public static final String _SELECT_MANY_CHECKBOX_WITH_INPUT_STYLE_CLASS = "select_many_checkbox_with_input_style_class";
	public static final String _SELECT_MANY_CHECKBOX_WITH_TWO_INPUTS_STYLE_CLASS = "select_many_checkbox_with_two_input_style_class";
	public static final String _SELECT_MANY_CHECKBOX_WITHOUT_INPUT_STYLE_CLASS = "select_many_checkbox_without_input_style_class";
	public static final String _CLIENT_GEOLOCATION_INPUT_STYLE_CLASS = "client_geolocation_input_style_class";
	public static final String _FILE_UPLOADER_STYLE_CLASS = "file_uploader_style_class";
	public static final String _AUTO_COMPLETE_STYLE_CLASS = "auto_complete_style_class";

	// EXCEL
	public static final String EXCEL_RECORD_PREFIX = "Records";
	public static final int ZERO = 0;
	public static final int ONE = 1;
    public static final int TWO = 2;
	public static final String EXCEL_FILE_MAX_RECORDS_PER_FILE = "5000";

	// EXPORTED FILES
	public static final String HOUSEHOLD_DETAILS_CSV_FILENAME = "household_details.csv";
	public static final String HOUSEHOLD_MEMBERS_DETAILS_CSV_FILENAME = "household_members_details.csv";
	public static final String HOUSEHOLD_MAP_GEOJSON_FILENAME = "geojson.geojson";
	public static final String FRAUD_SUMMARY_FILE_PREFIX_NAME = "CATEGORY_SUMMARY_FILE";

	// PAYMENTS
	public static final String PAYMENT_CUTOFF_NAME = "Period";
	public static final String PAYMENT_CUTOFF_FILE_NAME = "File";
	public static final String PAYMENT_CUTOFF_FILE_FILTER_REFERENCE_FORMAT = "paymentAgencyId:%d,maxRecordsPerFile:%d,offset:%d";
	public static final String PAYMENT_CUTOFF_FILTER_REFERENCE_PAYMENT_AGENCY_MAP_KEY = "PAYMENT_AGENCY";
	public static final String PAYMENT_CUTOFF_FILTER_REFERENCE_MAX_RECORD_PER_FILE_MAP_KEY = "MAX_RECORD_PER_FILE";
	public static final String PAYMENT_CUTOFF_FILTER_REFERENCE_OFFSET_MAP_KEY = "OFFSET";

	public static final String PREFIX_ENCRYPTION_FILE = "encrypt_";
	public static final String PREFIX_DECRYPTION_FILE = "decrypt_";
	public static final String ENCRYPTION_ALGORITHM = "DES";
	public static final String PREFIX_REVIEW = "review ";
	public static final String PREFIX_ZIP_FILE = "zip_";

	// LINKAGES
	public static final String HOUSEHOLD_ASSIGNED_CSV_FILENAME = "household_assigned.csv";

	// PAYMENT AGENCY
	public static final String PAYMENT_AGENCY_ENTITY_SHORT_NAME = "payment_agency_";
	public static final String PAYMENT_SITE_ENTITY_SHORT_NAME = "payment_site_";

	// QUARTZ
	public static final Integer MAX_NUMBER_OF_ACTIVE_QUARTZ = 7;

	// MINIMAL SERVER
	public static final String MINIMAL_BACKUP_FILE = "BACKUP_";
	public static final String MINIMAL_SYNC_FILE = "SYNC_FILE_";
	public static final String MINIMAL_SHORT_NAME_BACKUP_FILE = "processed_backup_file_";
	public static final String MINIMAL_SHORT_NAME_BACKUP_SYNC_FILE = "processed_backup_sync_file_";
	public static final String MINIMAL_SYNC_FILE_SECURITY_PREFIX = "SEC_INFO_";
	public static final String SEARCH_TABLE_PREFIX = "GOVERN_cic_";

	public static final String MINIMAL_SHORT_NAME_RESTORE_BACKUP_FILE = "restored_backup_file_";
	public static final String MINIMAL_SHORT_NAME_RESTORE_SYNC_FILE = "restored_backup_sync_file_";
	public static final String MINIMAL_BACKUP_FOLDER_PREFIX = "ECT_BACKUPS";

	public static final String TEMP_TABLE_GEN_UPLOADED_PAID_BENEFICIARY_BY_CLIENT_DEVICE = "tmp_gen_uploaded_paid_beneficiary_by_client_device";
	public static final String PREFIX_BACKUP = "bkp";
	
	public static final String MAIL_CONTENT_TYPE_HTML = "text/html; charset=utf-8";

	// Grievances
	public static final String REQUEST_GRIEVANCE_CANCELLATION_FORM = "/pages/grievances/requestCancelationForm.jsf" ;
	public static final String VIEW_GRIEVANCE_CANCELLATION_FORM = "/pages/grievances/viewGrievanceCancelationForm.jsf" ;
	public static final String SEARCH_GRIEVANCES_FOR_CANCELLATION = "/pages/grievances/search/searchGrievances.jsf" ;
	public static final String SEARCH_GRIEVANCES_TO_APPROVE = "/pages/grievances/search/searchGrievancesToApprove.jsf" ;
	public static final String REQUEST_GRIEVANCE_CLOSURE_RECOMMENDATION_FORM = "/pages/recommendClosure/recommendGrievanceForClosure.jsf" ;
	public static final String SEARCH_GRIEVANCES_FOR_CLOSURE = "/pages/grievances/search/searchGrievancesForRequestClosure.jsf" ;
	public static final String VIEW_GRIEVANCE_CLOSURE_APPROVAL_FORM = "/pages/recommendClosure/viewGrievanceClosureForm.jsf" ;

	public static final String HTTP_POST_REQUEST = "POST";
	public static final String UNKNOWN_CONTACT_NAME = "UNKNOWN";
	
	public static final String PROHIBITED_MOBILE_NUMBER_PREFIX = "70";

	public static final String GRIEVANCE_CASE_CODE_PARAMETER = "P_GRIEVANCE_CASE_CODE";
	public static final String PAYMENT_AGENCY_CONTACT_NAME_PARAMETER = "P_PAYMENT_AGENCY_CONTACT_NAME";
	public static final String PAYMENT_SITE_CODE_PARAMETER = "P_PAYMENT_SITE_CODE";
	public static final String INPUTS_FROM_THE_FIELD_parameter = "P_INPUTS_FROM_THE_FIELD";
	public static final String ISSUE_LOG_ID_PARAMETER = "P_ISSUE_ID";
	public static final String PROJECT_PARAMETER = "P_PROJECT_NAME";
	

	
	
	public static final String NAME_OF_BANK_PARAMETER = "P_NAME_OF_BANK";
	public static final String RECEIVED_PAYMENT_SITE_TYPE_OF_CHANGE_PARAMETER = "P_RECEIVED_PAYMENT_SITE_TYPE_OF_CHANGE";
	public static final String GOVERNORATE_PARAMETER = "P_RECEIVED_PAYMENT_SITE_GOVERNORATE";
	public static final String DISTRICT_PARAMETER = "P_RECEIVED_PAYMENT_SITE_DISTRICT";
	public static final String OZLA_PARAMETER = "P_RECEIVED_PAYMENT_SITE_OZLA";
	public static final String PAYMENT_SITE_NAME_PARAMETER = "P_RECEIVED_PAYMENT_SITE_NAME";
	public static final String RECEIVED_PAYMENT_SITE_CODE_PARAMETER = "P_RECEIVED_PAYMENT_SITE_CODE";
	public static final String RECEIVED_PAYMENT_SITE_LAT_PARAMETER = "P_RECEIVED_PAYMENT_SITE_LAT";
	public static final String RECEIVED_PAYMENT_SITE_LON_PARAMETER = "P_RECEIVED_PAYMENT_SITE_LON";
	public static final String RECEIVED_PAYMENT_SITE_ADDRESS_PARAMETER = "P_RECEIVED_PAYMENT_SITE_ADDRESS";
	public static final String RECEIVED_PAYMENT_SITE_TYPE_PARAMETER = "P_RECEIVED_PAYMENT_SITE_TYPE";
	public static final String PROECT_NAME_ECT = "CashAid" ;
	
	public static final String BEARER_AUTHENTICATION_PREFIX = "Bearer" ; 
	public static final String GRIEVANCE_ACTION_CODE_PARAMETER = "GRIEVANCE_ACTION_CODE_PARAMETER" ; 
	public static final String OTP_CODE = "P_OTP_CODE";
	public static final String USER_NAME = "P_USER_NAME";
	public static final String OTP_EXPIRY_INTERVAL = "P_OTP_EXPIRY_INTERVAL"		;
	

	public static final String PROJECT = "CashAid MIS";
	public static final String PROJECT_NAME_PARAMETER = "P_PROJECT_NAME";
	public static final String PROJECT_NAME = "YCT MIS";

	public static final String KIB_PAYMENT_AGENCY = "KIB";
	public static final String AMB_PAYMENT_AGENCY = "AMB";
	
	public static final String AUTHORIZATION = "Authorization";
	public static final String CONTENT_TYPE = "Content-Type";
	
	public static final String SPACES_REGEX_EXPRESSION = "\\s+";
	public static final String MESSAGE_PARAMETER_PREFIX = "P_";

	public static final String API_VERSION = "v1";

	public static final String STRING_TYPE_EMAIL = "EMAIL";
	public static final String CHANGE_CATEGORY = "change_category";
	public static final String CHANGE_GRIEVANCE_GEO_LOCATION = "change_grievance_location_or_facility";

}