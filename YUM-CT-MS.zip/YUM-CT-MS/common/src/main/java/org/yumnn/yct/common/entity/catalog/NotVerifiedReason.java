package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name NotVerifiedReason.java
 * @class_description represents a catalog table from database which contains
 *                    Not verified reason
 * @create_date Jun 22, 2017
 * @last_Update Jun 22, 2017
 */
@Entity
@Table(name = "cat_not_verified_reason")
@NamedQueries({
		@NamedQuery(name = "NotVerifiedReason.findAllByOrderItem", query = "SELECT r from NotVerifiedReason r order by r.orderItem asc") })
public class NotVerifiedReason extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	

	public NotVerifiedReason() {
	}

	public NotVerifiedReason(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		NotVerifiedReason other = (NotVerifiedReason) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return super.toString();
	}

	
}
