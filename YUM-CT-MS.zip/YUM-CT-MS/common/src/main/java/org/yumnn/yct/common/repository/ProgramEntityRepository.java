package org.yumnn.yct.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.administration.ProgramEntity;

@Repository
public interface ProgramEntityRepository extends JpaRepository<ProgramEntity, Long> {

	//not used
//	List<ProgramEntity> findByGeolocationId(Long id);
	
	Optional<ProgramEntity> findById(Long id);
	
	ProgramEntity findByShortName(String shortName);
	
}
