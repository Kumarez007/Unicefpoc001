package org.yumnn.yct.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.base.DropDownModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 6, 2021 1:15:17 PM
 */

@Repository
public interface IDropDownRepository extends JpaRepository<DropDownModel, Long> , CustomizedDropdownRepository{

	
}
