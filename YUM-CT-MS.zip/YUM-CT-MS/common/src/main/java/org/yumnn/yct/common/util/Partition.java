/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.util;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class Partition<T> extends AbstractList<List<T>> {

	private final List<T> list;
	private final int chunkSize;

	/**
	 * 
	 * Constructor
	 */
	public Partition(List<T> list, int chunkSize) {
		this.list = new ArrayList<>(list);
		this.chunkSize = chunkSize;
	}

	/**
	 * 
	 * @author Reem Issa
	 * @date May 27, 2019
	 * @description_method
	 * @param list
	 * @param chunkSize
	 * @return
	 */
	public static <T> Partition<T> ofSize(List<T> list, int chunkSize) {
		return new Partition<>(list, chunkSize);
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @param index
	 * @return
	 */
	@Override
	public List<T> get(int index) {
		int start = index * chunkSize;
		int end = Math.min(start + chunkSize, list.size());

		if (start > end) {
			throw new IndexOutOfBoundsException(
					"Index " + index + " is out of the list range <0," + (size() - 1) + ">");
		}

		return new ArrayList<>(list.subList(start, end));
	}

	/**
	 * 
	 * {@inheritDoc}
	 * 
	 * @return
	 */
	@Override
	public int size() {
		return (int) Math.ceil((double) list.size() / (double) chunkSize);
	}

}
