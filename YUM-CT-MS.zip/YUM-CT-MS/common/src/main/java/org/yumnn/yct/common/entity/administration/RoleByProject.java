package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.project.Project;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name RoleByProject.java
 * @class_description 
 * @create_date Mar 26, 2021
 * @last_Update Mar 26, 2021
 */
@Entity
@Table(name = "user_access.adm_role_by_project")
public class RoleByProject  extends BaseEntity implements Serializable {



    @ManyToOne
    @JoinColumn(name = "id_role_fk")
    private Role role;


    @ManyToOne
    @JoinColumn(name = "id_project_fk")
    private Project project;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}


}
