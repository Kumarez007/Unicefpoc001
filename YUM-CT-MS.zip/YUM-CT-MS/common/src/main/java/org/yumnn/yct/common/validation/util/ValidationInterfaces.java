package org.yumnn.yct.common.validation.util;

import java.util.HashMap;
import java.util.List;

import org.springframework.context.NoSuchMessageException;
import org.yumnn.yct.common.util.CustomException;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class ValidationInterfaces {
  public interface didValidate {
    void didValidate(boolean isSuccess, List<HashMap<String, Enum>> errorMessage)
        throws NoSuchMessageException, CustomException;
  }
}
