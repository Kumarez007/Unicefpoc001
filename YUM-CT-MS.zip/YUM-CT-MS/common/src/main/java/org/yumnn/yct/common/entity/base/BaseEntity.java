package org.yumnn.yct.common.entity.base;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name BaseEntity.java
 * @class_description contains the general attributes for all entities in the
 *                    application
 * @create_date Oct 13, 2016
 * @last_Update Oct 13, 2016
 */
@MappedSuperclass
public abstract class BaseEntity implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", insertable = true, updatable = true)
	protected Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}