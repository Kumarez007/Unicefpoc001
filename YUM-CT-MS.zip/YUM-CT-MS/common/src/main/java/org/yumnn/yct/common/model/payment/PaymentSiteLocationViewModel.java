package org.yumnn.yct.common.model.payment;

import java.util.Date;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name PaymentSiteLocationViewModel.java
 * @create_date Dec 15, 2021
 * @last_Update Dec 15, 2021
 */
public class PaymentSiteLocationViewModel {

	private Long paymentSiteId;

	private Date initialDate;

	private Date endingDate;

    private String governorateNameAr;

	private String governorateNameEn;

	private String districtNameAr;

	private String districtNameEn;

	private String ozlaNameAr;

	private String ozlaNameEn;
	
	private String villageNameEn;

	private String villageNameAr;

	
	/**
	 * @return the paymentSiteId
	 */
	public Long getPaymentSiteId() {
		return paymentSiteId;
	}

	/**
	 * @param paymentSiteId the paymentSiteId to set
	 */
	public void setPaymentSiteId(Long paymentSiteId) {
		this.paymentSiteId = paymentSiteId;
	}

	/**
	 * @return the initialDate
	 */
	public Date getInitialDate() {
		return initialDate;
	}

	/**
	 * @param initialDate the initialDate to set
	 */
	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the governorateNameAr
	 */
	public String getGovernorateNameAr() {
		return governorateNameAr;
	}

	/**
	 * @param governorateNameAr the governorateNameAr to set
	 */
	public void setGovernorateNameAr(String governorateNameAr) {
		this.governorateNameAr = governorateNameAr;
	}

	/**
	 * @return the governorateNameEn
	 */
	public String getGovernorateNameEn() {
		return governorateNameEn;
	}

	/**
	 * @param governorateNameEn the governorateNameEn to set
	 */
	public void setGovernorateNameEn(String governorateNameEn) {
		this.governorateNameEn = governorateNameEn;
	}

	/**
	 * @return the districtNameAr
	 */
	public String getDistrictNameAr() {
		return districtNameAr;
	}

	/**
	 * @param districtNameAr the districtNameAr to set
	 */
	public void setDistrictNameAr(String districtNameAr) {
		this.districtNameAr = districtNameAr;
	}

	/**
	 * @return the districtNameEn
	 */
	public String getDistrictNameEn() {
		return districtNameEn;
	}

	/**
	 * @param districtNameEn the districtNameEn to set
	 */
	public void setDistrictNameEn(String districtNameEn) {
		this.districtNameEn = districtNameEn;
	}

	/**
	 * @return the ozlaNameAr
	 */
	public String getOzlaNameAr() {
		return ozlaNameAr;
	}

	/**
	 * @param ozlaNameAr the ozlaNameAr to set
	 */
	public void setOzlaNameAr(String ozlaNameAr) {
		this.ozlaNameAr = ozlaNameAr;
	}

	/**
	 * @return the ozlaNameEn
	 */
	public String getOzlaNameEn() {
		return ozlaNameEn;
	}

	/**
	 * @param ozlaNameEn the ozlaNameEn to set
	 */
	public void setOzlaNameEn(String ozlaNameEn) {
		this.ozlaNameEn = ozlaNameEn;
	}

	/**
	 * @return the villageNameEn
	 */
	public String getVillageNameEn() {
		return villageNameEn;
	}

	/**
	 * @param villageNameEn the villageNameEn to set
	 */
	public void setVillageNameEn(String villageNameEn) {
		this.villageNameEn = villageNameEn;
	}

	/**
	 * @return the villageNameAr
	 */
	public String getVillageNameAr() {
		return villageNameAr;
	}

	/**
	 * @param villageNameAr the villageNameAr to set
	 */
	public void setVillageNameAr(String villageNameAr) {
		this.villageNameAr = villageNameAr;
	}
}
