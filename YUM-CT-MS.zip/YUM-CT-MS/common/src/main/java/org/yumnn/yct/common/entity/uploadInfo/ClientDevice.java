package org.yumnn.yct.common.entity.uploadInfo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.uploadInfo.ClientDeviceTypeEnum;
import org.yumnn.yct.common.enumeration.uploadInfo.MinimalServerTypeEnum;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ClientDevice.java
 * @class_description
 * @create_date Oct 12, 2017
 * @last_Update Oct 12, 2017
 */
@Entity
@Table(name = "gen_client_device")
@NamedQueries({
		@NamedQuery(name = "ClientDevice.findByDeviceCode", query = "SELECT t FROM ClientDevice t WHERE t.deviceCode = :deviceCode"),
		@NamedQuery(name = "ClientDevice.findAllByDeviceType", query = "SELECT t FROM ClientDevice t WHERE t.deviceType = :deviceType order by t.deviceCode")})
public class ClientDevice extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "device_type")
	@Enumerated(EnumType.STRING)
	private ClientDeviceTypeEnum deviceType;

	@ManyToOne
	@JoinColumn(name = "id_geolocation_fk", referencedColumnName = "ID")
	private Geolocation geolocation;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;

	@Column(name = "device_code")
	private String deviceCode;

	@Column(name = "person_in_charge")
	private String personInCharge;

	@Column(name = "telephone_number")
	private String telephoneNumber;

	@Column(name = "gps_latitude")
	private String gpsLatitude;

	@Column(name = "gps_longitude")
	private String gpsLongitude;

	@Column(name = "server_location_type")
	@Enumerated(EnumType.STRING)
	private MinimalServerTypeEnum serverLocationType;

	public ClientDevice() {
		super();
	}

	/**
	 * @param deviceType
	 */
	public ClientDevice(ClientDeviceTypeEnum deviceType) {
		super();
		this.deviceType = deviceType;
		this.isActive = YesNoEnum.YES;
	}

	public ClientDevice(ClientDeviceTypeEnum deviceType, String deviceCode) {
		super();
		this.deviceType = deviceType;
		this.isActive = YesNoEnum.YES;
		this.deviceCode = deviceCode;
	}

	public ClientDevice(Long id) {
		super();
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClientDevice other = (ClientDevice) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public ClientDeviceTypeEnum getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(ClientDeviceTypeEnum deviceType) {
		this.deviceType = deviceType;
	}

	public Geolocation getGeolocation() {
		return geolocation;
	}

	public void setGeolocation(Geolocation geolocation) {
		this.geolocation = geolocation;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	public String getDeviceCode() {
		return deviceCode;
	}

	public void setDeviceCode(String deviceCode) {
		this.deviceCode = deviceCode;
	}

	public String getPersonInCharge() {
		return personInCharge;
	}

	public void setPersonInCharge(String personInCharge) {
		this.personInCharge = personInCharge;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getGpsLatitude() {
		return gpsLatitude;
	}

	public void setGpsLatitude(String gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	public String getGpsLongitude() {
		return gpsLongitude;
	}

	public void setGpsLongitude(String gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	public MinimalServerTypeEnum getServerLocationType() {
		return serverLocationType;
	}

	public void setServerLocationType(MinimalServerTypeEnum serverLocationType) {
		this.serverLocationType = serverLocationType;
	}

}
