package org.yumnn.yct.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Service;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Service
public class DateFormatterUtil {
  /**
   * The function formats the given date
   * 
   * @param date
   * @return date
   * @throws Exception
   */
  public String dateUtil(Date date) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
    return simpleDateFormat.format(date);

  }
  
  public static Date dateUtil(String dateStr, String format) throws ParseException {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
    return simpleDateFormat.parse(dateStr);
  }
  
  public static String formDateUtil(Date date) {
	  if(date==null) {
  		return "";
  	}
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
    return simpleDateFormat.format(date);

  }
  
  public static String creationDateUtil(Date date) {
  	if(date==null) {
  		return "";
  	}
  	
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ConstantsUtil.CREATION_TIMESTAMP_FORMAT);
    return simpleDateFormat.format(date);

  }
  
  public static String isoDateUtil(Date date) {
	  	if(date==null) {
	  		return "";
	  	}
	  	
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ConstantsUtil.ISO_DATE_FORMAT);
	    return simpleDateFormat.format(date);

	  }
  
  public static String dateToStringUtil(Date date,String format) {
	  	if(date==null) {
	  		return "";
	  	}
	  	
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
	    return simpleDateFormat.format(date);

	  }
  
}
