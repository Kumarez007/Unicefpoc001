package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name PaymentReceiverChangeReason.java
 * @class_description
 * @create_date Jan 7, 2018
 * @last_Update Jan 7, 2018
 */
@Entity
@Table(name = "cat_payment_receiver_change_reason")
@NamedQueries({
		@NamedQuery(name = "PaymentReceiverChangeReason.findAllByOrderItem", query = "SELECT t FROM PaymentReceiverChangeReason t ORDER BY t.orderItem") })
public class PaymentReceiverChangeReason extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	

	public PaymentReceiverChangeReason() {
	}

	public PaymentReceiverChangeReason(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return this.name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PaymentReceiverChangeReason other = (PaymentReceiverChangeReason) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	
}
