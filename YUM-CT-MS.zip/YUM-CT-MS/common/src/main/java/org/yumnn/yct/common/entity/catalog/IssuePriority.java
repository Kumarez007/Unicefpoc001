/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;


/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name IssuePriority.java
 * @create_date Feb 26, 2019
 * @last_Update Feb 26, 2019
 */
@Entity
@Table(name = "cat_issue_priority")
@NamedQueries({ @NamedQuery(
		name = "IssuePriority.findAllByOrderItem", query = "SELECT r from IssuePriority r order by r.orderItem asc"),
		@NamedQuery(
				name = "IssuePriority.retrieveByShorName",
				query = "SELECT r from IssuePriority r WHERE r.shortName = :shortName") })
public class IssuePriority extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;


	public IssuePriority() {
	}

	public IssuePriority(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		IssuePriority other = (IssuePriority) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}


}
