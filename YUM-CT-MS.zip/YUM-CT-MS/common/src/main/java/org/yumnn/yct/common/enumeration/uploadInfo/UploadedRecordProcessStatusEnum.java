package org.yumnn.yct.common.enumeration.uploadInfo;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name UploadedRecordProcessStatusEnum.java
 * @class_description
 * @create_date Oct 17, 2017
 * @last_Update Oct 17, 2017
 */
public enum UploadedRecordProcessStatusEnum {
	PENDING, IN_PROCESS, DONE, ERROR, DUPLICATED,APPROVED;
}
