package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.project.Project;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "user_access.adm_project_by_functionality")
public class ProjectByFunctionality extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_project_fk", referencedColumnName = "ID")
	private Project project;

	@ManyToOne
	@JoinColumn(name = "id_functionality_fk", referencedColumnName = "ID")
	private Functionality functionality;


	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}

	/**
	 * @return the functionality
	 */
	public Functionality getFunctionality() {
		return functionality;
	}

	/**
	 * @param functionality the functionality to set
	 */
	public void setFunctionality(Functionality functionality) {
		this.functionality = functionality;
	}

	
}
