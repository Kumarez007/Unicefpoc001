package org.yumnn.yct.common.enumeration.administration;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ProjectParameterEnum.java
 * @class_description
 * @create_date Dec 8, 2017
 * @last_Update Dec 8, 2017
 */
public enum ProjectParameterEnum {

		MAX_NUMBER_OF_FAILED_ATTEMPTS_FOR_LOGIN("max_number_of_failed_attempts_for_login"),
		IS_IT_DEPARTMENT_QUARTZ_ENABLED("is_it_department_quartz_enabled"),
		IT_DEPARTMENT_QUARTZ_FUNCTION("it_department_quartz_function"),
		TMP_FOLDER("tmp_folder"),
		PRODUCTION_INDICATORS_PATH("production_indicators_path"),
		PRODUCTION_INDICATORS_TEMP_PATH("production_indicators_tmp_path"),
		WEB_APP_ROOT_FOLDER("web_app_root_folder"),
		GEOLOCATION_PATH("geolocation_path"),
		MINIMAL_UNIQUE_INSTALLATION_CODE("min_unique_installation_code"),
		MINIMAL_CLIENT_DEVICE_ID("min_client_device_id"),
		MINIMAL_CLIENT_GEOLOCATION_ID("min_client_geolocation_id"),
		MINIMAL_CLIENT_TELEPHONE_NUMBER("min_client_telephone_number"),
		MINIMAL_CLIENT_PERSON_IN_CHARGE("min_client_person_in_charge"),
		BACKUP_PATH("production_backup_path"),
		OS_MEDIA_PATH("os_mount_media_path"),
		OPERATIVE_SYSTEM_FOLDER_SEPARATOR("operative_system_folder_separator"),
		LAST_EXTERNAL_MEDIA_PATH("last_external_media_path"),
		WEB_RESOURCE_RESTFULL_ADDRESS("web_resource_restfull_address"),
		PAYMENT_CYCLE_ID("payment_cycle_id"),
		MINIMAL_CLIENT_LATITUDE("min_client_latitude"),
		MINIMAL_CLIENT_LONGITUDE("min_client_longitude"),
		MINIMAL_CLIENT_SERVER_TYPE("min_client_server_type"),
		APPLIED_CYCLE_FOR_PAYMENT_SITE("applied_cycle_for_payment_site"),
		CIC_FILES_CONCILIATION_FOLDER("cic_files_conciliation_folder") ,
		RAPIDPRO_BROADCAST_ENDPOINT("rapidpro_broadcast_endpoint"),
		MIS_EMAIL_ADDRESS("mis_email_address"),
		MIS_EMAIL_ADDRESS_PASSWORD("mis_email_address_password") ,
		MAIL_SMTP_STARTTLS_ENABLE("mail.smtp.starttls.enable"),
		MAIL_SMTP_AUTH("mail.smtp.auth") ,
		MAIL_STMP_HOST("mail.smtp.host"),
		MAIL_STMP_PORT("mail.smtp.port"),
		RAPIDPRO_REQUEST_PROPERTY_AUTHORIZATION("rapidpro_authorization_bearer_token"),
		RAPID_PRO_MESSAGE_CONTENT_TYPE("rapidpro_api_content_type"),
		RAPIDPRO_CREATE_CONTACT_ENDPOINT("rapidpro_create_contact_endpoint"),
		ENABLE_SEND_EMAILS_WHEN_RECEIVING_PAYMENT_SITE_UPDATE("enable_send_emails_upon_receiving_sites") , 
		DAYS_TO_SEND_FOLLOWUP_MESSAGE("days_to_send_followup_message")  , 
		TIME_TO_SEND_FOLLOWUP_MESSAGE("time_to_send_followup_message"),
		MOBILE_NUMBER_COUNTRY_CODE("mobile_number_country_code"),
		AUTH_SERVER_URL("auth_server_url"),
		JWT_TOKEN_COOKIE_NAME("jwt_token_cookie_name"),
		SIGNING_KEY("signing_key"),
		APPLICATION_NAME("application_name"),
		SSO_APPLICATION_NAME("sso_application_name"),
		GRM_TASK_ENABLED("grm_task_enabled"),
		CASE_MANAGEMENT_NUMBER_OF_ALLOWED_CALL_ATTEMPTS("cm_number_of_allowed_call_attempts"),
		EXECLUDE_DATE_OF_BIRTH_VALIDATION_PROTOCOLS("execlude_dob_validation_protocols"),
		OTP_EXPIRY_INTERVAL("otp_expiry_interval"),
		OTP_MAX_NUMBER_OF_FAILED_ATTEMPTS_FOR_ACCESS("otp_max_number_of_failed_attempts_for_access"),
		ACTIVE_PROJECT("active_project"),
	    CURRENT_QUARTER("current_quarter");


	private String name;

	private ProjectParameterEnum(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
