/**
 * 
 */
package org.yumnn.yct.common.enumeration.administration;

import java.util.ArrayList;
import java.util.List;

/**
 * @author adarwish
 *
 */
public enum ShutdownFunctionTypeEnum  {

	WSDL_PAYMENTS("Web Service Payments"),
	WSDL_MOBILE_APP("Mobile App"),
	WSDL_VERIFICATION("Verification");

	private String value;

	ShutdownFunctionTypeEnum(String type) {
		this.value = type;
	}

	public static List<ShutdownFunctionTypeEnum> getListFunctionalities() {
		List<ShutdownFunctionTypeEnum> list = new ArrayList<ShutdownFunctionTypeEnum>();
		list.add(WSDL_PAYMENTS);
		list.add(WSDL_MOBILE_APP);
		list.add(WSDL_VERIFICATION);
		return list;
	}


	public String getValue() {
		return value;
	}

}