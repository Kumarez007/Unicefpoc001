/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.enumeration.administration;

/**
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FeatureShortNameEnum.java
 * @class_description
 * @create_date Feb 23, 2020
 * @last_Update Feb 23, 2020
 */
public enum FeatureShortNameEnum {

	YCA_765("YCA-765", "Create the setup to enable / disable tasks"),
	YCA_791("YCA-791", "OTP for privileged users"),
	YCA_924("YCA_924", "Include external grievances in GRM"),
	YMA_60816("YMA_60816", "Remove the approval step from all workflow");
	

	private String taskNumber;
	private String description;

	FeatureShortNameEnum(String taskNumber, String description) {
		this.taskNumber = taskNumber;
		this.description = description;
	}

	public String getTaskNumber() {
		return taskNumber;
	}

	public String getDescription() {
		return description;
	}

}
