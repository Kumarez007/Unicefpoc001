/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.enumeration.uploadInfo;

public enum UploadInformationCodesEnum {

	SUCCESS, DEVICE_NOT_FOUND(1), ERROR(2), RECORD_IS_EMPTY(3), INACTIVE_DEVICE(4), PAYMENT_SITE_NOT_FOUND(
			5), INVALID_OZLA_CODE(6), INVALID_USER(7), MISSING_MANDATORY_FIELDS(8), NO_PENDING_RECORDS_FOUND(
					9), INVALID_VERIFICATION_CODE(10), PAYMENT_SITE_NOT_APPROVED(11), INVALID_TOKEN(12), 
	SURVEY_TEMPLATE_NOT_FOUND(13), INVALID_GEOLOCATION_CODE(14), INVALID_PAYMENT_SITE_TYPE_CODE(15), INVALID_DAILY_REPORT_ISSUE_TYPE_CODE(16),
	INVALID_UNIQUE_CODE_AGAINST_MEMBER_CODE(17) , 
	INVALID_PAYMENT_SITE_AGAINST_PAYMENT_AGENCY(18), INVALID_PHONE_FORMAT(19),INVALID_ID_TYPE(21),INVALID_VALIDATION_CODE(22),INVALID_TIME(23),
	 INVALID_OPTION_VALUE(34) , NULL_INVALID_PROJECT_NAME(35);

	private Integer value;

	private UploadInformationCodesEnum(Integer value) {
		this.value = value;
	}

	private UploadInformationCodesEnum() {
		this.value = null;
	}

	public Integer getValue() {
		return value;
	}

}
