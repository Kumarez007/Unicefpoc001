/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.enumeration.paymentSites;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name PaymentSiteTypeEnum.java
 * @class_description 
 * @create_date May 17, 2021
 * @last_Update May 17, 2021
 */
public enum PaymentSiteTypeEnum  {
	
	
	FIXED("Fixed", "ثابت"), MOBILE("Mobile", "متحرك"), OUTREACH_MOBILE("outreach_mobile", "متحرك لايمكن الوصول له"), E_PAYMENT("e-payment", "دفع الكتروني");
			
	
	String value;
	String arValue;

	PaymentSiteTypeEnum(String yesNo) {
		this.value = yesNo;
	}

	PaymentSiteTypeEnum(String yesNo, String arValue) {
		this.value = yesNo;
		this.arValue = arValue;
	}

	public String getArValue() {
		return this.arValue;
	}

	public String getValue() {
		return value;
	}
	@JsonCreator
    public static PaymentSiteTypeEnum setValue(String key) {
        return Arrays.stream(PaymentSiteTypeEnum.values())
            .filter(exampleEnum -> exampleEnum.toString().equals(key.toUpperCase()))
            .findAny()
            .orElse(null);
    }
}
