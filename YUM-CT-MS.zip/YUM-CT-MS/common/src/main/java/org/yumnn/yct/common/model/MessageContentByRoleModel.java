package org.yumnn.yct.common.model;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {MessageContentByRoleModel.java
 * @create_date May 27, 2021
 * @last_Update May 27, 2021
 */
public class MessageContentByRoleModel {
	
	

}
