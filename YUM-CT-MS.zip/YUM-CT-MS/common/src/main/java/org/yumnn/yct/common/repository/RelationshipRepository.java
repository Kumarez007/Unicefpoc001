package org.yumnn.yct.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.Relationship;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Repository
public interface RelationshipRepository extends JpaRepository<Relationship, Long> {

  List<Relationship> findByIsActive(YesNoEnum isActive);

  Optional<Relationship> findById(Long id);
  
  Relationship findByShortName(String shortName);
}
