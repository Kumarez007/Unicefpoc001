package org.yumnn.yct.common.service;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.util.Utilities;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Service
public class JsonConverterService {

  private static Logger LOG = LogManager.getLogger();

  @SuppressWarnings("unchecked")
  public Object convertUnquotedFieldsJsonToObject(String jsonData,
      @SuppressWarnings("rawtypes") Class myClass) throws FailProcessException {
    try {
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.readValue(jsonData, myClass);
    } catch (Exception e) {
      LOG.error("... convertObjectToJson " + Utilities.convertStacktraceErrorToString(e));
      throw new FailProcessException();
    }

  }

  public StringWriter createJsonString(Object responseData)
      throws IOException, JsonGenerationException, JsonMappingException {
    ObjectMapper objectMapperCreator = new ObjectMapper();
    objectMapperCreator.configure(SerializationFeature.INDENT_OUTPUT, true);
    objectMapperCreator.setSerializationInclusion(Include.NON_NULL);
    StringWriter stringEmp = new StringWriter();
    objectMapperCreator.writeValue(stringEmp, responseData);
    return stringEmp;
  }

  /**
   * 
   * @author Reem Issa
   * @date Jun 16, 2019
   * @description_method
   * @param responseData
   * @return
   * @throws IOException
   * @throws JsonGenerationException
   * @throws JsonMappingException
   */
  public StringWriter createJsonStringIncludeNullValues(Object responseData)
      throws IOException, JsonGenerationException, JsonMappingException {
    ObjectMapper objectMapperCreator = new ObjectMapper();
    objectMapperCreator.configure(SerializationFeature.INDENT_OUTPUT, true);
    StringWriter stringEmp = new StringWriter();
    objectMapperCreator.writeValue(stringEmp, responseData);
    return stringEmp;
  }

}
