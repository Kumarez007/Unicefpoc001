package org.yumnn.yct.common.util.entityobject;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ParentEntityObject.java
 * @class_description parent class for all entity objects
 * @create_date Oct 14, 2016
 * @last_Update Oct 14, 2016
 */
@MappedSuperclass
public class ParentEntityObject implements Serializable {

	private static final long serialVersionUID = 1L;

}
