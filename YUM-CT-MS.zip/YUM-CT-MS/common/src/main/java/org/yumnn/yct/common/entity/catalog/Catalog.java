/*
 * Copyright 2016 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name Catalog.java
 * @class_description common interface to entities for catalog, this is used for
 *                    generic access to information
 * @create_date Jan 21, 2016
 * @last_Update Jan 21, 2016
 */
public interface Catalog {

	@JsonIgnore
	String getDisplayName();

	@JsonIgnore
	Object getObject();

	Long getId();

}
