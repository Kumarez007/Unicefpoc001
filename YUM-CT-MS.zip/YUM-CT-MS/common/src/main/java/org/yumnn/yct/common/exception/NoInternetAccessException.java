package org.yumnn.yct.common.exception;
import org.springframework.transaction.annotation.Transactional;

/**
 	* @author Jorge Villafuerte
 	* @department IT Department - Ecuador
 	* @owner Ayala Consulting Corporation.
 	* @class_name FailProcessException.java
 	* @class_description  Exception to all process that need rollback
 	* @create_date Oct 2, 2014
 	* @last_Update Oct 2, 2014
 	*/
@Transactional(rollbackFor=Exception.class)
public class NoInternetAccessException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoInternetAccessException() {
		super();
	}

	public NoInternetAccessException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoInternetAccessException(String message) {
		super(message);
	}

	public NoInternetAccessException(Throwable cause) {
		super(cause);
	}

}