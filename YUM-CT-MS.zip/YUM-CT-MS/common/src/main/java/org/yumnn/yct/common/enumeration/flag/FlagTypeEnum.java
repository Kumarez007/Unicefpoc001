package org.yumnn.yct.common.enumeration.flag;

/**
 * 
 * @author Alaa Darwish
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FlagTypeEnum.java
 * @class_description represents the flag type
 * @create_date May 08, 2019
 * @last_Update May 08, 2019
 */

public enum FlagTypeEnum {

	MAIN("main", "main"),SUB("sub","sub"),CM_ACTION("cm_acion","cm_action");

	private String valueToShow;
	private String fileName;
	
	FlagTypeEnum(String valueToShow, String fileName) {
		this.valueToShow = valueToShow;
		this.fileName = fileName;
	}

	public String getValueToShow() {
		return valueToShow;
	}

	public String getFileName() {
		return fileName;
	}




}
