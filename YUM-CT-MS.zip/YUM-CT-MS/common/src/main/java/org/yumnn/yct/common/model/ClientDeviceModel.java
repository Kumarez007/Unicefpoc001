package org.yumnn.yct.common.model;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {ClientDeviceModel.java
 * @create_date Jun 6, 2021
 * @last_Update Jun 6, 2021
 */
public class ClientDeviceModel {

	private Long id;
	
	private Boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
}
