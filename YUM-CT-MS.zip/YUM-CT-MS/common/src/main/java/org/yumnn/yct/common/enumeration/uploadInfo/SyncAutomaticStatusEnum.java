package org.yumnn.yct.common.enumeration.uploadInfo;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name SyncAutomaticStatusEnum.java
 * @class_description
 * @create_date Feb 1, 2018
 * @last_Update Feb 1, 2018
 */
public enum SyncAutomaticStatusEnum {
	IN_PROCESS, FINISHED, ERROR;
}
