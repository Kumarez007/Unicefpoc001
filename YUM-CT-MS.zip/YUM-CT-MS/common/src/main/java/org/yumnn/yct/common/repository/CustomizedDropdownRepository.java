package org.yumnn.yct.common.repository;

import java.util.List;

import org.yumnn.yct.common.entity.base.DropDownModel;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 6, 2021 1:16:50 PM
 */
public interface CustomizedDropdownRepository {
	
	List<DropDownModel> getProgramEntityDropdownByIdAsc(String id,Boolean onlyTFCRequired,String projectId);

	List<DropDownModel> getProgramEntityDropdownByIdAsc(String id,Boolean onlyTFCRequired,String projectId,String path);
	List<DropDownModel> getProjectDropdownByShortNameAsc(String shortName);
	
	List<DropDownModel> getOwnershipDropdownByAsc();
	
	List<DropDownModel> getGrievanceAgainstDropdownAsc();
	
	List<DropDownModel> getGrievanceCategoryDropdownAsc(String projectId);
	
	List<DropDownModel> getGrievanceCategoryDropdownAsc();
	
	List<DropDownModel> getGrievanceChannelDropdownAsc();
	
	List<DropDownModel> getGrievanceCycleDropdownAsc(String projectId);
	
	List<DropDownModel> getGovernorateDropDown();
	
	List<DropDownModel> getGeoDropDownByParentId(String id);
	
 	List<DropDownModel> getInquiryCatDropdown();

	List<DropDownModel> getInquiryCatDropdownById(String inquiryCatId);
	
 	List<DropDownModel> getInquiryTypeDropdownByCategory(String inquiryCatId);

	List<DropDownModel> getInquiryTypeDropdownById(String inquiryTypeId);
	
	List<DropDownModel> getProjectDropdown();
	
 	List<DropDownModel> getProjectDropdownById(String projectId);
 	
 	List<DropDownModel> getGrievanceActionDropdown();
 	
 	List<DropDownModel> getGrievanceActionDropdownTable();
 	
 	List<DropDownModel> getGrievanceActionDropdownSendBackToOwner();
 	
 	List<DropDownModel> getGrievanceActionDropdownByLoggedInRole(Long id);

 	List<DropDownModel> getAgenciesDropDown();
 	
 	List<DropDownModel> getActiveIssueTypesDropDown();
 	
	List<DropDownModel> getCFMProgrammeDropDown();

	List<DropDownModel> getCFMTypeOfInformationDropDown(Long roleId);

	List<DropDownModel> getGrievanceCategoryByRoleDropdownAsc(String roleId);
	
	List<DropDownModel> getGrievanceChannelByRoleDropdownAsc(String roleId);
	
	List<DropDownModel> getCFMProjectDropDownByProgrammeId(Long programmeId, Boolean mainProjectsOnly);
	
	List<DropDownModel> getCFMSubProjectsByMainProjectId(Long projectId);
	
	List<DropDownModel> getCFMGendersDropDown();
	
	List<DropDownModel> getCFMPriorityDropDown();

	List<DropDownModel> getCFMPComplainantMediumDropDown();

	List<DropDownModel> getCFMPInformationChannelDropDown();

	List<DropDownModel> getCFMPPreferedCommunicationChannelDropDown();

	List<DropDownModel> getCFMPriorityTimeframelDropDownByPriorityId(Long valueOf);
	
	List<DropDownModel> getCFMGrievanceStatusByTypeOfInformationIdDropDown(Long typeOfInfoId , String displayOnCFMForm);

	List<DropDownModel> getCFMImplementationPartnersByProgrammeIdDropDown(Long programmeId);

	List<DropDownModel> getCFMGrievanceCategoryByTypeOfInfoIdDropDown(Long typeOfInformationId, String isActive);

	List<DropDownModel> getCFMGrievanceCategoryByTypeOfInfoIdAndRoleIdDropDown(Long typeOfInformationId , Long roleId);

	List<DropDownModel> getCFMImplementationSitesByGeolocationIdDropDown(Long geolocationId);

	List<DropDownModel> getGrievanceCategoryByProjectDropdownAsc(String roleId, String projectId);
	
	List<DropDownModel> getGrievanceChannelByProjectDropdownAsc(String roleId, String projectId);
	
	List<DropDownModel> getCFMGrievanceActions();


	
}
