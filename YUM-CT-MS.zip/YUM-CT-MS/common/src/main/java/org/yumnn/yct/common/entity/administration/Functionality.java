package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Catalog;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.administration.FunctionalitiesFunctionalityTypesEnum;
import org.yumnn.yct.common.enumeration.administration.FunctionalitiesViewTagNameEnum;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user_access.adm_functionality")
@NamedQueries({
		@NamedQuery(name = "Functionality.findByViewTagName", query = "SELECT t FROM Functionality t WHERE t.viewTagName = :viewTagName "),
		@NamedQuery(name = "Functionality.findMatchingViewTagNameAndExcludingType", query = "SELECT t FROM Functionality t WHERE t.viewTagName IN ( :viewTagNameList ) AND t.functionalityType <> :functionalityType "),
		@NamedQuery(name = "Functionality.findChildrenByType", query = "SELECT t FROM Functionality t WHERE  t.parentFunctionality = :parentFunctionality AND t.functionalityType = :functionalityType "),
		@NamedQuery(name = "Functionality.findChildren", query = "SELECT t FROM Functionality t WHERE  t.parentFunctionality = :parentFunctionality"),
		@NamedQuery(name = "Functionality.findByRoleExcludingType", query = "SELECT t.functionality FROM RoleByProjectByFunctionality t WHERE  t.roleByProject.role = :role AND t.functionality.functionalityType <> :functionalityType "),
		@NamedQuery(name = "Functionality.findByRoleNotExcludesTypes", query = "SELECT t.functionality FROM RoleByProjectByFunctionality t WHERE  t.roleByProject.role = :role  ") })
public class Functionality extends BaseEntity implements Serializable, Catalog {



	private static final long serialVersionUID = 1L;

	@Column(name = "name")
	private String name;

	@Column(name = "url")
	private String url;

	@ManyToOne
	@JoinColumn(name = "id_functionality_fk", referencedColumnName = "ID")
	private Functionality parentFunctionality;

	@Column(name = "view_tag_name")
	@Enumerated(EnumType.STRING)
	private FunctionalitiesViewTagNameEnum viewTagName;

	@Column(name = "order_item")
	private Double orderItem;

	@Column(name = "functionality_type")
	@Enumerated(EnumType.STRING)
	private FunctionalitiesFunctionalityTypesEnum functionalityType;
	
	@Transient
	private Project project;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Functionality other = (Functionality) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public Functionality getParentFunctionality() {
		return parentFunctionality;
	}

	public void setParentFunctionality(Functionality parentFunctionality) {
		this.parentFunctionality = parentFunctionality;
	}

	public Double getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Double orderItem) {
		this.orderItem = orderItem;
	}

	public FunctionalitiesViewTagNameEnum getViewTagName() {
		return viewTagName;
	}

	public void setViewTagName(FunctionalitiesViewTagNameEnum viewTagName) {
		this.viewTagName = viewTagName;
	}

	public FunctionalitiesFunctionalityTypesEnum getFunctionalityType() {
		return functionalityType;
	}

	public void setFunctionalityType(FunctionalitiesFunctionalityTypesEnum functionalityType) {
		this.functionalityType = functionalityType;
	}

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}

}
