/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.model.administration;

import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

public class UserModel {

	protected Long id;
	
	private String username;

	private String password;

	private String firstName;

	private String lastName;

	private String sessionToken;

	private Integer loginAttempt;

	private String phoneNumber;

	private String uniqueUserSignature;

	private YesNoEnum isActive;


	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the sessionToken
	 */
	public String getSessionToken() {
		return sessionToken;
	}

	/**
	 * @param sessionToken the sessionToken to set
	 */
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	/**
	 * @return the loginAttempt
	 */
	public Integer getLoginAttempt() {
		return loginAttempt;
	}

	/**
	 * @param loginAttempt the loginAttempt to set
	 */
	public void setLoginAttempt(Integer loginAttempt) {
		this.loginAttempt = loginAttempt;
	}


	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the uniqueUserSignature
	 */
	public String getUniqueUserSignature() {
		return uniqueUserSignature;
	}

	/**
	 * @param uniqueUserSignature the uniqueUserSignature to set
	 */
	public void setUniqueUserSignature(String uniqueUserSignature) {
		this.uniqueUserSignature = uniqueUserSignature;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
}
