/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name PaymentSiteLocation.java
 * @class_description
 * @create_date Jun 26, 2019
 * @last_Update Jun 26, 2019
 */
@Entity
@Table(name = "payment.cat_payment_site_location")
public class PaymentSiteLocation extends BaseEntity {

	private static final long serialVersionUID = 1L;


	@ManyToOne
	@JoinColumn(name = "id_payment_site_fk")
	private PaymentSite paymentSite;
	
	@ManyToOne
	@JoinColumn(name = "id_geolocation_fk")
	private Geolocation geolocation;

	@Column(name = "initial_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date initialDate;

	@Column(name = "ending_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endingDate;


	/**
	 * @return the initialDate
	 */
	public Date getInitialDate() {
		return initialDate;
	}

	/**
	 * @param initialDate
	 *            the initialDate to set
	 */
	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate
	 *            the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	public PaymentSiteLocation() {
		super();
	}

	public PaymentSiteLocation(Long id) {
		this.id = id;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PaymentSiteLocation other = (PaymentSiteLocation) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public Geolocation getGeolocation() {
		return geolocation;
	}

	public void setGeolocation(Geolocation geolocation) {
		this.geolocation = geolocation;
	}

	/**
	 * @return the paymentSite
	 */
	public PaymentSite getPaymentSite() {
		return paymentSite;
	}

	/**
	 * @param paymentSite the paymentSite to set
	 */
	public void setPaymentSite(PaymentSite paymentSite) {
		this.paymentSite = paymentSite;
	}
}
