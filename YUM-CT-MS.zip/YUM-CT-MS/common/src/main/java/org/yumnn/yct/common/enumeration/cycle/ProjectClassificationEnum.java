package org.yumnn.yct.common.enumeration.cycle;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name ProjectClassificationEnum.java
 * @create_date Sep 5, 2021
 */
public enum ProjectClassificationEnum {

	CASH_BASED, VOUCHER_BASED,VOUCHER

}
