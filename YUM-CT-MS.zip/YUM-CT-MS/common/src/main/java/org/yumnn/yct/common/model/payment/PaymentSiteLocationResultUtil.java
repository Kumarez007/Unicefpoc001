package org.yumnn.yct.common.model.payment;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name PaymentSiteLocationResultUtil.java
 * @create_date Dec 15, 2021
 * @last_Update Dec 15, 2021
 */
@Entity
public class PaymentSiteLocationResultUtil {

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "initial_date")
	private Date initialDate;

	@Column(name = "ending_date")
	private Date endingDate;

	@Column(name = "govern_name")
	private String governorateNameEn;

	@Column(name = "govern_name_ar")
	private String governorateNameAr;

	@Column(name = "district_name")
	private String districtNameEn;

	@Column(name = "district_name_ar")
	private String districtNameAr;

	@Column(name = "ozla_name")
	private String ozlaNameEn;

	@Column(name = "ozla_name_ar")
	private String ozlaNameAr;

	@Column(name = "city_name")
	private String villageNameEn;

	@Column(name = "city_name_ar")
	private String villageNameAr;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the initialDate
	 */
	public Date getInitialDate() {
		return initialDate;
	}

	/**
	 * @param initialDate the initialDate to set
	 */
	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the governorateNameEn
	 */
	public String getGovernorateNameEn() {
		return governorateNameEn;
	}

	/**
	 * @param governorateNameEn the governorateNameEn to set
	 */
	public void setGovernorateNameEn(String governorateNameEn) {
		this.governorateNameEn = governorateNameEn;
	}

	/**
	 * @return the districtNameEn
	 */
	public String getDistrictNameEn() {
		return districtNameEn;
	}

	/**
	 * @param districtNameEn the districtNameEn to set
	 */
	public void setDistrictNameEn(String districtNameEn) {
		this.districtNameEn = districtNameEn;
	}

	/**
	 * @return the ozlaNameEn
	 */
	public String getOzlaNameEn() {
		return ozlaNameEn;
	}

	/**
	 * @param ozlaNameEn the ozlaNameEn to set
	 */
	public void setOzlaNameEn(String ozlaNameEn) {
		this.ozlaNameEn = ozlaNameEn;
	}

	/**
	 * @return the villageNameEn
	 */
	public String getVillageNameEn() {
		return villageNameEn;
	}

	/**
	 * @param villageNameEn the villageNameEn to set
	 */
	public void setVillageNameEn(String villageNameEn) {
		this.villageNameEn = villageNameEn;
	}

}
