package org.yumnn.yct.common.exception;
import org.springframework.transaction.annotation.Transactional;

/**
 	* @author Jorge Villafuerte
 	* @department IT Department - Ecuador
 	* @owner Ayala Consulting Corporation.
 	* @class_name FailProcessException.java
 	* @class_description  Exception to all process that need rollback
 	* @create_date Oct 2, 2014
 	* @last_Update Oct 2, 2014
 	*/
@Transactional(rollbackFor=Exception.class)
public class DateNotCorrectException extends Exception {

	private static final long serialVersionUID = 1L;

	public DateNotCorrectException() {
		super();
	}

	public DateNotCorrectException(String message, Throwable cause) {
		super(message, cause);
	}

	public DateNotCorrectException(String message) {
		super(message);
	}

	public DateNotCorrectException(Throwable cause) {
		super(cause);
	}

}