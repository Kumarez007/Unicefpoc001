package org.yumnn.yct.common.model.payment;

import java.util.List;

import org.yumnn.yct.common.enumeration.paymentSites.PaymentSiteTypeEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSitesConnectionTypeEnum;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name PaymentSiteViewModel.java
 * @create_date Dec 15, 2021
 * @last_Update Dec 15, 2021
 */
public class PaymentSiteViewModel {

	private String siteName;

	private String siteCode;

	private String agencyNameAr;

	private String agencyNameEn;

	private String paymentSiteAddress;

	private Integer expectedNumberOfBeneficiaries;

	private PaymentSiteTypeEnum siteType;

	private PaymentSitesConnectionTypeEnum connectionType;

	private String paymentAgentName;

	private List<PaymentSiteLocationResultUtil> paymentSiteLocationViewModelList;

	private String fixedSiteType;

	private Integer numberOfWorkingDays;

	private Integer numberOfDailyPayments;

	private Integer staffingMalesCashiers;

	private Integer staffingFemalesCashiers;

	private Integer staffingMalesScreening;

	private Integer staffingFemalesScreening;
	
    private Double gpsLongitude;

    private Double gpsLatitude;

	/**
	 * @return the paymentSiteLocationViewModelList
	 */
	public List<PaymentSiteLocationResultUtil> getPaymentSiteLocationViewModelList() {
		return paymentSiteLocationViewModelList;
	}

	/**
	 * @param paymentSiteLocationViewModelList the paymentSiteLocationViewModelList
	 *                                         to set
	 */
	public void setPaymentSiteLocationViewModelList(
			List<PaymentSiteLocationResultUtil> paymentSiteLocationViewModelList) {
		this.paymentSiteLocationViewModelList = paymentSiteLocationViewModelList;
	}

	/**
	 * @return the siteName
	 */
	public String getSiteName() {
		return siteName;
	}

	/**
	 * @param siteName the siteName to set
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	/**
	 * @return the siteCode
	 */
	public String getSiteCode() {
		return siteCode;
	}

	/**
	 * @param siteCode the siteCode to set
	 */
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	/**
	 * @return the agencyNameAr
	 */
	public String getAgencyNameAr() {
		return agencyNameAr;
	}

	/**
	 * @param agencyNameAr the agencyNameAr to set
	 */
	public void setAgencyNameAr(String agencyNameAr) {
		this.agencyNameAr = agencyNameAr;
	}

	/**
	 * @return the agencyNameEn
	 */
	public String getAgencyNameEn() {
		return agencyNameEn;
	}

	/**
	 * @param agencyNameEn the agencyNameEn to set
	 */
	public void setAgencyNameEn(String agencyNameEn) {
		this.agencyNameEn = agencyNameEn;
	}

	/**
	 * @return the expectedNumberOfBeneficiaries
	 */
	public Integer getExpectedNumberOfBeneficiaries() {
		return expectedNumberOfBeneficiaries;
	}

	/**
	 * @param expectedNumberOfBeneficiaries the expectedNumberOfBeneficiaries to set
	 */
	public void setExpectedNumberOfBeneficiaries(Integer expectedNumberOfBeneficiaries) {
		this.expectedNumberOfBeneficiaries = expectedNumberOfBeneficiaries;
	}

	/**
	 * @return the siteType
	 */
	public PaymentSiteTypeEnum getSiteType() {
		return siteType;
	}

	/**
	 * @param siteType the siteType to set
	 */
	public void setSiteType(PaymentSiteTypeEnum siteType) {
		this.siteType = siteType;
	}

	/**
	 * @return the connectionType
	 */
	public PaymentSitesConnectionTypeEnum getConnectionType() {
		return connectionType;
	}

	/**
	 * @param connectionType the connectionType to set
	 */
	public void setConnectionType(PaymentSitesConnectionTypeEnum connectionType) {
		this.connectionType = connectionType;
	}

	/**
	 * @return the paymentAgentName
	 */
	public String getPaymentAgentName() {
		return paymentAgentName;
	}

	/**
	 * @param paymentAgentName the paymentAgentName to set
	 */
	public void setPaymentAgentName(String paymentAgentName) {
		this.paymentAgentName = paymentAgentName;
	}

	/**
	 * @return the paymentSiteAddress
	 */
	public String getPaymentSiteAddress() {
		return paymentSiteAddress;
	}

	/**
	 * @param paymentSiteAddress the paymentSiteAddress to set
	 */
	public void setPaymentSiteAddress(String paymentSiteAddress) {
		this.paymentSiteAddress = paymentSiteAddress;
	}

	/**
	 * @return the fixedSiteType
	 */
	public String getFixedSiteType() {
		return fixedSiteType;
	}

	/**
	 * @param fixedSiteType the fixedSiteType to set
	 */
	public void setFixedSiteType(String fixedSiteType) {
		this.fixedSiteType = fixedSiteType;
	}

	/**
	 * @return the numberOfWorkingDays
	 */
	public Integer getNumberOfWorkingDays() {
		return numberOfWorkingDays;
	}

	/**
	 * @param numberOfWorkingDays the numberOfWorkingDays to set
	 */
	public void setNumberOfWorkingDays(Integer numberOfWorkingDays) {
		this.numberOfWorkingDays = numberOfWorkingDays;
	}

	/**
	 * @return the numberOfDailyPayments
	 */
	public Integer getNumberOfDailyPayments() {
		return numberOfDailyPayments;
	}

	/**
	 * @param numberOfDailyPayments the numberOfDailyPayments to set
	 */
	public void setNumberOfDailyPayments(Integer numberOfDailyPayments) {
		this.numberOfDailyPayments = numberOfDailyPayments;
	}

	/**
	 * @return the staffingMalesCashiers
	 */
	public Integer getStaffingMalesCashiers() {
		return staffingMalesCashiers;
	}

	/**
	 * @param staffingMalesCashiers the staffingMalesCashiers to set
	 */
	public void setStaffingMalesCashiers(Integer staffingMalesCashiers) {
		this.staffingMalesCashiers = staffingMalesCashiers;
	}

	/**
	 * @return the staffingFemalesCashiers
	 */
	public Integer getStaffingFemalesCashiers() {
		return staffingFemalesCashiers;
	}

	/**
	 * @param staffingFemalesCashiers the staffingFemalesCashiers to set
	 */
	public void setStaffingFemalesCashiers(Integer staffingFemalesCashiers) {
		this.staffingFemalesCashiers = staffingFemalesCashiers;
	}

	/**
	 * @return the staffingMalesScreening
	 */
	public Integer getStaffingMalesScreening() {
		return staffingMalesScreening;
	}

	/**
	 * @param staffingMalesScreening the staffingMalesScreening to set
	 */
	public void setStaffingMalesScreening(Integer staffingMalesScreening) {
		this.staffingMalesScreening = staffingMalesScreening;
	}

	/**
	 * @return the staffingFemalesScreening
	 */
	public Integer getStaffingFemalesScreening() {
		return staffingFemalesScreening;
	}

	/**
	 * @param staffingFemalesScreening the staffingFemalesScreening to set
	 */
	public void setStaffingFemalesScreening(Integer staffingFemalesScreening) {
		this.staffingFemalesScreening = staffingFemalesScreening;
	}

	/**
	 * @return the gpsLongitude
	 */
	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	/**
	 * @param gpsLongitude the gpsLongitude to set
	 */
	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	/**
	 * @return the gpsLatitude
	 */
	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	/**
	 * @param gpsLatitude the gpsLatitude to set
	 */
	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	
}
