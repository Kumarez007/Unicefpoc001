package org.yumnn.yct.common.entity.cycle;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.programPeriod.ProgramPeriod;
import org.yumnn.yct.common.enumeration.cycle.CycleStyleClassEnum;
import org.yumnn.yct.common.model.administration.CycleModel;
import org.yumnn.yct.common.util.Utilities;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name Cycle.java
 * @class_description reference to the Cycle table in the gen schema
 * @create_date Jun 22, 2017
 * @last_Update Jun 22, 2017
 */
@Entity
@Table(name = "user_access.adm_cycle")
@NamedQueries({
        @NamedQuery(name = "Cycle.retrieveAllCurrentCycleByStatus", query = "SELECT ftg FROM CycleStatus ftgs JOIN ftgs.cycle ftg  WHERE ftgs.cycleStatus = :status and ftgs.endingDate is null order by ftg.id asc"),
        @NamedQuery(name = "Cycle.findAllCyclesOrderedByIdDesc", query = "SELECT t FROM Cycle t ORDER BY t.id DESC"),
        @NamedQuery(name = "Cycle.findActive", query = "SELECT t FROM Cycle t WHERE t.endingDate IS NULL")})
public class Cycle extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManyToOne
    @JoinColumn(name = "id_program_period_fk", referencedColumnName = "ID")
    private ProgramPeriod programPeriod;


    @Column(name = "name")
    private String cycleName;

    @Column(name = "creation_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

    @Column(name = "ending_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endingDate;

    @Column(name = "style_class")
    @Enumerated(EnumType.STRING)
    private CycleStyleClassEnum cycleStyleClass;

    @Column(name = "cycle_number")
    private Integer cycleNumber;
    
    @Column(name = "display_name")
    private String cycleDisplayName;



    public Cycle() {
    }

    public Cycle(Long id) {
        this.id = id;
    }


    public String getCycleName() {
        return cycleName;
    }

    public void setCycleName(String cycleName) {
        this.cycleName = cycleName;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Cycle other = (Cycle) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }


    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getEndingDate() {
        return endingDate;
    }

    public void setEndingDate(Date endingDate) {
        this.endingDate = endingDate;
    }

    public CycleStyleClassEnum getCycleStyleClass() {
        return cycleStyleClass;
    }

    public void setCycleStyleClass(CycleStyleClassEnum cycleStyleClass) {
        this.cycleStyleClass = cycleStyleClass;
    }

    public ProgramPeriod getProgramPeriod() {
        return programPeriod;
    }

    public void setProgramPeriod(ProgramPeriod programPeriod) {
        this.programPeriod = programPeriod;
    }

    /**
     * @return the cycleNumber
     */
    public Integer getCycleNumber() {
        return cycleNumber;
    }

    /**
     * @param cycleNumber the cycleNumber to set
     */
    public void setCycleNumber(Integer cycleNumber) {
        this.cycleNumber = cycleNumber;
    }
    
    public String getCycleDisplayName() {
		return cycleDisplayName;
	}

	public void setCycleDisplayName(String cycleDisplayName) {
		this.cycleDisplayName = cycleDisplayName;
	}

	public CycleModel getCycleModel() {
    	CycleModel cycleModel = new CycleModel();
    	cycleModel.setCreationDate(creationDate);
    	cycleModel.setCycleName(cycleName);
    	cycleModel.setId(id);
    	cycleModel.setCycleNumber(cycleNumber);
    	cycleModel.setEndingDate(endingDate);
    	cycleModel.setCycleDisplayName(cycleDisplayName);
    	cycleModel.setProgramPeriodId(Utilities.isNULL(programPeriod)? null : programPeriod.getId());
    	return cycleModel;
    }
}
