package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

@Entity
@Table(name = "cat_officer_type")
@NamedQueries({
		@NamedQuery(name = "OfficerType.findAllByOrderItem", query = "SELECT r from OfficerType r order by r.orderItem asc"),
		@NamedQuery(name = "OfficerType.findByShortName", query = "SELECT r from OfficerType r WHERE r.shortName = :shortName"),
		@NamedQuery(name = "OfficerType.findAllForByShortName", query = "SELECT r from OfficerType r WHERE r.shortName IN (:list) order by r.orderItem asc")})
public class OfficerType extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;


	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		OfficerType other = (OfficerType) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	
}
