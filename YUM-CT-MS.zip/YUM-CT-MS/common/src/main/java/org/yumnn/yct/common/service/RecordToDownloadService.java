package org.yumnn.yct.common.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.uploadInfo.RecordToDownload;
import org.yumnn.yct.common.enumeration.quartz.UploadedRecordTypeEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.exception.FailProcessWithoutRollbackException;
import org.yumnn.yct.common.repository.IRecordToDownloadRepository;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {RecordToDownloadService.java
 * @create_date May 26, 2021
 * @last_Update May 26, 2021
 */
@Service
public class RecordToDownloadService {

	@Autowired
	private IRecordToDownloadRepository iRecordToDownloadRepository;

	/**
	 * 
	 * @author Reem Issa
	 * @date Jul 5, 2019
	 * @description_method
	 * @param recordToDownload
	 * @return
	 * @throws FailProcessException
	 */
	public RecordToDownload save(RecordToDownload recordToDownload) throws FailProcessException {
		try {
			iRecordToDownloadRepository.save(recordToDownload);
			return recordToDownload;
		} catch (Exception e) {
			throw new FailProcessException();
		}
	}

	/**
	 * 
	 * @author Reem Issa
	 * @date Mar 10, 2020
	 * @description_method
	 * @param id
	 * @return
	 * @throws FailProcessException
	 * @throws FailProcessWithoutRollbackException
	 */
	public RecordToDownload retrieveById(Long id) throws FailProcessException, FailProcessWithoutRollbackException {

		Optional<RecordToDownload> recordToDownload = iRecordToDownloadRepository.findById(id);
		return recordToDownload.orElse(null);

	}

	/**
	 * 
	 * @author Reem Issa
	 * @date Mar 10, 2020
	 * @description_method
	 * @param user
	 * @param recordType
	 * @return
	 * @throws FailProcessException
	 * @throws FailProcessWithoutRollbackException
	 */
	public RecordToDownload retrievePendingRecord(User user, UploadedRecordTypeEnum recordType)
			throws FailProcessException, FailProcessWithoutRollbackException {
		try {
			return iRecordToDownloadRepository.retrievePendingRecord(user, recordType);
		} catch (FailProcessWithoutRollbackException e) {
			throw e;
		} catch (FailProcessException e) {
			throw e;
		}
	}

}
