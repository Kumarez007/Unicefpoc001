package org.yumnn.yct.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.uploadInfo.PaymentSiteToDownload;

@Repository
public interface IPaymentSiteToDownloadRepository extends JpaRepository<PaymentSiteToDownload, Long>{

}
