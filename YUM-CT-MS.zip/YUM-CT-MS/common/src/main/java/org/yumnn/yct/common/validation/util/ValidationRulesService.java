package org.yumnn.yct.common.validation.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.yumnn.yct.common.enumeration.role.RuleEnum;
import org.yumnn.yct.common.util.ConstantsUtil;
import org.yumnn.yct.common.util.SHA512EncryptionUtil;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class ValidationRulesService {

  private static Logger logger = LogManager.getLogger();

  public static void validate(List<HashMap<String, Object>> listOfMap,
      ValidationInterfaces.didValidate didValidate) throws Exception {
    ArrayList<HashMap<String, Enum>> errorMessage = new ArrayList<>();
    RuleEnum rule = null;
    HashMap<String, Enum> errorMap = new LinkedHashMap<>();
    for (int i = 0; i < listOfMap.size(); i++) {
      String field = listOfMap.get(i).get(ConstantsUtil.FIELD_NAME).toString();
      String value = (listOfMap.get(i).get(ConstantsUtil.FIELD_VALUE) != null)
          ? (listOfMap.get(i).get(ConstantsUtil.FIELD_VALUE).toString())
          : null;
      String dbValue = (listOfMap.get(i).get(ConstantsUtil.DB_VALUE) != null)
          ? (listOfMap.get(i).get(ConstantsUtil.DB_VALUE).toString())
          : null;

      List<HashMap<Enum, String>> validation =
          (List<HashMap<Enum, String>>) listOfMap.get(i).get(ConstantsUtil.VALIDATION);
      if (validation != null) {
        for (int j = 0; j < validation.size(); j++) {
          rule = (RuleEnum) validation.get(j).keySet().iterator().next();
          errorMap = validateRules(rule, validation.get(j), field, value, dbValue);
          if (!errorMap.isEmpty()) {
            logger.warn("validate: " + field + "| rule: " + rule + "| value:" + value);
            errorMessage.add(errorMap);
          }
        }
      }
    }
    if (errorMessage.isEmpty()) {
      didValidate.didValidate(true, errorMessage);
    } else {
      didValidate.didValidate(false, errorMessage);
    }
  }

  // defined all validation rules
  private static HashMap<String, Enum> validateRules(RuleEnum rule,
      HashMap<Enum, String> validationMap, String fieldName, String value, String dbValue)
      throws Exception {
    HashMap<String, Enum> errorMap = new LinkedHashMap<>();
    final String numberRegExp = "[0-9]+";
    switch (rule) {
      case NOT_EMPTY:
        if (value == null || "".equals(value.trim())) {
          errorMap.put(fieldName, RuleEnum.NOT_EMPTY);
        }
        break;
      case USER_NOT_EXIST:
        if (value != null && !("").equals(value) && !value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.USER_NOT_EXIST);
        }
        break;

      case SIX_DIGIT_PASSWORD:
        if (value != null && value.length() > 0 && value.length() < 6) {
          errorMap.put(fieldName, RuleEnum.SIX_DIGIT_PASSWORD);
        }
        break;
      case WRONG_PASSWORD:
        String encryptedPassword = SHA512EncryptionUtil.sha512encrypt(value);
        if (value != null && !encryptedPassword.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.WRONG_PASSWORD);
        }
        break;

      case DEACTIVATE_USER:
        if (value != null && value.equals("false")) {
          errorMap.put(fieldName, RuleEnum.DEACTIVATE_USER);
        }
        break;

      case PHONE_NUMBER:
        String regexLandLine = "^0[1-7][0-9]{6}$";
        String regex = "^[7][0-9]{8}$";
        if (value != null && (value.trim().length() < 8 || value.trim().length() > 9
            || (value.trim().length() == 8 && !value.matches(regexLandLine))
            || (value.trim().length() == 9 && !value.matches(regex))))
          errorMap.put(fieldName, RuleEnum.PHONE_NUMBER);
        break;

      case MISMATCH_PASSWORD:
        if (value != null && !value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.MISMATCH_PASSWORD);
        }
        break;
      case MANDATORY_HEADER_FIELDS_NOT_EXIST:
        if (value == null || value.isEmpty()) {
          errorMap.put(fieldName, RuleEnum.MANDATORY_HEADER_FIELDS_NOT_EXIST);
        }
        break;
      case MANDATORY_FIELDS_NOT_EXIST:
        if (value == null || value.isEmpty()) {
          errorMap.put(fieldName, RuleEnum.MANDATORY_FIELDS_NOT_EXIST);
        }
        break;
      case MANDATORY_FIELDS_NOT_EXIST_SEARCH:
        if (!value.isEmpty() || value != null) {
          errorMap.put(fieldName, RuleEnum.MANDATORY_FIELDS_NOT_EXIST);
        }
        break;
      case USERID_NOT_PRESENT:
        if (value != null && !value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.USERID_NOT_PRESENT);
        }
        break;
      case VOUCHER_SERIAL_NUMBER_DOES_NOT_EXIST:
        if (dbValue == null) {
          errorMap.put(fieldName, RuleEnum.VOUCHER_SERIAL_NUMBER_DOES_NOT_EXIST);
        }
        break;
      case INACTIVE_VOUCHER_SERIAL_NUMBER:
        if (value != null && !value.equals("true")) {
          errorMap.put(fieldName, RuleEnum.INACTIVE_VOUCHER_SERIAL_NUMBER);
        }
        break;
      case INVALID_VOUCHER_SERIAL_NUMBER:
        if (value != null && (value.trim().length() != 8 || !value.trim().matches(numberRegExp))) {
          errorMap.put(fieldName, RuleEnum.INVALID_VOUCHER_SERIAL_NUMBER);
        }
        break;
      case INVALID_BOOKLET_NUMBER:
        if (value != null && (value.trim().length() != 6 || !value.trim().matches(numberRegExp))) {
          errorMap.put(fieldName, RuleEnum.INVALID_BOOKLET_NUMBER);
        }
        break;
      case NAME_ON_DISCHARGE_CARD_NOT_MATCHED:
        if (value != null && !value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.NAME_ON_DISCHARGE_CARD_NOT_MATCHED);
        }
        break;
      case ABORTION_WAS_PREVIOUSLY_REGISTERED:
        if (value != null) {
          errorMap.put(fieldName, RuleEnum.ABORTION_WAS_PREVIOUSLY_REGISTERED);
        }
        break;
      case DELIVERY_WAS_PREVIOUSLY_REGISTERED:
        if (value != null) {
          errorMap.put(fieldName, RuleEnum.DELIVERY_WAS_PREVIOUSLY_REGISTERED);
        }
        break;
      case DELIVERY_DATE_EXCEEDED_TWO_MONTHS_FROM_NOW:
        if (value != null && value.equals("false")) {
          errorMap.put(fieldName, RuleEnum.DELIVERY_DATE_EXCEEDED_TWO_MONTHS_FROM_NOW);
        }
        break;
      case ABORTION_WAS_PREVIOUSLY_REGISTERED_PERIODIC_CHECKUP:
        if (value != null) {
          errorMap.put(fieldName, RuleEnum.ABORTION_WAS_PREVIOUSLY_REGISTERED_PERIODIC_CHECKUP);
        }
        break;
      case ISO_DATE:
        String iso_date_regex =
            "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[13-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$";
        if (value != null && !value.matches(iso_date_regex)) {
          errorMap.put(fieldName, RuleEnum.ISO_DATE);
        }
        break;
      case ID_NOT_EXIST_IN_DB:
        if (value != null && !value.equals("") && !value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.ID_NOT_EXIST_IN_DB);
        }
        break;
      case BENEFICIARY_NOT_EXIST_IN_DB:
        if (dbValue == null) {
          errorMap.put(fieldName, RuleEnum.BENEFICIARY_NOT_EXIST_IN_DB);
        }
        break;
      case VOUCHER_NOT_UNIQUE:
        if (dbValue != null && !dbValue.equals(ConstantsUtil.TOTAL_VOUCHER_PER_BENEFICIARY)) {
          errorMap.put(fieldName, RuleEnum.VOUCHER_NOT_UNIQUE);
        }
        break;
      case VOUCHER_ALREADY_EXIST_IN_DB:
        if (value != null && value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.VOUCHER_ALREADY_EXIST_IN_DB);
        }
        break;

      case NUMBER_OF_VALIDATED_SERVICES_ARE_LESS_THAN_FOUR:
        if (Integer.parseInt(value) < 4) {
          errorMap.put(fieldName, RuleEnum.NUMBER_OF_VALIDATED_SERVICES_ARE_LESS_THAN_FOUR);
        }
        break;
      case NUMBER_OF_VALIDATED_SERVICES_IS_EQUAL_FOUR:
        if (Integer.parseInt(value) == 4) {
          errorMap.put(fieldName, RuleEnum.NUMBER_OF_VALIDATED_SERVICES_IS_EQUAL_FOUR);
        }
        break;
      case SERVICE_HAS_BEEN_VALIDATED:
        if (Integer.parseInt(value) == 4) {
          errorMap.put(fieldName, RuleEnum.NUMBER_OF_VALIDATED_SERVICES_IS_EQUAL_FOUR);

        }
        break;
      case BOOKLET_ALREADY_EXIST_IN_DB:
        if (value != null && value.equals(dbValue)) {
          errorMap.put(fieldName, RuleEnum.BOOKLET_ALREADY_EXIST_IN_DB);

        }
        break;
      case NOT_EMPTY_VALIDATION_OFFICER_SEARCH:
        if (value == null) {
          errorMap.put(fieldName, RuleEnum.NOT_EMPTY_VALIDATION_OFFICER_SEARCH);
        }
        break;
      case VOUCHER_SERIAL_NUMBER_DOES_NOT_BELONGS_TO_THE_BENEFICIARY:
        if (value == null) {
          errorMap.put(fieldName,
              RuleEnum.VOUCHER_SERIAL_NUMBER_DOES_NOT_BELONGS_TO_THE_BENEFICIARY);
        }
        break;
      case ONLY_FULLNAME_EXIST:
        if (!value.isEmpty()) {
          errorMap.put(fieldName, RuleEnum.ONLY_FULLNAME_EXIST);
        }
        break;
      case DELIVERY_ONCE_PER_YEAR:
        if (value != null && value.equals("true")) {
          errorMap.put(fieldName, RuleEnum.DELIVERY_ONCE_PER_YEAR);
        }
        break;
      case POST_NATAL_ONCE_PER_YEAR:
        if (value != null && value.equals("true")) {
          errorMap.put(fieldName, RuleEnum.POST_NATAL_ONCE_PER_YEAR);
        }
        break;
      case ABORTION_ONCE_PER_YEAR:
        if (value.equals("true")) {
          errorMap.put(fieldName, RuleEnum.ABORTION_ONCE_PER_YEAR);
        }
        break;
      case INACTIVE_VOUCHER_SEARCH:
        if (value.equals("true")) {
          errorMap.put(fieldName, RuleEnum.INACTIVE_VOUCHER_SEARCH);
        }
        break;
      case ESTIMATED_STAGE_OF_PREGNANCY:
        String estimatedStageOfPregnancyRegex = "\\b([0-9]|[1-3][0-9]|40)\\b";
        if (!value.matches(estimatedStageOfPregnancyRegex)) {
          errorMap.put(fieldName, RuleEnum.ESTIMATED_STAGE_OF_PREGNANCY);
        }
        break;
    }
    return errorMap;
  }
}


