package org.yumnn.yct.common.enumeration.role;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public enum RolesEnum {
  SUPERVISER(1L), 
  ENROLLMENT_OFFICER(2L), 
  VALIDATION_OFFICER(3L), 
  PMU(4L), 
  CMA(16L), 
  FIELD_MONITOR(20L);

  private Long enumValue;

  /**
   * @param enumValue
   */
  private RolesEnum(Long enumValue) {
    this.enumValue = enumValue;
  }

  /**
   * @return the enumValue
   */
  public Long getEnumValue() {
    return enumValue;
  }

  /**
   * @param enumValue the enumValue to set
   */
  public void setEnumValue(Long enumValue) {
    this.enumValue = enumValue;
  }
}
