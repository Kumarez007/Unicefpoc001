/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name UserAccess.java
 * @class_description 
 * @create_date Feb 17, 2020
 * @last_Update Feb 17, 2020
 */
@Entity
@Table(name = "hst_user_access")
@NamedQueries({
		@NamedQuery(name = "UserAccess.findByUser", query = "SELECT u from UserAccess u where u.user = :user "),
		@NamedQuery(name = "UserAccess.retrieveBySessionId", query = "SELECT u from UserAccess u where u.sessionId = :sessionId ")
		
		
})
public class UserAccess extends BaseEntity implements Serializable {
	private static final long serialVersionUID = -6739919052158515878L;

	@Column(name = "login_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date loginTime;
	
	@Column(name = "logout_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date logoutTime;
	
	@Column(name = "ip_address")
	private String ipAddress;
	
	@Column(name = "host_name")
	private String hostName;
	
	@Column(name = "session_id")
	private String sessionId;
	
	@ManyToOne
	@JoinColumn(name = "id_user_fk", referencedColumnName = "ID")
	private User user;
	
	/**
	 * 
	 */
	public UserAccess() {
	}
	
	/**
	 * @return the loginTime
	 */
	public Date getLoginTime() {
		return loginTime;
	}


	/**
	 * @param loginTime the loginTime to set
	 */
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}


	/**
	 * @return the logoutTime
	 */
	public Date getLogoutTime() {
		return logoutTime;
	}


	/**
	 * @param logoutTime the logoutTime to set
	 */
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}


	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}


	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}


	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}


	/**
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}


	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}


	/**
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}


	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}


	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAccess other = (UserAccess) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
