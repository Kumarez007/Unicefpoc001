package org.yumnn.yct.common.enumeration.cycle;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name CycleStatusEnum.java
 * @class_description contains the different statuses used to generate amount
 *                    for the households
 * @create_date Jun 22, 2017
 * @last_Update Jun 22, 2017
 */
public enum GenerateHouseholdAmountByCycleStatusEnum {

	PENDING_TO_GENERATE_AMOUNT("---"), AMOUNT_GENERATED("Generated Amount"), RECONCILED("Paid"), CLOSED_BY_CYCLE("Unpaid");
	
	private String valueToShow;
	
	private GenerateHouseholdAmountByCycleStatusEnum(String valueToShow) {
		this.valueToShow=valueToShow;
	}
	
	public String getValueToShow() {
		return valueToShow;
	}

}
