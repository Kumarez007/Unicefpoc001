package org.yumnn.yct.common.json;

public abstract class ParentResponseObject {

	private Boolean success;
	private Integer reason;
	
	protected ParentResponseObject(){
		
	}
	
	protected ParentResponseObject(Boolean success, Integer reason) {
		super();
		this.success = success;
		this.reason = reason;
	}

	public Boolean getSuccess() {
		return success;
	}


	public Integer getReason() {
		return reason;
	}


}
