/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSiteStatusEnum;

/**
 * @author Reem Issa
 * @department PMU.
 * @owner UNICEF.
 * @class_name PaymentSiteStatus.java
 * @class_description
 * @create_date Feb 26, 2019
 * @last_Update Feb 26, 2019
 */
@Entity
@Table(name = "payment.cat_payment_site_status")
public class PaymentSiteStatus extends BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private PaymentSiteStatusEnum paymentSiteStatus;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;

	@Column(name = "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	@ManyToOne
	@JoinColumn(name = "created_by", referencedColumnName = "ID")
	private User createdBy;

	@ManyToOne
	@JoinColumn(name = "id_payment_site_fk", referencedColumnName = "ID")
	private PaymentSite paymentSite;

	@Column(name = "ending_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endingDate;
	
	@Column(name = "recommendation")
	private String recommendation;
	
	@Column(name = "endorsement_comment")
	private String endorsementComment;
	
	@Column(name = "send_endorsement_comment_to_bank")
	@Enumerated(EnumType.STRING)
	private YesNoEnum sendEndorsementCommentToBank;

	@Column(name = "decline_comment")
	private String declineComment;
	

	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the paymentSite
	 */
	public PaymentSite getPaymentSite() {
		return paymentSite;
	}

	/**
	 * @param paymentSite the paymentSite to set
	 */
	public void setPaymentSite(PaymentSite paymentSite) {
		this.paymentSite = paymentSite;
	}

	/**
	 * @return the paymentSiteStatus
	 */
	public PaymentSiteStatusEnum getPaymentSiteStatus() {
		return paymentSiteStatus;
	}

	/**
	 * @param paymentSiteStatus the paymentSiteStatus to set
	 */
	public void setPaymentSiteStatus(PaymentSiteStatusEnum paymentSiteStatus) {
		this.paymentSiteStatus = paymentSiteStatus;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the recommendation
	 */
	public String getRecommendation() {
		return recommendation;
	}

	/**
	 * @param recommendation the recommendation to set
	 */
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}

	/**
	 * @return the endorsementComment
	 */
	public String getEndorsementComment() {
		return endorsementComment;
	}

	/**
	 * @param endorsementComment the endorsementComment to set
	 */
	public void setEndorsementComment(String endorsementComment) {
		this.endorsementComment = endorsementComment;
	}

	/**
	 * @return the sendEndorsementCommentToBank
	 */
	public YesNoEnum getSendEndorsementCommentToBank() {
		return sendEndorsementCommentToBank;
	}

	/**
	 * @param sendEndorsementCommentToBank the sendEndorsementCommentToBank to set
	 */
	public void setSendEndorsementCommentToBank(YesNoEnum sendEndorsementCommentToBank) {
		this.sendEndorsementCommentToBank = sendEndorsementCommentToBank;
	}

	/**
	 * @return the declineComment
	 */
	public String getDeclineComment() {
		return declineComment;
	}

	/**
	 * @param declineComment the declineComment to set
	 */
	public void setDeclineComment(String declineComment) {
		this.declineComment = declineComment;
	}
}
