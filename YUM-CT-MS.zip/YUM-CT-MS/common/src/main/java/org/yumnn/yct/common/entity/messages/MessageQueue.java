/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.messages.MessageQueueActionTypeEnum;

/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name MessageQueue.java
 * @create_date Apr 23, 2019
 * @last_Update Apr 23, 2019
 */
@Entity
@Table(name = "messages.tra_message_queue")
public class MessageQueue extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "message_content_to_send")
	private String messageTextToSend ;
	
	@ManyToOne
	@JoinColumn(name = "id_message_content_fk")
	private MessageContent messageContent;
	
	@Column(name= "email_address")
	private String emailAddress;
	
	@Column(name= "cc_email_address")
	private String ccEmailAddress;
	
	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn ;

	@Column(name= "message_reference_id")
	private Long messageReferenceId;
	
	@Column(name= "message_reference_type")
	private String messageReferenceType;
	
	@Column(name = "action_type")
	@Enumerated(EnumType.STRING)
	private MessageQueueActionTypeEnum actionType;
	
	
	public MessageQueue() {
		super();
		this.createdOn = new Date();
	}
	
	/**
	 * @return the messageContent
	 */
	public MessageContent getMessageContent() {
		return messageContent;
	}

	/**
	 * @param messageContent the messageContent to set
	 */
	public void setMessageContent(MessageContent messageContent) {
		this.messageContent = messageContent;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getMessageTextToSend() {
		return messageTextToSend;
	}
	
	public void setMessageTextToSend(String messageTextToSend) {
		this.messageTextToSend = messageTextToSend;
	}

	/**
	 * @return the messageReferenceId
	 */
	public Long getMessageReferenceId() {
		return messageReferenceId;
	}

	/**
	 * @param messageReferenceId the messageReferenceId to set
	 */
	public void setMessageReferenceId(Long messageReferenceId) {
		this.messageReferenceId = messageReferenceId;
	}

	/**
	 * @return the messageReferenceType
	 */
	public String getMessageReferenceType() {
		return messageReferenceType;
	}

	/**
	 * @param messageReferenceType the messageReferenceType to set
	 */
	public void setMessageReferenceType(String messageReferenceType) {
		this.messageReferenceType = messageReferenceType;
	}

	/**
	 * @return the actionType
	 */
	public MessageQueueActionTypeEnum getActionType() {
		return actionType;
	}

	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(MessageQueueActionTypeEnum actionType) {
		this.actionType = actionType;
	}

	public String getCcEmailAddress() {
		return ccEmailAddress;
	}

	public void setCcEmailAddress(String ccEmailAddress) {
		this.ccEmailAddress = ccEmailAddress;
	}
	
}
