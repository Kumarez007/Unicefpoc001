package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.CatalogParentEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "user_access.cat_geolocation")
@NamedQueries({
		@NamedQuery(
			name = "Geolocation.findRootGeolocations",
			query = "SELECT g FROM Geolocation g WHERE g.geolocationParent IS NULL order by g.id"),
		@NamedQuery(
			name = "Geolocation.findAllByGeolocationParent",
			query = "SELECT g FROM Geolocation g WHERE g.geolocationParent = :geolocationParent order by g.id"),
		@NamedQuery(
				name = "Geolocation.findAllByGeolocationParentByName",
				query = "SELECT g FROM Geolocation g WHERE g.geolocationParent = :geolocationParent order by g.name"),
		@NamedQuery(name = "Geolocation.findByCode", query = "SELECT g FROM Geolocation g WHERE g.code = :code"),
		@NamedQuery(name = "Geolocation.findByName", query = "SELECT g FROM Geolocation g WHERE g.name = :name"),
		@NamedQuery(
			name = "Geolocation.findCountByGeolocationParent",
			query = "SELECT count(g) FROM Geolocation g WHERE g.geolocationParent = :geolocationParent"),
		@NamedQuery(
			name = "Geolocation.findAllRelatedToGeolocationType",
			query = "SELECT g FROM Geolocation g WHERE g.geolocationType = :geolocationType ORDER BY g.id "), 
		@NamedQuery(
				name = "Geolocation.retrieveByParents",
				query = "SELECT g FROM Geolocation g WHERE g.geolocationParent.id in (:parents) order by g.id"),
		
		@NamedQuery(
				name = "Geolocation.Geolocation",
				query = "SELECT g.id FROM Geolocation g WHERE g.code = :code")

	})
public class Geolocation extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	@JoinColumn(name = "id_geolocation_type_fk")
	private GeolocationType geolocationType;

	@ManyToOne(fetch = FetchType.EAGER)
    @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	@JoinColumn(name = "id_geolocation_parent_fk")
	private Geolocation geolocationParent;

	@Column(name = "code")
	private String code;

	@Column(name = "latitude", precision = 9, scale = 6)
	private BigDecimal latitude;

	@Column(name = "longitude", precision = 9, scale = 6)
	private BigDecimal longitude;

	@Column(name = "security_level")
	private String securityLevel;

	@Column(name = "is_active")
	private String isActive;

	@Transient
	private String geolocationParentsEnNames;
	
	@Transient
	private String geolocationParentsArNames;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = true)
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_updated_by_fk", nullable = true)
	private User updatedBy;

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Geolocation() {
		super();
	}

	public Geolocation(Long id) {
		super();
		this.id = id;
	}

	public Geolocation(Long id, String code) {
		super();
		this.id = id;
		this.code = code;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	public GeolocationType getGeolocationType() {
		return geolocationType;
	}

	public void setGeolocationType(GeolocationType geolocationType) {
		this.geolocationType = geolocationType;
	}

	public Geolocation getGeolocationParent() {
		return geolocationParent;
	}

	public void setGeolocationParent(Geolocation geolocationParent) {
		this.geolocationParent = geolocationParent;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Geolocation other = (Geolocation) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public String getGeolocationParentsEnNames() {
		generateGeolocationParentEnNames();
		return geolocationParentsEnNames;
	}
	
	public String getGeolocationParentsArNames() {
		generateGeolocationParentArNames();
		return geolocationParentsArNames;
	}

	/**
	 * @author Christian Alvarez
	 * @date Dec 2, 2014
	 * @description_method
	 */
	private void generateGeolocationParentEnNames() {
		List<String> names = new ArrayList<String>();
		geolocationParentsEnNames = "";
		if (geolocationParent != null) {
			geolocationParentsEnNames = getParentEnNames(geolocationParent, names);
		}
	}

	private void generateGeolocationParentArNames() {
		List<String> names = new ArrayList<String>();
		geolocationParentsArNames = "";
		if (geolocationParent != null) {
			geolocationParentsArNames = getParentArNames(geolocationParent, names);
		}
	}
	
	/**
	 * @author Christian Alvarez
	 * @date Sep 25, 2014
	 * @description_method
	 * @param systemFunctionality
	 */
	private String getParentEnNames(Geolocation geolocationParent, List<String> names) {
		if (geolocationParent.getEnglishName() != null) {
			names.add(geolocationParent.getEnglishName() + " - ");
		}
		if (geolocationParent.getGeolocationParent() != null) {
			getParentEnNames(geolocationParent.getGeolocationParent(), names);
		}
		return buildParentsNameString(names);
	}
	
	private String getParentArNames(Geolocation geolocationParent, List<String> names) {
		if (geolocationParent.getArabicName() != null) {
			names.add(geolocationParent.getArabicName() + " - ");
		}
		if (geolocationParent.getGeolocationParent() != null) {
			getParentArNames(geolocationParent.getGeolocationParent(), names);
		}
		return buildParentsNameString(names);
	}

	/**
	 * @author Christian Alvarez
	 * @date Sep 25, 2014
	 * @description_method
	 * @param names
	 */
	private String buildParentsNameString(List<String> names) {
		int listSize = names.size() - 1;
		String namesBuilt = "";
		for (int i = listSize; i >= 0; i--) {
			namesBuilt += names.get(i);
		}
		return namesBuilt;
	}

	public BigDecimal getLatitude() {
		return latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		return getEnglishName();
	}

	public String getSecurityLevel() {
		return securityLevel;
	}

	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}

	public void setGeolocationParentsEnNames(String geolocationParentsEnNames) {
		this.geolocationParentsEnNames = geolocationParentsEnNames;
	}

	public void setGeolocationParentsArNames(String geolocationParentsArNames) {
		this.geolocationParentsArNames = geolocationParentsArNames;
	}
	
	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Integer getCheckParent(){
		Integer count = 0;
		if(getGeolocationParent() != null){
			count = 1;
			if(getGeolocationParent().getGeolocationParent() != null){
				count = 2;
				if(getGeolocationParent().getGeolocationParent().getGeolocationParent() != null){
					count = 3;
				}
			}
		}
		return count;
	}

}
