package org.yumnn.yct.common.entity.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name CatalogParentEntity.java
 * @class_description contains the attributes that all catalogs must have
 * @create_date Oct 13, 2016
 * @last_Update Oct 13, 2016
 */
@MappedSuperclass
public abstract class CatalogParentEntity extends BaseEntity {


	private static final long serialVersionUID = 1L;

	@Column(name = "name")
	protected String name;

	@Column(name = "short_name", unique = true)
	protected String shortName;
	
	@Column(name = "en_name",nullable = false)
	private String englishName;
	
	@Column(name = "ar_name",nullable = false)
	private String arabicName;
	
	@Column(name = "order_item")
	private Integer orderItem;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	@Override
	public String toString() {
		return this.name;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public Integer getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Integer orderItem) {
		this.orderItem = orderItem;
	}
}
