package org.yumnn.yct.common.model;

import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {UserByRoleModel.java
 * @create_date May 27, 2021
 * @last_Update May 27, 2021
 */
public class UserByRoleModel {

	private Long userId;

	private Long roleId;

	private String recipientType;
	
	private String emailId;
	
	private YesNoEnum isActive;
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRecipientType() {
		return recipientType;
	}

	public void setRecipientType(String recipientType) {
		this.recipientType = recipientType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public YesNoEnum getIsActive() {
		return isActive;
	}

	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
	
	
	
}
