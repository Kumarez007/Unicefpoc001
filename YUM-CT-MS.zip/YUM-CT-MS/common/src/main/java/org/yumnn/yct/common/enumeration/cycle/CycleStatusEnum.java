package org.yumnn.yct.common.enumeration.cycle;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name CycleStatusEnum.java
 * @class_description represents the different status of cycle in the system
 * @create_date Jun 22, 2017
 * @last_Update Jun 22, 2017
 */
public enum CycleStatusEnum {

	/*
	 * PENDING_TO_COPY_HOUSEHOLDS("Pending to copy beneficiaries"),
	 * COPYING_HOUSEHOLDS("Copying households"),
	 * PENDING_TO_GENERATE_HOUSEHOLD_AMOUNT("Pending to generate beneficiary amount"
	 * ), GENERATING_HOUSEHOLD_AMOUNT("Generating beneficiary amount"),
	 * PENDING_TO_CLOSE_UNPAID_HOUSEHOLDS("Pending to close unpaid beneficiaries"),
	CLOSING_UNPAID_HOUSEHOLDS("Closing unpaid beneficiaries"),

	ERROR("Error"),
	ANNULLED("Annulled")
	 */
	CLOSED("Closed"),
	ACTIVE("Active");
	

	private String valueToShow;

	private CycleStatusEnum(String valueToShow) {
		this.valueToShow = valueToShow;
	}

	public static Boolean canCloseCycle(CycleStatusEnum cycleStatus) {
		return cycleStatus.equals(ACTIVE);
	}
	
	public static Boolean canOpenCycle(CycleStatusEnum cycleStatus) {
		return cycleStatus.equals(CLOSED);
	}

	public static List<CycleStatusEnum> getActiveStatuses() {
		List<CycleStatusEnum> list = new ArrayList<>();
		list.add(ACTIVE);
		return list;
		/*
		 * list.add(PENDING_TO_COPY_HOUSEHOLDS); list.add(COPYING_HOUSEHOLDS);
		 * list.add(PENDING_TO_GENERATE_HOUSEHOLD_AMOUNT);
		 * list.add(GENERATING_HOUSEHOLD_AMOUNT);
		 */

	}

	public String getValueToShow() {
		return valueToShow;
	}
}
