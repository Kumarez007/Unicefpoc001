package org.yumnn.yct.common.util;

public enum SourceTypeEnum {
  ENROLLMENT("enrolllment"),ADMISSION("admission"), MEDICAL_CHECKUP("medical checkup"), VALIDATION(
      "validation"), VALIDATION_UPLOAD_DISCHARGE_CARD(
          "validation-upload discharge card"), PERIODIC_CHECKUP(
              "periodic checkup"), UPDATED("updated"), ISSUE_ADDITIONAL_BOOKLET("issue booklet");

  private String enumValue;

  /**
   * @param enumValue
   */
  private SourceTypeEnum(String enumValue) {
    this.enumValue = enumValue;
  }

  /**
   * @return the enumValue
   */
  public String getEnumValue() {
    return enumValue;
  }

  /**
   * @param enumValue the enumValue to set
   */
  public void setEnumValue(String enumValue) {
    this.enumValue = enumValue;
  }
}
