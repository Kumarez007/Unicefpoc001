package org.yumnn.yct.common.repository;

import java.util.List;

import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.util.GeolocationUtil;

public interface CustomizedGeolocationRepository {
	
	public GeolocationUtil geolocationDetails(Long geolocationId);
	
	public GeolocationUtil getGeolocationDetailsByCode(String code);
	
	public List<Geolocation> retrieveByParents(Long[] parents);


	
}
