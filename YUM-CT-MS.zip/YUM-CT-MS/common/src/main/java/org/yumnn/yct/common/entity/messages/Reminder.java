package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name Reminder.java
 * @create_date Nov 29, 2021
 * @last_Update Nov 29, 2021
 */
@Entity
@Table(name = "messages.stp_reminder")
@NamedQueries({
		@NamedQuery(name = "Reminder.retrieveAllActive", query = "SELECT r from Reminder r where  r.isActive = 'Yes' order by r.creationDate "), })
public class Reminder extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_message_content_fk", referencedColumnName = "ID")
	private MessageContent messageContent;

	@Column(name = "query")
	private String query;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "creation_date")
	private Date creationDate;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;

	/**
	 * @return the messageContent
	 */
	public MessageContent getMessageContent() {
		return messageContent;
	}

	/**
	 * @param messageContent the messageContent to set
	 */
	public void setMessageContent(MessageContent messageContent) {
		this.messageContent = messageContent;
	}

	/**
	 * @return the query
	 */
	public String getQuery() {
		return query;
	}

	/**
	 * @param query the query to set
	 */
	public void setQuery(String query) {
		this.query = query;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
	
}
