/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.model.payment;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.yumnn.yct.common.enumeration.payment.RegionEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSiteTypeEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSitesConnectionTypeEnum;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;
import org.yumnn.yct.common.util.Constants;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Reem Issa
 * @department PMU
 * @owner UNICEF.
 * @class_name PaymentSiteObject.java
 * @class_description utility class to map json string to java object
 * @create_date Feb 26, 2019
 * @last_Update Feb 26, 2019
 */
public class PaymentSiteObject implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull
	@JsonProperty("name")
	private String name;
	
	@NotNull
	@JsonProperty("siteCode")
	private String siteCode;
	
	@NotNull
	@JsonProperty("paymentAgencyId")
	private String paymentAgencyId;
	
	@NotNull
	@JsonProperty("ozlaCode")
	private String ozlaCode;
	
	@NotNull
	@JsonProperty("initialDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_FORMAT_yyyyMMdd, timezone = Constants.SERVER_TIME_ZONE)
	private Date initialDate;
	
	@NotNull
	@JsonProperty("endingDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_FORMAT_yyyyMMdd, timezone = Constants.SERVER_TIME_ZONE)
	private Date endingDate;
	
	@NotNull
	@JsonProperty("expectedNoOfBeneficiaries")
	private Integer expectedNoOfBeneficiaries;
	
	@NotNull
	@JsonProperty("gpsLatitude")
	private Double gpsLatitude;
	
	@NotNull
	@JsonProperty("gpsLongitude")
	private Double gpsLongitude;
	
	@NotNull
	@JsonProperty("type")
	private PaymentSiteTypeEnum type;
	
	@NotNull
	@JsonProperty("connectionType")
	private PaymentSitesConnectionTypeEnum connectionType;
	
	@NotNull
	@JsonProperty("paymentAgent")
	private String paymentAgentName;
	
	@NotNull
	@JsonProperty("paymentSiteAddress")
	private String paymentSiteAddress;
	
	@NotNull
	@JsonProperty("fixedSiteType")
	private String fixedSiteType;
	
	@NotNull
	@JsonProperty("workingDays")
	private Integer numberOfWorkingDays;
	
	@NotNull
	@JsonProperty("numberDailyPayments")
	private Integer numberOfDailyPayments;

	@NotNull
	@JsonProperty("staffingMalesCashiers")
	private Integer staffingMalesCashiers;
	
	@NotNull
	@JsonProperty("staffingFemalesCashiers")
	private Integer staffingFemalesCashiers;
	
	@NotNull
	@JsonProperty("staffingMalesScreening")
	private Integer staffingMalesScreening;
	
	@NotNull
	@JsonProperty("staffingFemalesScreening")
	private Integer staffingFemalesScreening;
	
	@NotNull
	@JsonProperty("siteStatus")
	private String siteStatus;
	
	@JsonProperty("projectName")
	private ProjectNameEnum projectName;
	
	@NotNull
	@JsonProperty("regionPaymentSite")
	private RegionEnum paymentSiteRegion;
	


	public PaymentSiteObject(String name, String siteCode, String paymentAgencyId, String ozlaCode, Date initialDate,
			Date endingDate, Integer expectedNoOfBeneficiaries, Double gpsLatitude, Double gpsLongitude, PaymentSiteTypeEnum type,
			PaymentSitesConnectionTypeEnum connectionType, String paymentAgentName, String paymentSiteAddress,
			String fixedSiteType, Integer numberOfWorkingDays, Integer numberOfDailyPayments,
			Integer staffingMalesCashiers, Integer staffingFemalesCashiers, Integer staffingMalesScreening,
			Integer staffingFemalesScreening, String siteStatus) {
		super();
		this.name = name;
		this.siteCode = siteCode;
		this.paymentAgencyId = paymentAgencyId;
		this.ozlaCode = ozlaCode;
		this.initialDate = initialDate;
		this.endingDate = endingDate;
		this.expectedNoOfBeneficiaries = expectedNoOfBeneficiaries;
		this.gpsLatitude = gpsLatitude;
		this.gpsLongitude = gpsLongitude;
		this.type = type;
		this.connectionType = connectionType;
		this.paymentAgentName = paymentAgentName;
		this.paymentSiteAddress = paymentSiteAddress;
		this.fixedSiteType = fixedSiteType;
		this.numberOfWorkingDays = numberOfWorkingDays;
		this.numberOfDailyPayments = numberOfDailyPayments;
		this.staffingMalesCashiers = staffingMalesCashiers;
		this.staffingFemalesCashiers = staffingFemalesCashiers;
		this.staffingMalesScreening = staffingMalesScreening;
		this.staffingFemalesScreening = staffingFemalesScreening;
		this.siteStatus= siteStatus;
	}

	public PaymentSiteObject() {
		// no implementatio needed.
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the siteCode
	 */
	public String getSiteCode() {
		return siteCode;
	}

	/**
	 * @param siteCode the siteCode to set
	 */
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	/**
	 * @return the paymentAgencyId
	 */
	public String getPaymentAgencyId() {
		return paymentAgencyId;
	}

	/**
	 * @param paymentAgencyId the paymentAgencyId to set
	 */
	public void setPaymentAgencyId(String paymentAgencyId) {
		this.paymentAgencyId = paymentAgencyId;
	}

	/**
	 * @return the ozlCode
	 */
	public String getOzlaCode() {
		return ozlaCode;
	}

	/**
	 * @param ozlCode the ozlCode to set
	 */
	public void setOzlaCode(String ozlaCode) {
		this.ozlaCode = ozlaCode;
	}

	/**
	 * @return the initialDate
	 */
	public Date getInitialDate() {
		return initialDate;
	}

	/**
	 * @param initialDate the initialDate to set
	 */
	public void setInitialDate(Date initialDate) {
		this.initialDate = initialDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the expectedNoOfBeneficiaries
	 */
	public Integer getExpectedNoOfBeneficiaries() {
		return expectedNoOfBeneficiaries;
	}

	/**
	 * @param expectedNoOfBeneficiaries the expectedNoOfBeneficiaries to set
	 */
	public void setExpectedNoOfBeneficiaries(Integer expectedNoOfBeneficiaries) {
		this.expectedNoOfBeneficiaries = expectedNoOfBeneficiaries;
	}

	/**
	 * @return the gpsLatitude
	 */
	public Double getGpsLatitude() {
		return gpsLatitude;
	}

	/**
	 * @param gpsLatitude the gpsLatitude to set
	 */
	public void setGpsLatitude(Double gpsLatitude) {
		this.gpsLatitude = gpsLatitude;
	}

	/**
	 * @return the gpsLongitude
	 */
	public Double getGpsLongitude() {
		return gpsLongitude;
	}

	/**
	 * @param gpsLongitude the gpsLongitude to set
	 */
	public void setGpsLongitude(Double gpsLongitude) {
		this.gpsLongitude = gpsLongitude;
	}

	/**
	 * @return the type
	 */
	public PaymentSiteTypeEnum getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(PaymentSiteTypeEnum type) {
		this.type = type;
	}

	/**
	 * @return the connectionType
	 */
	public PaymentSitesConnectionTypeEnum getConnectionType() {
		return connectionType;
	}

	/**
	 * @param connectionType the connectionType to set
	 */
	public void setConnectionType(PaymentSitesConnectionTypeEnum connectionType) {
		this.connectionType = connectionType;
	}

	/**
	 * @return the paymentAgentName
	 */
	public String getPaymentAgentName() {
		return paymentAgentName;
	}

	/**
	 * @param paymentAgentName the paymentAgentName to set
	 */
	public void setPaymentAgentName(String paymentAgentName) {
		this.paymentAgentName = paymentAgentName;
	}

	/**
	 * @return the paymentSiteAddress
	 */
	public String getPaymentSiteAddress() {
		return paymentSiteAddress;
	}

	/**
	 * @param paymentSiteAddress the paymentSiteAddress to set
	 */
	public void setPaymentSiteAddress(String paymentSiteAddress) {
		this.paymentSiteAddress = paymentSiteAddress;
	}

	/**
	 * @return the fixedSiteType
	 */
	public String getFixedSiteType() {
		return fixedSiteType;
	}

	/**
	 * @param fixedSiteType the fixedSiteType to set
	 */
	public void setFixedSiteType(String fixedSiteType) {
		this.fixedSiteType = fixedSiteType;
	}

	/**
	 * @return the numberOfWorkingDays
	 */
	public Integer getNumberOfWorkingDays() {
		return numberOfWorkingDays;
	}

	/**
	 * @param numberOfWorkingDays the numberOfWorkingDays to set
	 */
	public void setNumberOfWorkingDays(Integer numberOfWorkingDays) {
		this.numberOfWorkingDays = numberOfWorkingDays;
	}

	/**
	 * @return the numberOfDailyPayments
	 */
	public Integer getNumberOfDailyPayments() {
		return numberOfDailyPayments;
	}

	/**
	 * @param numberOfDailyPayments the numberOfDailyPayments to set
	 */
	public void setNumberOfDailyPayments(Integer numberOfDailyPayments) {
		this.numberOfDailyPayments = numberOfDailyPayments;
	}

	/**
	 * @return the staffingMalesCashiers
	 */
	public Integer getStaffingMalesCashiers() {
		return staffingMalesCashiers;
	}

	/**
	 * @param staffingMalesCashiers the staffingMalesCashiers to set
	 */
	public void setStaffingMalesCashiers(Integer staffingMalesCashiers) {
		this.staffingMalesCashiers = staffingMalesCashiers;
	}

	/**
	 * @return the staffingFemalesCashiers
	 */
	public Integer getStaffingFemalesCashiers() {
		return staffingFemalesCashiers;
	}

	/**
	 * @param staffingFemalesCashiers the staffingFemalesCashiers to set
	 */
	public void setStaffingFemalesCashiers(Integer staffingFemalesCashiers) {
		this.staffingFemalesCashiers = staffingFemalesCashiers;
	}

	/**
	 * @return the staffingMalesScreening
	 */
	public Integer getStaffingMalesScreening() {
		return staffingMalesScreening;
	}

	/**
	 * @param staffingMalesScreening the staffingMalesScreening to set
	 */
	public void setStaffingMalesScreening(Integer staffingMalesScreening) {
		this.staffingMalesScreening = staffingMalesScreening;
	}

	/**
	 * @return the staffingFemalesScreening
	 */
	public Integer getStaffingFemalesScreening() {
		return staffingFemalesScreening;
	}

	/**
	 * @param staffingFemalesScreening the staffingFemalesScreening to set
	 */
	public void setStaffingFemalesScreening(Integer staffingFemalesScreening) {
		this.staffingFemalesScreening = staffingFemalesScreening;
	}

	/**
	 * @return the siteStatus
	 */
	public String getSiteStatus() {
		return siteStatus;
	}

	/**
	 * @param siteStatus the siteStatus to set
	 */
	public void setSiteStatus(String siteStatus) {
		this.siteStatus = siteStatus;
	}

	/**
	 * @return the projectName
	 */
	public ProjectNameEnum getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(ProjectNameEnum projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the paymentSiteRegion
	 */
	public RegionEnum getPaymentSiteRegion() {
		return paymentSiteRegion;
	}

	/**
	 * @param paymentSiteRegion the paymentSiteRegion to set
	 */
	public void setPaymentSiteRegion(RegionEnum paymentSiteRegion) {
		this.paymentSiteRegion = paymentSiteRegion;
	}
}
