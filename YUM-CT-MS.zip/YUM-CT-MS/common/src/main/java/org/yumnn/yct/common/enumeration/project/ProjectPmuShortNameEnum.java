package org.yumnn.yct.common.enumeration.project;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name ProjectPmuShortNameEnum.java
 * @create_date Jan 31, 2022
 * @last_Update Jan 31, 2022
 */
public enum ProjectPmuShortNameEnum {

	hct("HCT"), sgp("SGP"), nvs("NVS"), tti("TTI"), eti("ETI"), rft("RFT"), ehn_unicef("health_nutrition"), wash("wash"), 
	ehn_who("who"), health_worker("health_worker"), hai("hazard_allowance"), hwp("health_per_diem"), health_facility("health_facility"), ehn("EHN"),
	EMS("EMS");
	
	
	String shortName;

	ProjectPmuShortNameEnum(String shortName) {
		this.shortName = shortName;
	}

	/**
	 * @return the shortName
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * @param shortName the shortName to set
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
}
