/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.messages.MessageStatusEnum;

/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name MessageQueueStatus.java
 * @create_date Apr 23, 2019
 * @last_Update Apr 23, 2019
 */
@Entity
@Table(name = "messages.tra_message_queue_status")
@NamedQueries({
	@NamedQuery(name = "MessageQueueStatus.findByPendingStatusAndNullEndingDate", 
			query = "SELECT m from MessageQueueStatus m where m.status= 'PENDING' AND m.endingnDate is null"),
	@NamedQuery(name = "MessageQueueStatus.findActiveByMessageQueue", 
	query = "SELECT m from MessageQueueStatus m where m.messageQueue= :messageQueue AND m.endingnDate is null"),
	@NamedQuery(name = "MessageQueueStatus.retrieveByCreationDateAndActionTypeAndRefId", 
	query = "SELECT m.messageQueue from MessageQueueStatus m where  m.creationDate = :creationDate AND m.endingnDate is null and m.messageQueue.actionType =:actionType and m.messageQueue.messageReferenceId = :refId"),

})
public class MessageQueueStatus extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name = "id_message_queue_fk")
	private MessageQueue messageQueue;
	
	@Column(name = "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate ;
	
	@Column(name = "ending_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endingnDate ;
	
	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private MessageStatusEnum status;

	/**
	 * @return the messageQueue
	 */
	public MessageQueue getMessageQueue() {
		return messageQueue;
	}

	/**
	 * @param messageQueue the messageQueue to set
	 */
	public void setMessageQueue(MessageQueue messageQueue) {
		this.messageQueue = messageQueue;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the endingnDate
	 */
	public Date getEndingnDate() {
		return endingnDate;
	}

	/**
	 * @param endingnDate the endingnDate to set
	 */
	public void setEndingnDate(Date endingnDate) {
		this.endingnDate = endingnDate;
	}

	/**
	 * @return the status
	 */
	public MessageStatusEnum getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(MessageStatusEnum status) {
		this.status = status;
	}
}
