package org.yumnn.yct.common.enumeration.project;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum ProjectNameEnum {

    YCT("Yummen cash Transfer Project"),
    ECT("ECT"),
    EDU("EDU"),
    TTI("TTI"),
    ETI("ETI"),
    RFT("RFT"),
    HN("Health Project"),
    HCT("HCT"),
    NVS("NVS"),
    SGP("SGP"),
    health_nutrition("health_nutrition"),
    wash_payment("wash_payment"),
    who("who"),
    health_per_diem("health_per_diem"),
    hazard_allowance("hazard_allowance"),
    health_facility("health_facility"),
    health_worker("health_worker"),
    CHNV("CHNV"),
    EMS("EMS"),
    PBG("PBG"),
	IDP("IDP"),
	UCT_CP("UCT_CP"),
	CFM("CFM"),
	REAL_SCHOOLS("REAL_SCHOOLS"),
	REAL_TEACHERS("REAL_TEACHERS");

	
    private String value;

    ProjectNameEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    
    @JsonCreator
    public static ProjectNameEnum setValue(String key) {
        return Arrays.stream(ProjectNameEnum.values())
            .filter(exampleEnum -> exampleEnum.toString().equals(key.toUpperCase()))
            .findAny()
            .orElse(null);
    }

}