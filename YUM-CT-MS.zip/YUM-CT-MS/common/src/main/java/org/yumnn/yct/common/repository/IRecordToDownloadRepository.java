package org.yumnn.yct.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.uploadInfo.RecordToDownload;
import org.yumnn.yct.common.enumeration.quartz.UploadedRecordTypeEnum;
import org.yumnn.yct.common.exception.FailProcessException;
import org.yumnn.yct.common.exception.FailProcessWithoutRollbackException;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {IRecordToDownloadRepository.java
 * @create_date May 26, 2021
 * @last_Update May 26, 2021
 */
@Repository
public interface IRecordToDownloadRepository extends JpaRepository<RecordToDownload, Long> {

	@Query(value = "select * from gen_record_to_download  to_download\\n\" + \"where to_download.record_type = '%s'\\n\"\n"
			+ "				+ \"and to_download.id > coalesce((select downloaded.id_record_to_download_fk \"\n"
			+ "				+ \"from gen_downloaded_record_by_user downloaded where downloaded.id_user_fk = %s ) , 0) limit 1 ", nativeQuery = true)
	public RecordToDownload retrievePendingRecord(User user, UploadedRecordTypeEnum recordType)
			throws FailProcessWithoutRollbackException, FailProcessException;

}