package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public enum TypeOfServiceEnum {
  DELIVERY_SERVICE(1), COMPLICATIONS_SERVICE(2), POST_NATAL_SERVICE(3);

  private final Integer enumValue;

  /**
   * @param enumValue
   * 
   */
  private TypeOfServiceEnum(Integer enumValue) {
    this.enumValue = enumValue;
  }

  /**
   * @return enumValue
   */
  public Integer getEnumValue() {
    return enumValue;
  }
}
