package org.yumnn.yct.common.util;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.role.RuleEnum;
import org.yumnn.yct.common.exception.FailProcessException;


public class Utilities implements Serializable {

	private static final long serialVersionUID = 1L;
	public static Logger LOG = LoggerFactory.getLogger(Utilities.class.getName());

	public static boolean isNULL(Object object) {
		return object == null;
	}

	public static boolean isNULLOrEmpty(String text) {
		return isNULL(text) || (!isNULL(text) && text.trim().isEmpty());
	}

	public static double getRandom() {
		Random random = new Random();
		return random.nextDouble();
	}

	public static String toUpperCase(String message) {
		return message.toUpperCase();
	}

	public static String getDateWithFormatyyyyMMdd() {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_yyyyMMdd);
		return DATE_FORMAT.format(new Date());
	}

	public static String getDateWithFormatyyyyMMddhhmm() {
		DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT_ddMMyyyy_hhmm);
		String reportDate = df.format(Calendar.getInstance().getTime());
		return reportDate;
	}

	public static String getDateWithFormat() {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT);
		return DATE_FORMAT.format(new Date());
	}

	public static String getDateWithFormatOnlyNumbers() {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_ONLY_NUMBERS);
		return DATE_FORMAT.format(new Date());
	}

	public static String getDateWithFormat(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT);
		return DATE_FORMAT.format(date);
	}

	public static String getDateWithFormatWithMiliSecond() {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_FOR_REPORTS_WITH_MILISICOND);
		return DATE_FORMAT.format(new Date());
	}

	public static String getDateFormatWithMonthName() {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_WITH_MONTH_NAME);
		return DATE_FORMAT.format(new Date());
	}

	public static String getDateFormatWithMonthDayYearHoursMinutes(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_MMddyyyy_hhmm);
		return DATE_FORMAT.format(date);
	}

	public static String getDateFormatWithMonthDayYearHoursMinutesSeconds(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_MMddyyyy_hhmmss);
		return DATE_FORMAT.format(date);
	}

	public static String getDateFormatWithYYYYMMDDWithSlash(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD_WITH_SLASH);
		return DATE_FORMAT.format(date);
	}
	
	public static String getDateFormatWithDDMMYYYYWithSlash(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_DDMMYYYY_WITH_SLASH);
		return DATE_FORMAT.format(date);
	}

	public static String getDateFormatWithYearMonthDayHoursMinutesSeconds(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.DATE_FORMAT_yyyyMMddHHmmss);
		return DATE_FORMAT.format(date);
	}

	public static String getTimeFormatWithHoursMinutes(Date date) {
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(Constants.TIME_FORMAT_HH_mm);
		return DATE_FORMAT.format(date);
	}

	public static String convertTimeWithZoneToFormattedDate(String timeWithZone) throws ParseException {
		if (isNULLOrEmpty(timeWithZone)) {
			return Constants.EMPTY;
		}
		DateFormat formatter = new SimpleDateFormat(Constants.DATE_FORMAT_HIDDEN_INPUT);
		Date date = formatter.parse(timeWithZone);
		return getDateWithFormat(date);
	}

	public static String convertTimeWithZoneToFormattedTime(String timeWithZone) throws ParseException {
		if (isNULLOrEmpty(timeWithZone)) {
			return Constants.EMPTY;
		}
		DateFormat formatter = new SimpleDateFormat(Constants.DATE_FORMAT_HIDDEN_INPUT);
		Date date = formatter.parse(timeWithZone);
		return getTimeFormatWithHoursMinutes(date);
	}

	public static Boolean isInteger(Object object) {
		if (Utilities.isNULL(object)) {
			return Boolean.FALSE;
		} else {
			try {
				Integer.valueOf(object.toString());
				return Boolean.TRUE;
			} catch (NumberFormatException e) {
				return Boolean.FALSE;
			}
		}
	}

	public static Integer convertStringToIntegerWithNullValueControl(String value) {
		if (isNULL(value)) {
			return null;
		} else {
			if (isInteger(value)) {
				return Integer.valueOf(value);
			} else {
				return null;
			}
		}
	}

	public static String convertIntegerToStringWithNullValueControl(Integer value) {
		if (isNULL(value)) {
			return null;
		} else {
			return value.toString();
		}
	}

	public static String convertStacktraceErrorToString(Exception e) {
		return StringUtils.join(ExceptionUtils.getRootCauseStackTrace(e), "\n");
	}

	public static String convertStacktraceErrorToString(Throwable e) {
		return StringUtils.join(ExceptionUtils.getRootCauseStackTrace(e), "\n");
	}

	public static Date convertStringToDateWithCustomFormat(String dateAsString, String format) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.parse(dateAsString);
	}

	public static String implode(String glue, List<?> stringArray) {
		String ret = "";
		if (stringArray != null) {
			for (int i = 0; i < stringArray.size(); i++) {
				ret += i == stringArray.size() - 1 ? stringArray.get(i) : stringArray.get(i) + glue;
			}
		}
		return ret;
	}

	public static String implodeAsString(String glue, List<?> stringArray) {
		String ret = "";
		if (stringArray != null) {
			for (int i = 0; i < stringArray.size(); i++) {
				String value = Constants.APOSTROPHE + stringArray.get(i) + Constants.APOSTROPHE;
				ret += i == stringArray.size() - 1 ? value : value + glue;
			}
		}
		return ret;
	}

	@SuppressWarnings("rawtypes")
	public static Boolean hasSameKeys(Map mapOne, Map mapTwo) {

		if (mapOne.size() != mapTwo.size()) {
			return Boolean.FALSE;
		}

		// true when the keys are different
		@SuppressWarnings("unchecked")
		Boolean thereAreChanges = mapOne.keySet().retainAll(mapTwo.keySet());

		return !thereAreChanges;
	}

	public static boolean isNotNullAndNotEmpty(String value) {
		return value != null && !value.trim().isEmpty();
	}

	public static String retrieveTableNameFromEntityClass(Class<?> entityClass) throws FailProcessException {
		try {
			Class<?> c = entityClass;
			Table table = c.getAnnotation(Table.class);
			String tableName = table.name();
			LOG.info("... retrieveTableNameFromEntityClass " + c.getName() + " tableName " + tableName);
			return tableName;
		} catch (Exception e) {
			LOG.error("... retrieveTableNameFromEntityClass " + Utilities.convertStacktraceErrorToString(e));
			throw new FailProcessException(e);
		}
	}
	
	public static YesNoEnum getValueByInteger(Integer number) {
		if(Utilities.isNULL(number)) {
			return YesNoEnum.NO;
		}
		return number.equals(1) ? YesNoEnum.YES : YesNoEnum.NO;
	}
	
	/**
	 * 
	 * @author Reem Issa
	 * @date Jul 2, 2019
	 * @description_method
	 * @return
	 */
	public static Date getCurrentDate() {
		
		LocalDate currentDate = LocalDate.now();
		LocalTime timeToSendMessage = LocalTime.now();
		LocalDateTime dateTime = LocalDateTime.of(currentDate, timeToSendMessage);
				
		return Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
	}
	
	
	public static String getCurrentDateWithoutTimestamp() {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.DATE_FORMAT_ONLY_NUMBERS_FOR_VIEW);
	
		
		return LocalDate.now().format(formatter);
	}
	/**
	 * 
	 * @author Reem Issa
	 * @date Jul 11, 2019
	 * @description_method
	 * @param object
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	public static boolean validateNegativeValues(Object object)
			throws IllegalArgumentException, IllegalAccessException {
		
		for (Field field : object.getClass().getDeclaredFields()) {
			field.setAccessible(true);
			if (field.getType().equals(Long.class)
					&& ((Long) field.get(object) < 0)) {
				return false;
			}
			if (field.getType().equals(Integer.class)
					&& ((Integer) field.get(object) < 0)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @author Reem Issa
	 * @date Aug 1, 2019
	 * @description_method
	 * @param email
	 * @return
	 */
	public static boolean isValidEmailAddress(String email) {
		
		boolean result = true;
		try {
			InternetAddress emailAddr = new InternetAddress(email);
			emailAddr.validate();
		} catch (AddressException ex) {
			result = false;
		}
		return result;
	}
	/**
	 * 
	 * @author WQ
	 * @date Apr 30, 2020
	 * @description_method 
	 * @param cellphoneTelephone
	 * @return
	 */
	public static Boolean isCellphoneNumberValid(String cellphoneTelephone) {
		if (Utilities.isNULLOrEmpty(cellphoneTelephone)) {
			return Boolean.TRUE;
		}

		if (cellphoneTelephone.length() != 9 || !cellphoneTelephone.startsWith("7")) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;

	}
	/**
	 * 
	* @author WQ
	* @date Sep 30, 2020
	* @description_method 
	* @param fileName
	* @return
	 */
	public static String getFileExtension(String fileName) {
		int lastIndexOf = fileName.lastIndexOf(".");
		if (lastIndexOf == -1) {
			return ""; 
		}
		return fileName.substring(lastIndexOf);
	}
	/**
	 * 
	 * @author WQ
	 * @date Dec 1, 2020
	 * @description_method 
	 * @param commaSeparatedString
	 * @return
	 */
	public static List <String> getListFromCommaSeparatedString(String commaSeparatedString) {
		if(isNotNullAndNotEmpty(commaSeparatedString)) {
			String[] commaSeparatedArray = commaSeparatedString.split(",");
			return  Arrays.asList(commaSeparatedArray);
		}
		return null;
	}
	
	public static byte[] base64decodeByteArray(String base64Str) {
		
		
		if(!org.apache.commons.codec.binary.Base64.isBase64(base64Str)) {
			return null;
		}
		byte[] out = Base64.getDecoder().decode(base64Str);
		return out;
	}

	public static Boolean isLandlineNumberValid(String householdTelephone) {
		if (Utilities.isNULL(householdTelephone)) {
			return Boolean.TRUE;
		}
		String numberAsString = householdTelephone;

		if (numberAsString.length() < 8) {
			return Boolean.FALSE;
		}

		if (numberAsString.startsWith("7")) {
			return Boolean.FALSE;
		}

		if (numberAsString.length() == 8 && !numberAsString.startsWith("0")) {
			return Boolean.FALSE;
		}
		if (numberAsString.length() == 8 && (numberAsString.startsWith("8", 1) || numberAsString.startsWith("9", 1)
				|| numberAsString.startsWith("0", 1))) {
			return Boolean.FALSE;
		}

		return Boolean.TRUE;

	}
	/**
	 * 
	 * @author WQ
	 * @date May 9, 2021
	 * @description_method 
	 * @param fieldName
	 * @param fieldValue
	 * @return
	 */
	public static HashMap<String, Object> validateNotEmpty(String fieldName, String fieldValue) {
		HashMap<Enum, String> rule = new HashMap<>();
		List<HashMap<Enum, String>> validationRulesEnum = new ArrayList<>();
		HashMap<String, Object> fieldMap = new HashMap<String, Object>();
		fieldMap.put(ConstantsUtil.FIELD_NAME, fieldName);
		fieldMap.put(ConstantsUtil.FIELD_VALUE, fieldValue);
		rule.put(RuleEnum.NOT_EMPTY, ConstantsUtil.API_MESSAGE);
		validationRulesEnum.add(rule);
		fieldMap.put(ConstantsUtil.VALIDATION, validationRulesEnum);
		return fieldMap;
	}
	
	public static boolean isValidString(String str) {
		return (str!=null && !str.trim().isEmpty() && !"null".equalsIgnoreCase(str.trim()));
	}
	
	public static boolean isListNULLOrEmpty(List<?> list) {
		return isNULL(list) || (!isNULL(list) && list.isEmpty());
	}
}
