package org.yumnn.yct.common.enumeration.common;

public enum RecipientTypeEnum {
	TO, CC , BCC
}
