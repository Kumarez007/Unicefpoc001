package org.yumnn.yct.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.catalog.GeolocationType;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
@Repository
public interface IGeolocationTypeRepository extends JpaRepository<GeolocationType, Long>,CustomizedGeolocationTypeRepository {
	@Query("SELECT t.geolocationType FROM Geolocation t where t.id = :id")
	public GeolocationType getGeolocationTypeByGeolocationId(@Param("id") Long id);

}
