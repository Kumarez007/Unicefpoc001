package org.yumnn.yct.common.model.payment;

import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name BookletValidationCodeModel.java
 * @class_description 
 * @create_date Jun 9, 2021
 * @last_Update Jun 9, 2021
 */
public class BookletValidationCodeModel {

	private String validationCode;
	private Long bookletId;
	private YesNoEnum isActive;
	private YesNoEnum isUsed;
	private YesNoEnum isRedeemed;
	private Long validationCodeId;
	/**
	 * @return the validationCode
	 */
	public String getValidationCode() {
		return validationCode;
	}
	/**
	 * @param validationCode the validationCode to set
	 */
	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}
	/**
	 * @return the bookletId
	 */
	public Long getBookletId() {
		return bookletId;
	}
	/**
	 * @param bookletId the bookletId to set
	 */
	public void setBookletId(Long bookletId) {
		this.bookletId = bookletId;
	}
	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the validationCodeId
	 */
	public Long getValidationCodeId() {
		return validationCodeId;
	}
	/**
	 * @param validationCodeId the validationCodeId to set
	 */
	public void setValidationCodeId(Long validationCodeId) {
		this.validationCodeId = validationCodeId;
	}
	/**
	 * @return the isUsed
	 */
	public YesNoEnum getIsUsed() {
		return isUsed;
	}
	/**
	 * @param isUsed the isUsed to set
	 */
	public void setIsUsed(YesNoEnum isUsed) {
		this.isUsed = isUsed;
	}
	/**
	 * @return the isRedeemed
	 */
	public YesNoEnum getIsRedeemed() {
		return isRedeemed;
	}
	/**
	 * @param isRedeemed the isRedeemed to set
	 */
	public void setIsRedeemed(YesNoEnum isRedeemed) {
		this.isRedeemed = isRedeemed;
	}

}
