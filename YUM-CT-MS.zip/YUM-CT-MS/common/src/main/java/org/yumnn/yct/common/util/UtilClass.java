package org.yumnn.yct.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class UtilClass {

  private static Logger logger = LogManager.getLogger();

  /**
   * @param dateInString
   * @return
   * @throws ParseException
   */
  public static Date StringToDate(String dateInString) throws ParseException {
    logger.debug("String to Date :" + new SimpleDateFormat("dd-MM-yyyy").parse(dateInString));
    return new SimpleDateFormat("dd-MM-yyyy").parse(dateInString);
  }

  /**
   * @param dateInString
   * @return
   * @throws ParseException
   */
  public static Date StringToDateIssueBooklet(String dateInString) throws ParseException {
    logger.debug("String to Date :" + new SimpleDateFormat("yyyy-MM-dd").parse(dateInString));
    return new SimpleDateFormat("yyyy-MM-dd").parse(dateInString);
  }


  /**
   * @param dateInString
   * @return
   * @throws ParseException
   */
  public static Date StringToDateTime(String dateInString) throws ParseException {
    logger.debug("String to Date :"
        + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").parse(dateInString));
    return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").parse(dateInString);
  }

  /**
   * @param date
   * @return
   */
  public static String DateToString(Date date) {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
    return dateFormat.format(date);
  }

  /**
   * @param date
   * @return
   */
  public static String DateTimeToString(Date date) {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    return dateFormat.format(date);
  }

  /**
   * @param text
   * @return
   */
  public static boolean isNULLOrEmpty(String text) {
    return isNULL(text) || (!isNULL(text) && text.trim().isEmpty());
  }

  /**
   * @param object
   * @return
   */
  public static boolean isNULL(Object object) {
    return object == null;
  }

  /**
   * @param stringDate
   * @param format
   * @return
   */

  public static Date stringToDate(String stringDate, String format) {
    try {
      return new SimpleDateFormat(format).parse(stringDate);
    } catch (Exception e) {
    }
    return null;
  }
}

