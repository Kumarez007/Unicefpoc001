package org.yumnn.yct.common.enumeration.messages;

public enum MessageReferenceTypeEnum {

	PAYMENT_SITE("Payment site"), ISSUE_LOG("Issue log"), GRIEVANCE_FOLLOWUP_ACTION("Grievance FOllowup Action"),
	GRIEVANCE_CLOSURE("Grievance Closure"), CFM_GRIEVANCE_FOLLOWUP_ACTION("CFM Grievance Followup Action"), 
	GRIEVANCE_CREATED_ACTION("Grievance Created Action");

	private String value;

	MessageReferenceTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
