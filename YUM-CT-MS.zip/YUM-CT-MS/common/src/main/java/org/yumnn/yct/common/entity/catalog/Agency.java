/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.catalog.AgencyTypeEnum;

/**
 * @author Reem Issa
 * @department PMU.
 * @owner UNICEF.
 * @class_name Agency.java
 * @class_description
 * @create_date Mar 06, 2019
 * @last_Update Mar 06, 2019
 */
@Entity
@Table(name = "payment.cat_agency")
public class Agency extends CatalogParentEntity implements Serializable, Catalog {
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "contact_name")
	private String contactName;
	
	@Column(name = "email_address")
	private String emailAddress;
	
	@Column(name = "agency_type")
	@Enumerated(EnumType.STRING)
	private AgencyTypeEnum agencyTypeype;
	
	
	@Column(name = "send_feedback")
	private String sendFeedback;
	
	@ManyToOne
	@JoinColumn(name = "id_project_fk", referencedColumnName = "ID")
	private Project project;
	
	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Agency other = (Agency) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}


	/**
	 * @return the contactName
	 */
	public String getContactName() {
		return contactName;
	}

	/**
	 * @param contactName the contactName to set
	 */
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the sendFeedback
	 */
	public String getSendFeedback() {
		return sendFeedback;
	}

	/**
	 * @param sendFeedback the sendFeedback to set
	 */
	public void setSendFeedback(String sendFeedback) {
		this.sendFeedback = sendFeedback;
	}

	/**
	 * @return the agencyTypeype
	 */
	public AgencyTypeEnum getAgencyTypeype() {
		return agencyTypeype;
	}

	/**
	 * @param agencyTypeype the agencyTypeype to set
	 */
	public void setAgencyTypeype(AgencyTypeEnum agencyTypeype) {
		this.agencyTypeype = agencyTypeype;
	}

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}
	
}
