package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

public class DuplicateRequestCustomException extends RuntimeException {
  
  private static final long serialVersionUID = 1L;

  private String message;

  /**
   * Parameterized constructor
   * 
   * @param message
   */
  public DuplicateRequestCustomException(String message) {
    super();
    this.message = message;
  }


  /**
   * return message
   */
  @Override
  public String getMessage() {
    return message;
  }

  /**
   * @param message the message to set
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
