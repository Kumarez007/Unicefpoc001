package org.yumnn.yct.common.model.message;

import java.util.Date;

/**
 *
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {SMSRequestModel.java
 * @create_date May 9, 2021
 * @last_Update May 9, 2021
 */
public class SMSRequestModel extends  MessageRequestModel{

    private String mobileNumber;

    private String recordUniqueCode;

    private Date scheduledSendingDate;


    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    public String getRecordUniqueCode() {
        return recordUniqueCode;
    }

    public void setRecordUniqueCode(String recordUniqueCode) {
        this.recordUniqueCode = recordUniqueCode;
    }

    public Date getScheduledSendingDate() {
        return scheduledSendingDate;
    }

    public void setScheduledSendingDate(Date scheduledSendingDate) {
        this.scheduledSendingDate = scheduledSendingDate;
    }
}
