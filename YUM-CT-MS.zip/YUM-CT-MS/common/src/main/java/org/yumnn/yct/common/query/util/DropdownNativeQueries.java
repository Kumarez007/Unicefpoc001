package org.yumnn.yct.common.query.util;

import org.yumnn.yct.common.util.Utilities;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Jul 6, 2021 1:37:53 PM
 */
public class DropdownNativeQueries {

	public static String getProgramEntityDropdownByIdAsc(String id, Boolean onlyTFCRequired, String projectId) {
		String query = "";

		if (projectId != null) {

			query = "select c.id,c.en_name,c.ar_name from user_access.cat_program_entity c where id_form_fk in "
					+ "(select id from beneficiary.cur_form where id_project_fk in "
					+ "(select id from user_access.adm_project where project_type in "
					+ "(select CASE WHEN project_type = 'BENEFICIARY' THEN 'HEALTH' ELSE project_type END AS project_type from user_access.adm_project where id = " + projectId
					+ " union select CASE WHEN project_type = 'BENEFICIARY' THEN 'EDUCATION' ELSE project_type END AS project_type from user_access.adm_project where id = " + projectId + "))) and id_geolocation_fk=" + id;
			if (onlyTFCRequired) {
				query += " and id_program_entity_type_fk=1 ";
			}
		} else {

			query = "select id,en_name,ar_name from user_access.cat_program_entity where id_geolocation_fk=" + id;


			if (onlyTFCRequired) {
				query += " and id_program_entity_type_fk=1 ";
			}
		}
		return query;
	}

	public static String getProgramEntityDropdownByIdAsc(String id, Boolean onlyTFCRequired, String projectId,String path) {
		String query = "";

		if (projectId != null) {

				query = "select c.id,c.en_name,c.ar_name from user_access.cat_program_entity c,user_access.sch_program_entity she where she.is_active='YES' and she.id_cur_form_fk=c.id_form_fk  and id_form_fk in "
						+ "(select id from beneficiary.cur_form where id_project_fk in "
						+ "(select id from user_access.adm_project where project_type in "
						+ "(select CASE WHEN project_type = 'BENEFICIARY' THEN 'HEALTH' ELSE project_type END AS project_type from user_access.adm_project where id = " + projectId
						+ " union select CASE WHEN project_type = 'BENEFICIARY' THEN 'EDUCATION' ELSE project_type END AS project_type from user_access.adm_project where id = " + projectId + "))) and id_geolocation_fk=" + id;

			if (onlyTFCRequired) {
				query += " and id_program_entity_type_fk=1 ";
			}
		} else {

			//query = "select id,en_name,ar_name from user_access.cat_program_entity where id_geolocation_fk=" + id;
			query = "select cpe.id,cpe.en_name,cpe.ar_name from user_access.cat_program_entity cpe,user_access.sch_program_entity she  \n" +
					"where  she.is_active='YES' and she.id_cur_form_fk=cpe.id_form_fk and cpe.id_geolocation_fk=" +id;

			if (onlyTFCRequired) {
				query += " and id_program_entity_type_fk=1 ";
			}
		}
		return query;
	}

	public static String getProjectDropdownByShortNameAsc(String shortName) {
		return "select id,name as en_name , name as ar_name from user_access.adm_project where short_name = '"
				+ shortName + "'";
	}

	public static String getOwnershipDropdownByAsc() {
		return "select id,en_name,ar_name from user_access.cat_ownership_type order by order_item asc";
	}

	public static String getGrievanceAgainstDropdownAsc() {
		return "select id,en_name,ar_name from grievance.cat_grievance_against order by order_item asc";
	}

	public static String getGrievanceCategoryDropdownAsc(String projectId) {
		return "select id,en_name,ar_name from grievance.cat_grievance_category where id_project_fk=" + projectId
				+ " and is_active='YES' " + "order by order_item asc";
	}
	
	
	
	
	
	public static String getGrievanceCategoryByRoleDropdownAsc(String roleId) {
		return "select cat.id,cat.en_name,cat.ar_name  from grievance.cat_grievance_category cat join \r\n" + 
				"grievance.adm_grievance_category_by_role cr on cr.id_grievance_category_fk=cat.id\r\n" + 
				"where cr.id_role_fk = "+roleId+"";
	}
	
	public static String getGrievanceCategoryDropdownAsc() {
		return "select id,en_name,ar_name from grievance.cat_grievance_category where is_active='YES' order by order_item asc";
	}
	
	public static String getGrievanceChannelDropdownAsc() {
		return "select id,en_name,ar_name from grievance.adm_channel";
	}

	
	public static String getGrievanceCycleDropdownAsc(String projectId) {
		return "select cyc.id as id ,cyc.display_name as en_name, cyc.display_name as ar_name   from \r\n" +   
				"user_access.adm_cycle_by_project acbp \r\n"+
				"join user_access.adm_cycle cyc on acbp.id_cycle_fk=cyc.id where acbp.id_project_fk =" + projectId +" order by cyc.id desc";



	}
	public static String getGovernorateDropDown() {
		return "select id,en_name,ar_name from user_access.cat_geolocation where id_geolocation_parent_fk is null";
	}

	public static String getGeoDropDownByParentId(String id) {
		return "select id,en_name,ar_name from user_access.cat_geolocation where id_geolocation_parent_fk is not null and id_geolocation_parent_fk="
				+ id;
	}

	public static String getInquiryCatDropdown() {
		return "select id,en_name,ar_name from grievance.cat_inquiry_category where is_active='YES' ";
	}

	public static String getInquiryCatDropdownById(String id) {
		return "select id,en_name,ar_name from grievance.cat_inquiry_category where is_active='YES' and id=" + id;
	}

	public static String getInquiryTypeDropdownByCategory(String id) {
		return "select id,en_name,ar_name from grievance.cat_inquiry_type where is_active='YES' and id_inquiry_category_fk="
				+ id;
	}

	public static String getInquiryTypeDropdownById(String id) {
		return "select id,en_name,ar_name from grievance.cat_inquiry_type where is_active='YES' and id=" + id;
	}

	public static String getProjectDropdown() {
		return "select id,name as en_name,name as ar_name from user_access.adm_project";
	}

	public static String getProjectDropdownById(String id) {
		return "select id,name as en_name,name as ar_name from user_access.adm_project where id=" + id;
	}

	public static String getGrievanceActionDropdown() {
		return "select id,en_name,ar_name from grievance.cat_grievance_action WHERE is_active = 'YES' order by order_item asc";
	}
	
	public static String getGrievanceActionDropdownTable() {
		return "select id,en_name,ar_name from grievance.cat_grievance_action WHERE is_active = 'YES' AND short_name <> 'send_back_to_owner' order by order_item asc";
	}
	
	public static String getGrievanceActionDropdownSendBackToOwner() {
		return "select id,en_name,ar_name from grievance.cat_grievance_action WHERE is_active = 'YES' and id=29 order by order_item asc";
	}

	public static String getGrievanceActionDropdownByRoleId(Long id) {
		return "select T1.id AS id , T1.en_name AS en_name, T1.ar_name AS ar_name FROM grievance.cat_grievance_action T1 JOIN user_access.adm_role_action_mapping T2 ON T1.id = T2.id_action_fk \r\n" + 
				"JOIN user_access.adm_role T3 ON T3.id = t2.id_role_fk  WHERE T2.id_role_fk = " + id + " and T1.is_active = 'YES' order by T1.order_item asc";
	}

	public static String getAgencyDropdown() {
		return "SELECT id,en_name,ar_name from payment.cat_agency  order by order_item asc";
	}

	public static String getActiveIssueTypesDropDown() {
		return "SELECT id,en_name,ar_name from issue_log.cat_issue_type  order by order_item asc";
	}
	
	public static String getCFMProgrammeDropDown() {
		return "select id,name as en_name,ar_name as ar_name from user_access.adm_cfm_programme";
	}

	public static String getCFMTypeOfInformationDropDown(Long roleId) {
		String query = null;
		if (!Utilities.isNULL(roleId)) {
			query = "select distinct info.id,info.en_name as en_name,info.ar_name as ar_name from user_access.adm_cfm_type_of_information info\r\n" + 
					"join grievance.cat_cfm_grievance_category cat on cat.id_type_of_information_fk=info.id\r\n" + 
					"join grievance.adm_cfm_grievance_category_by_role cat_role on cat_role.id_cfm_grievance_category_fk=cat.id\r\n" + 
					"where id_role_fk="+roleId+" order by info.id";
		} else {
			query = "select id,name as en_name,ar_name as ar_name from user_access.adm_cfm_type_of_information";
		}
		return query;
	}

	public static String getCFMProjectDropDownByProgrammeId(Long programmeId, Boolean mainProjectsOnly) {
		String query = "select id,name as en_name,ar_name as ar_name from user_access.adm_cfm_project where id_cfm_programme_fk ="
				+ programmeId;
		if (mainProjectsOnly) {
			query += " and id_parent_project_fk is null ";
		}
		return query;

	}

	public static String getCFMSubProjectsByMainProjectId(Long projectId) {
		String query = "select id,name as en_name,ar_name as ar_name from user_access.adm_cfm_project where id_parent_project_fk ="
				+ projectId;

		return query;

	}

	public static String getCFMTGendersDropDown() {
		return "select id,name as en_name,ar_name as ar_name from beneficiary.cat_cfm_gender";
	}

	public static String getCFMPriorityDropDown() {
		return "select id,name as en_name,ar_name as ar_name from user_access.cat_cfm_priority";
	}

	public static String getCFMPComplainantMediumDropDown() {
		return "select id,name as en_name,ar_name as ar_name from user_access.cat_cfm_complainant_medium";
	}

	public static String getCFMPInformationChannelDropDown() {
		return "select id,name as en_name,ar_name as ar_name from user_access.cat_cfm_information_channel";
	}

	public static String getCFMPPreferedCommunicationChannelDropDown() {
		return "select id,name as en_name,ar_name as ar_name from user_access.cat_cfm_preferred_communication_channel";
	}

	public static String getCFMPriorityTimeframelDropDownByPriorityId(Long priorityId) {
		return "select id,name as en_name,ar_name as ar_name from user_access.cat_cfm_priority_timeframe where id_cfm_priority_fk ="
				+ priorityId;

	}

	public static String getCFMGrievanceStatusByTypeOfInfoIdDropDown(Long typeOfInfoId, String displayOnCFMForm) {
		String query = "select adm_cfm_grievance_status.id as id,name as en_name,ar_name as ar_name from grievance.adm_cfm_grievance_status "
				+ "join grievance.adm_cfm_grievance_status_by_type_of_information on \n"
				+ "adm_cfm_grievance_status_by_type_of_information.id_cfm_grievance_status_fk = adm_cfm_grievance_status.id\n"
				+ "and adm_cfm_grievance_status_by_type_of_information.id_cfm_type_of_information_fk = " + typeOfInfoId
				+ " where 1=1";

		if (!Utilities.isNULL(displayOnCFMForm)) {
			query += " and display_on_cfm_form ='" + displayOnCFMForm + "'";
		}

		return query;
	}

	public static String getCFMImplementationPartnersByProgrammeIdDropDown(Long programmeId) {
		return "select id,name as en_name,ar_name as ar_name from user_access.adm_cfm_implementation_partner where id_cfm_programme_fk ="
				+ programmeId;
	}
	public static String getCFMGrievanceCategoryByTypeOfInfoIdDropDown(Long typeOfInfoId, String isActive) {
		String query="select id,name as en_name,ar_name as ar_name from 	grievance.cat_cfm_grievance_category where id_type_of_information_fk ="+ typeOfInfoId;
		if(!Utilities.isNULLOrEmpty(isActive))
			query=query+" and is_active='YES' ";
		return query;
	}

	public static String getCFMGrievanceCategoryByTypeOfInfoIdAndRoleIdDropDown(Long typeOfInfoId, Long roleId) {
		String query = "select id,name as en_name,ar_name as ar_name from 	grievance.cat_cfm_grievance_category where id_type_of_information_fk ="
				+ typeOfInfoId + " and exists \n" + "(select 1 from grievance.adm_cfm_grievance_category_by_role \n"
				+ "where adm_cfm_grievance_category_by_role.id_cfm_grievance_category_fk = cat_cfm_grievance_category.id\n"
				+ "and adm_cfm_grievance_category_by_role.id_role_fk = " + roleId + ")";

		return query;
	}

	public static String getCFMImplementationSitesByGeolocationIdDropDown(Long geolocationId) {
		return "select id, ar_name as ar_name, en_name as en_name from user_access.cat_cfm_implementation_site  where  new_code = 'other' or id_geolocation_fk ="
				+ geolocationId;
	}
	
	public static String getGrievanceCategoryByProjectDropdownAsc(String roleId,String projectId) {
		return "select  cat.id,cat.en_name,cat.ar_name from grievance.adm_grievance_category_by_role role join "
				+ "grievance.cat_grievance_category cat on "
				+ "cat.id=role.id_grievance_category_fk where role.id_role_fk="+roleId+
				" and cat.id_project_fk="+projectId;
	}

	public static String getCFMGrievanceActions() {
		return "select id,name as en_name,ar_name as ar_name from 	grievance.cat_cfm_grievance_action";
	}

}
