package org.yumnn.yct.common.query.util;

import org.yumnn.yct.common.entity.administration.Role;
import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.catalog.Geolocation;
import org.yumnn.yct.common.enumeration.quartz.UploadedRecordTypeEnum;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {GlobalNativeQueries.java
 * @create_date May 26, 2021
 * @last_Update May 26, 2021
 */
public class GlobalNativeQueries {
	
	public static String getQueryForFindRolesNameByUserName() {
		return String.format("select t1.role_name from ADM_ROLE t1 left join ADM_USER_BY_ROLE t2 "
				+ "on t1.id=t2.id_role_fk left join adm_user t3 on t3.id=t2.id_user_fk where user_name='");

	}

	public static String getQueryForFindRecursiveGeolocation(Long geolocationId) {
		return String.format("WITH RECURSIVE geolocation_recursive AS(SELECT	id FROM	cat_geolocation WHERE id = %d and lower(is_active) = 'yes'"
				+ "UNION ALL SELECT T.id FROM	cat_geolocation T INNER JOIN geolocation_recursive R ON T.id_geolocation_parent_fk = R.ID and lower(T.is_active) = 'yes') "
				+ "SELECT id FROM geolocation_recursive", geolocationId);
	}

	public static String getQueryForFindRecursiveGeolocationNodes(Long geolocationId) {
		return String.format(
				"WITH RECURSIVE geolocation_recursive AS(SELECT	id, code FROM	cat_geolocation WHERE id = %d  and lower(is_active) = 'yes'"
						+ "UNION ALL SELECT T.id, T.code FROM	cat_geolocation T INNER JOIN geolocation_recursive R "
						+ "ON T.id_geolocation_parent_fk = R.ID and lower(is_active) = 'yes')  " + "SELECT id,code FROM geolocation_recursive ",
				geolocationId);
	}

	public static String getQueryForInsertFromGeolocationTempTable() {
		return String.format(
				"insert into cat_geolocation(id,name,code,latitude,longitude,id_geolocation_type_fk,area_type,id_geolocation_parent_fk)"
						+ " select id, name, code, latitude,longitude, id_geolocation_type_fk,area_type,"
						+ "(select id from cat_temp_geolocation t where t.name=b.geolocation_parent_name AND t.id_geolocation_type_fk=b.id_geolocation_type_fk-1) from cat_temp_geolocation b");
	}

	public static String getQueryForCleanGeolocationTempTables() {
		return String.format(
				"truncate table cat_temp_geolocation; ALTER SEQUENCE cat_temp_geolocation_id_seq RESTART WITH 1;");
	}

	/**
	 * 
	 * @author Ala'a Darwish
	 * @date May 15, 2019
	 * @description_method
	 * @return
	 */
	public static String getAllCycleWithStatusUtil() {
		return String.format(
				"select gen_cycle.id as cycle_id,gen_cycle.name as cycle_name,cycle_status.status as cycle_status,gen_cycle.creation_date as creation_date\n"
						+ "				,gen_cycle.ending_date as ending_date,gen_cycle.style_class as style_class \n"
						+ "				from gen_cycle gen_cycle join gen_cycle_status cycle_status\n"
						+ "				on cycle_status.id_cycle_fk = gen_cycle.id and cycle_status.ending_date is null order by gen_cycle.id desc");
	}

	

	/**
	 * 
	 * @author Reem Issa
	 * @date Jan 13, 2019
	 * @description_method
	 * @param geolocation
	 * @param role
	 * @return
	 */
	public static String getUsersByGeoLocationAndRole(Geolocation geolocation, Role role) {

		StringBuilder query = new StringBuilder(
				" select usr.first_name ||' '|| usr.last_name as name , usr.id  id_user ,  usr.user_name from adm_user usr ");

		if (geolocation.getId() != null || role.getId() != null) {
			query.append(" where exists ( select 1 from adm_geolocations_by_user_by_role geo , \n"
					+ " adm_user_by_role usrByrole , adm_user usr2 , cat_geolocation cat "
					+ " where usrByrole.id = geo.id_user_by_role_fk and usr2.id = usr.id and usr2.id = usrByrole.id_user_fk and cat.id = geo.id_geolocation_fk ");
		}

		if (geolocation.getId() != null && geolocation.getId() != null) {
			query.append(" AND cat.id = '" + geolocation.getId() + "'");
		}
		if (role.getId() != null) {
			query.append(" AND usrByrole.id_role_fk = '" + role.getId() + "'");
		}
		query.append(")");

		return String.format(query.toString());

	}

	
	/**
	 * 
	 * @author Reem Issa
	 * @date Jul 14, 2019
	 * @description_method
	 * @param geolocation
	 * @return
	 */
	public static String retrieveGeolocationLevelsById(Geolocation geolocation) {

		return String
				.format("select location.govern_id as geolocation_id , location.govern_name_en governorateNameEn,location.govern_name_ar governorateNameAr,"
						+ "location.district_name_en districtNameEn,location.district_name_ar districtNameAr,"
						+ "location.ozla_name_en ozlaNameEn,location.ozla_name_ar ozlaNameAr "
						+ "from get_geolocation_details_by_any_level_id(%d) location ", geolocation.getId());
	}

	
	/**
	 * 
	 * @author WQ
	 * @date Feb 27, 2020
	 * @description_method 
	 * @param user
	 * @return
	 */
	public static String isPrivilegedUser(User user) {
		StringBuilder query = new StringBuilder(
				" select count(1) from adm_user \n" + 
				" join adm_user_by_role on adm_user_by_role.id_user_fk = adm_user.id \n" + 
				" join adm_role on adm_role.id = adm_user_by_role.id_role_fk \n" + 
				" where adm_role.is_privileged = 'YES' \n" + 
				" and adm_user.id = " + user.getId());
		return String.format(query.toString());
	}
	
	/**
	 * 
	 * @author WQ
	 * @date May 19, 2021
	 * @description_method 
	 * @param geolocationId
	 * @return
	 */
	public static String geolocationDetails(Long geolocationId) {
		return "select govern_id,govern_name_en,govern_name_ar, district_id, district_name_en , "
				+ " district_name_ar, ozla_id, ozla_name_en, ozla_name_ar , city_id , city_name,city_name_en,city_name_ar from  user_access.get_geolocation_details_by_any_level_id("+geolocationId+ ");";
	}
	
	/**
	 * 
	 * @author WQ
	 * @date Jun 3, 2021
	 * @description_method 
	 * @param code
	 * @return
	 */
	public static String geolocationDetails(String code) {
		return "select govern_id,govern_name_en,govern_name_ar, district_id, district_name_en , "
				+ " district_name_ar, ozla_id, ozla_name_en, ozla_name_ar , city_id , city_name,city_name_en,city_name_ar from  user_access.get_geolocation_details_by_any_level_id((select id from user_access.cat_geolocation where code = '"+code+ "'));";
	}

}
