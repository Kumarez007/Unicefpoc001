package org.yumnn.yct.common.exception;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name IncompleteStatusException.java
 * @class_description this exception handles general troubles but without
 *                    rollback
 * @create_date Apr 28, 2015
 * @last_Update Apr 28, 2015
 */
@Transactional(rollbackFor=Exception.class)
public class FailProcessWithoutRollbackException extends Exception {

	private static final long serialVersionUID = 1L;

	private String details;
	private String detailsTwo;

	public FailProcessWithoutRollbackException() {
		super();
	}

	public FailProcessWithoutRollbackException(String message, Throwable cause) {
		super(message, cause);

	}

	public FailProcessWithoutRollbackException(String message) {
		super(message);
	}

	public FailProcessWithoutRollbackException(String message, String details) {
		super(message);
		this.details = details;
	}

	public FailProcessWithoutRollbackException(String message, String details, String detailsTwo) {
		super(message);
		this.details = details;
		this.detailsTwo = detailsTwo;
	}

	public FailProcessWithoutRollbackException(Throwable cause) {
		super(cause);
	}

	public String getDetails() {
		return details;
	}

	public String getDetailsTwo() {
		return detailsTwo;
	}

}