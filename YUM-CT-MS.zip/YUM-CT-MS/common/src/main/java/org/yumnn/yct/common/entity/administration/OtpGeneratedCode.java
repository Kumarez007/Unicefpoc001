/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.administration;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name OtpGeneratedCode.java
 * @class_description 
 * @create_date Feb 25, 2020
 * @last_Update Feb 25, 2020
 */
@Entity
@Table(name = "tra_otp_generated_code")
@NamedQueries({
		@NamedQuery(name = "OtpGeneratedCode.findByUserAccess", query = "SELECT u from OtpGeneratedCode u where u.userAccess = :userAccess "),
		@NamedQuery(name = "OtpGeneratedCode.findActiveByUserAccess", query = "SELECT u from OtpGeneratedCode u where u.userAccess = :userAccess and u.isActive = :isActive")
})
public class OtpGeneratedCode extends BaseEntity implements Serializable {
	private static final long serialVersionUID = -6739919052158515878L;

	@Column(name = "creation_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationTime;
		
	@Column(name = "otp_code")
	private String otpCode;
	
	@ManyToOne
	@JoinColumn(name = "id_user_access", referencedColumnName = "ID")
	private UserAccess userAccess;
	
	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;
	
	@Column(name = "failed_attempts_for_access")
	private Integer failedAttemptsForAccess;
	
	
	/**
	 * 
	 */
	public OtpGeneratedCode() {
	}
	
	/**
	 * @return the creationTime
	 */
	public Date getCreationTime() {
		return creationTime;
	}


	/**
	 * @return the failedAttemptsForAccess
	 */
	public Integer getFailedAttemptsForAccess() {
		return failedAttemptsForAccess;
	}

	/**
	 * @param failedAttemptsForAccess the failedAttemptsForAccess to set
	 */
	public void setFailedAttemptsForAccess(Integer failedAttemptsForAccess) {
		this.failedAttemptsForAccess = failedAttemptsForAccess;
	}

	/**
	 * @param creationTime the creationTime to set
	 */
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}


	/**
	 * @return the optCode
	 */
	public String getOtpCode() {
		return otpCode;
	}


	/**
	 * @param optCode the optCode to set
	 */
	public void setOtpCode(String optCode) {
		this.otpCode = optCode;
	}


	/**
	 * @return the userAccess
	 */
	public UserAccess getUserAccess() {
		return userAccess;
	}


	/**
	 * @param userAccess the userAccess to set
	 */
	public void setUserAccess(UserAccess userAccess) {
		this.userAccess = userAccess;
	}


	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OtpGeneratedCode other = (OtpGeneratedCode) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
