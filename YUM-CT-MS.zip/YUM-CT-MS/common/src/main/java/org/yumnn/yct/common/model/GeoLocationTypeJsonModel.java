package org.yumnn.yct.common.model;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class GeoLocationTypeJsonModel {

  private Long id;
  private String name;
  private String shortName;
  private Long geolocationTypeParent;
  private String englishName;
  private String arabicName;

  public GeoLocationTypeJsonModel() {}

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getShortName() {
    return shortName;
  }

  public void setShortName(String shortName) {
    this.shortName = shortName;
  }

  public Long getGeolocationTypeParent() {
    return geolocationTypeParent;
  }

  public void setGeolocationTypeParent(Long geolocationTypeParent) {
    this.geolocationTypeParent = geolocationTypeParent;
  }

  public String getEnglishName() {
    return englishName;
  }

  public void setEnglishName(String englishName) {
    this.englishName = englishName;
  }

  public String getArabicName() {
    return arabicName;
  }

  public void setArabicName(String arabicName) {
    this.arabicName = arabicName;
  }

}


/**
 * 
 * 
 * <p>
 * 
 * Created on 11-Mar-2020 at 1:31:39 pm Package Name org.yumnn.yct.useraccessservice.configuration Project Name
 * UNICEF
 * 

 * 
 */
