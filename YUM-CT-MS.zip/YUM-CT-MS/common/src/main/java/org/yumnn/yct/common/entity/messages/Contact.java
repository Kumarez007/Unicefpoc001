/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.messages;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name Contact.java
 * @create_date Apr 03, 2019
 * @last_Update Apr 03, 2019
 */
@Entity
@Table(name = "messages.msg_contact")
@NamedQueries({
		@NamedQuery(name = "Contact.findByMobileNumber", 
				query = "SELECT r from Contact r where r.currentContactInformationByBeneficiary.cellPhone = :cellPhone or r.mobileNumber = :cellPhone")

})
public class Contact extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "uuid")
	private String uuid;

	@Column(name = "name")
	private String name;

	@Column(name = "mobile_number")
	private String mobileNumber;

	@ManyToOne
	@JoinColumn(name = "id_contact_information_by_beneficiary_fk")
	private CurrentContactInformationByForm currentContactInformationByBeneficiary;

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the mobileNUmber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNUmber the mobileNUmber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the currentContactInformationByBeneficiary
	 */
	public CurrentContactInformationByForm getCurrentContactInformationByBeneficiary() {
		return currentContactInformationByBeneficiary;
	}

	/**
	 * @param currentContactInformationByBeneficiary the currentContactInformationByBeneficiary to set
	 */
	public void setCurrentContactInformationByBeneficiary(
			CurrentContactInformationByForm currentContactInformationByBeneficiary) {
		this.currentContactInformationByBeneficiary = currentContactInformationByBeneficiary;
	}
}
