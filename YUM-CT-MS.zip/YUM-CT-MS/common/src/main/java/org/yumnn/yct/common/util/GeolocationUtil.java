package org.yumnn.yct.common.util;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name GeolocationUtil.java
 * @class_description 
 * @create_date May 19, 2021
 * @last_Update May 19, 2021
 */
@Entity
public class GeolocationUtil implements Serializable  {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "govern_id")
	private Long	governorateId;
	
	@Column(name = "district_id")
	private Long	districtId;
	
	@Column(name = "ozla_id")
	private Long	ozlaId;
	
	@Column(name = "city_id")
	private Long	cityId;
	
	@Column(name = "govern_name_en")
	private String	governNameEn;
	
	@Column(name = "govern_name_ar")
	private String	governNameAr;
	
	@Column(name = "district_name_en")
	private String	districtNameEn;
	
	@Column(name = "district_name_ar")
	private String	districtNameAr;
	
	@Column(name = "ozla_name_en")
	private String	ozlaNameEn;
	
	@Column(name = "ozla_name_ar")
	private String	ozlaNameAr;
	
	@Column(name = "city_name")
	private String	cityName;
	
	@Column(name = "city_name_en")
	private String	cityNameEn;
	
	@Column(name = "city_name_ar")
	private String	cityNameAr;
	
	/**
	 * @return the governorateId
	 */
	public Long getGovernorateId() {
		return governorateId;
	}
	/**
	 * @param governorateId the governorateId to set
	 */
	public void setGovernorateId(Long governorateId) {
		this.governorateId = governorateId;
	}
	/**
	 * @return the districtId
	 */
	public Long getDistrictId() {
		return districtId;
	}
	/**
	 * @param districtId the districtId to set
	 */
	public void setDistrictId(Long districtId) {
		this.districtId = districtId;
	}
	/**
	 * @return the ozlaId
	 */
	public Long getOzlaId() {
		return ozlaId;
	}
	/**
	 * @param ozlaId the ozlaId to set
	 */
	public void setOzlaId(Long ozlaId) {
		this.ozlaId = ozlaId;
	}
	
	/**
	 * @return the cityId
	 */
	public Long getCityId() {
		return cityId;
	}
	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}
	/**
	 * @return the governNameEn
	 */
	public String getGovernNameEn() {
		return governNameEn;
	}
	/**
	 * @param governNameEn the governNameEn to set
	 */
	public void setGovernNameEn(String governNameEn) {
		this.governNameEn = governNameEn;
	}
	/**
	 * @return the governNameAr
	 */
	public String getGovernNameAr() {
		return governNameAr;
	}
	/**
	 * @param governNameAr the governNameAr to set
	 */
	public void setGovernNameAr(String governNameAr) {
		this.governNameAr = governNameAr;
	}
	/**
	 * @return the districtNameEn
	 */
	public String getDistrictNameEn() {
		return districtNameEn;
	}
	/**
	 * @param districtNameEn the districtNameEn to set
	 */
	public void setDistrictNameEn(String districtNameEn) {
		this.districtNameEn = districtNameEn;
	}
	/**
	 * @return the districtNameAr
	 */
	public String getDistrictNameAr() {
		return districtNameAr;
	}
	/**
	 * @param districtNameAr the districtNameAr to set
	 */
	public void setDistrictNameAr(String districtNameAr) {
		this.districtNameAr = districtNameAr;
	}
	/**
	 * @return the ozlaNameEn
	 */
	public String getOzlaNameEn() {
		return ozlaNameEn;
	}
	/**
	 * @param ozlaNameEn the ozlaNameEn to set
	 */
	public void setOzlaNameEn(String ozlaNameEn) {
		this.ozlaNameEn = ozlaNameEn;
	}
	/**
	 * @return the ozlaNameAr
	 */
	public String getOzlaNameAr() {
		return ozlaNameAr;
	}
	/**
	 * @param ozlaNameAr the ozlaNameAr to set
	 */
	public void setOzlaNameAr(String ozlaNameAr) {
		this.ozlaNameAr = ozlaNameAr;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityNameEn() {
		return cityNameEn;
	}
	public void setCityNameEn(String cityNameEn) {
		this.cityNameEn = cityNameEn;
	}
	public String getCityNameAr() {
		return cityNameAr;
	}
	public void setCityNameAr(String cityNameAr) {
		this.cityNameAr = cityNameAr;
	}

	

}
