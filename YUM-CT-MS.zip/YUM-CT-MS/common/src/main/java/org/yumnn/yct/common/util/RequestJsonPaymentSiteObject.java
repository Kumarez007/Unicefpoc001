package org.yumnn.yct.common.util;

import javax.validation.Valid;

import org.yumnn.yct.common.enumeration.project.ProjectPmuShortNameEnum;
import org.yumnn.yct.common.model.payment.PaymentSiteObject;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name RequestJsonPaymentSiteObject.java
 * @create_date Mar 8, 2022
 * @last_Update Mar 8, 2022
 */
public class RequestJsonPaymentSiteObject  {

	@Valid
	private PaymentSiteObject recordJson;

	private ProjectPmuShortNameEnum projectName;

	/**
	 * @return the projectName
	 */
	public ProjectPmuShortNameEnum getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(ProjectPmuShortNameEnum projectName) {
		this.projectName = projectName;
	}
	
	/**
	 * @return the recordJson
	 */
	public PaymentSiteObject getRecordJson() {
		return recordJson;
	}

	/**
	 * @param recordJson the recordJson to set
	 */
	public void setRecordJson(PaymentSiteObject recordJson) {
		this.recordJson = recordJson;
	}

}
