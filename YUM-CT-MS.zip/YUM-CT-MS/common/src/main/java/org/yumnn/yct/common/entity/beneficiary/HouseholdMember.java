package org.yumnn.yct.common.entity.beneficiary;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Documents;
import org.yumnn.yct.common.entity.catalog.Gender;
import org.yumnn.yct.common.entity.catalog.HouseholdMemberType;
import org.yumnn.yct.common.entity.catalog.Relationship;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.util.SourceTypeEnum;


@Entity
@Table(name = "beneficiary.cur_household_member")
public class HouseholdMember extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_form_fk")
	private CurrentForm currentForm;

	@Column(name = "member_code")
	private String memberCode;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_gender_fk")
	private Gender gender;

	@Temporal(TemporalType.DATE)
	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "phone_number")
	private String phoneNumber;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_documents_fk")
	private Documents document;

	@Column(name = "document_reference_number")
	private String documentReferenceNumber;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_relationship_fk")
	private Relationship relationship;

	@Column(name = "is_assigned_as_payment_receiver")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isAssignedAsPaymentReceiver;

	//Below column is removed as per user story - 91502
//	@Column(name = "is_require_investigation")
//	@Enumerated(EnumType.STRING)
//	private YesNoEnum isRequireInvestigation;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_household_member_type_fk")
	private HouseholdMemberType householdMemberType;

	@Column(name = "is_primary")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isPrimary;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false)
	private Date createdAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = true)
	private Date updatedAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_created_by_fk", nullable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_user_updated_by_fk", nullable = true)
	private User updatedBy;
	
	@Column(name = "source_id")
	private Long sourceId;
	
	@Column(name = "source_type")
	@Enumerated(EnumType.STRING)
	private SourceTypeEnum sourceType;
	

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public Documents getDocument() {
		return document;
	}

	public void setDocument(Documents document) {
		this.document = document;
	}

	public String getDocumentReferenceNumber() {
		return documentReferenceNumber;
	}

	public void setDocumentReferenceNumber(String documentReferenceNumber) {
		this.documentReferenceNumber = documentReferenceNumber;
	}

	public Relationship getRelationship() {
		return relationship;
	}

	public void setRelationship(Relationship relationship) {
		this.relationship = relationship;
	}

	public YesNoEnum getIsAssignedAsPaymentReceiver() {
		return isAssignedAsPaymentReceiver;
	}

	public void setIsAssignedAsPaymentReceiver(YesNoEnum isAssignedAsPaymentReceiver) {
		this.isAssignedAsPaymentReceiver = isAssignedAsPaymentReceiver;
	}

	public HouseholdMemberType getHouseholdMemberType() {
		return householdMemberType;
	}

	public void setHouseholdMemberType(HouseholdMemberType householdMemberType) {
		this.householdMemberType = householdMemberType;
	}

	public YesNoEnum getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(YesNoEnum isPrimary) {
		this.isPrimary = isPrimary;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public Long getSourceId() {
		return sourceId;
	}

	public void setSourceId(Long sourceId) {
		this.sourceId = sourceId;
	}

	public SourceTypeEnum getSourceType() {
		return sourceType;
	}

	public void setSourceType(SourceTypeEnum sourceType) {
		this.sourceType = sourceType;
	}
	
}
