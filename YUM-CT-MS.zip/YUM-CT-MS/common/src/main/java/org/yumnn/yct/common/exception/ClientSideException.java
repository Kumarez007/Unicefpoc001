package org.yumnn.yct.common.exception;


import org.springframework.transaction.annotation.Transactional;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ClientSideException.java
 * @class_description this class is used for all exceptions thrown in the manage
 *                    beans
 * @create_date May 4, 2015
 * @last_Update May 4, 2015
 */
@Transactional(rollbackFor=Exception.class)
public class ClientSideException extends Exception {

	private static final long serialVersionUID = 1L;

	private String clientMessage;

	public ClientSideException(String clientMessage, String message) {
		super(message);
		this.clientMessage = clientMessage;
	}

	public String getClientMessage() {
		return clientMessage;
	}

	public void setClientMessage(String clientMessage) {
		this.clientMessage = clientMessage;
	}

	public ClientSideException() {
		super();
	}

	public ClientSideException(String message, Throwable cause) {
		super(message, cause);

	}

	public ClientSideException(String message) {
		super(message);
	}

	public ClientSideException(Throwable cause) {
		super(cause);
	}

}