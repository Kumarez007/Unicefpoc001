package org.yumnn.yct.common.model.historical;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentStatusEnum;

/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name HistoricalPaymentInformationModel.java
 * @class_description 
 * @create_date Aug 8, 2021
 * @last_Update Aug 8, 2021
 */
public class HistoricalPaymentInformationModel extends BaseEntity implements Serializable {	

	private Long currentFormId;

	private Long cycleId;

	private Long assignedPaymentAgencyId;

	private Long paidPaymentAgencyId;

	private Long correctProgramPeriodId;

	private Long paymentSiteId;

	private Double calculatedAmount;

	private Double collectedAmount;

	@Enumerated(EnumType.STRING)
	private PaymentStatusEnum paymentStatus;

	private Double arrearsAmount;

	private Double reimburesment;

	private Double amountToDeduct;

	@Temporal(TemporalType.TIMESTAMP)
	private Date paymentDate;

	private Double sentAmount;

	private Long currentHouseholdMemberId;
	
	private String bankRemmitanceNo;

	/**
	 * @return the currentFormId
	 */
	public Long getCurrentFormId() {
		return currentFormId;
	}

	/**
	 * @param currentFormId the currentFormId to set
	 */
	public void setCurrentFormId(Long currentFormId) {
		this.currentFormId = currentFormId;
	}

	/**
	 * @return the cycleId
	 */
	public Long getCycleId() {
		return cycleId;
	}

	/**
	 * @param cycleId the cycleId to set
	 */
	public void setCycleId(Long cycleId) {
		this.cycleId = cycleId;
	}

	/**
	 * @return the assignedPaymentAgencyId
	 */
	public Long getAssignedPaymentAgencyId() {
		return assignedPaymentAgencyId;
	}

	/**
	 * @param assignedPaymentAgencyId the assignedPaymentAgencyId to set
	 */
	public void setAssignedPaymentAgencyId(Long assignedPaymentAgencyId) {
		this.assignedPaymentAgencyId = assignedPaymentAgencyId;
	}

	/**
	 * @return the paidPaymentAgencyId
	 */
	public Long getPaidPaymentAgencyId() {
		return paidPaymentAgencyId;
	}

	/**
	 * @param paidPaymentAgencyId the paidPaymentAgencyId to set
	 */
	public void setPaidPaymentAgencyId(Long paidPaymentAgencyId) {
		this.paidPaymentAgencyId = paidPaymentAgencyId;
	}

	/**
	 * @return the correctProgramPeriodId
	 */
	public Long getCorrectProgramPeriodId() {
		return correctProgramPeriodId;
	}

	/**
	 * @param correctProgramPeriodId the correctProgramPeriodId to set
	 */
	public void setCorrectProgramPeriodId(Long correctProgramPeriodId) {
		this.correctProgramPeriodId = correctProgramPeriodId;
	}

	/**
	 * @return the paymentSiteId
	 */
	public Long getPaymentSiteId() {
		return paymentSiteId;
	}

	/**
	 * @param paymentSiteId the paymentSiteId to set
	 */
	public void setPaymentSiteId(Long paymentSiteId) {
		this.paymentSiteId = paymentSiteId;
	}

	/**
	 * @return the calculatedAmount
	 */
	public Double getCalculatedAmount() {
		return calculatedAmount;
	}

	/**
	 * @param calculatedAmount the calculatedAmount to set
	 */
	public void setCalculatedAmount(Double calculatedAmount) {
		this.calculatedAmount = calculatedAmount;
	}

	/**
	 * @return the collectedAmount
	 */
	public Double getCollectedAmount() {
		return collectedAmount;
	}

	/**
	 * @param collectedAmount the collectedAmount to set
	 */
	public void setCollectedAmount(Double collectedAmount) {
		this.collectedAmount = collectedAmount;
	}

	/**
	 * @return the paymentStatus
	 */
	public PaymentStatusEnum getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(PaymentStatusEnum paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the arrearsAmount
	 */
	public Double getArrearsAmount() {
		return arrearsAmount;
	}

	/**
	 * @param arrearsAmount the arrearsAmount to set
	 */
	public void setArrearsAmount(Double arrearsAmount) {
		this.arrearsAmount = arrearsAmount;
	}

	/**
	 * @return the reimburesment
	 */
	public Double getReimburesment() {
		return reimburesment;
	}

	/**
	 * @param reimburesment the reimburesment to set
	 */
	public void setReimburesment(Double reimburesment) {
		this.reimburesment = reimburesment;
	}

	/**
	 * @return the amountToDeduct
	 */
	public Double getAmountToDeduct() {
		return amountToDeduct;
	}

	/**
	 * @param amountToDeduct the amountToDeduct to set
	 */
	public void setAmountToDeduct(Double amountToDeduct) {
		this.amountToDeduct = amountToDeduct;
	}

	/**
	 * @return the paymentDate
	 */
	public Date getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * @return the sentAmount
	 */
	public Double getSentAmount() {
		return sentAmount;
	}

	/**
	 * @param sentAmount the sentAmount to set
	 */
	public void setSentAmount(Double sentAmount) {
		this.sentAmount = sentAmount;
	}

	/**
	 * @return the currentHouseholdMemberId
	 */
	public Long getCurrentHouseholdMemberId() {
		return currentHouseholdMemberId;
	}

	/**
	 * @param currentHouseholdMemberId the currentHouseholdMemberId to set
	 */
	public void setCurrentHouseholdMemberId(Long currentHouseholdMemberId) {
		this.currentHouseholdMemberId = currentHouseholdMemberId;
	}

	public String getBankRemmitanceNo() {
		return bankRemmitanceNo;
	}

	public void setBankRemmitanceNo(String bankRemmitanceNo) {
		this.bankRemmitanceNo = bankRemmitanceNo;
	}
	
	

}
