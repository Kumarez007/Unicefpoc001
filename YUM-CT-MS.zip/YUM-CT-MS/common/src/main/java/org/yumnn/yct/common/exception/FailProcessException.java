package org.yumnn.yct.common.exception;
import org.springframework.transaction.annotation.Transactional;

/**
 	* @author Jorge Villafuerte
 	* @department IT Department - Ecuador
 	* @owner Ayala Consulting Corporation.
 	* @class_name FailProcessException.java
 	* @class_description  Exception to all process that need rollback
 	* @create_date Oct 2, 2014
 	* @last_Update Oct 2, 2014
 	*/
@Transactional(rollbackFor=RuntimeException.class)
public class FailProcessException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public FailProcessException() {
		super();
	}

	public FailProcessException(String message, Throwable cause) {
		super(message, cause);
	}

	public FailProcessException(String message) {
		super(message);
	}

	public FailProcessException(Throwable cause) {
		super(cause);
	}

}