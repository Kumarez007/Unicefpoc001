package org.yumnn.yct.common.entity.administration;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.project.Project;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name ProgramEntityByProject.java
 * @create_date Oct 24, 2021
 * @last_Update Oct 24, 2021
 */
@Entity
@Table(name = "user_access.cat_program_entity_by_project")
public class ProgramEntityByProject extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@ManyToOne
	@JoinColumn(name = "id_project_fk", referencedColumnName = "ID")
	private Project project;

	@ManyToOne
	@JoinColumn(name = "id_program_entity_fk", referencedColumnName = "ID")
	private ProgramEntity programEntity;

	@ManyToOne
	@JoinColumn(name = "id_user_fk", referencedColumnName = "ID")
	private User user;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "creation_date")
	private Date creationDate;

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}

	/**
	 * @return the programEntity
	 */
	public ProgramEntity getProgramEntity() {
		return programEntity;
	}

	/**
	 * @param programEntity the programEntity to set
	 */
	public void setProgramEntity(ProgramEntity programEntity) {
		this.programEntity = programEntity;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
