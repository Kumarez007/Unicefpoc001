/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.entity.administration;


import org.yumnn.yct.common.entity.base.BaseEntity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name Person.java
 * @class_description represents table from database which contains available
 *                    role by user in the application
 * @create_date Apr 28, 2014
 * @last_Update Apr 28, 2014
 */
@Entity
@Table(name = "user_access.adm_user_by_role")
@NamedQueries({
		@NamedQuery(name = "UserByRole.findByUserAndRole", query = "SELECT u from UserByRole u where u.user = :user and u.role = :role"),
		@NamedQuery(name = "UserByRole.findRolesByUser", query = "SELECT u.role FROM UserByRole u WHERE u.user = :user order by u.role.id"),
		@NamedQuery(name = "UserByRole.deleteByUser", query = "DELETE  FROM UserByRole u WHERE u.user = :user "),
		@NamedQuery(name = "UserByRole.findByUserExcludingRole", query = "SELECT u from UserByRole u where u.user = :user and u.role != :roleToExclude"),
		@NamedQuery(name = "UserByRole.findByUserAndRoleList", query = "SELECT u FROM UserByRole u WHERE u.user = :user and u.role in (:roles)"),
		@NamedQuery(name = "UserByRole.deleteByUserAndRoleList", query = "DELETE  FROM UserByRole u WHERE u.user = :user and u.role in (:listRoleToDelete)"),
		@NamedQuery(name = "UserByRole.findByUser", query = "SELECT u FROM UserByRole u WHERE u.user = :user "),
		@NamedQuery(name = "UserByRole.findByRoleName", 
		query = "SELECT u FROM UserByRole u WHERE u.role.roleName = :roleName and u.user.isActive = :isActive order by u.user.firstName") ,
		@NamedQuery(name = "UserByRole.findByRoleNameExecludeUsers", query = "SELECT u FROM UserByRole u WHERE u.role.roleName = :roleName AND u.user not in (:userIds) ")
})
public class UserByRole extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_user_fk", referencedColumnName = "ID")
	private User user;

	@ManyToOne
	@JoinColumn(name = "id_role_fk", referencedColumnName = "ID")
	private Role role;
	

	@ManyToOne
	@JoinColumn(name = "id_updated_by", referencedColumnName = "ID")
	private User updatedBy;
	
	public UserByRole(User user, Role role) {
		super();
		this.user = user;
		this.role = role;
	}

	public UserByRole() {
		super();
	}

	public UserByRole(Long id) {
		super();
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * @return the updatedBy
	 */
	public User getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}

}
