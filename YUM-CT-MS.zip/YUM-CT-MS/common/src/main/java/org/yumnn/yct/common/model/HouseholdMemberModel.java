package org.yumnn.yct.common.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class HouseholdMemberModel {

	private String id;
	private String fullName;
	private String currentFormId;
	private String genderShortName;
	private String dateOfBirth;
	private String phoneNumber;
	private String catDocShortName;
	private String documentReferenceNumber;
	private String relationshipShortName;
	private String isAssignedAsPaymentReceiver;
	private String householdMemberTypeShortName;
	private String isPrimary;
	private List<AttachmentModel> attachments;
	private String createdBy;
	private String createdDate;
	private String isUpdated;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCurrentFormId() {
		return currentFormId;
	}

	public void setCurrentFormId(String currentFormId) {
		this.currentFormId = currentFormId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	

	public String getDocumentReferenceNumber() {
		return documentReferenceNumber;
	}

	public void setDocumentReferenceNumber(String documentReferenceNumber) {
		this.documentReferenceNumber = documentReferenceNumber;
	}

	

	public String getIsAssignedAsPaymentReceiver() {
		return isAssignedAsPaymentReceiver;
	}

	public void setIsAssignedAsPaymentReceiver(String isAssignedAsPaymentReceiver) {
		this.isAssignedAsPaymentReceiver = isAssignedAsPaymentReceiver;
	}

	public String getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(String isPrimary) {
		this.isPrimary = isPrimary;
	}

	public String getGenderShortName() {
		return genderShortName;
	}

	public void setGenderShortName(String genderShortName) {
		this.genderShortName = genderShortName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCatDocShortName() {
		return catDocShortName;
	}

	public void setCatDocShortName(String catDocShortName) {
		this.catDocShortName = catDocShortName;
	}

	public String getRelationshipShortName() {
		return relationshipShortName;
	}

	public void setRelationshipShortName(String relationshipShortName) {
		this.relationshipShortName = relationshipShortName;
	}

	public String getHouseholdMemberTypeShortName() {
		return householdMemberTypeShortName;
	}

	public void setHouseholdMemberTypeShortName(String householdMemberTypeShortName) {
		this.householdMemberTypeShortName = householdMemberTypeShortName;
	}

	public List<AttachmentModel> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<AttachmentModel> attachments) {
		this.attachments = attachments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsUpdated() {
		return isUpdated;
	}

	public void setIsUpdated(String isUpdated) {
		this.isUpdated = isUpdated;
	}

	@Override
	public String toString() {
		return "HouseholdMemberModel [id=" + id + ", fullName=" + fullName + ", currentFormId=" + currentFormId
				+ ", genderShortName=" + genderShortName + ", dateOfBirth=" + dateOfBirth + ", phoneNumber="
				+ phoneNumber + ", catDocShortName=" + catDocShortName + ", documentReferenceNumber="
				+ documentReferenceNumber + ", relationshipShortName=" + relationshipShortName
				+ ", isAssignedAsPaymentReceiver=" + isAssignedAsPaymentReceiver + ", householdMemberTypeShortName="
				+ householdMemberTypeShortName + ", isPrimary=" + isPrimary + ", attachments=" + attachments
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", isUpdated=" + isUpdated + "]";
	}

	
}
