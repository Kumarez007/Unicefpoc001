/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.enumeration.messages;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name MessageQueueActionTypeEnum.java
 * @class_description
 * @create_date Jul 23, 2019
 * @last_Update Jul 23, 2019
 */
public enum MessageQueueActionTypeEnum {

	RECEIVE_PAYMENT_SITE("Receive payment Site "),
	RECOMMEND_PAYMENT_SITE("Receive payment Site "),
	ENDORSE_PAYMENT_SITE("Endorse payment site"),
	APPROVE_PAYMENT_SITE("Approve payment site"),
	DECLINE_PAYMENT_SITE("Decline payment site"),
	SEND_ISSUE_LOG_TO_BANK("Send issue log to bank for feedback"),
	GRIEVANCE_FOLLOWUP_ACTION_REGISTERED("Grievance Followup Action"),
	CFM_GRIEVANCE_FOLLOWUP_ACTION_REGISTERED("CFM Grievance Followup Action"),
	REMINDER("Reminder"),	
	GRIEVANCE_PROVIDE_RECOMMENDATION("Recommendation Endorsement"),
	GRIEVANCE_PROVIDE_ADDITIONAL_INFO("Provide Additional Information"),
	GRIEVANCE_RECOMMENDATION_APPROVAL("Recommendation Approval"),
	GRIEVANCE_INESTIGATION_RECOMMENDATION("Investigation Endorsement"),
	GRIEVANCE_INESTIGATION_APPROVAL("Investigation Approval"),
	GRIEVANCE_REVIEW_DOCUMENT("Document Review Endorsement"),
	GRIEVANCE_REVIEW_DOCUMENT_APPROVAL("Document Review Approval"),
	GRIEVANCE_PROVIDE_CLARIFICATION("Provide Clarification"),
	GRIEVANCE_REDRESSAL_ENDORSMENT("Redressal Endorsement"),
	GRIEVANCE_REDRESSAL_APPROVAL("Redressal Approval"),
	GRIEVANCE_CLOSURE_REGISTERED("Grievance Closure"),
	GRIEVANCE_REVIEW_DOCUMENT_CLEARANCE("Document Review Clearance"),
	GRIEVANCE_ADDITIONAL_REVIEW_DOCUMENT("Additional Document Review"),
	GRIEVANCE_ADDITIONAL_REVIEW_DOCUMENT_ENDOR("Additional Document Review Endorsement"),
	GRIEVANCE_FINAL_REDRESSAL("Final Redressal"), SEND_OTP_CODE("Send OTP generated Code"),
	GRIEVANCE_CREATED_ACTION_REGISTERED("Grievance Followup Action"),
	OPEN_GRIEVANCES_GI_CATEGORY("Open Grievance GI Category"),
	OPEN_GRIEVANCES_GBV_CATEGORY("Open Grievance GBV Category"),
	OPEN_GRIEVANCES_SEA_CATEGORY("Open Grievance SEA Category");


	private String value;

	MessageQueueActionTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
