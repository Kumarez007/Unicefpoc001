package org.yumnn.yct.common.enumeration.quartz;

import org.yumnn.yct.common.enumeration.cicFiles.TypeOfConciliatedCodeEnum;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name UploadedRecordProcessStatusEnum.java
 * @class_description
 * @create_date Oct 17, 2017
 * @last_Update Oct 17, 2017
 */
public enum UploadedRecordTypeEnum {
	
	VERIFICATION(TypeOfConciliatedCodeEnum.BENEFICIARY),
	NON_VERIFICATION(TypeOfConciliatedCodeEnum.UNVERIFIED),
	FRAUD(TypeOfConciliatedCodeEnum.FRAUD),
	INELIGIBLE(TypeOfConciliatedCodeEnum.INELIGIBLE),
	VERIFIABLE(TypeOfConciliatedCodeEnum.VERIFIABLE),
	NON_VERIFIABLE(TypeOfConciliatedCodeEnum.NON_VERIFIABLE),
	HOUSE_PAYMENT(TypeOfConciliatedCodeEnum.HOUSE_PAYMENT),
	DUPLICATE_AUTHORIZATION_FORM(TypeOfConciliatedCodeEnum.DUPLICATE_AUTHORIZATION_FORM),
	DAILY_REPORT_CVI_FORM(TypeOfConciliatedCodeEnum.DAILY_REPORT_CVI_FORM),
	DAILY_REPORT_VERIFICATION_FORM(TypeOfConciliatedCodeEnum.DAILY_REPORT_VERIFICATION_FORM), 
	DAILY_REPORT_GRIEVANCE_FORM(TypeOfConciliatedCodeEnum.DAILY_REPORT_GRIEVANCE_FORM),
	CONSOLIDATED_GRIEVANCE_INFO(TypeOfConciliatedCodeEnum.CONSOLIDATED_GRIEVANCE_INFO),
	PAID_BENEFICIARY(TypeOfConciliatedCodeEnum.PAID_BENEFICIARY),
	CALL_REGISTRATION(TypeOfConciliatedCodeEnum.CALL_REGISTRATION),
	PAYMENT_SITE(TypeOfConciliatedCodeEnum.PAYMENT_SITE),
	ISSUE_LOG(TypeOfConciliatedCodeEnum.ISSUE_LOG) ,
	VERIFICATION_FORM(TypeOfConciliatedCodeEnum.VERIFICATION_FORM),
	VERIFICATION_FORM_PICTURE(TypeOfConciliatedCodeEnum.VERIFICATION_FORM_PICTURE),
	VERIFICATION_FORM_ATTENDACE(TypeOfConciliatedCodeEnum.VERIFICATION_FORM_ATTENDANCE),
	NOT_PAID_BENEFICIARY(TypeOfConciliatedCodeEnum.NOT_PAID_BENEFICIARY),
	BROADCAST(TypeOfConciliatedCodeEnum.BROADCAST),
	GRIEVANCE(TypeOfConciliatedCodeEnum.GRIEVANCE),
	CMA_FORM(TypeOfConciliatedCodeEnum.CMA_FORM),
	CMA_CASE(TypeOfConciliatedCodeEnum.CMA_CASE),
	SURVEY(TypeOfConciliatedCodeEnum.SURVEY),
	DAILY_REPORT(TypeOfConciliatedCodeEnum.DAILY_REPORT),
	CMA_INFORMATION_BY_CASE(TypeOfConciliatedCodeEnum.CMA_INFORMATION_BY_CASE),
	CMA(TypeOfConciliatedCodeEnum.CMA),
	UPDATE_INFORMATION( TypeOfConciliatedCodeEnum.UPDATE_INFORMATION),
	ENROLL_BENEFICIARY( TypeOfConciliatedCodeEnum.ENROLL_BENEFICIARY),
	REPLACE_VOUCHER( TypeOfConciliatedCodeEnum.REPLACE_VOUCHER),
	CMA_RECEIVE_VALIDATION_CODE(TypeOfConciliatedCodeEnum.CMA_RECEIVE_VALIDATION_CODE);

	private TypeOfConciliatedCodeEnum relatedTypeOfConciliatedCicFilesCodeEnum;
	
	private UploadedRecordTypeEnum(TypeOfConciliatedCodeEnum typeOfConciliatedCicFilesCodeEnum) {
		this.relatedTypeOfConciliatedCicFilesCodeEnum = typeOfConciliatedCicFilesCodeEnum;
	}

	private UploadedRecordTypeEnum() {
		
	}

	public TypeOfConciliatedCodeEnum getRelatedTypeOfConciliatedCicFilesCodeEnum() {
		return relatedTypeOfConciliatedCicFilesCodeEnum;
	}

}
