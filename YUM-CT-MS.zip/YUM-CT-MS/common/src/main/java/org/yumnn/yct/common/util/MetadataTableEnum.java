package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

public enum MetadataTableEnum {

  GEOGRAPHICAL_AREA("GeographicalArea"), HEALTH_FACILITY(
      "HealthFacility"), REASONS_OF_ISSUE_BOOKLET("ReasonsOfIssueBooklet"), PLACE_OF_REFERRAL(
          "PlaceOfreferral"), COMPLICATIONS(
              "Complications"), ID_TYPE("IdType"), RELATIONSHIP("Relationship");


  private final String enumValue;

  /**
   * @param enumValue
   */
  private MetadataTableEnum(String enumValue) {
    this.enumValue = enumValue;
  }

  /**
   * @return enumValue in String format
   */
  public String getEnumValue() {
    return enumValue;
  }
}
