package org.yumnn.yct.common.enumeration.catalog;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name AppliedCycleForPaymentSiteEnum.java
 * @class_description identifier of applied cycle for payment site catalog
 * @create_date Oct 9, 2018
 * @last_Update Oct 9, 2018
 */
public enum AppliedCycleForPaymentSiteEnum {

	CYCLE_ONE, CYCLE_TWO, CYCLE_ONE_AND_TWO, CYCLE_THREE, CYCLE_FOUR;
}
