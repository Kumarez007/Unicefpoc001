/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.enumeration.catalog;

/**
 * 
 	* @author Ala'a Darwish
 	* @department PMU - ICT
 	* @owner UNICEF
 	* @class_name QuestionTypeEnum.java
 	* @class_description 
 	* @create_date Sep 25, 2019
 	* @last_Update Sep 25, 2019
 */
public enum QuestionTypeEnum {
	
	CHECK_BOX("Check box"),
	TEXT("Text"),
	TEXT_AREA("Text Area"),
	SELECT_ONE_MENU("Select one menu");

	String value;

	QuestionTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}


}
