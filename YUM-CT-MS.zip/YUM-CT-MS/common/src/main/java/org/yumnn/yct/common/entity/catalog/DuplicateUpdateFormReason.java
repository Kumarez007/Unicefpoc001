package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.enumeration.catalog.DuplicateUpdateFormReasonShortNameEnum;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name DuplicateUpdateFormReason.java
 * @class_description
 * @create_date Jan 28, 2018
 * @last_Update Jan 28, 2018
 */
@Entity
@Table(name = "cat_duplicate_update_form_reason")
@NamedQueries({
		@NamedQuery(name = "DuplicateUpdateFormReason.findAllByOrderItem", query = "SELECT r from DuplicateUpdateFormReason r order by r.orderItem asc") })
public class DuplicateUpdateFormReason extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;


	@Column(name = "duplicate_short_name")
	@Enumerated(EnumType.STRING)
	private DuplicateUpdateFormReasonShortNameEnum duplicateUpdateShortName;

	public DuplicateUpdateFormReason() {
	}

	public DuplicateUpdateFormReason(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DuplicateUpdateFormReason other = (DuplicateUpdateFormReason) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return super.toString();
	}


	public DuplicateUpdateFormReasonShortNameEnum getDuplicateUpdateShortName() {
		return duplicateUpdateShortName;
	}

	public void setDuplicateUpdateShortName(DuplicateUpdateFormReasonShortNameEnum duplicateUpdateShortName) {
		this.duplicateUpdateShortName = duplicateUpdateShortName;
	}

}
