package org.yumnn.yct.common.enumeration.flag;

/**
 * 
 * @author Christian Alvarez
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name FlagForHouseholdOrIndividualEnum.java
 * @class_description
 * @create_date Jun 7, 2019
 * @last_Update Jun 7, 2019
 */
public enum FlagForHouseholdOrIndividualEnum  {

	HOUSEHOLD("Household", "Household"), INDIVIDUAL("Individual", "Individual");

	private String valueToShow;
	private String fileName;

	FlagForHouseholdOrIndividualEnum(String valueToShow, String fileName) {
		this.valueToShow = valueToShow;
		this.fileName = fileName;
	}

	public String getValueToShow() {
		return valueToShow;
	}

	public String getFileName() {
		return fileName;
	}


}
