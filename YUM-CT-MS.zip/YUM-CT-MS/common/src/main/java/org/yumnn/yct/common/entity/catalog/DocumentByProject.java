package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
/**
 * 
 * @author WQ
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name DocumentByProject.java
 * @class_description 
 * @create_date Sep 29, 2021
 * @last_Update Sep 29, 2021
 */
@Entity
@Table(name = "beneficiary.adm_documents_by_project")
public class DocumentByProject extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_project_fk", referencedColumnName = "ID")
	private Project project;

	@ManyToOne
	@JoinColumn(name = "id_document_fk", referencedColumnName = "ID")
	private Documents document;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}

	/**
	 * @return the document
	 */
	public Documents getDocument() {
		return document;
	}

	/**
	 * @param document the document to set
	 */
	public void setDocument(Documents document) {
		this.document = document;
	}

	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	

}
