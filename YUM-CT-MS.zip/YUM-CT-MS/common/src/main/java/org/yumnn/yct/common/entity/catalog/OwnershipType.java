package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name OwnershipType.java
 * @class_description encapsulates whole attributes needed for OwnershipType
 *                    table in database
 * @create_date Mar 16, 2016
 * @last_Update Mar 16, 2016
 */
@Entity
@Table(name = "cat_ownership_type", schema="user_access")
@NamedQueries({ @NamedQuery(name = "OwnershipType.findAllByOrderItem",
		query = "SELECT r from OwnershipType r order by r.orderItem asc") })
public class OwnershipType extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	
	public OwnershipType() {
	}

	public OwnershipType(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnershipType other = (OwnershipType) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	

}
