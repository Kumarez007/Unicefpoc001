package org.yumnn.yct.common.model;

import java.math.BigDecimal;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

public class GeographicalAreaJsonModel {

  private Long id;
  private String name;
  private String shortName;
  private Long geolocationTypeId;
  private String locationType;
  private Long parentId;
  private String code;
  private BigDecimal latitude;
  private BigDecimal longitude;
  private String enGeographicalArea;
  private String arGeographicalArea;
  private String securityLevel;
  private Boolean isActive;
  private Long geographicalAreaId;

  public GeographicalAreaJsonModel() {}

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getShortName() {
    return shortName;
  }

  public void setShortName(String shortName) {
    this.shortName = shortName;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public BigDecimal getLatitude() {
    return latitude;
  }

  public void setLatitude(BigDecimal latitude) {
    this.latitude = latitude;
  }

  public BigDecimal getLongitude() {
    return longitude;
  }

  public void setLongitude(BigDecimal longitude) {
    this.longitude = longitude;
  }

  public String getSecurityLevel() {
    return securityLevel;
  }

  public void setSecurityLevel(String securityLevel) {
    this.securityLevel = securityLevel;
  }

  public Boolean getIsActive() {
    return isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

  public Long getGeolocationTypeId() {
    return geolocationTypeId;
  }

  public void setGeolocationTypeId(Long geolocationTypeId) {
    this.geolocationTypeId = geolocationTypeId;
  }

  public String getLocationType() {
    return locationType;
  }

  public void setLocationType(String locationType) {
    this.locationType = locationType;
  }

  public Long getParentId() {
    return parentId;
  }

  public void setParentId(Long parentId) {
    this.parentId = parentId;
  }

  public String getEnGeographicalArea() {
    return enGeographicalArea;
  }

  public void setEnGeographicalArea(String enGeographicalArea) {
    this.enGeographicalArea = enGeographicalArea;
  }

  public String getArGeographicalArea() {
    return arGeographicalArea;
  }

  public void setArGeographicalArea(String arGeographicalArea) {
    this.arGeographicalArea = arGeographicalArea;
  }

  public Long getGeographicalAreaId() {
    return geographicalAreaId;
  }

  public void setGeographicalAreaId(Long geographicalAreaId) {
    this.geographicalAreaId = geographicalAreaId;
  }
}

