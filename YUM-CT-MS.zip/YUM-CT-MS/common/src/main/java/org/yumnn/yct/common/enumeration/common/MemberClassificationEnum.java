package org.yumnn.yct.common.enumeration.common;

/**
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name MemberClassificationEnum.java
 * @create_date Oct 12, 2021
 */
public enum MemberClassificationEnum {

	BENEFICIARY, PROGRAM_ENTITY

}
