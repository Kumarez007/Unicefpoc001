package org.yumnn.yct.common.util;

import java.io.Serializable;
import java.util.Map;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public class SuccessResponse implements Serializable {


  private static final long serialVersionUID = 1L;

  private Integer status;

  private String message;

  private Map<String, Object> data;
  
  
  public SuccessResponse() {
		super();
	}

/**
   * 
   * @param status
   * @param message
   * @param data
   */
  public SuccessResponse(Integer status, String message, Map<String, Object> data) {
	super();
	this.status = status;
	this.message = message;
	this.data = data;
  }

/**
   * @return status
   */
  public Integer getStatus() {
    return status;
  }

  /**
   * @param status the status to set
   */
  public void setStatus(Integer status) {
    this.status = status;
  }

  /**
   * @return message
   */
  public String getMessage() {
    return message;
  }

  /**
   * @param message the message to set
   */
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   * @return data
   */
  public Map<String, Object> getData() {
    return data;
  }

  /**
   * @param data the data to set
   */
  public void setData(Map<String, Object> data) {
    this.data = data;
  }

  @Override
  public String toString() {
    return "SuccessResponse [status=" + status + ", message=" + message + ", data=" + data + "]";
  }
}

