/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.entity.cycle;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.cycle.CycleStyleClassEnum;

/**
 * 
 * 
 * @author Reem Issa
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name CycleByProject.java
 * @class_description
 * @create_date Jul 20, 2020
 * @last_Update Jul 20, 2020
 */
@Entity
@Table(name = "user_access.adm_cycle_by_project")

public class CycleByProject extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "id_project_fk", referencedColumnName = "ID")
	private Project project;

	@ManyToOne
	@JoinColumn(name = "id_cycle_fk", referencedColumnName = "ID")
	private Cycle cycle;

	@Column(name = "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	@Column(name = "ending_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endingDate;

	@Column(name = "has_started")
    @Enumerated(EnumType.STRING)
    private YesNoEnum hasStarted;
	
	@Column(name = "is_future")
    @Enumerated(EnumType.STRING)
    private YesNoEnum isFuture;

	/**
	 * @return the project
	 */
	public Project getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(Project project) {
		this.project = project;
	}

	/**
	 * @return the cycle
	 */
	public Cycle getCycle() {
		return cycle;
	}

	/**
	 * @param cycle the cycle to set
	 */
	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the endingDate
	 */
	public Date getEndingDate() {
		return endingDate;
	}

	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	/**
	 * @return the hasStarted
	 */
	public YesNoEnum getHasStarted() {
		return hasStarted;
	}

	/**
	 * @param hasStarted the hasStarted to set
	 */
	public void setHasStarted(YesNoEnum hasStarted) {
		this.hasStarted = hasStarted;
	}

	/**
	 * @return the isFuture
	 */
	public YesNoEnum getIsFuture() {
		return isFuture;
	}

	/**
	 * @param isFuture the isFuture to set
	 */
	public void setIsFuture(YesNoEnum isFuture) {
		this.isFuture = isFuture;
	}
}
