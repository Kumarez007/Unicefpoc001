package org.yumnn.yct.common.model;

public class BeneficeriesNomineeModel {

	String name;
	Boolean isBeneficery;
	Boolean isNominee;
	String id;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the isBeneficery
	 */
	public Boolean getIsBeneficery() {
		return isBeneficery;
	}

	/**
	 * @param isBeneficery the isBeneficery to set
	 */
	public void setIsBeneficery(Boolean isBeneficery) {
		this.isBeneficery = isBeneficery;
	}

	/**
	 * @return the isNominee
	 */
	public Boolean getIsNominee() {
		return isNominee;
	}

	/**
	 * @param isNominee the isNominee to set
	 */
	public void setIsNominee(Boolean isNominee) {
		this.isNominee = isNominee;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

}
