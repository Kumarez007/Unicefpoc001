package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.enumeration.catalog.DuplicateReasonShortNameEnum;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name NotVerifiedReason.java
 * @class_description represents a catalog table from database which contains
 *                    duplicate authorization form reason
 * @create_date Jun 22, 2017
 * @last_Update Jun 22, 2017
 */
@Entity
@Table(name = "cat_duplicate_reason")
@NamedQueries({
		@NamedQuery(name = "DuplicateReason.findAllByOrderItem", query = "SELECT r from DuplicateReason r order by r.orderItem asc") })
public class DuplicateReason extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	
	@Column(name = "redirect_url")
	private String redirectUrl;
	
	@Column(name = "duplicate_short_name")
	@Enumerated(EnumType.STRING)
	private DuplicateReasonShortNameEnum duplicateShortName;

	public DuplicateReason() {
	}

	public DuplicateReason(Long id) {
		this.id = id;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DuplicateReason other = (DuplicateReason) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return super.toString();
	}

	

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public DuplicateReasonShortNameEnum getDuplicateShortName() {
		return duplicateShortName;
	}

	public void setDuplicateShortName(DuplicateReasonShortNameEnum duplicateShortName) {
		this.duplicateShortName = duplicateShortName;
	}
}
