/*
 * Copyright 2014 Ayala Consulting Corporation.
 *
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 *
 * http://www.ayalaconsulting.us
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.enumeration.catalog;

import org.yumnn.yct.common.entity.base.Displayable;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name ActiveInactive.java
 * @class_description values for yes and no options
 * @create_date Mar 12, 2014
 * @last_Update Mar 12, 2014
 */
public enum YesNoEnum implements Displayable{
    YES("Yes", "نعم"), NO("No", "لآ");
    String value;
    String arValue;

    YesNoEnum(String yesNo) {
        this.value = yesNo;
    }

    YesNoEnum(String yesNo, String arValue) {
        this.value = yesNo;
        this.arValue = arValue;
    }

    public String getValue() {
        return value;
    }

    public String getArValue() {
        return this.arValue;
    }

  @Override
  public String getDisplayName() {
    return this.value + " - " + this.arValue;
  }

  @Override
  public Object getObject() {
    return this;
  }
}
