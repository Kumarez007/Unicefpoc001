package org.yumnn.yct.common.model.historical;

import java.util.List;

public class HistoricalBeneficiaryModelData {

    private List<HistoricalBeneficiaryModel> data;

    public List<HistoricalBeneficiaryModel> getData() {
        return data;
    }

    public void setData(List<HistoricalBeneficiaryModel> data) {
        this.data = data;
    }
}
