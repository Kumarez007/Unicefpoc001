package org.yumnn.yct.common.enumeration.payment;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name RegionEnum.java
 * @create_date Jan 27, 2022
 * @last_Update Jan 27, 2022
 */
public enum RegionEnum {

	NORTH, SOUTH

}
