package org.yumnn.yct.common.model.message;

import org.yumnn.yct.common.enumeration.messages.MessageQueueActionTypeEnum;

/**
 *
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {SMSRequestModel.java
 * @create_date May 9, 2021
 * @last_Update May 9, 2021
 */
public class EmailRequestModel extends MessageRequestModel {

	private String emailAddress;
	private String ccEmailAddress;
	private MessageQueueActionTypeEnum actionType;
	private Long messageReferenceId;
	private Long grievanceCategoryId;
	private String messageReferenceType;


	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public MessageQueueActionTypeEnum getActionType() {
		return actionType;
	}

	public void setActionType(MessageQueueActionTypeEnum actionType) {
		this.actionType = actionType;
	}

	public Long getMessageReferenceId() {
		return messageReferenceId;
	}

	public void setMessageReferenceId(Long messageReferenceId) {
		this.messageReferenceId = messageReferenceId;
	}

	public String getMessageReferenceType() {
		return messageReferenceType;
	}

	public void setMessageReferenceType(String messageReferenceType) {
		this.messageReferenceType = messageReferenceType;
	}

	/**
	 * @return the grievanceCategoryId
	 */
	public Long getGrievanceCategoryId() {
		return grievanceCategoryId;
	}

	/**
	 * @param grievanceCategoryId the grievanceCategoryId to set
	 */
	public void setGrievanceCategoryId(Long grievanceCategoryId) {
		this.grievanceCategoryId = grievanceCategoryId;
	}

	public String getCcEmailAddress() {
		return ccEmailAddress;
	}

	public void setCcEmailAddress(String ccEmailAddress) {
		this.ccEmailAddress = ccEmailAddress;
	}
	
}
