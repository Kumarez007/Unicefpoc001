
package org.yumnn.yct.common.util;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On May 03, 2021
 *
 */

import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.OkHttp3ClientHttpRequestFactory;

import okhttp3.OkHttpClient;

public abstract class SSLClientFactory {

	private static final long LOGIN_TIMEOUT_SEC = 10;
	private static HttpClientBuilder closeableClientBuilder = null;
	private static OkHttpClient.Builder okHttpClientBuilder = null;
	
	public enum HttpClientType{
		HttpClient,
		OkHttpClient
	}
	
	
	public static synchronized HttpComponentsClientHttpRequestFactory getRequestFactory() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				return true;
			}
		};

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
		        .loadTrustMaterial(null, acceptingTrustStrategy)
		        .build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		CloseableHttpClient httpClient = HttpClients.custom()
		        .setSSLSocketFactory(csf)
		        .build();

		HttpComponentsClientHttpRequestFactory requestFactory =
		        new HttpComponentsClientHttpRequestFactory();

		requestFactory.setHttpClient(httpClient);
		//requestFactory.setBufferRequestBody(false); // added by Ricky to enable streaming mode
		return requestFactory;
	}
	
	public static synchronized ClientHttpRequestFactory getClientHttpRequestFactory(HttpClientType httpClientType) throws KeyManagementException, NoSuchAlgorithmException {
		ClientHttpRequestFactory requestFactory = null;
		
		SSLContext sslContext = SSLClientFactory.getFactorySimple();

		if(null == sslContext) {
			return requestFactory;
		}
		
		switch (httpClientType) {
		case HttpClient:
			closeableClientBuilder = HttpClientBuilder.create();
			closeableClientBuilder.setSSLContext(sslContext);
			closeableClientBuilder.setSSLHostnameVerifier(getHostNameVerifier());
			requestFactory = new HttpComponentsClientHttpRequestFactory(closeableClientBuilder.build());
			break;
			
		case OkHttpClient:
			okHttpClientBuilder = new OkHttpClient().newBuilder().readTimeout(LOGIN_TIMEOUT_SEC, TimeUnit.SECONDS);
			okHttpClientBuilder.socketFactory(sslContext.getSocketFactory());
			okHttpClientBuilder.hostnameVerifier(getHostNameVerifier());
			requestFactory = new OkHttp3ClientHttpRequestFactory(okHttpClientBuilder.build());
			break;	

		default:
			break;
		}
		return requestFactory;
		
	}
	
	
	
	private static HostnameVerifier getHostNameVerifier() {
		HostnameVerifier hostnameVerifier = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		return hostnameVerifier;
	}

	
	private static SSLContext getFactorySimple() throws NoSuchAlgorithmException, KeyManagementException {
		
		TrustManager[] trustAllCerts = new TrustManager[]{
                new X509ExtendedTrustManager() {

					public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
							throws CertificateException {
						
					}

					public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
							throws CertificateException {
						
					}

					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					@Override
					public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1, Socket arg2)
							throws CertificateException {
						
					}

					@Override
					public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1,
							SSLEngine arg2) throws CertificateException {
						
					}

					@Override
					public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1, Socket arg2)
							throws CertificateException {
						
					}

					@Override
					public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1,
							SSLEngine arg2) throws CertificateException {
						
					}
                }
            };
		
		SSLContext context = SSLContext.getInstance("SSL");
		context.init(null, trustAllCerts, new java.security.SecureRandom());
		return context;
	}

	@SuppressWarnings("unused")
	private static SSLContext getSSlContext() throws KeyManagementException {
		final TrustManager[] trustAllCerts = new TrustManager[] {getTrustManager()};
		
		SSLContext sslContext = null;
		
		try {
			sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new SecureRandom());
		}catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static X509TrustManager getTrustManager() {
		final X509TrustManager trustManager = new X509TrustManager() {
			
			public X509Certificate[] getAcceptedIssuers() {
				X509Certificate[] cArr = new X509Certificate[0];
				return cArr;
			}
			
			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				
			}
			
			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				
			}
		};
		return trustManager;
	}
	
	
	
}
