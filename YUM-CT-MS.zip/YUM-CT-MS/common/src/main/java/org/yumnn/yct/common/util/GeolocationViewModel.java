package org.yumnn.yct.common.util;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name GeolocationViewModel.java
 * @create_date Nov 5, 2021
 * @last_Update Nov 5, 2021
 */
public class GeolocationViewModel {

	private Long id;

	private Long parentId;

	private String arName;

	private String enName;

	private String parentArName;

	private String parentEnName;

	private String shortName;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the parentId
	 */
	public Long getParentId() {
		return parentId;
	}

	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the arName
	 */
	public String getArName() {
		return arName;
	}

	/**
	 * @param arName the arName to set
	 */
	public void setArName(String arName) {
		this.arName = arName;
	}

	/**
	 * @return the enName
	 */
	public String getEnName() {
		return enName;
	}

	/**
	 * @param enName the enName to set
	 */
	public void setEnName(String enName) {
		this.enName = enName;
	}

	/**
	 * @return the shortName
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * @param shortName the shortName to set
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	/**
	 * @return the parentArName
	 */
	public String getParentArName() {
		return parentArName;
	}

	/**
	 * @param parentArName the parentArName to set
	 */
	public void setParentArName(String parentArName) {
		this.parentArName = parentArName;
	}

	/**
	 * @return the parentEnName
	 */
	public String getParentEnName() {
		return parentEnName;
	}

	/**
	 * @param parentEnName the parentEnName to set
	 */
	public void setParentEnName(String parentEnName) {
		this.parentEnName = parentEnName;
	}

}
