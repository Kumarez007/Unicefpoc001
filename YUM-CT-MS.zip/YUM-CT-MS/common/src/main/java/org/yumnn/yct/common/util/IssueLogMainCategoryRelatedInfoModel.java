package org.yumnn.yct.common.util;

import java.util.List;

/**
 * 
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name IssueLogMainCategoryRelatedInfoModel.java
 * @create_date Nov 5, 2021
 * @last_Update Nov 5, 2021
 */
public class IssueLogMainCategoryRelatedInfoModel {

	private Long mainCategoryId;

	private String mainCategoryDescriptionAr;
	private String mainCategoryDescriptionEn;

	private List<IsueFromFieldModel> isueFromFieldModelList;

	/**
	 * @return the mainCategoryId
	 */
	public Long getMainCategoryId() {
		return mainCategoryId;
	}

	/**
	 * @param mainCategoryId the mainCategoryId to set
	 */
	public void setMainCategoryId(Long mainCategoryId) {
		this.mainCategoryId = mainCategoryId;
	}

	/**
	 * @return the mainCategoryDescriptionAr
	 */
	public String getMainCategoryDescriptionAr() {
		return mainCategoryDescriptionAr;
	}

	/**
	 * @param mainCategoryDescriptionAr the mainCategoryDescriptionAr to set
	 */
	public void setMainCategoryDescriptionAr(String mainCategoryDescriptionAr) {
		this.mainCategoryDescriptionAr = mainCategoryDescriptionAr;
	}

	/**
	 * @return the mainCategoryDescriptionEn
	 */
	public String getMainCategoryDescriptionEn() {
		return mainCategoryDescriptionEn;
	}

	/**
	 * @param mainCategoryDescriptionEn the mainCategoryDescriptionEn to set
	 */
	public void setMainCategoryDescriptionEn(String mainCategoryDescriptionEn) {
		this.mainCategoryDescriptionEn = mainCategoryDescriptionEn;
	}

	/**
	 * @return the isueFromFieldModelList
	 */
	public List<IsueFromFieldModel> getIsueFromFieldModelList() {
		return isueFromFieldModelList;
	}

	/**
	 * @param isueFromFieldModelList the isueFromFieldModelList to set
	 */
	public void setIsueFromFieldModelList(List<IsueFromFieldModel> isueFromFieldModelList) {
		this.isueFromFieldModelList = isueFromFieldModelList;
	}

}
