package org.yumnn.yct.common.entity.payment;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;

/**
 * @author Ricky.Tiwari
 *
 * @CreatedAt Sep 30, 2021 8:24:44 PM
 */

@Entity
@Table(name = "payment.gen_record_to_download")
public class PaymentRecordDownload extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "record_json")
	private String recordJson;
	
	@Column(name = "record_type")
	private String recordType;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "creation_date", nullable = true)
	private Date creationDate;

	public String getRecordJson() {
		return recordJson;
	}

	public void setRecordJson(String recordJson) {
		this.recordJson = recordJson;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
