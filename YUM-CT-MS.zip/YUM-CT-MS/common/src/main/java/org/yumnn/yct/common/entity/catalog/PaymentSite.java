package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.cycle.CycleByProject;
import org.yumnn.yct.common.enumeration.catalog.AppliedCycleForPaymentSiteEnum;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.payment.RegionEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSiteTypeEnum;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentSitesConnectionTypeEnum;
import org.yumnn.yct.common.enumeration.paymentSites.UploadedPaymentSiteStatusEnum;

@Entity
@Table(name = "payment.cat_payment_site")
public class PaymentSite extends CatalogParentEntity implements Serializable, Catalog {

    private static final long serialVersionUID = 1L;

    @Column(name = "is_active")
    @Enumerated(EnumType.STRING)
    protected YesNoEnum isActive;


    @Column(name = "applied_cycle")
    @Enumerated(EnumType.STRING)
    private AppliedCycleForPaymentSiteEnum appliedCycleForPaymentSiteEnum;

    @Column(name = "connection_type")
    @Enumerated(EnumType.STRING)
    private PaymentSitesConnectionTypeEnum connectionType;

    @Column(name = "expected_no_of_beneficiaries")
    private Integer expectedNoOfBeneficiaries;

    @Column(name = "payment_agent_name")
    private String paymentAgentName;

    @Column(name = "payment_site_address")
    private String paymentSiteAddress;

    @Column(name = "fixed_site_type")
    private String fixedSiteType;

    @Column(name = "number_of_working_days")
    private Integer numberOfWorkingDays;

    @Column(name = "number_of_daily_paid")
    private Integer numberOfDailyPayments;

    @Column(name = "gps_longitude")
    private Double gpsLongitude;

    @Column(name = "gps_latitude")
    private Double gpsLatitude;

    @Column(name = "payment_site_type")
    @Enumerated(EnumType.STRING)
    private PaymentSiteTypeEnum paymentSiteType;

    @ManyToOne
    @JoinColumn(name = "id_agency_fk", referencedColumnName = "ID")
    private Agency paymentAgency;
    
    @ManyToOne
	@JoinColumn(name = "id_cycle_by_project_fk" , referencedColumnName = "ID")
	private CycleByProject cycleByProject;

    @Column(name = "staffing_males_cashiers")
    private Integer staffingMalesCashiers;

    @Column(name = "staffing_females_cashiers")
    private Integer staffingFemalesCashiers;

    @Column(name = "number_of_male_screening_officers")
    private Integer staffingMalesScreening;

    @Column(name = "number_of_female_screening_officers")
    private Integer staffingFemalesScreening;

    @Column(name = "uploaded_payment_site_status")
    @Enumerated(EnumType.STRING)
    protected UploadedPaymentSiteStatusEnum uploadedPaymentSiteStatus;

    @OneToMany(mappedBy = "paymentSite")
    private List<PaymentSiteStatus> paymentSiteStatus;

	
	@Column( name = "payment_site_region")
	@Enumerated(EnumType.STRING)
	private RegionEnum paymentSiteRegion;

   

    /**
     * @return the paymentAgency
     */
    public Agency getPaymentAgency() {
        return paymentAgency;
    }

    /**
     * @param paymentAgency the paymentAgency to set
     */
    public void setPaymentAgency(Agency paymentAgency) {
        this.paymentAgency = paymentAgency;
    }

    /**
     * @return the gpsLongitude
     */
    public Double getGpsLongitude() {
        return gpsLongitude;
    }

    /**
     * @param gpsLongitude the gpsLongitude to set
     */
    public void setGpsLongitude(Double gpsLongitude) {
        this.gpsLongitude = gpsLongitude;
    }

    /**
     * @return the gpsLatitude
     */
    public Double getGpsLatitude() {
        return gpsLatitude;
    }

    /**
     * @param gpsLatitude the gpsLatitude to set
     */
    public void setGpsLatitude(Double gpsLatitude) {
        this.gpsLatitude = gpsLatitude;
    }

    /**
     * @return the connectionType
     */
    public PaymentSitesConnectionTypeEnum getConnectionType() {
        return connectionType;
    }

    /**
     * @param connectionType the connectionType to set
     */
    public void setConnectionType(PaymentSitesConnectionTypeEnum connectionType) {
        this.connectionType = connectionType;
    }

    /**
     * @return the expectedNoOfBeneficiaries
     */
    public Integer getExpectedNoOfBeneficiaries() {
        return expectedNoOfBeneficiaries;
    }

    /**
     * @param expectedNoOfBeneficiaries the expectedNoOfBeneficiaries to set
     */
    public void setExpectedNoOfBeneficiaries(Integer expectedNoOfBeneficiaries) {
        this.expectedNoOfBeneficiaries = expectedNoOfBeneficiaries;
    }

    /**
     * @return the paymentAgentName
     */
    public String getPaymentAgentName() {
        return paymentAgentName;
    }

    /**
     * @param paymentAgentName the paymentAgentName to set
     */
    public void setPaymentAgentName(String paymentAgentName) {
        this.paymentAgentName = paymentAgentName;
    }

    /**
     * @return the paymentSiteAddress
     */
    public String getPaymentSiteAddress() {
        return paymentSiteAddress;
    }

    /**
     * @param paymentSiteAddress the paymentSiteAddress to set
     */
    public void setPaymentSiteAddress(String paymentSiteAddress) {
        this.paymentSiteAddress = paymentSiteAddress;
    }

    /**
     * @return the fixedSiteType
     */
    public String getFixedSiteType() {
        return fixedSiteType;
    }

    /**
     * @param fixedSiteType the fixedSiteType to set
     */
    public void setFixedSiteType(String fixedSiteType) {
        this.fixedSiteType = fixedSiteType;
    }

    /**
     * @return the numberOfWorkingDays
     */
    public Integer getNumberOfWorkingDays() {
        return numberOfWorkingDays;
    }

    /**
     * @param numberOfWorkingDays the numberOfWorkingDays to set
     */
    public void setNumberOfWorkingDays(Integer numberOfWorkingDays) {
        this.numberOfWorkingDays = numberOfWorkingDays;
    }

    /**
     * @return the numberOfDailyPayments
     */
    public Integer getNumberOfDailyPayments() {
        return numberOfDailyPayments;
    }

    /**
     * @param numberOfDailyPayments the numberOfDailyPayments to set
     */
    public void setNumberOfDailyPayments(Integer numberOfDailyPayments) {
        this.numberOfDailyPayments = numberOfDailyPayments;
    }

    /**
     * @return the appliedCycleForPaymentSiteEnum
     */
    public AppliedCycleForPaymentSiteEnum getAppliedCycleForPaymentSiteEnum() {
        return appliedCycleForPaymentSiteEnum;
    }

    /**
     * @param appliedCycleForPaymentSiteEnum the appliedCycleForPaymentSiteEnum to set
     */
    public void setAppliedCycleForPaymentSiteEnum(AppliedCycleForPaymentSiteEnum appliedCycleForPaymentSiteEnum) {
        this.appliedCycleForPaymentSiteEnum = appliedCycleForPaymentSiteEnum;
    }

    @Override
    public String getDisplayName() {
        return name;
    }

    public PaymentSite() {
        super();
    }

    public PaymentSite(Long id) {
        this.id = id;
    }

    @Override
    public Object getObject() {
        return this;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PaymentSite other = (PaymentSite) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    public YesNoEnum getIsActive() {
        return isActive;
    }

    public void setIsActive(YesNoEnum isActive) {
        this.isActive = isActive;
    }
    /**
     * @return the staffingMalesCashiers
     */
    public Integer getStaffingMalesCashiers() {
        return staffingMalesCashiers;
    }

    /**
     * @param staffingMalesCashiers the staffingMalesCashiers to set
     */
    public void setStaffingMalesCashiers(Integer staffingMalesCashiers) {
        this.staffingMalesCashiers = staffingMalesCashiers;
    }

    /**
     * @return the staffingFemalesCashiers
     */
    public Integer getStaffingFemalesCashiers() {
        return staffingFemalesCashiers;
    }

    /**
     * @param staffingFemalesCashiers the staffingFemalesCashiers to set
     */
    public void setStaffingFemalesCashiers(Integer staffingFemalesCashiers) {
        this.staffingFemalesCashiers = staffingFemalesCashiers;
    }

    /**
     * @return the staffingMalesScreening
     */
    public Integer getStaffingMalesScreening() {
        return staffingMalesScreening;
    }

    /**
     * @param staffingMalesScreening the staffingMalesScreening to set
     */
    public void setStaffingMalesScreening(Integer staffingMalesScreening) {
        this.staffingMalesScreening = staffingMalesScreening;
    }

    /**
     * @return the staffingFemalesScreening
     */
    public Integer getStaffingFemalesScreening() {
        return staffingFemalesScreening;
    }

    /**
     * @param staffingFemalesScreening the staffingFemalesScreening to set
     */
    public void setStaffingFemalesScreening(Integer staffingFemalesScreening) {
        this.staffingFemalesScreening = staffingFemalesScreening;
    }

    /**
     * @return the uploadedPaymentSiteStatus
     */
    public UploadedPaymentSiteStatusEnum getUploadedPaymentSiteStatus() {
        return uploadedPaymentSiteStatus;
    }

    /**
     * @param uploadedPaymentSiteStatus the uploadedPaymentSiteStatus to set
     */
    public void setUploadedPaymentSiteStatus(UploadedPaymentSiteStatusEnum uploadedPaymentSiteStatus) {
        this.uploadedPaymentSiteStatus = uploadedPaymentSiteStatus;
    }

    /**
     * @return the paymentSiteStatus
     */
    public List<PaymentSiteStatus> getPaymentSiteStatus() {
        return paymentSiteStatus;
    }

    /**
     * @param paymentSiteStatus the paymentSiteStatus to set
     */
    public void setPaymentSiteStatus(List<PaymentSiteStatus> paymentSiteStatus) {
        this.paymentSiteStatus = paymentSiteStatus;
    }

	/**
	 * @return the paymentSiteType
	 */
	public PaymentSiteTypeEnum getPaymentSiteType() {
		return paymentSiteType;
	}

	/**
	 * @param paymentSiteType the paymentSiteType to set
	 */
	public void setPaymentSiteType(PaymentSiteTypeEnum paymentSiteType) {
		this.paymentSiteType = paymentSiteType;
	}

	/**
	 * @return the cycleByProject
	 */
	public CycleByProject getCycleByProject() {
		return cycleByProject;
	}

	/**
	 * @param cycleByProject the cycleByProject to set
	 */
	public void setCycleByProject(CycleByProject cycleByProject) {
		this.cycleByProject = cycleByProject;
	}

	/**
	 * @return the paymentSiteRegion
	 */
	public RegionEnum getPaymentSiteRegion() {
		return paymentSiteRegion;
	}

	/**
	 * @param paymentSiteRegion the paymentSiteRegion to set
	 */
	public void setPaymentSiteRegion(RegionEnum paymentSiteRegion) {
		this.paymentSiteRegion = paymentSiteRegion;
	}
}
