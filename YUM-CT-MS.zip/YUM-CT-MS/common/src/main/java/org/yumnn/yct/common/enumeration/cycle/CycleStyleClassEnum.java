package org.yumnn.yct.common.enumeration.cycle;

import java.util.ArrayList;
import java.util.List;


/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name CycleStyleClassEnum.java
 * @class_description style class for cycles
 * @create_date Jun 29, 2017
 * @last_Update Jun 29, 2017
 */
public enum CycleStyleClassEnum {

	DEFAULT_STYLE_CLASS("cycle_default_style_class"),
	CURRENT_STYLE_CLASS("cycle_default_style_class"),
	RED("cycle_red_style_class"),
	BLUE("cycle_blue_style_class"),
	DARK_BLUE("cycle_dark_blue_style_class"),
	YELLOW("cycle_yellow_style_class"),
	ORANGE("cycle_orange_style_class"),
	BURGUNDY("cycle_burgundy_style_class"),
	GREEN("cycle_green_style_class"),
	DARK_GREEN("cycle_dark_green_style_class"),
	PURPLE("cycle_purple_style_class"),
	WARM_GREY("cycle_warm_grey_style_class"),
	COOL_GREY("cycle_cool_grey_style_class"),
	BLACK("cycle_black_style_class"),
	DARK_RED("cycle_red_style_class");

	private String styleClassValue;

	private CycleStyleClassEnum(String styleClassValue) {
		this.styleClassValue = styleClassValue;
	}

	public String getStyleClassValue() {
		return styleClassValue;
	}
	
	public static List<CycleStyleClassEnum> getStyleClass(){
		List<CycleStyleClassEnum> list = new ArrayList<>();
		list.add(DEFAULT_STYLE_CLASS);
		list.add(RED);
		list.add(BLUE);
		list.add(DARK_BLUE);
		list.add(YELLOW);
		list.add(ORANGE);
		list.add(BURGUNDY);
		list.add(GREEN);
		list.add(DARK_GREEN);
		list.add(PURPLE);
		list.add(WARM_GREY);
		list.add(COOL_GREY);
		list.add(BLACK);

		return list;
	}

}
