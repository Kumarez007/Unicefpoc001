package org.yumnn.yct.common.entity.base;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */
public interface Displayable {

	@JsonIgnore
	String getDisplayName();

	@JsonIgnore
	Object getObject();
}
