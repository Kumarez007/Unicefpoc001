package org.yumnn.yct.common.enumeration.uploadInfo;

import org.yumnn.yct.common.entity.base.Displayable;

/**
 * 
 * @author Christian Alvarez
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name MinimalServerTypeEnum.java
 * @class_description
 * @create_date Feb 26, 2018
 * @last_Update Feb 26, 2018
 */
public enum MinimalServerTypeEnum implements Displayable {

	OUTREACH("Outreach", "متنقل"), FIXED("Fixed", "ثابت");

	String value;
	String arValue;

	MinimalServerTypeEnum(String yesNo, String arValue) {
		this.value = yesNo;
		this.arValue = arValue;
	}

	public String getValue() {
		return value;
	}

	public String getArValue() {
		return this.value + " - " + this.arValue;
	}

	@Override
	public String getDisplayName() {
		return this.getArValue();
	}

	@Override
	public Object getObject() {
		return this;
	}

}
