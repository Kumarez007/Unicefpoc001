package org.yumnn.yct.common.entity.history;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.beneficiary.CurrentForm;
import org.yumnn.yct.common.entity.beneficiary.HouseholdMember;
import org.yumnn.yct.common.entity.catalog.Agency;
import org.yumnn.yct.common.entity.catalog.Booklet;
import org.yumnn.yct.common.entity.catalog.PaymentSite;
import org.yumnn.yct.common.entity.cycle.Cycle;
import org.yumnn.yct.common.entity.programPeriod.ProgramPeriod;
import org.yumnn.yct.common.enumeration.paymentSites.PaymentStatusEnum;
import org.yumnn.yct.common.model.historical.HistoricalPaymentInformationModel;
import org.yumnn.yct.common.util.Utilities;

@Entity
@Table(name= "payment.hst_payment_information")
@NamedQueries({
	@NamedQuery(name = "HistoricalPaymentInformation.getByBenefeciaryForm",
			query = "SELECT h from HistoricalPaymentInformation h WHERE  h.currentForm = :currentForm order by h.cycle.id  desc"),
	@NamedQuery(name = "HistoricalPaymentInformation.getByFormAndCycle",
	query = "SELECT h from HistoricalPaymentInformation h WHERE h.currentForm = :currentForm and h.cycle= :cycle")})
public class HistoricalPaymentInformation extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name= "id_cur_form_fk", referencedColumnName= "ID")
	private CurrentForm currentForm;
	
	@ManyToOne
	@JoinColumn(name= "id_cycle_fk", referencedColumnName= "ID")
	private Cycle cycle;
	
	@ManyToOne
	@JoinColumn(name= "id_assigned_agency_fk", referencedColumnName= "ID")
	private Agency assignedPaymentAgency;
	
	
	@ManyToOne
	@JoinColumn(name= "id_paid_agency_fk", referencedColumnName= "ID")
	private Agency paidPaymentAgency;
	
	@ManyToOne
	@JoinColumn(name= "id_paid_program_period_fk", referencedColumnName= "ID")
	private ProgramPeriod correctProgramPeriod;
	
	@ManyToOne
	@JoinColumn(name= "id_payment_site_fk", referencedColumnName= "ID")
	private PaymentSite paymentSite;
	
	@Column(name= "calculated_amount")
	private Double calculatedAmount;

	@Column(name= "collected_amount")
	private Double collectedAmount;
	
	@Column(name= "payment_status")
	@Enumerated(EnumType.STRING)
	private PaymentStatusEnum paymentStatus;
	
	@Column(name= "arrears_amount")
	private Double arrearsAmount;
	 
	@Column(name= "reimbursement")
	private Double reimburesment;
	
	@Column(name= "amount_to_deduct")
	private Double amountToDeduct;
	
	@Column(name= "payment_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date paymentDate;

	@Column(name= "sent_amount")
	private Double sentAmount;
	
	@ManyToOne
	@JoinColumn(name = "id_household_member_fk", referencedColumnName = "ID")
	private HouseholdMember currentHouseholdMember;	

	@Column(name = "payment_modality")
	private String paymentModality;
	
	@Column(name = "paid_region")
	private String paidRegion;

	@Column(name = "rep_payment_site_district_code")
	private String repPaymentSiteDistrictCode;

	@Column(name = "rep_payment_site_code")
	private String repPaymentSiteCode;

	@Column(name = "rep_payment_site_name")
	private String repPaymentSiteName;

	@Column(name = "payment_order")
	private String paymentOrder;

	@Column(name = "cashier_name")
	private String cashierName;

	@Column(name = "collected_amount_usd")
	private Double collectedAmountUsd;
	
	@Column(name = "bank_remmitance_no")
	private String bankRemmitanceNo;

	@ManyToOne
	@JoinColumn(name= "id_booklet_fk", referencedColumnName= "ID")
	private Booklet booklet;

	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}

	public Cycle getCycle() {
		return cycle;
	}

	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	public Agency getAssignedPaymentAgency() {
		return assignedPaymentAgency;
	}

	public void setAssignedPaymentAgency(Agency assignedPaymentAgency) {
		this.assignedPaymentAgency = assignedPaymentAgency;
	}

	public Agency getPaidPaymentAgency() {
		return paidPaymentAgency;
	}

	public void setPaidPaymentAgency(Agency paidPaymentAgency) {
		this.paidPaymentAgency = paidPaymentAgency;
	}

	public ProgramPeriod getProgramPeriod() {
		return correctProgramPeriod;
	}

	public void setProgramPeriod(ProgramPeriod correctProgramPeriod) {
		this.correctProgramPeriod = correctProgramPeriod;
	}

	public Double getCalculatedAmount() {
		return calculatedAmount;
	}

	public void setCalculatedAmount(Double calculatedAmount) {
		this.calculatedAmount = calculatedAmount;
	}

	public Double getCollectedAmount() {
		return collectedAmount;
	}

	public void setCollectedAmount(Double collectedAmount) {
		this.collectedAmount = collectedAmount;
	}

	public PaymentStatusEnum getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(PaymentStatusEnum paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Double getArrearsAmount() {
		if(Utilities.isNULL(arrearsAmount))
			return 0.0;
		return arrearsAmount;
	}

	public void setArrearsAmount(Double arrearsAmount) {
		this.arrearsAmount = arrearsAmount;
	}

	public Double getReimburesment() {
		return reimburesment;
	}

	public void setReimburesment(Double reimburesment) {
		this.reimburesment = reimburesment;
	}

	public Double getAmountToDeduct() {
		return amountToDeduct;
	}

	public void setAmountToDeduct(Double amountToDeduct) {
		this.amountToDeduct = amountToDeduct;
	}

	public PaymentSite getPaymentSite() {
		return paymentSite;
	}

	public void setPaymentSite(PaymentSite paymentSite) {
		this.paymentSite = paymentSite;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public ProgramPeriod getCorrectProgramPeriod() {
		return correctProgramPeriod;
	}

	public void setCorrectProgramPeriod(ProgramPeriod correctProgramPeriod) {
		this.correctProgramPeriod = correctProgramPeriod;
	}

	public Double getSentAmount() {
		if(Utilities.isNULL(sentAmount))
			return 0.0;
		return sentAmount;
	}

	public void setSentAmount(Double sentAmount) {
		this.sentAmount = sentAmount;
	}

	public HouseholdMember getCurrentHouseholdMember() {
		return currentHouseholdMember;
	}

	public void setHouseholdMember(HouseholdMember currentHouseholdMember) {
		this.currentHouseholdMember = currentHouseholdMember;
	}

	public String getPaymentModality() {
		return paymentModality;
	}

	public void setPaymentModality(String paymentModality) {
		this.paymentModality = paymentModality;
	}

	public String getPaidRegion() {
		return paidRegion;
	}

	public void setPaidRegion(String paidRegion) {
		this.paidRegion = paidRegion;
	}

	public String getRepPaymentSiteDistrictCode() {
		return repPaymentSiteDistrictCode;
	}

	public void setRepPaymentSiteDistrictCode(String repPaymentSiteDistrictCode) {
		this.repPaymentSiteDistrictCode = repPaymentSiteDistrictCode;
	}

	public String getRepPaymentSiteCode() {
		return repPaymentSiteCode;
	}

	public void setRepPaymentSiteCode(String repPaymentSiteCode) {
		this.repPaymentSiteCode = repPaymentSiteCode;
	}

	public String getRepPaymentSiteName() {
		return repPaymentSiteName;
	}

	public void setRepPaymentSiteName(String repPaymentSiteName) {
		this.repPaymentSiteName = repPaymentSiteName;
	}

	public String getPaymentOrder() {
		return paymentOrder;
	}

	public void setPaymentOrder(String paymentOrder) {
		this.paymentOrder = paymentOrder;
	}

	public String getCashierName() {
		return cashierName;
	}

	public void setCashierName(String cashierName) {
		this.cashierName = cashierName;
	}

	public Double getCollectedAmountUsd() {
		return collectedAmountUsd;
	}

	public void setCollectedAmountUsd(Double collectedAmountUsd) {
		this.collectedAmountUsd = collectedAmountUsd;
	}

	public Booklet getBooklet() {
		return booklet;
	}

	public void setBooklet(Booklet booklet) {
		this.booklet = booklet;
	}
	
	public String getBankRemmitanceNo() {
		return bankRemmitanceNo;
	}

	public void setBankRemmitanceNo(String bankRemmitanceNo) {
		this.bankRemmitanceNo = bankRemmitanceNo;
	}

	public HistoricalPaymentInformationModel getHistoricalPaymentInformationModel() {
		HistoricalPaymentInformationModel model = new HistoricalPaymentInformationModel();
		model.setAmountToDeduct(amountToDeduct);
		model.setArrearsAmount(arrearsAmount);
		model.setAssignedPaymentAgencyId(Utilities.isNULL(assignedPaymentAgency) ? null : assignedPaymentAgency.getId());
		model.setCalculatedAmount(calculatedAmount);
		model.setCollectedAmount(collectedAmount);
		model.setCorrectProgramPeriodId(Utilities.isNULL(correctProgramPeriod) ? null : correctProgramPeriod.getId());
		model.setCurrentFormId(currentForm.getId());
		model.setCurrentHouseholdMemberId(Utilities.isNULL(currentHouseholdMember) ? null : currentHouseholdMember.getId());
		model.setCycleId(Utilities.isNULL(cycle) ? null : cycle.getId());
		model.setId(id);
		model.setPaidPaymentAgencyId(Utilities.isNULL(paidPaymentAgency) ? null : paidPaymentAgency.getId());
		model.setPaymentDate(paymentDate);
		model.setPaymentSiteId(Utilities.isNULL(paymentSite) ? null : paymentSite.getId());
		model.setPaymentStatus(paymentStatus);
		model.setReimburesment(reimburesment);
		model.setSentAmount(sentAmount);
		model.setBankRemmitanceNo(bankRemmitanceNo);
		return model;
	}

}
