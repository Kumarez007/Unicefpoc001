/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.enumeration.paymentSites;

/**
 * @author Reem Issa
 * @department PMU.
 * @owner UNICEF.
 * @class_name PaymentSiteStatusEnum.java
 * @class_description
 * @create_date Feb 26, 2019
 * @last_Update Feb 26, 2019
 */
public enum PaymentSiteStatusEnum  {

	APPROVED("Approved", "موافق "), DECLINE("Declined", "مرفوض"), PENDING("Pending", "قيد الانتظار"),
	APPROVAL_RECOMMENDED("Approval Recommended", "موصى بالموافقة"), DECLINE_RECOMMENDED("Decline Recommended","موصى بالرفض"),
	
	ENDORSE_APPROVAL("Recommendation Endorsed" , "إقرار بالموافقة") , ENDORSE_DECLINE("Recommendation Declined" , "إقرار بالرفض");
	
	String value;
	String arValue;

	PaymentSiteStatusEnum(String yesNo) {
		this.value = yesNo;
	}

	PaymentSiteStatusEnum(String yesNo, String arValue) {
		this.value = yesNo;
		this.arValue = arValue;
	}

	public String getArValue() {
		return this.arValue;
	}

	public String getValue() {
		return value;
	}

}
