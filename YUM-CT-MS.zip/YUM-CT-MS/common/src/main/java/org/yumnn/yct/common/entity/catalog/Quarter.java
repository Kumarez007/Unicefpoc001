package org.yumnn.yct.common.entity.catalog;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.administration.User;
import org.yumnn.yct.common.entity.base.CatalogParentEntity;
import org.yumnn.yct.common.enumeration.catalog.YesNoEnum;
import org.yumnn.yct.common.enumeration.cycle.CycleStyleClassEnum;
import org.yumnn.yct.common.model.QuarterModel;

@Entity
@Table(name = "user_access.cat_quarter")
@NamedQueries({
	@NamedQuery(name = "Quarter.findAllByOrderItem", query = "SELECT r from Quarter r order by r.orderItem asc"),
	@NamedQuery(name = "Quarter.retrieveByShortName", query = "SELECT r from Quarter r where r.shortName = :shortName")

})
public class Quarter extends CatalogParentEntity implements Serializable, Catalog {

	private static final long serialVersionUID = 1L;

	@Column(name = "is_active")
	@Enumerated(EnumType.STRING)
	private YesNoEnum isActive;


	/**
	 * @return the isActive
	 */
	public YesNoEnum getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(YesNoEnum isActive) {
		this.isActive = isActive;
	}

	@Override
	public String getDisplayName() {
		return name;
	}

	@Override
	public Object getObject() {
		return this;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Quarter other = (Quarter) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public QuarterModel getModel() {
		QuarterModel quarterModel = new QuarterModel();
		quarterModel.setId(id);
		quarterModel.setArabicName(getArabicName());
		quarterModel.setEnglishName(getEnglishName());
		quarterModel.setShortName(getShortName());
		return quarterModel;
	}
}
