package org.yumnn.yct.common.enumeration.administration;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name UserCategoryTypeEnum.java
 * @class_description defines all the possible type to be assigned to the User
 * @create_date Jul 12, 2017
 * @last_Update Jul 12, 2017
 */
public enum UserCategoryTypeEnum {

	PAYMENT_AGENCY("Payment Agency"), PAYMENT_SITE("Payment Site");

	private String value;

	UserCategoryTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static List<UserCategoryTypeEnum> getAllItems() {
		List<UserCategoryTypeEnum> list = new ArrayList<>();
		list.add(PAYMENT_AGENCY);
		list.add(PAYMENT_SITE);
		return list;

	}

}
