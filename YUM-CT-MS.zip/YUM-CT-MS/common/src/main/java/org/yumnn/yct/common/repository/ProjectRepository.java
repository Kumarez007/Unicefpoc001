package org.yumnn.yct.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.yumnn.yct.common.entity.project.Project;
import org.yumnn.yct.common.enumeration.project.ProjectNameEnum;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Sachin.Salunkhe
 *
 * @Created On Apr 15, 2021
 *
 */
@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
	Project findByShortName(ProjectNameEnum shortName);
	
}
