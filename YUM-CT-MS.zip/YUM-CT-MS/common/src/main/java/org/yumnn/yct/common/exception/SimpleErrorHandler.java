/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.yumnn.yct.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * @author Oswaldo Tutillo
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name SimpleErrorHandler.java
 * @class_description this class is used for report errors in xml's files 
 * @create_date Jul 4, 2014
 * @last_Update Jul 4, 2014
 */
public class SimpleErrorHandler implements ErrorHandler {
	public static Logger LOG = LoggerFactory.getLogger(SimpleErrorHandler.class);

	@Override
	public void error(SAXParseException e) throws SAXException {
		LOG.error("****SAXParseException ERROR OCCURRED :"+e.getMessage());
	}

	@Override
	public void fatalError(SAXParseException e) throws SAXException {
		LOG.error("****SAXParseException FATAL ERROR OCCURRED :"+e.getMessage());
	}

	@Override
	public void warning(SAXParseException e) throws SAXException {
		LOG.error("****SAXParseException WARNING OCCURRED :"+e.getMessage());
	}
}
