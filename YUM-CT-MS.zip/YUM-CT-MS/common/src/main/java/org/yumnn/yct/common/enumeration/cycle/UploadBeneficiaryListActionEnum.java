package org.yumnn.yct.common.enumeration.cycle;

public enum UploadBeneficiaryListActionEnum {


	NEW("Upload New Beneficiary list", "تحميل قائمة مستفيدين جدد"), UPDATE("Update Beneficiary List","تعديل معلومات المستفيدين"),
	UPDATE_AMOUNT("Update Amounts","تعديل المبلغ للمستفيدين"), UPDATE_AMOUNT_QUARTER("Update Amounts","تعديل المبلغ للمستفيدين"), 
	START_PAYMENT_CYCLE("Start payment cycle","بدء دورة الصرف"), MIGRATE_DATA("Migrate Data","ترحيل البيانات");
	

	private String englishName;
	private String arabicName;

	UploadBeneficiaryListActionEnum(String englishName, String arabicName) {
		this.englishName = englishName;
		this.arabicName = arabicName;
	}

	/**
	 * @return the englishName
	 */
	public String getEnglishName() {
		return englishName;
	}

	/**
	 * @param englishName the englishName to set
	 */
	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	/**
	 * @return the arabicName
	 */
	public String getArabicName() {
		return arabicName;
	}

	/**
	 * @param arabicName the arabicName to set
	 */
	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}
}
