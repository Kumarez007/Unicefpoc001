package org.yumnn.yct.common.entity.uploadInfo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.enumeration.quartz.UploadedRecordTypeEnum;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name {RecordToDownload.java
 * @create_date May 26, 2021
 * @last_Update May 26, 2021
 */
@Entity
@Table(name = "payment.gen_record_to_download")
public class RecordToDownload  extends BaseEntity {


	@Column(name = "record_json")
	private String recordJson;

	@Column(name = "record_type")
	@Enumerated(EnumType.STRING)
	private UploadedRecordTypeEnum uploadedRecordType;

	@Column(name = "creation_date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date creationDate;

	/**
	 * @return the recordJson
	 */
	public String getRecordJson() {
		return recordJson;
	}

	/**
	 * @param recordJson the recordJson to set
	 */
	public void setRecordJson(String recordJson) {
		this.recordJson = recordJson;
	}

	/**
	 * @return the uploadedRecordType
	 */
	public UploadedRecordTypeEnum getUploadedRecordType() {
		return uploadedRecordType;
	}

	/**
	 * @param uploadedRecordType the uploadedRecordType to set
	 */
	public void setUploadedRecordType(UploadedRecordTypeEnum uploadedRecordType) {
		this.uploadedRecordType = uploadedRecordType;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
}
