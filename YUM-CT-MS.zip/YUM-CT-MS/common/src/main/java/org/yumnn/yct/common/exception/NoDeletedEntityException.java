/*
 * Copyright 2014 Ayala Consulting Corporation.
 * 
 * Licensed under the Ayala Consulting License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * http://www.ayalaconsulting.us
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.exception;

/**
 * @author Jorge Villafuerte
 * @department IT Department - Ecuador
 * @owner Ayala Consulting Corporation.
 * @class_name NoDeletedEntityException.java
 * @class_description this exception handles troubles in the delete process
 * @create_date Oct 14, 2016
 * @last_Update Oct 14, 2016
 */
public class NoDeletedEntityException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoDeletedEntityException() {
		super();
	}

	public NoDeletedEntityException(String message, Throwable cause) {
		super(message, cause);

	}

	public NoDeletedEntityException(String message) {
		super(message);
	}

	public NoDeletedEntityException(Throwable cause) {
		super(cause);
	}

}
