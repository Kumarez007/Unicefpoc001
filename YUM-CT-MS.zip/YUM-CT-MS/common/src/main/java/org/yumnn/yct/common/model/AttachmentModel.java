package org.yumnn.yct.common.model;

public class AttachmentModel {

	private String id;
	private String fileMimeType;
	private String file;
	private String fileSize;
	private String sourceType;
	private String referenceId;
	private String referenceType;
	private String attachmentName;
	private String attachmentExtension;
	private String isActive;
	private String createdBy;
	private String createdDate;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFileMimeType() {
		return fileMimeType;
	}

	public void setFileMimeType(String fileMimeType) {
		this.fileMimeType = fileMimeType;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentExtension() {
		return attachmentExtension;
	}

	public void setAttachmentExtension(String attachmentExtension) {
		this.attachmentExtension = attachmentExtension;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "AttachmentModel [id=" + id + ", fileMimeType=" + fileMimeType + ", file=" + file + ", fileSize="
				+ fileSize + ", sourceType=" + sourceType + ", referenceId=" + referenceId + ", referenceType="
				+ referenceType + ", attachmentName=" + attachmentName + ", attachmentExtension=" + attachmentExtension
				+ ", isActive=" + isActive + ", createdBy=" + createdBy + ", createdDate=" + createdDate + "]";
	} 
	
}
