package org.yumnn.yct.common.entity.beneficiary;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.yumnn.yct.common.entity.base.BaseEntity;
import org.yumnn.yct.common.entity.catalog.Flag;
import org.yumnn.yct.common.entity.cycle.Cycle;

/**
 * 
 * @author Alaa Darwish
 * @department PMU - ICT
 * @owner UNICEF
 * @class_name CurrentFormFlag.java
 * @class_description represents the table of beneficiary's flags
 * @create_date May 08, 2019
 * @last_Update May 08, 2019
 */

@Entity
@Table(name = "cur_form_flag")
@NamedQueries({
	@NamedQuery(
			name = "CurrentFormFlag.findByCurrentInfoForm",
			query = "SELECT f FROM CurrentFormFlag f WHERE f.currentForm = :currentForm order By f.cycle.id desc, f.flag.orderItem"),
	@NamedQuery(
			name = "CurrentFormFlag.getMainFlagByCurrentFormAndCycle",
			query = "SELECT f FROM CurrentFormFlag f WHERE f.currentForm = :currentForm and f.cycle = :cycle order by f.flag.orderItem"),
	@NamedQuery(
			name = "CurrentFormFlag.retrieveByActiveCycleAndFlagShortName",
			query = "SELECT f FROM CurrentFormFlag f WHERE f.currentForm = :currentForm and f.cycle = :cycle and f.flag.shortName = :flagShortName")})
public class CurrentFormFlag extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name = "id_cur_form_fk", referencedColumnName="ID")
	private CurrentForm currentForm;	

	@ManyToOne
	@JoinColumn(name = "id_cycle_fk", referencedColumnName="ID")
	private Cycle cycle;
	
	@ManyToOne
	@JoinColumn(name = "id_flag_fk", referencedColumnName="ID")
	private Flag flag;	
	
	@Column(name= "creation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;

	public CurrentForm getCurrentForm() {
		return currentForm;
	}

	public void setCurrentForm(CurrentForm currentForm) {
		this.currentForm = currentForm;
	}

	public Cycle getCycle() {
		return cycle;
	}

	public void setCycle(Cycle cycle) {
		this.cycle = cycle;
	}

	public Flag getFlag() {
		return flag;
	}

	public void setFlag(Flag flag) {
		this.flag = flag;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}	
	

}