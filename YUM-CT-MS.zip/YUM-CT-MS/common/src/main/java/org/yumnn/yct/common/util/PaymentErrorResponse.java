package org.yumnn.yct.common.util;

import java.io.Serializable;

/**
 * 
 * @author Reem Issa
 * @department MIS - PMU
 * @owner UNICEF.
 * @class_name PaymentErrorResponse.java
 * @create_date Aug 24, 2021
 * @last_Update Aug 24, 2021
 */
public class PaymentErrorResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String status;

	private Integer errorCode;

	private String messageDetails;

	public PaymentErrorResponse() {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(String messageDetails) {
		this.messageDetails = messageDetails;
	}
}
