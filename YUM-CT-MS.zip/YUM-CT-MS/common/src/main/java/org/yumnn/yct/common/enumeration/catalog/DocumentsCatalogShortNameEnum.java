/*
 * Copyright 2018 UNICEF PMU.
 * 
 * Licensed under the UNICEF PMU License, Version 1.0 (the "License"); you
 * may not use this file except in compliance with the License. You may buy a
 * copy of the License at
 * 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.yumnn.yct.common.enumeration.catalog;


public enum DocumentsCatalogShortNameEnum {
	passbook,
	national_id,
	electoral_id,
	passport,
	family_card,
	old_national_id,
	birth_certificate,
	student_seat_number_card,
	marriage_contract,
	disabled_care_rehabilitation_fund_id,
	letter_with_photo,
	letter_without_photo,
	cvi_form,
	death_document;
}
