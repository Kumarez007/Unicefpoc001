package org.yumnn.yct.commonswagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

@Configuration
public class CommonSwaggerConfig {

	@Bean
	public OpenAPI customOpenAPI() {
		return new OpenAPI().components(new Components()).info(new Info().title("Unicef YCT Ecosystem Project")
				.description("Unicef YCT Ecosystem Project API")
				.license(new License().name("Apache-2.0").url("http://www.apache.org/licenses/LICENSE-2.0.html"))
				.termsOfService("").version("1.0.0").contact(
						new Contact().email("https://www.linkedin.com/company/unicef/").url("https://www.unicef.org")));
	}

}
