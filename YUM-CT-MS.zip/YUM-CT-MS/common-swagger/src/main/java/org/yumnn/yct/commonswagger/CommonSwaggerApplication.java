package org.yumnn.yct.commonswagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Profile;

/**
 * Project Name: YUM-CT-MS
 *
 * @author Ricky.Tiwari
 *
 * @Created On Apr 12, 2021
 *
 */

@SpringBootApplication
@Profile("swagger")
public class CommonSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonSwaggerApplication.class, args);
	}

}
